V13：使用A/B/C/D有标签场景建立公共泄漏模型，预测无标签G
======================================================================

一、核心逻辑
----------------------------------------------------------------------
训练阶段只使用A/B/C/D：

  1. 每个样本已经由v9完成“中心点 - 周围环境背景”；
  2. 每个有标签场景内部比较 TRUE 和 FALSE；
  3. 只保留多个训练场景共同支持的泄漏属性；
  4. 用留一场景验证：BCD测A、ACD测B、ABD测C、ABC测D；
  5. 用真正的OOF分数校准概率和TRUE/FALSE/SUSPECT阈值；
  6. 使用全部A/B/C/D冻结最终模型。

预测G时：

  1. 只读取G的v9残差NPZ；
  2. G不参与特征筛选、模型训练和阈值选择；
  3. G的label列会被完全忽略，即使以前临时填了TRUE/FALSE也不使用；
  4. 输出每个文件的 TRUE_LEAK / FALSE_LEAK / SUSPECT 和概率。

二、文件要求
----------------------------------------------------------------------
程序包中必须保留：

  v13_shared_leak_train_predict.py
  v12_shared_leak_component_discovery.py

A/B/C/D/G各自的v9结果目录至少包含：

  v9_all_features.csv
  residual_npz\*.npz
  v9_run_config.json（训练场景建议存在）

G运行v9时，DATASETS中的label可以写成空字符串：

  "label": ""

v9本身允许空label。即便G已有临时标签，v13预测也会忽略。

三、安装依赖
----------------------------------------------------------------------
在PowerShell中进入程序目录：

  pip install -r .\requirements_v13.txt

四、先运行自检
----------------------------------------------------------------------
  python .\v13_shared_leak_train_predict.py --self-test

最后应出现：

  V13自检通过

五、训练A/B/C/D模型
----------------------------------------------------------------------
先检查 v13_train_config.json 中A/B/C/D路径。

运行：

  python .\v13_shared_leak_train_predict.py train --config .\v13_train_config.json

或者双击：

  run_v13_train.bat

最重要的训练输出：

  leak_v13_ABCD_model_results\
    v13_frozen_ABCD_shared_leak_model.npz   冻结模型
    v13_loso_oof_scores.csv                 每个场景被完全留出时的结果
    v13_loso_calibrated_scene_summary.csv   A/B/C/D留一场景指标
    v13_model_dimensions.csv                最终使用的公共属性
    v13_shared_positive_leak_spectrum.csv   公共TRUE增强频谱
    v13_train_report.txt                    训练报告

先查看 v13_loso_calibrated_scene_summary.csv。
如果某个训练场景的留出AUC接近0.5，说明该场景与其他场景规律不一致，
不建议直接预测G，应先排查该场景。

六、预测无标签G
----------------------------------------------------------------------
训练成功后，检查 v13_predict_G_config.json：

  model_file  指向冻结ABCD模型
  v9_dir      指向G的v9结果目录
  output_dir  G预测结果目录

运行：

  python .\v13_shared_leak_train_predict.py predict --config .\v13_predict_G_config.json

或者双击：

  run_v13_predict_G.bat

主要输出：

  factory_G_v13_predictions\
    v13_unlabeled_predictions.csv
    v13_unlabeled_prediction_summary.csv
    v13_prediction_failures.csv
    v13_unlabeled_prediction_report.txt

七、如何看G结果
----------------------------------------------------------------------
v13_unlabeled_predictions.csv 重点字段：

  probability_TRUE
      ABCD冻结模型认为是真泄漏的概率分数。

  prediction
      probability >= 0.65  -> TRUE_LEAK
      probability <= 0.35  -> FALSE_LEAK
      中间                 -> SUSPECT

  score_spectral_raw / score_temporal_raw / score_spatial_raw
      频谱、时间、空间三个分项证据。

  quality_warning
      非空表示该文件部分属性超出ABCD训练范围，需谨慎。

  needs_review
      1表示SUSPECT或存在质量警告，应优先复核。

  input_label_ignored
      仅展示v9 CSV原来写了什么，程序没有使用它。

八、结果限制
----------------------------------------------------------------------
G没有真实标签，因此程序不会、也不能输出：

  准确率、AUC、TP、TN、FP、FN。

TRUE_LEAK表示：

  该文件含有与A/B/C/D跨场景公共泄漏残差相符的属性。

它仍需要人工检查、肥皂水、气体传感器或其他独立手段确认，尤其是：

  SUSPECT；
  quality_warning非空；
  probability接近0.5；
  新型机械干扰可能未被A/B/C/D覆盖。
