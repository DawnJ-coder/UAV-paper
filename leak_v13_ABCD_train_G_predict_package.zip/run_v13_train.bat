@echo off
cd /d "%~dp0"
python v13_shared_leak_train_predict.py train --config v13_train_config.json
pause
