@echo off
cd /d "%~dp0"
python v13_shared_leak_train_predict.py predict --config v13_predict_G_config.json
pause
