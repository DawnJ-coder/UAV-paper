AB + 实验室真实泄漏：多尺度粗频带共性分析
================================================

这个版本不再用细频点作为最终结果。
最终共同频带必须同时得到：
1. 场景A中 TRUE > FALSE；
2. 场景B中 TRUE > FALSE；
3. 实验室真实泄漏稳定支持；
4. 5 kHz和10 kHz两个尺度同时支持。

一、准备数据
------------
场景A和B都必须已经运行v9，并包含：

v9结果目录
├─ v9_all_features.csv
└─ residual_npz
   └─ *.npz

v9_all_features.csv中必须同时包含TRUE_LEAK和FALSE_LEAK。
A、B应使用相同的v9方法，例如全部使用median。

实验室数据可以是一个WAV、多个WAV，或包含WAV的目录。

二、修改配置
------------
打开 AB_lab_multiscale_config.json，只需要重点修改：

scene_A.v9_dir
scene_B.v9_dir
lab_wav_paths
output_dir

Windows路径必须写成双反斜杠，例如：
C:\\Users\\jiangxinru6\\Desktop\\wurenji\\factory_A_v9_results

三、安装依赖
------------
python -m pip install -r requirements_AB_lab_multiscale.txt

四、先自检
----------
python AB_lab_commonality_multiscale.py --self-test

或双击：
run_AB_lab_multiscale_self_test.bat

五、正式运行
------------
python AB_lab_commonality_multiscale.py --config AB_lab_multiscale_config.json

或双击：
run_AB_lab_multiscale.bat

六、结果只看三个文件
--------------------
1. 00_结果先看这里.txt
   直接给出总体结果、两个共性分数、共同频带，以及A/B中TRUE高于FALSE的AUC。

2. multiscale_common_frequency_bands.csv
   最终共同频带。这里的频带必须同时得到5 kHz和10 kHz支持，不再保留很窄的偶然重合频带。

3. sample_TRUE_FALSE_separation_summary.csv
   检查A和B中TRUE是否确实比FALSE更符合最终共同特征。
   重点看 metric=final_common_evidence_score 的 AUC_TRUE_higher：
   - 越接近1越好；
   - 接近0.5说明TRUE和FALSE差不多；
   - 小于0.5说明方向相反。

七、其他主要文件
----------------
coarse_band_commonality_5kHz.csv
coarse_band_commonality_10kHz.csv
    分别显示A、B、实验室在每个粗频带上的支持情况。

coarse_scale_metrics.csv
    5 kHz和10 kHz尺度下的A/B共性与AB/实验室共性。

factory_sample_multiscale_similarity.csv
    每个A/B样本与AB、实验室和最终共同指纹的相似度。

scalar_feature_commonality.csv
    频谱中心、带宽、熵、平坦度和时间属性的共性。

AB_lab_multiscale_common_fingerprint.npz
    最终多尺度共同指纹，供后续程序读取。

八、结果含义
------------
“较强”：粗频带共性、实验室一致性、A/B中的TRUE-FALSE方向都较好。
“中等”：存在共同频带，但仍有场景差异或样本分离不足。
“较弱”：目前不能确认稳定泄漏共性，不应直接拿共同频带训练后续模型。

本程序不恢复可播放的纯泄漏WAV，也不训练分类器。
