@echo off
chcp 65001 >nul
cd /d "%~dp0"
python AB_lab_commonality_multiscale.py --config AB_lab_multiscale_config.json
pause
