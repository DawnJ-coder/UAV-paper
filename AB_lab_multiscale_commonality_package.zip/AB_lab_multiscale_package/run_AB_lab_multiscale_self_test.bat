@echo off
chcp 65001 >nul
cd /d "%~dp0"
python AB_lab_commonality_multiscale.py --self-test
pause
