# -*- coding: utf-8 -*-
"""
空间局部超额分离 + 八方向测试特征提取 v3.3-2point
=============================================

本版明确拆成两条互不混淆的分支。

A. WAV分离分支
--------------
保留v3.1.2的相反方向空间背景预测、局部超额、外环/方向不确定度、
实验室NMF辅助门控与WAV重建。该分支仍可使用lab_gate_floor。

B. T/F候选真实性判定分支
-------------------------
1. 只由中心点投影实验室泄漏字典，生成统一泄漏时频权重 M(f,t)。
2. 中心与全部128个周围点共用同一个M。
3. 不做相反方向平均，保留8方向完整径向曲线。
4. 计算：worst_direction_margin_db、center_rank_fraction、
   radial_decay_direction_fraction、max_radial_rebound_db。
5. 所有工厂T/F样本均只作为测试集，不训练任何监督分类器。
6. 不从工厂数据学习阈值或综合分数；标签只用于事后测试评价。
7. 实验室相似度仅保留为诊断列，不参与四个核心空间特征。
8. 每个工况只实际处理00_00和00_01；其他center_id不读取、不计算。

正式运行：
    python spatial_directional_test_only_v3_3_two_points.py --config spatial_directional_test_only_config_v3_3_two_points.json

自检：
    python spatial_directional_test_only_v3_3.py --self-test

依赖：
    pip install numpy pandas scipy matplotlib scikit-learn
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import re
import sys
import tempfile
import traceback
import unicodedata
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import ndimage, signal
from scipy.io import wavfile
from scipy.spatial.distance import jensenshannon
from sklearn.decomposition import NMF
from sklearn.metrics import roc_auc_score

EPS = 1.0e-20
DB_PER_NATURAL_LOG = 10.0 / math.log(10.0)

DIRECTIONS = [
    "up", "down", "left", "right",
    "up_left", "down_left", "up_right", "down_right",
]
DIRECTION_ANGLES = {
    "up": np.pi / 2,
    "down": -np.pi / 2,
    "left": np.pi,
    "right": 0.0,
    "up_left": 3 * np.pi / 4,
    "down_left": -3 * np.pi / 4,
    "up_right": np.pi / 4,
    "down_right": -np.pi / 4,
}
OPPOSITE_AXES: Dict[str, Tuple[str, str]] = {
    "vertical": ("up", "down"),
    "horizontal": ("left", "right"),
    "diag_up_left": ("up_left", "down_right"),
    "diag_up_right": ("up_right", "down_left"),
}
DIRECTION_RE = "|".join(re.escape(x) for x in sorted(DIRECTIONS, key=len, reverse=True))
CENTER_RE = re.compile(r"(?P<center>\d+(?:_\d+)?)_beamform_result\.wav$", re.I)
OFFSET_RE = re.compile(
    rf"(?P<center>\d+(?:_\d+)?)d(?P<distance>\d+)_(?P<direction>{DIRECTION_RE})(?P<suffix>.*?)\.wav$",
    re.I,
)


@dataclass
class AlgorithmConfig:
    # 主分析频段
    freq_low_hz: float = 50_000.0
    freq_high_hz: float = 70_000.0
    expected_sample_rate_hz: int = 192_000

    # 每个 center_id 对应的时段
    time_slice_seconds: float = 1.0
    segment_mode: str = "indexed"  # indexed / first / auto
    strict_time_slice: bool = True

    # 仅处理指定中心编号。v3.3-2point默认只计算00_00和00_01；
    # 其他中心编号只在扫描清单中记录，不读取WAV、不做STFT、不计算特征。
    selected_center_ids: List[str] = field(default_factory=lambda: ["00_00", "00_01"])

    # STFT
    nperseg: int = 4096
    hop_length: int = 2048
    nfft: int = 4096
    minimum_frequency_bins: int = 50

    # 消声室泄漏参考
    leak_components: int = 8

    # 消声室数据划分方式：
    # cross_group：指定孔径组完整训练，另一孔径组完整独立验证
    # within_group_holdout：每个孔径组内部按lab_train_fraction划分
    lab_split_mode: str = "cross_group"
    lab_train_groups: List[str] = field(default_factory=lambda: ["0.5mm"])
    lab_validation_groups: List[str] = field(default_factory=lambda: ["0.1mm"])
    lab_train_fraction: float = 0.70
    random_state: int = 42
    max_lab_seconds_per_file: float = 30.0
    max_lab_training_frames: int = 20_000
    nmf_max_iter: int = 350
    lab_projection_iterations: int = 180
    lab_projection_l1_ratio: float = 0.002

    # 相反方向空间预测
    spatial_min_distance_cm: float = 5.0
    spatial_max_distance_cm: float = 80.0
    min_neighbors: int = 64
    min_complete_opposite_pairs: int = 20
    min_complete_axes: int = 3

    # “中心比两侧高多少”才形成空间证据
    pair_support_threshold_db: float = 1.0
    excess_base_threshold_db: float = 1.0
    uncertainty_threshold_weight: float = 0.35
    excess_db_softness: float = 1.0

    # 多方向支持软门控
    pair_support_midpoint: float = 0.55
    axis_support_midpoint: float = 0.50
    support_softness: float = 0.12

    # 背景预测离散度门控
    prediction_uncertainty_ref_db: float = 4.0
    prediction_confidence_floor: float = 0.35

    # 消声室只做辅助门控，不允许它凭空制造泄漏
    lab_frame_cosine_midpoint: float = 0.76
    lab_frame_cosine_softness: float = 0.06
    lab_gate_floor: float = 0.35
    lab_gate_exponent: float = 0.35

    # 时频掩膜平滑
    mask_frequency_median_bins: int = 3
    mask_temporal_median_frames: int = 3

    # 仅用于输出“证据强/弱”的初始规则，不是最终分类阈值
    evidence_score_threshold: float = 0.22
    evidence_axis_support_threshold: float = 0.50
    # 兼容旧配置；v3.3测试特征不使用实验室相似度阈值
    evidence_lab_similarity_threshold: float = 0.70

    # 幅值检查
    amplitude_peak_fullscale_threshold: float = 0.985
    amplitude_uniform_peak_cv_threshold: float = 0.015
    amplitude_uniform_rms_cv_threshold: float = 0.020

    # 输出
    save_plots: bool = True
    save_npz: bool = True
    save_wavs: bool = True
    plot_limit: int = 100


@dataclass
class FactoryDataset:
    name: str
    center_root_dir: str
    offset_root_dirs: List[str]
    time_folders: List[str]
    default_label: str
    label_by_folder: Dict[str, str]


@dataclass
class RunConfig:
    lab_groups: Dict[str, List[str]]
    factory_datasets: List[FactoryDataset]
    output_dir: str
    pairing_remove_tokens: List[str]
    algorithm: AlgorithmConfig


@dataclass
class WavSlice:
    path: Path
    fs: int
    x: np.ndarray
    original_dtype: str
    duration_seconds: float
    segment_start_seconds: float
    segment_end_seconds: float
    peak: float
    rms: float
    clipping_fraction: float


@dataclass
class SpatialFile:
    center_id: str
    distance_cm: int
    direction: str
    path: Path
    x_cm: float
    y_cm: float


# -----------------------------------------------------------------------------
# 配置与文件工具
# -----------------------------------------------------------------------------

def dataclass_from_dict(cls: Any, values: Optional[Mapping[str, Any]]) -> Any:
    raw = dict(values or {})
    allowed = {f.name for f in fields(cls)}
    return cls(**{k: v for k, v in raw.items() if k in allowed})


def load_config(path: Path) -> RunConfig:
    with path.open("r", encoding="utf-8-sig") as f:
        raw = json.load(f)
    algo = dataclass_from_dict(AlgorithmConfig, raw.get("algorithm"))
    datasets: List[FactoryDataset] = []
    for item in raw.get("factory_datasets", []):
        datasets.append(
            FactoryDataset(
                name=str(item["name"]),
                center_root_dir=str(item["center_root_dir"]),
                offset_root_dirs=[str(x) for x in item.get("offset_root_dirs", [])],
                time_folders=[str(x) for x in item.get("time_folders", [])],
                default_label=str(item.get("default_label", "UNLABELED")),
                label_by_folder={str(k): str(v) for k, v in item.get("label_by_folder", {}).items()},
            )
        )
    lab_groups: Dict[str, List[str]] = {}
    for key, value in raw.get("lab_groups", {}).items():
        lab_groups[str(key)] = [str(value)] if isinstance(value, str) else [str(v) for v in value]
    cfg = RunConfig(
        lab_groups=lab_groups,
        factory_datasets=datasets,
        output_dir=str(raw.get("output_dir", "spatial_local_excess_v3_1_results")),
        pairing_remove_tokens=[str(x) for x in raw.get("pairing_remove_tokens", ["_null", "null"])],
        algorithm=algo,
    )
    validate_config(cfg)
    return cfg


def validate_config(cfg: RunConfig) -> None:
    a = cfg.algorithm
    if "0.1mm" not in cfg.lab_groups or "0.5mm" not in cfg.lab_groups:
        raise ValueError("lab_groups 必须包含 0.1mm 和 0.5mm")
    if not cfg.factory_datasets:
        raise ValueError("factory_datasets 不能为空")
    if a.freq_low_hz < 0 or a.freq_high_hz <= a.freq_low_hz:
        raise ValueError("主频段设置错误")
    if a.nperseg < 256 or a.hop_length < 1 or a.nfft < a.nperseg:
        raise ValueError("STFT参数错误")
    if a.segment_mode not in {"indexed", "first", "auto"}:
        raise ValueError("segment_mode只能是 indexed / first / auto")
    normalized_selected_ids = [str(x).strip() for x in a.selected_center_ids if str(x).strip()]
    if not normalized_selected_ids:
        raise ValueError("selected_center_ids不能为空；v3.3-2point应至少包含00_00和00_01")
    if len(set(normalized_selected_ids)) != len(normalized_selected_ids):
        raise ValueError("selected_center_ids中存在重复编号")
    a.selected_center_ids = normalized_selected_ids
    if a.lab_split_mode not in {"cross_group", "within_group_holdout"}:
        raise ValueError("lab_split_mode只能是 cross_group / within_group_holdout")
    if a.lab_split_mode == "within_group_holdout":
        if not 0.0 < a.lab_train_fraction < 1.0:
            raise ValueError("lab_train_fraction必须位于(0,1)")
    else:
        if not a.lab_train_groups or not a.lab_validation_groups:
            raise ValueError("cross_group模式下训练组和验证组都不能为空")
        overlap = set(a.lab_train_groups) & set(a.lab_validation_groups)
        if overlap:
            raise ValueError(f"消声室训练组和验证组不能重叠: {sorted(overlap)}")
        missing = [g for g in list(a.lab_train_groups) + list(a.lab_validation_groups) if g not in cfg.lab_groups]
        if missing:
            raise ValueError(f"配置中缺少消声室组: {missing}")
    if a.spatial_max_distance_cm < a.spatial_min_distance_cm:
        raise ValueError("空间距离范围错误")
    if a.min_complete_axes < 1 or a.min_complete_axes > len(OPPOSITE_AXES):
        raise ValueError("min_complete_axes范围错误")
    if not 0.0 <= a.lab_gate_floor <= 1.0:
        raise ValueError("lab_gate_floor必须位于[0,1]")


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_json(path: Path, obj: Any) -> None:
    ensure_dir(path.parent)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]], columns: Optional[Sequence[str]] = None) -> None:
    ensure_dir(path.parent)
    if columns is None:
        keys: List[str] = []
        seen = set()
        for row in rows:
            for key in row.keys():
                if key not in seen:
                    keys.append(key)
                    seen.add(key)
        columns = keys
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(columns))
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in columns})


def discover_wavs(paths: Sequence[str]) -> List[Path]:
    """递归发现WAV，兼容 .wav/.WAV/混合大小写。

    不再依赖 rglob("*.wav") 的文件系统大小写行为。
    """
    found: Dict[str, Path] = {}
    for raw in paths:
        raw = str(raw).strip().strip('\"').strip("'")
        if not raw:
            continue
        p = Path(raw).expanduser()
        if p.is_file() and p.suffix.lower() == ".wav":
            resolved = p.resolve()
            found[str(resolved).casefold()] = resolved
        elif p.is_dir():
            for candidate in p.rglob("*"):
                if candidate.is_file() and candidate.suffix.lower() == ".wav":
                    resolved = candidate.resolve()
                    found[str(resolved).casefold()] = resolved
    return sorted(found.values(), key=lambda x: str(x).casefold())


def lab_path_diagnostics(group: str, paths: Sequence[str]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for raw in paths:
        cleaned = str(raw).strip().strip('\"').strip("'")
        p = Path(cleaned).expanduser()
        discovered = discover_wavs([cleaned]) if cleaned else []
        rows.append({
            "group": group,
            "configured_path": cleaned,
            "exists": p.exists() if cleaned else False,
            "is_file": p.is_file() if cleaned else False,
            "is_dir": p.is_dir() if cleaned else False,
            "discovered_wav_count": len(discovered),
            "example_wav": str(discovered[0]) if discovered else "",
        })
    return rows


def list_wavs(folder: Path) -> List[Path]:
    """只读取当前目录中的 WAV，兼容扩展名大小写。"""
    if not folder.is_dir():
        return []
    return sorted(
        [p for p in folder.iterdir() if p.is_file() and p.suffix.lower() == ".wav"],
        key=lambda x: x.name.casefold(),
    )


def normalize_relative_folder(value: str) -> str:
    """把配置中的相对目录统一成正斜杠形式，保留中文。"""
    text = str(value or "").strip().replace("\\", "/")
    parts = [part for part in text.split("/") if part not in {"", "."}]
    if any(part == ".." for part in parts):
        raise ValueError(f"time_folder 不允许包含上级目录 '..': {value}")
    return "/".join(parts)


def relative_folder_path(root: Path, relative_folder: str) -> Path:
    relative = normalize_relative_folder(relative_folder)
    if not relative:
        return root
    return root.joinpath(*relative.split("/"))


def directory_has_center_wav(folder: Path) -> bool:
    return any(CENTER_RE.search(path.name) for path in list_wavs(folder))


def directory_has_offset_wav(folder: Path) -> bool:
    return any(OFFSET_RE.search(path.name) for path in list_wavs(folder))


def discover_center_condition_folders(root: Path) -> List[str]:
    """递归查找真正包含中心波束 WAV 的目录，并返回相对路径。

    例如：
        快插/100kPa_3770sccm_2m
        螺纹/200kPa_6450sccm_2m
        0.2mm_100kPa_690sccm_2.0m

    这样不会把“快插、螺纹”等一级类型目录当成最终工况目录，也不会漏掉第二层或更深层工况。
    """
    root = root.expanduser()
    if not root.is_dir():
        return []
    found: set[str] = set()
    for wav_path in root.rglob("*"):
        if not wav_path.is_file() or wav_path.suffix.lower() != ".wav":
            continue
        if not CENTER_RE.search(wav_path.name):
            continue
        relative_parent = wav_path.parent.relative_to(root)
        relative_text = "" if str(relative_parent) == "." else relative_parent.as_posix()
        found.add(normalize_relative_folder(relative_text))
    return sorted(found, key=lambda value: (value.count("/"), value.casefold()))


def resolve_time_dir(root: Path, time_folder: str, *, expect: str = "any") -> Path:
    """按相对路径解析工况目录；必要时做唯一目录名回退。

    expect 可取 center / offset / any。回退只在候选唯一时启用，避免不同泄漏类型下同名工况串目录。
    """
    root = root.expanduser()
    relative = normalize_relative_folder(time_folder)
    exact = relative_folder_path(root, relative)

    def valid(folder: Path) -> bool:
        if not folder.is_dir():
            return False
        if expect == "center":
            return directory_has_center_wav(folder)
        if expect == "offset":
            return directory_has_offset_wav(folder)
        return bool(list_wavs(folder))

    if valid(exact):
        return exact
    if exact.is_dir() and expect == "any":
        return exact
    if not root.is_dir() or not relative:
        return exact

    # 仅按完整相对路径末级目录名回退；若存在多个同名目录则拒绝猜测。
    leaf = relative.split("/")[-1].casefold()
    candidates: List[Path] = []
    for candidate in root.rglob("*"):
        if candidate.is_dir() and candidate.name.casefold() == leaf and valid(candidate):
            candidates.append(candidate)
    if len(candidates) == 1:
        return candidates[0]
    return exact


def available_time_folders(dataset: FactoryDataset) -> List[str]:
    if dataset.time_folders:
        return [normalize_relative_folder(value) for value in dataset.time_folders]
    return discover_center_condition_folders(Path(dataset.center_root_dir))


def build_center_index(folder: Path) -> Dict[str, List[Path]]:
    out: Dict[str, List[Path]] = {}
    for path in list_wavs(folder):
        match = CENTER_RE.search(path.name)
        if match:
            out.setdefault(match.group("center"), []).append(path)
    for key in out:
        out[key] = sorted(out[key], key=lambda p: p.name.lower())
    return out


def build_offset_index(
    folders: Sequence[Path],
    allowed_center_ids: Optional[Sequence[str]] = None,
) -> Dict[Tuple[str, int, str], List[Path]]:
    """建立周围点文件索引；若给出allowed_center_ids，只索引这些中心对应的周围点。"""
    out: Dict[Tuple[str, int, str], List[Path]] = {}
    allowed = set(str(x) for x in allowed_center_ids) if allowed_center_ids is not None else None
    for folder in folders:
        for path in list_wavs(folder):
            match = OFFSET_RE.search(path.name)
            if not match:
                continue
            center_id = match.group("center")
            if allowed is not None and center_id not in allowed:
                continue
            key = (center_id, int(match.group("distance")), match.group("direction").lower())
            out.setdefault(key, []).append(path)
    for key in out:
        out[key] = sorted(set(out[key]), key=lambda p: str(p).lower())
    return out


def center_sort_key(center_id: str) -> Tuple[int, ...]:
    try:
        return tuple(int(x) for x in center_id.split("_"))
    except Exception:
        return (10**9,)


def sample_label(dataset: FactoryDataset, folder: str) -> str:
    normalized = normalize_relative_folder(folder)
    mapping = {
        normalize_relative_folder(key): value
        for key, value in dataset.label_by_folder.items()
    }
    value = mapping.get(normalized, mapping.get(normalized.split("/")[-1], dataset.default_label))
    return str(value).upper().strip() or "UNLABELED"


def safe_slug(text: str) -> str:
    """生成 Windows 可用且保留中文的单级目录名。"""
    value = unicodedata.normalize("NFKC", str(text or "")).strip()
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", value)
    value = re.sub(r"\s+", "_", value)
    value = re.sub(r"_+", "_", value).strip(" ._")
    if not value:
        value = "sample"
    reserved = {
        "CON", "PRN", "AUX", "NUL",
        *(f"COM{i}" for i in range(1, 10)),
        *(f"LPT{i}" for i in range(1, 10)),
    }
    if value.upper() in reserved:
        value = f"_{value}"
    return value[:180].rstrip(" .") or "sample"


def safe_relative_parts(relative_folder: str) -> List[str]:
    relative = normalize_relative_folder(relative_folder)
    if not relative:
        return ["root"]
    return [safe_slug(part) for part in relative.split("/")]


def infer_leak_type_and_condition(time_folder: str) -> Tuple[str, str]:
    """从相对目录中提取泄漏类型，兼容嵌套目录和扁平目录。

    嵌套示例：快插/100kPa_3770sccm_2m -> 快插
    扁平示例：螺纹_200kPa_6450sccm_2m -> 螺纹
    扁平示例：0.2mm_100kPa_690sccm_2.0m -> 0.2mm
    """
    relative = normalize_relative_folder(time_folder)
    parts = relative.split("/") if relative else ["root"]
    condition_name = parts[-1]
    if len(parts) >= 2:
        return parts[0], condition_name

    flat = condition_name
    pressure_match = re.search(r"(?i)(?<![A-Za-z0-9.])\d+(?:\.\d+)?\s*kpa", flat)
    if pressure_match:
        prefix = flat[:pressure_match.start()].strip(" _-.—")
        if prefix:
            return prefix, condition_name
    first_token = re.split(r"[_\s-]+", flat, maxsplit=1)[0].strip()
    return (first_token or "未识别类型"), condition_name


def canonical_condition(text: str, remove_tokens: Sequence[str]) -> str:
    value = normalize_relative_folder(str(text)).strip().casefold()
    for token in remove_tokens:
        if token:
            value = value.replace(str(token).casefold(), "")
    value = re.sub(r"[\/\s\-_]+", "_", value).strip("_")
    return value


# -----------------------------------------------------------------------------
# WAV/STFT与基础数学
# -----------------------------------------------------------------------------

def segment_bounds(center_id: str, wav_duration: float, cfg: AlgorithmConfig) -> Tuple[float, float, str]:
    duration = float(cfg.time_slice_seconds)
    if cfg.segment_mode == "first":
        return 0.0, duration, "first"
    parts = center_id.split("_")
    if not parts[-1].isdigit():
        if cfg.segment_mode == "auto":
            return 0.0, duration, "auto_first"
        raise ValueError(f"center_id={center_id}无法解析秒编号")
    index = int(parts[-1])
    indexed_start = index * duration
    indexed_end = indexed_start + duration
    if cfg.segment_mode == "indexed":
        return indexed_start, indexed_end, "indexed"
    if wav_duration + 1e-9 >= indexed_end:
        return indexed_start, indexed_end, "auto_indexed"
    return 0.0, duration, "auto_first"


def pcm_to_float(raw: np.ndarray) -> Tuple[np.ndarray, str, float]:
    dtype_name = str(raw.dtype)
    if np.issubdtype(raw.dtype, np.integer):
        info = np.iinfo(raw.dtype)
        full_scale = float(max(abs(info.min), abs(info.max)))
        return raw.astype(np.float64) / max(full_scale, 1.0), dtype_name, 1.0
    if np.issubdtype(raw.dtype, np.floating):
        return raw.astype(np.float64), dtype_name, 1.0
    raise TypeError(f"不支持的WAV类型: {raw.dtype}")


def read_wav_slice(path: Path, center_id: str, cfg: AlgorithmConfig) -> WavSlice:
    fs, raw = wavfile.read(str(path))
    if raw.ndim > 1:
        raw = np.mean(raw.astype(np.float64), axis=1)
    total_duration = len(raw) / float(fs)
    start_s, end_s, _ = segment_bounds(center_id, total_duration, cfg)
    start = int(round(start_s * fs))
    end = int(round(end_s * fs))
    if start >= len(raw):
        raise ValueError(f"目标片段起点超出WAV: {path.name}")
    if end > len(raw):
        if cfg.strict_time_slice:
            raise ValueError(f"目标片段不完整: {path.name}, 需要[{start_s:.3f},{end_s:.3f})s")
        end = len(raw)
    x, dtype_name, full_scale = pcm_to_float(np.asarray(raw[start:end]))
    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    if x.size < 256:
        raise ValueError(f"片段过短: {path}")
    x = x - float(np.mean(x))
    peak = float(np.max(np.abs(x))) if x.size else 0.0
    rms = float(np.sqrt(np.mean(x * x) + EPS))
    clipping_fraction = float(np.mean(np.abs(x) >= 0.999 * full_scale)) if x.size else 0.0
    return WavSlice(
        path=path, fs=int(fs), x=np.asarray(x, dtype=np.float64), original_dtype=dtype_name,
        duration_seconds=total_duration, segment_start_seconds=start_s,
        segment_end_seconds=end_s, peak=peak, rms=rms, clipping_fraction=clipping_fraction,
    )


def read_lab_wav(path: Path, max_seconds: float) -> Tuple[int, np.ndarray, str, float]:
    fs, raw = wavfile.read(str(path))
    dtype_name = str(raw.dtype)
    if raw.ndim > 1:
        raw = np.mean(raw.astype(np.float64), axis=1)
    x, _, _ = pcm_to_float(np.asarray(raw))
    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    if max_seconds > 0:
        x = x[: int(round(max_seconds * fs))]
    x = x - float(np.mean(x))
    return int(fs), np.asarray(x, dtype=np.float64), dtype_name, len(raw) / float(fs)


def stft_full(x: np.ndarray, fs: int, cfg: AlgorithmConfig) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    nperseg = min(cfg.nperseg, len(x))
    if nperseg < 256:
        raise ValueError("STFT片段过短")
    hop = min(cfg.hop_length, nperseg)
    noverlap = nperseg - hop
    nfft = max(cfg.nfft, nperseg)
    f, t, z = signal.stft(
        x, fs=fs, window="hann", nperseg=nperseg, noverlap=noverlap, nfft=nfft,
        detrend=False, return_onesided=True, boundary="zeros", padded=True,
    )
    return f, t, z


def frequency_mask(freq: np.ndarray, low: float, high: float) -> np.ndarray:
    return (freq >= low) & (freq <= high)


def power_band_from_stft(freq: np.ndarray, z: np.ndarray, cfg: AlgorithmConfig) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    mask = frequency_mask(freq, cfg.freq_low_hz, cfg.freq_high_hz)
    if int(np.sum(mask)) < cfg.minimum_frequency_bins:
        raise ValueError(f"主频段内频点不足: {int(np.sum(mask))}")
    return freq[mask], np.abs(z[mask]) ** 2, mask


def normalize_vector(x: np.ndarray) -> np.ndarray:
    x = np.maximum(np.nan_to_num(np.asarray(x, dtype=np.float64), nan=0.0, posinf=0.0, neginf=0.0), 0.0)
    total = float(np.sum(x))
    if total <= EPS:
        return np.full_like(x, 1.0 / max(len(x), 1))
    return x / total


def normalize_columns(v: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    v = np.maximum(np.nan_to_num(np.asarray(v, dtype=np.float64), nan=0.0, posinf=0.0, neginf=0.0), 0.0)
    scale = np.maximum(np.sum(v, axis=0, keepdims=True), EPS)
    return v / scale, scale


def l2_normalize_columns(v: np.ndarray) -> np.ndarray:
    denom = np.sqrt(np.sum(v * v, axis=0, keepdims=True))
    return v / np.maximum(denom, EPS)


def representative_spectrum(power: np.ndarray) -> np.ndarray:
    if power.ndim != 2 or power.shape[1] == 0:
        raise ValueError("功率矩阵为空")
    spec = np.median(np.maximum(power, 0.0), axis=1)
    if float(np.sum(spec)) <= EPS:
        return np.zeros_like(spec, dtype=np.float64)
    return normalize_vector(spec)


def sigmoid(x: np.ndarray | float) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(np.asarray(x, dtype=np.float64), -60.0, 60.0)))


def weighted_mean(x: np.ndarray, weights: np.ndarray) -> float:
    w = np.maximum(np.asarray(weights, dtype=np.float64), 0.0)
    return float(np.sum(np.asarray(x, dtype=np.float64) * w) / (np.sum(w) + EPS))


def robust_positive_summary(x: np.ndarray, weight: Optional[np.ndarray] = None) -> Tuple[float, float]:
    values = np.asarray(x, dtype=np.float64)
    mask = np.isfinite(values) & (values > 0)
    if not np.any(mask):
        return 0.0, 0.0
    median = float(np.median(values[mask]))
    if weight is None:
        mean = float(np.mean(values[mask]))
    else:
        mean = weighted_mean(values[mask], np.asarray(weight)[mask])
    return median, mean


def deterministic_split(files: Sequence[Path], train_fraction: float, seed: int) -> Tuple[List[Path], List[Path]]:
    scored: List[Tuple[int, Path]] = []
    for path in files:
        token = f"{seed}|{str(path.resolve()).lower()}".encode("utf-8")
        score = int(hashlib.sha256(token).hexdigest()[:16], 16)
        scored.append((score, path))
    ordered = [path for _, path in sorted(scored, key=lambda item: item[0])]
    if len(ordered) <= 1:
        return ordered, []
    n_train = int(round(len(ordered) * train_fraction))
    n_train = min(max(n_train, 1), len(ordered) - 1)
    return ordered[:n_train], ordered[n_train:]


def subsample_columns(v: np.ndarray, max_columns: int, rng: np.random.Generator) -> np.ndarray:
    if v.shape[1] <= max_columns:
        return v
    idx = np.sort(rng.choice(v.shape[1], size=max_columns, replace=False))
    return v[:, idx]


def fit_dictionary(v: np.ndarray, n_components: int, max_iter: int, seed: int) -> np.ndarray:
    vn, _ = normalize_columns(v)
    n_components = min(n_components, max(1, min(vn.shape[0], vn.shape[1]) - 1))
    model = NMF(
        n_components=n_components, init="nndsvda", solver="mu", beta_loss="kullback-leibler",
        max_iter=max_iter, random_state=seed, tol=1e-5,
    )
    model.fit(vn.T)
    w = np.maximum(model.components_.T, EPS)
    w /= np.maximum(np.sum(w, axis=0, keepdims=True), EPS)
    return w


def dynamic_penalty(base_ratio: float, projection: np.ndarray) -> float:
    positive = projection[np.isfinite(projection) & (projection > 0)]
    typical = float(np.median(positive)) if positive.size else 1.0
    return max(base_ratio, 0.0) * max(typical, EPS)


def infer_single_dictionary(v: np.ndarray, w: np.ndarray, iterations: int, l1_ratio: float, seed: int) -> Tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    h = rng.random((w.shape[1], v.shape[1])) + 0.05
    lam = dynamic_penalty(l1_ratio, w.T @ v)
    for _ in range(iterations):
        recon = w @ h + EPS
        h *= (w.T @ v) / (w.T @ recon + lam + EPS)
        h = np.maximum(h, EPS)
    return h, w @ h


# -----------------------------------------------------------------------------
# 消声室参考与相似度
# -----------------------------------------------------------------------------

def spectrum_metrics(a: np.ndarray, b: np.ndarray) -> Dict[str, float]:
    a_raw = np.maximum(np.asarray(a, dtype=np.float64), 0.0)
    b_raw = np.maximum(np.asarray(b, dtype=np.float64), 0.0)
    if float(np.sum(a_raw)) <= EPS or float(np.sum(b_raw)) <= EPS:
        return {
            "cosine": 0.0, "pearson": 0.0, "overlap": 0.0,
            "js_similarity": 0.0, "combined": 0.0,
        }
    p = normalize_vector(a_raw)
    q = normalize_vector(b_raw)
    cosine = float(np.dot(p, q) / (np.linalg.norm(p) * np.linalg.norm(q) + EPS))
    pearson = 0.0 if np.std(p) <= EPS or np.std(q) <= EPS else float(np.corrcoef(p, q)[0, 1])
    overlap = float(np.sum(np.minimum(p, q)))
    js_distance = float(jensenshannon(p + EPS, q + EPS, base=2.0))
    js_similarity = float(np.clip(1.0 - js_distance, 0.0, 1.0))
    combined = float(np.mean([
        np.clip(cosine, 0.0, 1.0),
        np.clip((pearson + 1.0) / 2.0, 0.0, 1.0),
        overlap,
        js_similarity,
    ]))
    return {
        "cosine": cosine, "pearson": pearson, "overlap": overlap,
        "js_similarity": js_similarity, "combined": combined,
    }


def evaluate_against_lab(spec: np.ndarray, lab_specs: Sequence[Tuple[str, Path, np.ndarray]]) -> Dict[str, Any]:
    if not lab_specs:
        return {
            "lab_similarity_combined_median": float("nan"),
            "lab_similarity_combined_max": float("nan"),
            "lab_similarity_best_file": "",
            "lab_cosine_median": float("nan"),
            "lab_pearson_median": float("nan"),
            "lab_overlap_median": float("nan"),
            "lab_js_similarity_median": float("nan"),
        }
    rows = []
    for group, path, lab_spec in lab_specs:
        rows.append((group, path, spectrum_metrics(spec, lab_spec)))
    combined = np.asarray([row[2]["combined"] for row in rows], dtype=float)
    best = int(np.nanargmax(combined))
    return {
        "lab_similarity_combined_median": float(np.nanmedian(combined)),
        "lab_similarity_combined_max": float(combined[best]),
        "lab_similarity_best_file": str(rows[best][1]),
        "lab_cosine_median": float(np.nanmedian([row[2]["cosine"] for row in rows])),
        "lab_pearson_median": float(np.nanmedian([row[2]["pearson"] for row in rows])),
        "lab_overlap_median": float(np.nanmedian([row[2]["overlap"] for row in rows])),
        "lab_js_similarity_median": float(np.nanmedian([row[2]["js_similarity"] for row in rows])),
    }


def prepare_lab_reference(cfg: RunConfig, output_dir: Path) -> Dict[str, Any]:
    """准备消声室训练字典和独立验证参考。

    v3.1.2修复：
    1. 不再使用 ``Path -> role`` 的单值字典，避免训练/验证目录重叠时
       后扫描组把先扫描组覆盖，导致训练集合被错误清空。
    2. WAV发现兼容扩展名大小写、路径两端引号和空格。
    3. 若训练/验证目录有包含关系，优先根据路径中的组名（如0.5mm、0.1mm）
       自动归属；无法唯一判断时明确报“目录重叠”，不再误报“没有WAV”。
    4. 输出详细路径、发现数量和读取错误诊断。
    """
    a = cfg.algorithm
    rng = np.random.default_rng(a.random_state)
    scan_rows: List[Dict[str, Any]] = []
    split_rows: List[Dict[str, Any]] = []
    train_blocks: List[np.ndarray] = []
    validation_specs: List[Tuple[str, Path, np.ndarray]] = []
    train_specs: List[Tuple[str, Path, np.ndarray]] = []
    errors: List[Dict[str, Any]] = []
    freq_ref: Optional[np.ndarray] = None

    path_diag_rows: List[Dict[str, Any]] = []
    for group, configured_paths in cfg.lab_groups.items():
        path_diag_rows.extend(lab_path_diagnostics(group, configured_paths))
    write_csv(output_dir / "00_lab_path_diagnostics.csv", path_diag_rows)

    # 每条记录独立保存，不能再用path作为唯一键覆盖role/group。
    records: List[Tuple[str, Path, str, str]] = []  # group, path, role, resolution

    def normalized_text(value: str) -> str:
        s = str(value).casefold().replace("毫米", "mm")
        for ch in (" ", "_", "-", "\\", "/"):
            s = s.replace(ch, "")
        return s

    def group_is_in_path(group: str, path: Path) -> bool:
        ptxt = normalized_text(str(path))
        gtxt = normalized_text(group)
        variants = {gtxt, gtxt.replace(".", "")}
        return any(token and token in ptxt for token in variants)

    if a.lab_split_mode == "cross_group":
        train_groups = list(a.lab_train_groups)
        validation_groups = list(a.lab_validation_groups)
        ordered_groups = list(dict.fromkeys(train_groups + validation_groups))

        discovered_by_group: Dict[str, List[Path]] = {}
        for group in ordered_groups:
            files = discover_wavs(cfg.lab_groups.get(group, []))
            discovered_by_group[group] = files
            role = "train" if group in train_groups else "validation"
            print(
                f"[LAB] group={group}, role={role}, "
                f"configured_paths={cfg.lab_groups.get(group, [])}, discovered_wavs={len(files)}"
            )

        assignments: Dict[Path, List[Tuple[str, str]]] = {}
        for group in ordered_groups:
            role = "train" if group in train_groups else "validation"
            for path in discovered_by_group[group]:
                assignments.setdefault(path, []).append((group, role))

        ambiguous_overlap: List[Tuple[Path, List[Tuple[str, str]]]] = []
        for path, candidates in assignments.items():
            unique_candidates = list(dict.fromkeys(candidates))
            roles = {role for _, role in unique_candidates}
            if len(roles) == 1:
                # 同一WAV即使被同角色的多个根目录重复发现，也只保留一次。
                group, role = unique_candidates[0]
                records.append((group, path, role, "unique_or_same_role_deduplicated"))
                continue

            # 同一WAV同时进入训练与验证：尝试用路径中的0.5mm/0.1mm标识唯一归属。
            matched = [(group, role) for group, role in unique_candidates if group_is_in_path(group, path)]
            matched = list(dict.fromkeys(matched))
            if len(matched) == 1:
                group, role = matched[0]
                records.append((group, path, role, "cross_role_overlap_resolved_by_path_group_token"))
            else:
                ambiguous_overlap.append((path, unique_candidates))

        for group, path, role, resolution in records:
            split_rows.append({
                "group": group,
                "file": str(path),
                "role": role,
                "split_mode": "cross_group",
                "independent_validation": True,
                "assignment_resolution": resolution,
            })

        validation_mode = (
            "CROSS_GROUP_HOLDOUT_"
            + "+".join(train_groups)
            + "_TO_"
            + "+".join(validation_groups)
        )

        if ambiguous_overlap:
            for path, candidates in ambiguous_overlap:
                split_rows.append({
                    "group": "|".join(g for g, _ in candidates),
                    "file": str(path),
                    "role": "AMBIGUOUS_TRAIN_VALIDATION_OVERLAP",
                    "split_mode": "cross_group",
                    "independent_validation": False,
                    "assignment_resolution": str(candidates),
                })
            write_csv(output_dir / "01_lab_train_validation_split.csv", split_rows)
            examples = "；".join(str(path) for path, _ in ambiguous_overlap[:3])
            raise RuntimeError(
                "消声室训练目录与验证目录发现了相同WAV，无法保证独立验证。"
                f"重叠文件数={len(ambiguous_overlap)}，示例={examples}。"
                "请把lab_groups中的0.5mm和0.1mm分别指向各自独立子文件夹；"
                "不要让两个键都指向同一个总目录。"
            )
    else:
        ordered_groups = list(cfg.lab_groups.keys())
        seen_role_paths: set = set()
        for group in ordered_groups:
            files = discover_wavs(cfg.lab_groups.get(group, []))
            train_files, validation_files = deterministic_split(
                files,
                a.lab_train_fraction,
                a.random_state + sum(ord(ch) for ch in group),
            )
            independent = len(validation_files) > 0
            for path in files:
                role = "train" if path in train_files else "validation"
                key = (path, role)
                if key in seen_role_paths:
                    continue
                seen_role_paths.add(key)
                records.append((group, path, role, "within_group_holdout"))
                split_rows.append({
                    "group": group,
                    "file": str(path),
                    "role": role,
                    "split_mode": "within_group_holdout",
                    "independent_validation": independent,
                    "assignment_resolution": "within_group_holdout",
                })
        validation_mode = "HELD_OUT_WAV_FILES_WITHIN_EACH_GROUP"

    # 训练记录先处理，使频率轴以训练组为基准。
    records.sort(key=lambda item: (0 if item[2] == "train" else 1, item[0], str(item[1]).casefold()))

    for group, path, role, resolution in records:
        try:
            fs, x, dtype_name, duration = read_lab_wav(path, a.max_lab_seconds_per_file)
            f, _, z = stft_full(x, fs, a)
            freq_band, power, _ = power_band_from_stft(f, z, a)
            if freq_ref is None:
                freq_ref = freq_band
            elif len(freq_ref) != len(freq_band) or np.max(np.abs(freq_ref - freq_band)) > 1e-6:
                raise ValueError(
                    "实验室WAV频率轴不一致；请确认0.5mm和0.1mm采样率及STFT参数一致"
                )
            spec = representative_spectrum(power)
            if role == "train":
                train_blocks.append(power)
                train_specs.append((group, path, spec))
            else:
                validation_specs.append((group, path, spec))
            scan_rows.append({
                "group": group,
                "file": str(path),
                "role": role,
                "split_mode": a.lab_split_mode,
                "assignment_resolution": resolution,
                "status": "OK",
                "sample_rate_hz": fs,
                "duration_seconds": duration,
                "used_seconds": len(x) / fs,
                "n_frames": power.shape[1],
                "dtype": dtype_name,
                "error": "",
            })
        except Exception as exc:
            scan_rows.append({
                "group": group,
                "file": str(path),
                "role": role,
                "split_mode": a.lab_split_mode,
                "assignment_resolution": resolution,
                "status": "ERROR",
                "sample_rate_hz": "",
                "duration_seconds": "",
                "used_seconds": "",
                "n_frames": "",
                "dtype": "",
                "error": f"{type(exc).__name__}: {exc}",
            })
            errors.append({
                "stage": "lab",
                "group": group,
                "role": role,
                "file": str(path),
                "error": f"{type(exc).__name__}: {exc}",
            })

    write_csv(output_dir / "00_lab_input_scan.csv", scan_rows)
    write_csv(output_dir / "01_lab_train_validation_split.csv", split_rows)
    write_csv(output_dir / "99_errors_lab.csv", errors)

    discovered_train_count = sum(1 for _, _, role, _ in records if role == "train")
    discovered_validation_count = sum(1 for _, _, role, _ in records if role == "validation")
    ok_train_count = len(train_specs)
    ok_validation_count = len(validation_specs)

    def first_error_text(role_name: str) -> str:
        selected = [e for e in errors if e.get("role") == role_name]
        if not selected:
            return "无具体读取错误（更可能是配置路径不存在、指错组或未发现WAV）"
        return "；".join(
            f"{Path(str(e.get('file', ''))).name}: {e.get('error', '')}"
            for e in selected[:3]
        )

    if not train_blocks or freq_ref is None:
        train_paths = [
            str(x) for group in a.lab_train_groups
            for x in cfg.lab_groups.get(group, [])
        ]
        raise RuntimeError(
            "没有可用的消声室训练WAV。"
            f"训练组={a.lab_train_groups}；配置路径={train_paths}；"
            f"发现WAV={discovered_train_count}个；成功读取={ok_train_count}个。"
            f"首要错误：{first_error_text('train')}。"
            "请查看输出目录中的00_lab_path_diagnostics.csv、"
            "00_lab_input_scan.csv、01_lab_train_validation_split.csv和99_errors_lab.csv。"
        )
    if not validation_specs:
        validation_paths = [
            str(x) for group in a.lab_validation_groups
            for x in cfg.lab_groups.get(group, [])
        ]
        raise RuntimeError(
            "没有可用的独立消声室验证WAV。"
            f"验证组={a.lab_validation_groups}；配置路径={validation_paths}；"
            f"发现WAV={discovered_validation_count}个；成功读取={ok_validation_count}个。"
            f"首要错误：{first_error_text('validation')}。"
            "cross_group模式不会用训练数据代替验证数据。"
        )

    v_train = subsample_columns(
        np.concatenate(train_blocks, axis=1),
        a.max_lab_training_frames,
        rng,
    )
    ws = fit_dictionary(v_train, a.leak_components, a.nmf_max_iter, a.random_state)

    # 验证原型只由独立验证组构成，不参与泄漏字典训练。
    lab_proto = normalize_vector(
        np.median(np.vstack([spec for _, _, spec in validation_specs]), axis=0)
    )

    np.savez_compressed(
        output_dir / "02_frozen_anechoic_leak_reference.npz",
        freq_hz=freq_ref,
        leak_dictionary=ws,
        validation_prototype=lab_proto,
        train_groups=np.asarray(a.lab_train_groups, dtype=str),
        validation_groups=np.asarray(a.lab_validation_groups, dtype=str),
        split_mode=np.asarray(a.lab_split_mode),
    )
    if a.save_plots:
        plot_dictionary(
            freq_ref,
            ws,
            "Frozen anechoic leak dictionary",
            output_dir / "02_frozen_anechoic_leak_reference.png",
        )

    validation_rows: List[Dict[str, Any]] = []
    for group, path, spec in validation_specs:
        validation_rows.append({
            "group": group,
            "file": str(path),
            "validation_mode": validation_mode,
            **spectrum_metrics(spec, lab_proto),
        })
    write_csv(output_dir / "03_lab_validation_similarity.csv", validation_rows)

    split_summary = {
        "split_mode": a.lab_split_mode,
        "train_groups": list(a.lab_train_groups),
        "validation_groups": list(a.lab_validation_groups),
        "n_train_files_discovered": discovered_train_count,
        "n_validation_files_discovered": discovered_validation_count,
        "n_train_files_ok": len(train_specs),
        "n_validation_files_ok": len(validation_specs),
        "validation_mode": validation_mode,
    }
    write_json(output_dir / "04_lab_split_summary.json", split_summary)

    return {
        "freq_hz": freq_ref,
        "ws": ws,
        "lab_proto": lab_proto,
        "validation_specs": validation_specs,
        "validation_mode": validation_mode,
        "split_summary": split_summary,
    }

def collect_sample_files(
    center_id: str,
    center_index: Dict[str, List[Path]],
    offset_index: Dict[Tuple[str, int, str], List[Path]],
) -> Tuple[Path, List[SpatialFile]]:
    center_files = center_index.get(center_id, [])
    if not center_files:
        raise FileNotFoundError(f"中心文件缺失: {center_id}")
    center_path = center_files[0]
    points: List[SpatialFile] = []
    for (cid, distance, direction), paths in offset_index.items():
        if cid != center_id or not paths or direction not in DIRECTION_ANGLES:
            continue
        angle = DIRECTION_ANGLES[direction]
        x_cm = float(distance * np.cos(angle))
        y_cm = float(distance * np.sin(angle))
        if abs(x_cm) < 1e-10:
            x_cm = 0.0
        if abs(y_cm) < 1e-10:
            y_cm = 0.0
        points.append(SpatialFile(center_id, int(distance), direction, paths[0], x_cm, y_cm))
    points.sort(key=lambda p: (p.distance_cm, DIRECTIONS.index(p.direction)))
    return center_path, points


def build_opposite_pair_prediction(
    v_center: np.ndarray,
    point_cache: Sequence[Tuple[SpatialFile, np.ndarray]],
    cfg: AlgorithmConfig,
) -> Tuple[Dict[str, np.ndarray], List[Dict[str, Any]]]:
    """
    由相反方向同半径点预测中心背景。

    返回的主要矩阵均为 [frequency, time]：
    background_power、local_excess_power、pair_support_ratio、axis_support_ratio、
    prediction_uncertainty_db、spatial_gate。
    """
    a = cfg
    by_key: Dict[Tuple[int, str], np.ndarray] = {
        (point.distance_cm, point.direction): power for point, power in point_cache
    }
    positive_center = v_center[v_center > 0]
    if positive_center.size:
        power_floor = max(float(np.quantile(positive_center, 0.01)) * 1e-6, EPS)
    else:
        power_floor = EPS
    log_center = np.log(np.maximum(v_center, power_floor))

    pair_logs: List[np.ndarray] = []
    pair_meta: List[Tuple[str, int, np.ndarray]] = []
    axis_logs: List[np.ndarray] = []
    axis_names: List[str] = []
    axis_radial_mad_nat: List[np.ndarray] = []

    for axis_name, (positive_dir, negative_dir) in OPPOSITE_AXES.items():
        distances = sorted({
            distance for distance, direction in by_key
            if direction == positive_dir
            and (distance, negative_dir) in by_key
            and a.spatial_min_distance_cm <= distance <= a.spatial_max_distance_cm
        })
        current_logs: List[np.ndarray] = []
        for distance in distances:
            p_plus = np.maximum(by_key[(distance, positive_dir)], power_floor)
            p_minus = np.maximum(by_key[(distance, negative_dir)], power_floor)
            pair_log = 0.5 * (np.log(p_plus) + np.log(p_minus))
            pair_delta_db = DB_PER_NATURAL_LOG * (log_center - pair_log)
            current_logs.append(pair_log)
            pair_logs.append(pair_log)
            pair_meta.append((axis_name, int(distance), pair_delta_db))
        if current_logs:
            stack = np.stack(current_logs, axis=0)
            axis_log = np.median(stack, axis=0)
            radial_mad = 1.4826 * np.median(np.abs(stack - axis_log[None, :, :]), axis=0)
            axis_logs.append(axis_log)
            axis_names.append(axis_name)
            axis_radial_mad_nat.append(radial_mad)

    if len(pair_logs) < a.min_complete_opposite_pairs:
        raise RuntimeError(
            f"完整相反方向同半径组合不足: {len(pair_logs)} < {a.min_complete_opposite_pairs}"
        )
    if len(axis_logs) < a.min_complete_axes:
        raise RuntimeError(f"完整相反方向轴不足: {len(axis_logs)} < {a.min_complete_axes}")

    pair_stack = np.stack(pair_logs, axis=0)
    axis_stack = np.stack(axis_logs, axis=0)
    background_log = np.median(axis_stack, axis=0)
    background_power = np.exp(background_log)

    axis_dispersion_nat = 1.4826 * np.median(
        np.abs(axis_stack - background_log[None, :, :]), axis=0
    )
    radial_dispersion_nat = np.median(np.stack(axis_radial_mad_nat, axis=0), axis=0)
    uncertainty_db = DB_PER_NATURAL_LOG * (axis_dispersion_nat + radial_dispersion_nat)

    pair_delta_db_stack = DB_PER_NATURAL_LOG * (log_center[None, :, :] - pair_stack)
    axis_delta_db_stack = DB_PER_NATURAL_LOG * (log_center[None, :, :] - axis_stack)
    pair_support_ratio = np.mean(pair_delta_db_stack > a.pair_support_threshold_db, axis=0)
    axis_support_ratio = np.mean(axis_delta_db_stack > a.pair_support_threshold_db, axis=0)

    center_excess_db = DB_PER_NATURAL_LOG * (log_center - background_log)
    local_excess_power = np.minimum(
        np.maximum(v_center - background_power, 0.0),
        np.maximum(v_center, 0.0),
    )

    effective_threshold_db = (
        a.excess_base_threshold_db
        + a.uncertainty_threshold_weight * np.minimum(uncertainty_db, 12.0)
    )
    db_gate = sigmoid((center_excess_db - effective_threshold_db) / max(a.excess_db_softness, 1e-6))
    pair_gate = sigmoid(
        (pair_support_ratio - a.pair_support_midpoint) / max(a.support_softness, 1e-6)
    )
    axis_gate = sigmoid(
        (axis_support_ratio - a.axis_support_midpoint) / max(a.support_softness, 1e-6)
    )
    uncertainty_confidence = (
        a.prediction_confidence_floor
        + (1.0 - a.prediction_confidence_floor)
        * np.exp(-uncertainty_db / max(a.prediction_uncertainty_ref_db, 1e-6))
    )
    spatial_gate = np.clip(
        db_gate * np.sqrt(pair_gate * axis_gate) * uncertainty_confidence,
        0.0,
        1.0,
    )
    spatial_local_power = local_excess_power * spatial_gate

    pair_rows: List[Dict[str, Any]] = []
    for axis_name, distance, delta_db in pair_meta:
        positive = delta_db[np.isfinite(delta_db)]
        pair_rows.append({
            "axis": axis_name,
            "distance_cm": distance,
            "center_minus_pair_prediction_db_median": float(np.median(positive)) if positive.size else float("nan"),
            "center_minus_pair_prediction_db_p90": float(np.quantile(positive, 0.90)) if positive.size else float("nan"),
            "support_fraction": float(np.mean(delta_db > a.pair_support_threshold_db)),
        })

    arrays = {
        "background_power": background_power,
        "local_excess_power": local_excess_power,
        "spatial_local_power": spatial_local_power,
        "center_excess_db": center_excess_db,
        "pair_support_ratio": pair_support_ratio,
        "axis_support_ratio": axis_support_ratio,
        "prediction_uncertainty_db": uncertainty_db,
        "effective_threshold_db": effective_threshold_db,
        "spatial_gate": spatial_gate,
        "pair_delta_db_stack": pair_delta_db_stack,
        "axis_delta_db_stack": axis_delta_db_stack,
        "axis_names": np.asarray(axis_names),
    }
    return arrays, pair_rows


def apply_anechoic_auxiliary_gate(
    spatial_local_power: np.ndarray,
    leak_dictionary: np.ndarray,
    cfg: AlgorithmConfig,
    seed: int,
) -> Dict[str, np.ndarray]:
    a = cfg
    h, lab_model_power = infer_single_dictionary(
        spatial_local_power,
        leak_dictionary,
        a.lab_projection_iterations,
        a.lab_projection_l1_ratio,
        seed,
    )
    tf_explained_fraction = np.clip(
        lab_model_power / np.maximum(spatial_local_power, EPS), 0.0, 1.0
    )
    frame_energy = np.sum(spatial_local_power, axis=0)
    frame_norm = l2_normalize_columns(spatial_local_power)
    atom_cosine = np.max(l2_normalize_columns(leak_dictionary).T @ frame_norm, axis=0)
    atom_cosine[frame_energy <= EPS] = 0.0
    frame_gate = sigmoid(
        (atom_cosine - a.lab_frame_cosine_midpoint) / max(a.lab_frame_cosine_softness, 1e-6)
    )
    soft_lab_evidence = np.clip(tf_explained_fraction * frame_gate[None, :], 0.0, 1.0)
    lab_gate = (
        a.lab_gate_floor
        + (1.0 - a.lab_gate_floor)
        * np.power(soft_lab_evidence, max(a.lab_gate_exponent, 1e-6))
    )
    final_leak_power = spatial_local_power * lab_gate
    return {
        "lab_activation": h,
        "lab_model_power": lab_model_power,
        "lab_tf_explained_fraction": tf_explained_fraction,
        "lab_atom_cosine_by_frame": atom_cosine,
        "lab_frame_gate": frame_gate,
        "lab_gate": lab_gate,
        "final_leak_power": final_leak_power,
    }


DIRECTIONAL_AUTHENTICITY_FEATURES = [
    "worst_direction_margin_db",
    "center_rank_fraction",
    "radial_decay_direction_fraction",
    "max_radial_rebound_db",
]


def build_center_leak_tf_weight(
    center_power: np.ndarray,
    leak_dictionary: np.ndarray,
    cfg: AlgorithmConfig,
    seed: int,
) -> Dict[str, np.ndarray]:
    """仅由中心点和实验室泄漏字典生成统一时频权重 M(f,t)。

    该权重只负责选择“更像泄漏”的时频单元。它不使用周围点，也不使用
    lab_gate_floor，因此不会让128个周围点各自拥有不同门控。
    """
    a = cfg
    h, model_power = infer_single_dictionary(
        center_power,
        leak_dictionary,
        a.lab_projection_iterations,
        a.lab_projection_l1_ratio,
        seed,
    )
    explained_fraction = np.clip(
        model_power / np.maximum(center_power, EPS), 0.0, 1.0
    )
    frame_energy = np.sum(center_power, axis=0)
    frame_norm = l2_normalize_columns(center_power)
    atom_cosine = np.max(l2_normalize_columns(leak_dictionary).T @ frame_norm, axis=0)
    atom_cosine[frame_energy <= EPS] = 0.0
    frame_gate = sigmoid(
        (atom_cosine - a.lab_frame_cosine_midpoint)
        / max(a.lab_frame_cosine_softness, 1e-6)
    )
    weight = np.clip(explained_fraction * frame_gate[None, :], 0.0, 1.0)
    return {
        "center_lab_activation": h,
        "center_lab_model_power": model_power,
        "center_lab_tf_explained_fraction": explained_fraction,
        "center_lab_atom_cosine_by_frame": atom_cosine,
        "center_lab_frame_gate": frame_gate,
        "leak_tf_weight": weight,
    }


def build_directional_center_features(
    center_power: np.ndarray,
    point_cache: Sequence[Tuple[SpatialFile, np.ndarray]],
    leak_tf_weight: np.ndarray,
    cfg: AlgorithmConfig,
) -> Tuple[Dict[str, float], List[Dict[str, Any]]]:
    """保留八方向完整径向曲线，并提取候选中心真实性的四个空间特征。

    定义：
      E0 = sum M(f,t) * Vcenter(f,t)
      E(r,d) = sum M(f,t) * V(r,d,f,t)
      margin(d) = 10log10(E0 / max_r E(r,d))

    radial_decay_direction_fraction：每个方向对“能量dB-距离”做一阶线性拟合，
    斜率<0记作该方向整体衰减。

    max_radial_rebound_db：同一方向内，任意更远半径相对任意更近半径的
    最大能量上升dB；若全程不反弹则为0。
    """
    if center_power.shape != leak_tf_weight.shape:
        raise ValueError(
            f"中心功率与统一泄漏时频权重形状不一致: {center_power.shape} vs {leak_tf_weight.shape}"
        )

    valid_points: List[Tuple[SpatialFile, np.ndarray]] = []
    for point, power in point_cache:
        if not (cfg.spatial_min_distance_cm <= point.distance_cm <= cfg.spatial_max_distance_cm):
            continue
        if power.shape != center_power.shape:
            raise ValueError(f"周围点功率形状不一致: {point.path.name}")
        valid_points.append((point, power))

    by_direction: Dict[str, List[Tuple[int, float, SpatialFile]]] = {d: [] for d in DIRECTIONS}
    e0 = float(np.sum(leak_tf_weight * center_power))
    energy_floor = max(abs(e0) * 1e-15, EPS)
    e0_safe = max(e0, energy_floor)

    all_neighbor_energies: List[float] = []
    for point, power in valid_points:
        energy = float(np.sum(leak_tf_weight * power))
        energy = max(energy, 0.0)
        by_direction[point.direction].append((int(point.distance_cm), energy, point))
        all_neighbor_energies.append(energy)

    missing = [d for d in DIRECTIONS if len(by_direction[d]) < 2]
    if missing:
        raise RuntimeError(
            "八方向径向特征需要每个方向至少2个有效半径点，缺失/不足方向: " + ", ".join(missing)
        )

    direction_margins: List[float] = []
    decay_flags: List[float] = []
    rebounds: List[float] = []
    diagnostics: List[Dict[str, Any]] = []

    for direction in DIRECTIONS:
        rows = sorted(by_direction[direction], key=lambda item: item[0])
        distances = np.asarray([row[0] for row in rows], dtype=float)
        energies = np.asarray([row[1] for row in rows], dtype=float)
        safe_energy = np.maximum(energies, energy_floor)
        energy_db = 10.0 * np.log10(safe_energy)
        rel_center_db = 10.0 * np.log10(safe_energy / e0_safe)

        max_index = int(np.argmax(energies))
        max_energy = float(energies[max_index])
        margin_db = float(10.0 * np.log10(e0_safe / max(max_energy, energy_floor)))
        slope_db_per_cm = float(np.polyfit(distances, energy_db, 1)[0])
        decay_flag = float(slope_db_per_cm < 0.0)

        rebound_db = 0.0
        min_inner_db = float(energy_db[0])
        for j in range(1, len(energy_db)):
            rebound_db = max(rebound_db, float(energy_db[j] - min_inner_db))
            min_inner_db = min(min_inner_db, float(energy_db[j]))
        rebound_db = max(0.0, rebound_db)

        direction_margins.append(margin_db)
        decay_flags.append(decay_flag)
        rebounds.append(rebound_db)

        for distance, energy, point in rows:
            current_db_rel_center = float(
                10.0 * np.log10(max(energy, energy_floor) / e0_safe)
            )
            diagnostics.append({
                "direction": direction,
                "distance_cm": int(distance),
                "weighted_energy": float(energy),
                "energy_db_relative_to_center": current_db_rel_center,
                "direction_margin_db": margin_db,
                "direction_radial_slope_db_per_cm": slope_db_per_cm,
                "direction_is_decay": int(decay_flag),
                "direction_max_radial_rebound_db": rebound_db,
                "direction_strongest_radius_cm": int(distances[max_index]),
                "direction_strongest_energy": max_energy,
                "point_file": str(point.path),
            })

    neighbor_array = np.asarray(all_neighbor_energies, dtype=float)
    features = {
        "directional_center_weighted_energy": e0,
        "directional_neighbor_count": float(len(neighbor_array)),
        "worst_direction_margin_db": float(np.min(direction_margins)),
        "center_rank_fraction": float(np.mean(neighbor_array < e0)),
        "radial_decay_direction_fraction": float(np.mean(decay_flags)),
        "max_radial_rebound_db": float(np.max(rebounds)),
    }
    return features, diagnostics


def smooth_amplitude_mask(mask: np.ndarray, cfg: AlgorithmConfig) -> np.ndarray:
    f_size = max(1, int(cfg.mask_frequency_median_bins))
    t_size = max(1, int(cfg.mask_temporal_median_frames))
    if f_size % 2 == 0:
        f_size += 1
    if t_size % 2 == 0:
        t_size += 1
    if f_size > 1 or t_size > 1:
        mask = ndimage.median_filter(mask, size=(f_size, t_size), mode="nearest")
    return np.clip(mask, 0.0, 1.0)


def reconstruct_wav(z_full: np.ndarray, fs: int, cfg: AlgorithmConfig, target_len: int) -> np.ndarray:
    nperseg = min(cfg.nperseg, target_len)
    hop = min(cfg.hop_length, nperseg)
    noverlap = nperseg - hop
    _, x = signal.istft(
        z_full, fs=fs, window="hann", nperseg=nperseg, noverlap=noverlap,
        nfft=max(cfg.nfft, nperseg), input_onesided=True, boundary=True,
    )
    if len(x) < target_len:
        x = np.pad(x, (0, target_len - len(x)))
    return np.asarray(x[:target_len], dtype=np.float64)


def amplitude_diagnostics(slices: Sequence[WavSlice], cfg: AlgorithmConfig) -> Dict[str, Any]:
    peaks = np.asarray([item.peak for item in slices], dtype=float)
    rms = np.asarray([item.rms for item in slices], dtype=float)
    clip = np.asarray([item.clipping_fraction for item in slices], dtype=float)
    peak_mean = float(np.mean(peaks)) if peaks.size else float("nan")
    rms_mean = float(np.mean(rms)) if rms.size else float("nan")
    peak_cv = float(np.std(peaks) / (peak_mean + EPS)) if peaks.size else float("nan")
    rms_cv = float(np.std(rms) / (rms_mean + EPS)) if rms.size else float("nan")
    near_full = float(np.mean(peaks >= cfg.amplitude_peak_fullscale_threshold)) if peaks.size else 0.0
    suspicious = bool(
        peaks.size >= 20 and (
            (near_full >= 0.90 and peak_cv <= cfg.amplitude_uniform_peak_cv_threshold)
            or (peak_cv <= cfg.amplitude_uniform_peak_cv_threshold and rms_cv <= cfg.amplitude_uniform_rms_cv_threshold)
        )
    )
    clipping = bool(float(np.max(clip)) > 1e-3) if clip.size else False
    return {
        "amplitude_status": "POSSIBLE_PER_FILE_NORMALIZATION" if suspicious else "AMPLITUDE_SCALE_OK",
        "clipping_status": "POSSIBLE_CLIPPING" if clipping else "NO_OBVIOUS_CLIPPING",
        "peak_cv": peak_cv,
        "rms_cv": rms_cv,
        "near_fullscale_fraction": near_full,
        "max_clipping_fraction": float(np.max(clip)) if clip.size else 0.0,
    }


# -----------------------------------------------------------------------------
# 绘图
# -----------------------------------------------------------------------------

def plot_dictionary(freq: np.ndarray, dictionary: np.ndarray, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(11, 6))
    for idx in range(dictionary.shape[1]):
        ax.plot(freq / 1000.0, normalize_vector(dictionary[:, idx]), linewidth=1.0, label=f"atom {idx + 1}")
    ax.set_xlabel("Frequency (kHz)")
    ax.set_ylabel("Normalized spectral weight")
    ax.set_title(title)
    ax.grid(alpha=0.25)
    if dictionary.shape[1] <= 12:
        ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def plot_sample_spectra(
    freq: np.ndarray,
    raw_spec: np.ndarray,
    background_prediction_spec: np.ndarray,
    leak_spec: np.ndarray,
    remaining_spec: np.ndarray,
    lab_proto: np.ndarray,
    title: str,
    path: Path,
) -> None:
    fig, ax = plt.subplots(figsize=(12, 7))
    ax.plot(freq / 1000.0, normalize_vector(raw_spec), label="raw center", linewidth=1.4)
    ax.plot(freq / 1000.0, normalize_vector(background_prediction_spec), label="spatial predicted background", linewidth=1.2)
    ax.plot(freq / 1000.0, normalize_vector(leak_spec), label="estimated local leak", linewidth=1.4)
    ax.plot(freq / 1000.0, normalize_vector(remaining_spec), label="remaining center", linewidth=1.2)
    ax.plot(freq / 1000.0, normalize_vector(lab_proto), label="anechoic reference", linewidth=1.4, linestyle="--")
    ax.set_xlabel("Frequency (kHz)")
    ax.set_ylabel("Normalized median power spectrum")
    ax.set_title(title)
    ax.grid(alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def plot_spatial_diagnostics(
    freq: np.ndarray,
    time_s: np.ndarray,
    center_excess_db: np.ndarray,
    axis_support_ratio: np.ndarray,
    prediction_uncertainty_db: np.ndarray,
    spatial_gate: np.ndarray,
    title: str,
    path: Path,
) -> None:
    fig, axes = plt.subplots(4, 1, figsize=(12, 12), sharex=True)
    matrices = [center_excess_db, axis_support_ratio, prediction_uncertainty_db, spatial_gate]
    labels = ["Center excess (dB)", "Axis support ratio", "Prediction uncertainty (dB)", "Spatial gate"]
    for ax, matrix, label in zip(axes, matrices, labels):
        im = ax.pcolormesh(time_s, freq / 1000.0, matrix, shading="auto")
        ax.set_ylabel("kHz")
        ax.set_title(label)
        fig.colorbar(im, ax=ax)
    axes[-1].set_xlabel("Time (s)")
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def plot_power_triplet(
    freq: np.ndarray,
    time_s: np.ndarray,
    raw: np.ndarray,
    predicted_background: np.ndarray,
    final_leak: np.ndarray,
    title: str,
    path: Path,
) -> None:
    fig, axes = plt.subplots(3, 1, figsize=(12, 10), sharex=True)
    mats = [raw, predicted_background, final_leak]
    labels = ["Raw center power", "Spatial predicted background", "Final local leak power"]
    for ax, matrix, label in zip(axes, mats, labels):
        db = 10.0 * np.log10(np.maximum(matrix, EPS))
        vmax = float(np.quantile(db[np.isfinite(db)], 0.99))
        vmin = vmax - 50.0
        im = ax.pcolormesh(time_s, freq / 1000.0, db, shading="auto", vmin=vmin, vmax=vmax)
        ax.set_ylabel("kHz")
        ax.set_title(label)
        fig.colorbar(im, ax=ax, label="dB")
    axes[-1].set_xlabel("Time (s)")
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def plot_directional_radial_curves(
    rows: Sequence[Mapping[str, Any]],
    title: str,
    path: Path,
) -> None:
    """绘制统一M加权后的8方向径向曲线，0 dB表示与中心等能量。"""
    if not rows:
        return
    frame = pd.DataFrame(rows)
    required = {"direction", "distance_cm", "energy_db_relative_to_center"}
    if not required.issubset(frame.columns):
        return
    fig, ax = plt.subplots(figsize=(12, 7))
    for direction in DIRECTIONS:
        sub = frame[frame["direction"] == direction].sort_values("distance_cm")
        if sub.empty:
            continue
        ax.plot(
            sub["distance_cm"].to_numpy(dtype=float),
            sub["energy_db_relative_to_center"].to_numpy(dtype=float),
            marker="o",
            markersize=3,
            linewidth=1.2,
            label=direction,
        )
    ax.axhline(0.0, linewidth=1.0, linestyle="--")
    ax.set_xlabel("Distance from candidate center (cm)")
    ax.set_ylabel("Shared-M weighted energy relative to center (dB)")
    ax.set_title(title + " | 8 directional radial curves")
    ax.grid(True, alpha=0.25)
    ax.legend(ncol=4, fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)


# -----------------------------------------------------------------------------
# 单样本处理
# -----------------------------------------------------------------------------

def process_factory_sample(
    dataset: FactoryDataset,
    time_folder: str,
    center_id: str,
    center_path: Path,
    spatial_files: Sequence[SpatialFile],
    lab: Dict[str, Any],
    cfg: RunConfig,
    sample_dir: Path,
    seed: int,
) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    a = cfg.algorithm
    ensure_dir(sample_dir)
    center_slice = read_wav_slice(center_path, center_id, a)
    neighbor_slices: List[Tuple[SpatialFile, WavSlice]] = []
    errors: List[Dict[str, Any]] = []

    for point in spatial_files:
        try:
            wav_slice = read_wav_slice(point.path, center_id, a)
            if wav_slice.fs != center_slice.fs:
                raise ValueError(f"采样率不一致: center={center_slice.fs}, point={wav_slice.fs}")
            if len(wav_slice.x) != len(center_slice.x):
                raise ValueError("片段长度不一致")
            neighbor_slices.append((point, wav_slice))
        except Exception as exc:
            errors.append({
                "dataset": dataset.name, "time_folder": time_folder, "center_id": center_id,
                "file": str(point.path), "stage": "read_neighbor",
                "error": f"{type(exc).__name__}: {exc}",
            })
    if len(neighbor_slices) < a.min_neighbors:
        raise RuntimeError(f"有效周围点不足: {len(neighbor_slices)} < {a.min_neighbors}")

    amp = amplitude_diagnostics([center_slice] + [item for _, item in neighbor_slices], a)
    freq_full, time_stft, z_center = stft_full(center_slice.x, center_slice.fs, a)
    freq_band, v_center, band_mask = power_band_from_stft(freq_full, z_center, a)
    if len(freq_band) != len(lab["freq_hz"]) or np.max(np.abs(freq_band - lab["freq_hz"])) > 1e-6:
        raise ValueError("工厂与消声室频率轴不一致")

    point_cache: List[Tuple[SpatialFile, np.ndarray]] = []
    for point, wav_slice in neighbor_slices:
        f, _, z = stft_full(wav_slice.x, wav_slice.fs, a)
        fb, power, _ = power_band_from_stft(f, z, a)
        if len(fb) != len(freq_band) or np.max(np.abs(fb - freq_band)) > 1e-6:
            raise ValueError(f"周围点频率轴不一致: {point.path.name}")
        point_cache.append((point, power))

    # 分离分支：仍保留原有相反方向空间背景预测。
    spatial, pair_rows = build_opposite_pair_prediction(v_center, point_cache, a)

    # 真假判定分支：M(f,t)只由中心点投影到实验室泄漏字典得到，
    # 随后中心和全部128个周围点共用同一个M，不再分别门控。
    center_detection_gate = build_center_leak_tf_weight(
        v_center, lab["ws"], a, seed + 50,
    )
    directional_features, directional_rows = build_directional_center_features(
        v_center, point_cache, center_detection_gate["leak_tf_weight"], a,
    )

    # WAV分离仍沿用原有空间局部超额 + 消声室辅助门控。
    # lab_gate_floor仅存在于该分离分支，不进入T/F真假分类特征。
    lab_gate = apply_anechoic_auxiliary_gate(
        spatial["spatial_local_power"], lab["ws"], a, seed + 100,
    )

    preliminary_power = np.minimum(lab_gate["final_leak_power"], v_center)
    amplitude_mask = np.sqrt(preliminary_power / np.maximum(v_center, EPS))
    amplitude_mask = smooth_amplitude_mask(amplitude_mask, a)
    final_leak_power = np.minimum(amplitude_mask * amplitude_mask * v_center, v_center)
    remaining_power = np.maximum(v_center - final_leak_power, 0.0)

    z_leak = np.zeros_like(z_center)
    z_leak[band_mask] = amplitude_mask * z_center[band_mask]
    z_remaining = z_center - z_leak
    leak_wav = reconstruct_wav(z_leak, center_slice.fs, a, len(center_slice.x))
    remaining_wav = reconstruct_wav(z_remaining, center_slice.fs, a, len(center_slice.x))

    if a.save_wavs:
        wavfile.write(str(sample_dir / "estimated_local_leak.wav"), center_slice.fs, leak_wav.astype(np.float32))
        wavfile.write(str(sample_dir / "estimated_background_remaining.wav"), center_slice.fs, remaining_wav.astype(np.float32))
        wavfile.write(str(sample_dir / "raw_center_slice.wav"), center_slice.fs, center_slice.x.astype(np.float32))

    raw_spec = representative_spectrum(v_center)
    predicted_background_spec = representative_spectrum(spatial["background_power"])
    local_excess_spec = representative_spectrum(spatial["local_excess_power"])
    spatial_local_spec = representative_spectrum(spatial["spatial_local_power"])
    leak_spec = representative_spectrum(final_leak_power)
    remaining_spec = representative_spectrum(remaining_power)

    raw_sim = evaluate_against_lab(raw_spec, lab["validation_specs"])
    local_excess_sim = evaluate_against_lab(local_excess_spec, lab["validation_specs"])
    spatial_local_sim = evaluate_against_lab(spatial_local_spec, lab["validation_specs"])
    leak_sim = evaluate_against_lab(leak_spec, lab["validation_specs"])
    remaining_sim = evaluate_against_lab(remaining_spec, lab["validation_specs"])

    total_power = float(np.sum(v_center)) + EPS
    local_excess_fraction = float(np.sum(spatial["local_excess_power"]) / total_power)
    spatial_local_fraction = float(np.sum(spatial["spatial_local_power"]) / total_power)
    final_leak_fraction = float(np.sum(final_leak_power) / total_power)

    excess_db_median, excess_db_weighted_mean = robust_positive_summary(
        spatial["center_excess_db"], spatial["local_excess_power"]
    )
    pair_support_weighted = weighted_mean(spatial["pair_support_ratio"], v_center)
    axis_support_weighted = weighted_mean(spatial["axis_support_ratio"], v_center)
    uncertainty_weighted = weighted_mean(spatial["prediction_uncertainty_db"], v_center)
    prediction_confidence_weighted = weighted_mean(
        a.prediction_confidence_floor
        + (1.0 - a.prediction_confidence_floor)
        * np.exp(-spatial["prediction_uncertainty_db"] / max(a.prediction_uncertainty_ref_db, 1e-6)),
        v_center,
    )
    # 旧版综合分数仅保留为诊断列，绝不参与v3.2真假判定。
    lab_similarity_for_legacy_diagnostic = float(
        spatial_local_sim["lab_similarity_combined_median"]
    )
    legacy_source_center_score_diagnostic = float(
        np.sqrt(max(local_excess_fraction, 0.0) * max(axis_support_weighted, 0.0))
        * max(lab_similarity_for_legacy_diagnostic, 0.0)
        * max(prediction_confidence_weighted, 0.0)
    )

    label = sample_label(dataset, time_folder)
    leak_type, condition_name = infer_leak_type_and_condition(time_folder)
    normalized_time_folder = normalize_relative_folder(time_folder)
    pair_key = f"{canonical_condition(normalized_time_folder, cfg.pairing_remove_tokens)}::{center_id}"
    summary: Dict[str, Any] = {
        "dataset": dataset.name,
        "leak_type": leak_type,
        "condition_name": condition_name,
        "time_folder": normalized_time_folder,
        "condition_relative_path": normalized_time_folder,
        "canonical_condition": canonical_condition(normalized_time_folder, cfg.pairing_remove_tokens),
        "pair_key": pair_key,
        "center_id": center_id,
        "label": label,
        "center_file": str(center_path),
        "segment_start_seconds": center_slice.segment_start_seconds,
        "segment_end_seconds": center_slice.segment_end_seconds,
        "sample_rate_hz": center_slice.fs,
        "n_neighbors_used": len(neighbor_slices),
        "n_complete_opposite_pairs": int(spatial["pair_delta_db_stack"].shape[0]),
        "n_complete_axes": int(spatial["axis_delta_db_stack"].shape[0]),
        "main_freq_low_hz": a.freq_low_hz,
        "main_freq_high_hz": a.freq_high_hz,
        "center_local_excess_power_fraction": local_excess_fraction,
        "center_spatial_filtered_power_fraction": spatial_local_fraction,
        "center_final_leak_power_fraction": final_leak_fraction,
        "center_excess_db_positive_median": excess_db_median,
        "center_excess_db_power_weighted_mean": excess_db_weighted_mean,
        "opposite_pair_support_ratio_power_weighted": pair_support_weighted,
        "opposite_axis_support_ratio_power_weighted": axis_support_weighted,
        "background_prediction_uncertainty_db_power_weighted": uncertainty_weighted,
        "background_prediction_confidence_power_weighted": prediction_confidence_weighted,
        "lab_atom_cosine_frame_median": float(np.median(lab_gate["lab_atom_cosine_by_frame"])),
        "lab_frame_gate_power_weighted": weighted_mean(
            lab_gate["lab_frame_gate"][None, :], spatial["spatial_local_power"]
        ),
        # v3.3：所有工厂数据均为测试集，不训练分类器、不学习阈值。
        # 以下旧列仅为兼容旧CSV结构，明确置空/标记为未计算。
        "source_center_score": float("nan"),
        "candidate_authenticity_score": float("nan"),
        "candidate_authenticity_threshold": float("nan"),
        "candidate_authenticity_prediction": "NOT_COMPUTED_TEST_ONLY",
        "candidate_authenticity_score_source": "NO_TRAINING_ALL_FACTORY_DATA_TEST_ONLY",
        "candidate_rank_within_pair": float("nan"),
        "candidate_selected_in_pair": False,
        "spatial_evidence_flag": "TEST_ONLY_NO_CLASSIFIER",
        "legacy_source_center_score_diagnostic": legacy_source_center_score_diagnostic,
        "center_detection_lab_atom_cosine_frame_median": float(
            np.median(center_detection_gate["center_lab_atom_cosine_by_frame"])
        ),
        **directional_features,
        "lab_validation_mode": lab["validation_mode"],
        **amp,
        **{f"raw_{key}": value for key, value in raw_sim.items()},
        **{f"local_excess_{key}": value for key, value in local_excess_sim.items()},
        **{f"spatial_local_{key}": value for key, value in spatial_local_sim.items()},
        **{f"leak_{key}": value for key, value in leak_sim.items()},
        **{f"remaining_{key}": value for key, value in remaining_sim.items()},
    }
    summary["leak_similarity_gain_over_raw"] = float(
        summary["leak_lab_similarity_combined_median"]
        - summary["raw_lab_similarity_combined_median"]
    )
    summary["leak_vs_remaining_similarity_gap"] = float(
        summary["leak_lab_similarity_combined_median"]
        - summary["remaining_lab_similarity_combined_median"]
    )

    enriched_pair_rows: List[Dict[str, Any]] = []
    for row in pair_rows:
        enriched_pair_rows.append({
            "dataset": dataset.name, "leak_type": leak_type,
            "condition_name": condition_name, "time_folder": normalized_time_folder,
            "condition_relative_path": normalized_time_folder,
            "canonical_condition": summary["canonical_condition"],
            "pair_key": pair_key, "center_id": center_id, "label": label,
            **row,
        })

    enriched_directional_rows: List[Dict[str, Any]] = []
    for row in directional_rows:
        enriched_directional_rows.append({
            "dataset": dataset.name, "leak_type": leak_type,
            "condition_name": condition_name, "time_folder": normalized_time_folder,
            "condition_relative_path": normalized_time_folder,
            "canonical_condition": summary["canonical_condition"],
            "pair_key": pair_key, "center_id": center_id, "label": label,
            **row,
        })

    if a.save_npz:
        np.savez_compressed(
            sample_dir / "spatial_local_excess_result.npz",
            freq_hz=freq_band,
            time_s=time_stft,
            raw_center_power=v_center,
            spatial_predicted_background_power=spatial["background_power"],
            local_excess_power=spatial["local_excess_power"],
            spatial_local_power=spatial["spatial_local_power"],
            final_leak_power=final_leak_power,
            remaining_power=remaining_power,
            amplitude_mask=amplitude_mask,
            center_excess_db=spatial["center_excess_db"],
            pair_support_ratio=spatial["pair_support_ratio"],
            axis_support_ratio=spatial["axis_support_ratio"],
            prediction_uncertainty_db=spatial["prediction_uncertainty_db"],
            spatial_gate=spatial["spatial_gate"],
            lab_gate=lab_gate["lab_gate"],
            leak_dictionary=lab["ws"],
            leak_activation=lab_gate["lab_activation"],
            center_detection_leak_tf_weight=center_detection_gate["leak_tf_weight"],
            center_detection_lab_model_power=center_detection_gate["center_lab_model_power"],
        )
    write_json(sample_dir / "summary.json", summary)
    write_csv(sample_dir / "opposite_pair_diagnostics.csv", enriched_pair_rows)
    write_csv(sample_dir / "directional_radial_diagnostics.csv", enriched_directional_rows)

    if a.save_plots:
        title = f"{dataset.name} | {time_folder} | {center_id}"
        plot_sample_spectra(
            freq_band, raw_spec, predicted_background_spec, leak_spec, remaining_spec,
            lab["lab_proto"], title, sample_dir / "spectrum_comparison.png",
        )
        plot_spatial_diagnostics(
            freq_band, time_stft, spatial["center_excess_db"],
            spatial["axis_support_ratio"], spatial["prediction_uncertainty_db"],
            spatial["spatial_gate"], title, sample_dir / "spatial_evidence.png",
        )
        plot_power_triplet(
            freq_band, time_stft, v_center, spatial["background_power"],
            final_leak_power, title, sample_dir / "power_spectrograms.png",
        )
        plot_directional_radial_curves(
            enriched_directional_rows, title, sample_dir / "directional_radial_curves.png"
        )

    return summary, enriched_pair_rows, enriched_directional_rows, errors


# -----------------------------------------------------------------------------
# T/F汇总
# -----------------------------------------------------------------------------

def _normalize_tf_label(value: Any) -> str:
    text = str(value).strip().upper()
    if text in {"T", "TRUE"}:
        return "T"
    if text in {"F", "FALSE"}:
        return "F"
    return "UNLABELED"


def build_directional_test_protocol(summary_df: pd.DataFrame) -> Dict[str, Any]:
    """记录本版严格的“全工厂数据只测试、不训练”协议。

    这里绝不调用fit，不拟合StandardScaler/LogisticRegression，也不从T/F标签学习阈值。
    标签只用于运行完成后的描述性评价（AUC、成对胜率、均值/中位数）。
    """
    n_samples = int(len(summary_df))
    labels = (
        summary_df.get("label", pd.Series(dtype=str))
        .astype(str).str.upper().replace({"TRUE": "T", "FALSE": "F"})
    )
    return {
        "program_version": "v3.3-directional-test-only-00_00-00_01",
        "factory_data_role": "TEST_ONLY",
        "processed_center_ids_note": "每个工况仅处理selected_center_ids（默认00_00、00_01）；其余中心编号不读取WAV、不计算",
        "training_performed": False,
        "scaler_fitted": False,
        "classifier_fitted": False,
        "threshold_learned_from_factory_data": False,
        "labels_used_for_feature_extraction": False,
        "labels_used_only_for_posthoc_test_evaluation": True,
        "feature_order": DIRECTIONAL_AUTHENTICITY_FEATURES,
        "expected_feature_directions": {
            "worst_direction_margin_db": "T_HIGHER",
            "center_rank_fraction": "T_HIGHER",
            "radial_decay_direction_fraction": "T_HIGHER",
            "max_radial_rebound_db": "F_HIGHER",
        },
        "n_factory_test_samples": n_samples,
        "n_T": int(np.sum(labels == "T")) if n_samples else 0,
        "n_F": int(np.sum(labels == "F")) if n_samples else 0,
        "note": (
            "所有工厂T/F样本均只用于测试。四个方向特征由中心与128点的统一M加权能量直接计算；"
            "程序不训练监督分类器，也不从这些工厂数据选择判定阈值。"
        ),
    }


def build_featurewise_pair_test(summary_df: pd.DataFrame) -> pd.DataFrame:
    """对同pair_key的T/F做逐特征测试比较，不生成学习型综合分数。"""
    if summary_df.empty or "pair_key" not in summary_df.columns or "label" not in summary_df.columns:
        return pd.DataFrame()
    labels = summary_df["label"].astype(str).str.upper().replace({"TRUE": "T", "FALSE": "F"})
    sub = summary_df.loc[labels.isin(["T", "F"])].copy()
    sub["label_norm"] = labels[labels.isin(["T", "F"])]
    if sub.empty:
        return pd.DataFrame()

    expected = {
        "worst_direction_margin_db": "T_HIGHER",
        "center_rank_fraction": "T_HIGHER",
        "radial_decay_direction_fraction": "T_HIGHER",
        "max_radial_rebound_db": "F_HIGHER",
    }
    grouped = sub.groupby(["pair_key", "label_norm"], as_index=False)[DIRECTIONAL_AUTHENTICITY_FEATURES].mean(numeric_only=True)
    t = grouped[grouped["label_norm"] == "T"].set_index("pair_key")
    f = grouped[grouped["label_norm"] == "F"].set_index("pair_key")
    common = sorted(set(t.index) & set(f.index))
    rows: List[Dict[str, Any]] = []
    for key in common:
        for feature in DIRECTIONAL_AUTHENTICITY_FEATURES:
            tv = float(t.loc[key, feature])
            fv = float(f.loc[key, feature])
            direction = expected[feature]
            if direction == "T_HIGHER":
                passed = bool(tv > fv)
                signed_advantage = tv - fv
            else:
                passed = bool(fv > tv)
                signed_advantage = fv - tv
            rows.append({
                "pair_key": key,
                "feature": feature,
                "expected_direction": direction,
                "T_value": tv,
                "F_value": fv,
                "T_minus_F": tv - fv,
                "expected_direction_pass": passed,
                "expected_direction_advantage": float(signed_advantage),
            })
    return pd.DataFrame(rows)


def numeric_group_summary(summary_df: pd.DataFrame) -> pd.DataFrame:
    if summary_df.empty:
        return pd.DataFrame()
    metrics = [
        "worst_direction_margin_db",
        "center_rank_fraction",
        "radial_decay_direction_fraction",
        "max_radial_rebound_db",
        "center_local_excess_power_fraction",
        "center_spatial_filtered_power_fraction",
        "center_final_leak_power_fraction",
        "center_excess_db_positive_median",
        "opposite_pair_support_ratio_power_weighted",
        "opposite_axis_support_ratio_power_weighted",
        "background_prediction_uncertainty_db_power_weighted",
        "spatial_local_lab_similarity_combined_median",
        "leak_lab_similarity_combined_median",
        "legacy_source_center_score_diagnostic",
    ]
    rows: List[Dict[str, Any]] = []
    for (dataset, label), sub in summary_df.groupby(["dataset", "label"], dropna=False):
        row: Dict[str, Any] = {"dataset": dataset, "label": label, "n_samples": len(sub)}
        for metric in metrics:
            values = pd.to_numeric(sub.get(metric), errors="coerce")
            row[f"{metric}_mean"] = float(values.mean())
            row[f"{metric}_median"] = float(values.median())
            row[f"{metric}_std"] = float(values.std(ddof=1)) if len(values) > 1 else 0.0
        rows.append(row)
    return pd.DataFrame(rows)


def tf_metric_auc(summary_df: pd.DataFrame) -> pd.DataFrame:
    if summary_df.empty or "label" not in summary_df.columns:
        return pd.DataFrame()
    labels = summary_df["label"].astype(str).str.upper()
    valid_mask = labels.isin(["T", "TRUE", "F", "FALSE"])
    sub = summary_df.loc[valid_mask].copy()
    if sub.empty:
        return pd.DataFrame()
    y = sub["label"].astype(str).str.upper().isin(["T", "TRUE"]).astype(int).to_numpy()
    if len(np.unique(y)) < 2:
        return pd.DataFrame()

    metric_expected = {
        "worst_direction_margin_db": "T_HIGHER",
        "center_rank_fraction": "T_HIGHER",
        "radial_decay_direction_fraction": "T_HIGHER",
        "max_radial_rebound_db": "F_HIGHER",
        # 以下均为诊断列；所有AUC都只是测试评价，不参与任何训练。
        "raw_lab_similarity_combined_median": "DIAGNOSTIC",
        "center_local_excess_power_fraction": "DIAGNOSTIC",
        "center_spatial_filtered_power_fraction": "DIAGNOSTIC",
        "center_final_leak_power_fraction": "DIAGNOSTIC",
        "center_excess_db_positive_median": "DIAGNOSTIC",
        "opposite_pair_support_ratio_power_weighted": "DIAGNOSTIC",
        "opposite_axis_support_ratio_power_weighted": "DIAGNOSTIC",
        "background_prediction_confidence_power_weighted": "DIAGNOSTIC",
        "spatial_local_lab_similarity_combined_median": "DIAGNOSTIC",
        "leak_lab_similarity_combined_median": "DIAGNOSTIC",
        "legacy_source_center_score_diagnostic": "DIAGNOSTIC",
    }
    rows: List[Dict[str, Any]] = []
    for metric, expected in metric_expected.items():
        if metric not in sub.columns:
            continue
        values = pd.to_numeric(sub[metric], errors="coerce")
        mask = values.notna().to_numpy()
        if np.sum(mask) < 2 or len(np.unique(y[mask])) < 2:
            continue
        auc_t_higher = float(roc_auc_score(y[mask], values.to_numpy()[mask]))
        if expected == "T_HIGHER":
            auc_expected = auc_t_higher
        elif expected == "F_HIGHER":
            auc_expected = 1.0 - auc_t_higher
        else:
            auc_expected = max(auc_t_higher, 1.0 - auc_t_higher)
        rows.append({
            "metric": metric,
            "auc_T_higher": auc_t_higher,
            "auc_expected_direction": float(auc_expected),
            "auc_best_direction": max(auc_t_higher, 1.0 - auc_t_higher),
            "expected_direction": expected,
            "n_samples": int(np.sum(mask)),
        })
    result = pd.DataFrame(rows)
    if result.empty:
        return result
    return result.sort_values("auc_expected_direction", ascending=False)


def paired_tf_comparison(summary_df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    if summary_df.empty:
        return pd.DataFrame(), pd.DataFrame()
    labels = summary_df["label"].astype(str).str.upper().replace({"TRUE": "T", "FALSE": "F"})
    sub = summary_df.loc[labels.isin(["T", "F"])].copy()
    sub["label_norm"] = labels[labels.isin(["T", "F"])]
    if sub.empty:
        return pd.DataFrame(), pd.DataFrame()
    metrics = [
        "worst_direction_margin_db",
        "center_rank_fraction",
        "radial_decay_direction_fraction",
        "max_radial_rebound_db",
        "center_local_excess_power_fraction",
        "center_final_leak_power_fraction",
        "center_excess_db_positive_median",
        "opposite_axis_support_ratio_power_weighted",
        "spatial_local_lab_similarity_combined_median",
        "legacy_source_center_score_diagnostic",
    ]
    grouped = sub.groupby(["pair_key", "label_norm"], as_index=False)[metrics].mean(numeric_only=True)
    t = grouped[grouped["label_norm"] == "T"].set_index("pair_key")
    f = grouped[grouped["label_norm"] == "F"].set_index("pair_key")
    common = sorted(set(t.index) & set(f.index))
    rows: List[Dict[str, Any]] = []
    for key in common:
        row: Dict[str, Any] = {"pair_key": key}
        for metric in metrics:
            tv = float(t.loc[key, metric])
            fv = float(f.loc[key, metric])
            row[f"T_{metric}"] = tv
            row[f"F_{metric}"] = fv
            row[f"T_minus_F_{metric}"] = tv - fv
        rows.append(row)
    paired = pd.DataFrame(rows)
    if paired.empty:
        return paired, pd.DataFrame()
    summary_rows: List[Dict[str, Any]] = []
    expected_map = {
        "worst_direction_margin_db": "T_HIGHER",
        "center_rank_fraction": "T_HIGHER",
        "radial_decay_direction_fraction": "T_HIGHER",
        "max_radial_rebound_db": "F_HIGHER",
    }
    for metric in metrics:
        diff_col = f"T_minus_F_{metric}"
        values = pd.to_numeric(paired[diff_col], errors="coerce").dropna()
        expected = expected_map.get(metric, "DIAGNOSTIC")
        if len(values) == 0:
            expected_win_fraction = float("nan")
        elif expected == "T_HIGHER":
            expected_win_fraction = float(np.mean(values > 0))
        elif expected == "F_HIGHER":
            expected_win_fraction = float(np.mean(values < 0))
        else:
            expected_win_fraction = float("nan")
        summary_rows.append({
            "metric": metric,
            "expected_direction": expected,
            "n_pairs": len(values),
            "T_greater_F_fraction": float(np.mean(values > 0)) if len(values) else float("nan"),
            "expected_direction_win_fraction": expected_win_fraction,
            "T_minus_F_mean": float(values.mean()) if len(values) else float("nan"),
            "T_minus_F_median": float(values.median()) if len(values) else float("nan"),
        })
    return paired, pd.DataFrame(summary_rows)


# -----------------------------------------------------------------------------
# 运行入口
# -----------------------------------------------------------------------------

def write_read_me_first(output_dir: Path, cfg: RunConfig, lab: Dict[str, Any]) -> None:
    text = f"""空间局部超额分离 + 八方向测试特征提取 v3.3-2point：结果阅读说明
========================================================

主分析频带：{cfg.algorithm.freq_low_hz/1000:g}-{cfg.algorithm.freq_high_hz/1000:g} kHz
消声室验证模式：{lab['validation_mode']}

最重要原则：所有工厂T/F数据全部是测试集。
本版额外限制：每个工况只处理中心编号 {', '.join(cfg.algorithm.selected_center_ids)}。
- 其他中心编号仅扫描文件名，不读取WAV、不做STFT、不计算空间特征或重建WAV；
- 对00_00和00_01，每个中心仍使用其对应的全部周围方向/距离点进行空间计算。
- 不训练 StandardScaler；
- 不训练 LogisticRegression；
- 不从工厂T/F学习任何阈值；
- T/F标签不参与M(f,t)或四个空间特征的计算；
- T/F标签只在计算完成后用于测试评价：分组统计、AUC、同工况成对胜率。

A. WAV分离分支（保留旧方法）
- 相反方向同半径点继续用于空间背景预测；
- 局部超额、方向支持、外环/方向不确定度继续保留；
- 实验室NMF字典继续辅助门控并重建 estimated_local_leak.wav；
- lab_gate_floor 只影响WAV分离，不参与T/F测试指标。

B. 八方向测试特征分支
1. 只用中心点投影实验室泄漏字典，生成统一时频权重 M(f,t)。
2. 中心与全部128个周围点使用同一个M。
3. 8个方向分别保留完整径向曲线，不做相反方向平均。
4. 只提取四个物理空间指标：
   - worst_direction_margin_db：越高越符合T；
   - center_rank_fraction：越高越符合T；
   - radial_decay_direction_fraction：越高越符合T；
   - max_radial_rebound_db：越低越符合T。
5. 不计算学习型 candidate_authenticity_score，不输出学习型T/F预测。

四个指标定义：
- E0 = sum M(f,t) * Vcenter(f,t)
- E(r,d) = sum M(f,t) * V(r,d,f,t)
- margin(d) = 10log10[E0 / max_r E(r,d)]
- worst_direction_margin_db = min_d margin(d)
- center_rank_fraction = 128个周围点中 E(r,d) < E0 的比例
- radial_decay_direction_fraction = 8方向中“能量dB-距离”拟合斜率<0的方向比例
- max_radial_rebound_db = 同方向向更远半径移动时出现的最大重新增强dB

主要输出：
- 10_factory_sample_summary.csv：每个测试样本的四个核心指标及旧诊断列。
- 12_TF_group_summary.csv：T/F测试集分组均值、中位数、标准差。
- 13_TF_metric_auc.csv：测试集描述性AUC；不参与训练。
- 14_TF_paired_comparison.csv / 15_TF_paired_summary.csv：同pair_key T/F成对测试。
- 16_directional_radial_diagnostics.csv：8方向全部半径点曲线。
- 17_directional_feature_pair_test.csv：只针对四个核心特征的T/F成对胜负。
- 18_directional_feature_test_summary.csv：四特征总体测试汇总。
- 19_test_protocol.json：明确记录“所有工厂数据只测试、无训练、无阈值学习”。

注意：
candidate_authenticity_score、source_center_score 等旧列为了兼容旧CSV结构仍保留，但在v3.3中为空，
不能拿它们判断T/F。真正先看四个方向特征本身能否在测试数据上稳定区分T/F。
"""
    (output_dir / "00_READ_ME_FIRST.txt").write_text(text, encoding="utf-8")


def build_type_summary(summary_df: pd.DataFrame) -> pd.DataFrame:
    if summary_df.empty:
        return pd.DataFrame(columns=["dataset", "label", "leak_type", "n_samples", "n_conditions"])
    required = {"dataset", "label", "leak_type", "time_folder"}
    if not required.issubset(summary_df.columns):
        return pd.DataFrame()
    return (
        summary_df.groupby(["dataset", "label", "leak_type"], dropna=False)
        .agg(n_samples=("center_id", "size"), n_conditions=("time_folder", "nunique"))
        .reset_index()
        .sort_values(["dataset", "label", "leak_type"], kind="stable")
    )


def run_analysis(cfg: RunConfig) -> Dict[str, Path]:
    output_dir = ensure_dir(Path(cfg.output_dir))
    print("=" * 92)
    print("空间局部超额分离 + 八方向测试特征提取 v3.3-2point")
    print("输出目录:", output_dir)
    print("主分析频带:", f"{cfg.algorithm.freq_low_hz:g}-{cfg.algorithm.freq_high_hz:g} Hz")
    print("目录扫描: 递归查找中心WAV，保留中文泄漏类型和完整相对路径")
    print("仅处理中心编号:", ", ".join(cfg.algorithm.selected_center_ids))
    print("其余中心编号: 只扫描，不读取WAV、不计算")
    print("=" * 92)

    lab = prepare_lab_reference(cfg, output_dir)
    write_read_me_first(output_dir, cfg, lab)
    summaries: List[Dict[str, Any]] = []
    all_pairs: List[Dict[str, Any]] = []
    all_directional: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []
    scan_manifest: List[Dict[str, Any]] = []
    sample_counter = 0
    plot_count = 0

    for dataset in cfg.factory_datasets:
        print("\n" + "#" * 92)
        print(f"数据集: {dataset.name}, label={dataset.default_label}")
        center_root = Path(dataset.center_root_dir).expanduser()
        folders = available_time_folders(dataset)
        if not folders:
            errors.append({
                "dataset": dataset.name,
                "stage": "scan",
                "center_root_dir": str(center_root),
                "error": "递归扫描后没有找到包含 *_beamform_result.wav 的工况目录",
            })
            continue

        type_counts: Dict[str, int] = {}
        for folder in folders:
            leak_type, _ = infer_leak_type_and_condition(folder)
            type_counts[leak_type] = type_counts.get(leak_type, 0) + 1
        print("扫描到工况:", len(folders))
        print("扫描到类型:", ", ".join(f"{key}({value})" for key, value in sorted(type_counts.items())))

        for time_folder in folders:
            normalized_folder = normalize_relative_folder(time_folder)
            leak_type, condition_name = infer_leak_type_and_condition(normalized_folder)
            center_dir = resolve_time_dir(center_root, normalized_folder, expect="center")
            offset_dirs = [
                resolve_time_dir(Path(root), normalized_folder, expect="offset")
                for root in dataset.offset_root_dirs
            ]
            existing_offset_dirs = [path for path in offset_dirs if directory_has_offset_wav(path)]
            center_index = build_center_index(center_dir) if directory_has_center_wav(center_dir) else {}
            # 周围点只为00_00和00_01建立索引；其他编号连后续空间点列表都不会建立。
            offset_index = (
                build_offset_index(existing_offset_dirs, cfg.algorithm.selected_center_ids)
                if existing_offset_dirs else {}
            )
            all_center_ids = sorted(center_index.keys(), key=center_sort_key)
            # 严格限制实际计算样本：只保留配置中的00_00、00_01。
            # 未入选中心不会进入collect_sample_files/process_factory_sample，因此不会读取音频。
            center_ids = [cid for cid in cfg.algorithm.selected_center_ids if cid in center_index]
            missing_selected_ids = [cid for cid in cfg.algorithm.selected_center_ids if cid not in center_index]

            scan_row: Dict[str, Any] = {
                "dataset": dataset.name,
                "label": sample_label(dataset, normalized_folder),
                "leak_type": leak_type,
                "condition_name": condition_name,
                "condition_relative_path": normalized_folder,
                "center_dir": str(center_dir),
                "center_dir_exists": center_dir.is_dir(),
                "center_wav_count": sum(len(values) for values in center_index.values()),
                "discovered_center_id_count": len(all_center_ids),
                "discovered_center_ids": ";".join(all_center_ids),
                "selected_center_id_count": len(center_ids),
                "selected_center_ids": ";".join(center_ids),
                "missing_selected_center_ids": ";".join(missing_selected_ids),
                # 兼容旧列名：center_id_count/center_ids现在表示“实际会计算的中心”。
                "center_id_count": len(center_ids),
                "center_ids": ";".join(center_ids),
                "configured_offset_root_count": len(dataset.offset_root_dirs),
                "resolved_offset_dir_count": len(existing_offset_dirs),
                "resolved_offset_dirs": ";".join(str(path) for path in existing_offset_dirs),
                "offset_combination_count": len(offset_index),
                "scan_status": "OK",
                "scan_message": "",
            }

            if not center_dir.is_dir() or not all_center_ids:
                scan_row["scan_status"] = "ERROR"
                scan_row["scan_message"] = "中心目录不存在或没有匹配中心WAV"
                scan_manifest.append(scan_row)
                errors.append({
                    "dataset": dataset.name,
                    "leak_type": leak_type,
                    "time_folder": normalized_folder,
                    "stage": "scan",
                    "error": f"中心目录不存在或没有匹配中心WAV: {center_dir}",
                })
                continue
            if not center_ids:
                scan_row["scan_status"] = "ERROR"
                scan_row["scan_message"] = (
                    "存在中心WAV，但没有找到要处理的中心编号: "
                    + ", ".join(cfg.algorithm.selected_center_ids)
                )
                scan_manifest.append(scan_row)
                errors.append({
                    "dataset": dataset.name,
                    "leak_type": leak_type,
                    "time_folder": normalized_folder,
                    "stage": "scan",
                    "error": scan_row["scan_message"],
                    "discovered_center_ids": ";".join(all_center_ids),
                })
                continue
            if missing_selected_ids:
                scan_row["scan_status"] = "WARNING"
                scan_row["scan_message"] = (
                    "部分指定中心编号缺失，仅处理已找到的编号；缺失: "
                    + ", ".join(missing_selected_ids)
                )
            if not existing_offset_dirs:
                scan_row["scan_status"] = "ERROR"
                scan_row["scan_message"] = "没有找到包含周围点WAV的对应目录"
                scan_manifest.append(scan_row)
                errors.append({
                    "dataset": dataset.name,
                    "leak_type": leak_type,
                    "time_folder": normalized_folder,
                    "stage": "scan",
                    "error": "偏移目录全部不存在或不含匹配WAV",
                    "attempted_offset_dirs": ";".join(str(path) for path in offset_dirs),
                })
                continue
            scan_manifest.append(scan_row)

            print(
                f"\n[{leak_type}] {normalized_folder or '[root]'}: "
                f"selected_centers={center_ids}, discovered={len(all_center_ids)}, "
                f"offset组合={len(offset_index)}"
            )
            if missing_selected_ids:
                print(f"  WARNING 缺少指定中心: {missing_selected_ids}")
            for center_id in center_ids:
                sample_counter += 1
                original_save_plots = cfg.algorithm.save_plots
                try:
                    center_path, spatial_files = collect_sample_files(center_id, center_index, offset_index)
                    relative_parts = safe_relative_parts(normalized_folder)
                    sample_dir = (
                        output_dir / "samples" / safe_slug(dataset.name)
                    ).joinpath(*relative_parts, f"center_{safe_slug(center_id)}")

                    if plot_count >= cfg.algorithm.plot_limit:
                        cfg.algorithm.save_plots = False
                    summary, pair_rows, directional_rows, sample_errors = process_factory_sample(
                        dataset, normalized_folder, center_id, center_path, spatial_files,
                        lab, cfg, sample_dir, cfg.algorithm.random_state + sample_counter * 17,
                    )
                    summary["output_sample_dir"] = str(sample_dir)
                    cfg.algorithm.save_plots = original_save_plots
                    summaries.append(summary)
                    all_pairs.extend(pair_rows)
                    all_directional.extend(directional_rows)
                    errors.extend(sample_errors)
                    if original_save_plots and plot_count < cfg.algorithm.plot_limit:
                        plot_count += 1
                    print(
                        f"  {center_id}: worst_margin={summary['worst_direction_margin_db']:.2f} dB, "
                        f"rank={summary['center_rank_fraction']:.3f}, "
                        f"decay_dirs={summary['radial_decay_direction_fraction']:.3f}, "
                        f"max_rebound={summary['max_radial_rebound_db']:.2f} dB"
                    )
                except Exception as exc:
                    cfg.algorithm.save_plots = original_save_plots
                    errors.append({
                        "dataset": dataset.name,
                        "leak_type": leak_type,
                        "time_folder": normalized_folder,
                        "center_id": center_id,
                        "stage": "sample",
                        "error": f"{type(exc).__name__}: {exc}",
                    })
                    print(f"  {center_id}: ERROR {type(exc).__name__}: {exc}")

    scan_path = output_dir / "01_factory_scan_manifest.csv"
    type_path = output_dir / "02_factory_type_summary.csv"
    summary_path = output_dir / "10_factory_sample_summary.csv"
    pair_path = output_dir / "11_opposite_pair_diagnostics.csv"
    group_path = output_dir / "12_TF_group_summary.csv"
    auc_path = output_dir / "13_TF_metric_auc.csv"
    paired_path = output_dir / "14_TF_paired_comparison.csv"
    paired_summary_path = output_dir / "15_TF_paired_summary.csv"
    directional_path = output_dir / "16_directional_radial_diagnostics.csv"
    pair_feature_test_path = output_dir / "17_directional_feature_pair_test.csv"
    feature_test_summary_path = output_dir / "18_directional_feature_test_summary.csv"
    protocol_path = output_dir / "19_test_protocol.json"
    errors_path = output_dir / "99_errors_factory.csv"

    # v3.3：工厂数据全部只测试。这里不训练任何分类器、不学习阈值。
    summary_df = pd.DataFrame(summaries)
    pair_feature_test_df = build_featurewise_pair_test(summary_df)
    protocol_info = build_directional_test_protocol(summary_df)

    # 单样本summary.json在特征提取时已经写出；无需回写任何训练结果。

    write_csv(scan_path, scan_manifest)
    summary_df.to_csv(summary_path, index=False, encoding="utf-8-sig")
    write_csv(pair_path, all_pairs)
    write_csv(directional_path, all_directional)
    write_csv(errors_path, errors)
    pair_feature_test_df.to_csv(pair_feature_test_path, index=False, encoding="utf-8-sig")
    write_json(protocol_path, protocol_info)

    type_df = build_type_summary(summary_df)
    group_df = numeric_group_summary(summary_df)
    auc_df = tf_metric_auc(summary_df)
    paired_df, paired_summary_df = paired_tf_comparison(summary_df)

    # 只汇总四个核心方向特征，方便先判断“物理特征本身能不能分开T/F”。
    core_auc = auc_df[auc_df["metric"].isin(DIRECTIONAL_AUTHENTICITY_FEATURES)].copy() if not auc_df.empty else pd.DataFrame()
    pair_core_summary = (
        pair_feature_test_df.groupby(["feature", "expected_direction"], as_index=False)
        .agg(
            n_pairs=("expected_direction_pass", "size"),
            paired_expected_win_fraction=("expected_direction_pass", "mean"),
            paired_expected_advantage_median=("expected_direction_advantage", "median"),
        )
        if not pair_feature_test_df.empty else pd.DataFrame()
    )
    if not core_auc.empty and not pair_core_summary.empty:
        feature_test_summary_df = core_auc.merge(pair_core_summary, left_on=["metric", "expected_direction"], right_on=["feature", "expected_direction"], how="left").drop(columns=["feature"])
    elif not core_auc.empty:
        feature_test_summary_df = core_auc
    else:
        feature_test_summary_df = pair_core_summary.rename(columns={"feature": "metric"})

    type_df.to_csv(type_path, index=False, encoding="utf-8-sig")
    group_df.to_csv(group_path, index=False, encoding="utf-8-sig")
    auc_df.to_csv(auc_path, index=False, encoding="utf-8-sig")
    paired_df.to_csv(paired_path, index=False, encoding="utf-8-sig")
    paired_summary_df.to_csv(paired_summary_path, index=False, encoding="utf-8-sig")
    feature_test_summary_df.to_csv(feature_test_summary_path, index=False, encoding="utf-8-sig")

    run_info = {
        "program_version": "v3.3-directional-test-only-00_00-00_01",
        "config": {
            "lab_groups": cfg.lab_groups,
            "factory_datasets": [asdict(item) for item in cfg.factory_datasets],
            "output_dir": cfg.output_dir,
            "pairing_remove_tokens": cfg.pairing_remove_tokens,
            "algorithm": asdict(cfg.algorithm),
        },
        "lab_validation_mode": lab["validation_mode"],
        "discovered_condition_count": len(scan_manifest),
        "discovered_leak_types": sorted({str(row.get("leak_type", "")) for row in scan_manifest}),
        "successful_factory_samples": len(summaries),
        "factory_error_count": len(errors),
        "test_protocol": protocol_info,
    }
    write_json(output_dir / "00_run_info.json", run_info)

    print("\n" + "=" * 92)
    print("处理完成")
    print("扫描清单:", scan_path)
    print("类型汇总:", type_path)
    print("样本总表:", summary_path)
    print("T/F分组:", group_path)
    print("T/F AUC:", auc_path)
    print("成对比较:", paired_summary_path)
    print("八方向径向曲线:", directional_path)
    print("四特征成对测试:", pair_feature_test_path)
    print("四特征测试汇总:", feature_test_summary_path)
    print("测试协议:", protocol_path)
    print("错误表:", errors_path)
    print("=" * 92)
    return {
        "output_dir": output_dir,
        "scan_manifest": scan_path,
        "type_summary": type_path,
        "summary": summary_path,
        "pairs": pair_path,
        "errors": errors_path,
        "group_summary": group_path,
        "auc": auc_path,
        "paired": paired_path,
        "paired_summary": paired_summary_path,
        "directional": directional_path,
        "directional_pair_test": pair_feature_test_path,
        "directional_test_summary": feature_test_summary_path,
        "test_protocol": protocol_path,
    }


# -----------------------------------------------------------------------------
# 自检
# -----------------------------------------------------------------------------

def synth_leak(fs: int, seconds: float, rng: np.random.Generator, variant: float) -> np.ndarray:
    n = int(round(fs * seconds))
    white = rng.standard_normal(n)
    sos = signal.butter(5, [50_000, 70_000], btype="bandpass", fs=fs, output="sos")
    band = signal.sosfilt(sos, white)
    t = np.arange(n) / fs
    modulation = 0.65 + 0.35 * np.sin(2 * np.pi * (7.0 + variant) * t + variant)
    return 0.05 * modulation * band


def synth_noise(fs: int, seconds: float, rng: np.random.Generator, variant: float) -> np.ndarray:
    n = int(round(fs * seconds))
    t = np.arange(n) / fs
    white = 0.012 * rng.standard_normal(n)
    tones = (
        0.010 * np.sin(2 * np.pi * (53_000 + 300 * variant) * t)
        + 0.008 * np.sin(2 * np.pi * (62_000 - 200 * variant) * t)
    )
    return white + tones


def write_synthetic_factory(
    root: Path,
    label: str,
    fs: int,
    seconds: float,
    rng: np.random.Generator,
    leak: np.ndarray,
) -> Tuple[Path, Path, Path]:
    suffix = "condition" if label == "T" else "condition_null"
    center_root = ensure_dir(root / f"center_{label}" / suffix)
    near_root = ensure_dir(root / f"near_{label}" / suffix)
    far_root = ensure_dir(root / f"far_{label}" / suffix)
    common_noise = synth_noise(fs, seconds, rng, 0.0)

    center_leak_amp = 1.0 if label == "T" else 0.32
    for center_id in ("00_00", "00_01"):
        center = common_noise + center_leak_amp * leak + 0.002 * rng.standard_normal(len(leak))
        wavfile.write(str(center_root / f"synthetic_{center_id}_beamform_result.wav"), fs, center.astype(np.float32))

        for direction in DIRECTIONS:
            angle = DIRECTION_ANGLES[direction]
            for distance in range(5, 85, 5):
                if label == "T":
                    amp = 0.62 * math.exp(-distance / 38.0)
                else:
                    # 假中心：泄漏场在局部近似平滑梯度；相反方向几何平均可预测中心。
                    x_cm = distance * math.cos(angle)
                    y_cm = distance * math.sin(angle)
                    amp = center_leak_amp * math.exp(0.004 * x_cm - 0.003 * y_cm)
                local_noise = common_noise + 0.002 * rng.standard_normal(len(leak))
                x = local_noise + amp * leak
                target = near_root if distance <= 40 else far_root
                wavfile.write(
                    str(target / f"synthetic_{center_id}d{distance}_{direction}_beamform_result.wav"),
                    fs,
                    x.astype(np.float32),
                )
    return center_root.parent, near_root.parent, far_root.parent


def run_self_test() -> None:
    print("开始SELF-TEST...")
    rng = np.random.default_rng(1234)
    fs = 192_000
    seconds = 0.35
    with tempfile.TemporaryDirectory(prefix="spatial_v3_test_") as temp_dir:
        root = Path(temp_dir)
        lab01 = ensure_dir(root / "lab" / "0.1mm")
        lab05 = ensure_dir(root / "lab" / "0.5mm")
        for group_dir, shift in ((lab01, 0.0), (lab05, 1.4)):
            for idx in range(4):
                x = synth_leak(fs, seconds, rng, shift + idx * 0.1)
                wavfile.write(str(group_dir / f"lab_{idx}.wav"), fs, x.astype(np.float32))

        leak = synth_leak(fs, seconds, rng, 0.25)
        t_center, t_near, t_far = write_synthetic_factory(root, "T", fs, seconds, rng, leak)
        f_center, f_near, f_far = write_synthetic_factory(root, "F", fs, seconds, rng, leak)
        # 故意额外放入00_02中心文件；若筛选失效，程序会尝试处理并导致summary行数不为4。
        for center_parent, condition_name in ((t_center, "condition"), (f_center, "condition_null")):
            center_dir = center_parent / condition_name
            extra = synth_noise(fs, seconds, rng, 2.0)
            wavfile.write(str(center_dir / "synthetic_00_02_beamform_result.wav"), fs, extra.astype(np.float32))

        cfg = RunConfig(
            lab_groups={"0.1mm": [str(lab01)], "0.5mm": [str(lab05)]},
            factory_datasets=[
                FactoryDataset("synthetic_T", str(t_center), [str(t_near), str(t_far)], ["condition"], "T", {}),
                FactoryDataset("synthetic_F", str(f_center), [str(f_near), str(f_far)], ["condition_null"], "F", {}),
            ],
            output_dir=str(root / "out"),
            pairing_remove_tokens=["_null", "null"],
            algorithm=AlgorithmConfig(
                time_slice_seconds=seconds,
                segment_mode="first",
                nperseg=1024,
                hop_length=512,
                nfft=2048,
                minimum_frequency_bins=20,
                leak_components=4,
                max_lab_training_frames=3000,
                nmf_max_iter=120,
                lab_projection_iterations=80,
                min_neighbors=100,
                min_complete_opposite_pairs=50,
                save_plots=False,
                plot_limit=0,
            ),
        )
        paths = run_analysis(cfg)
        summary = pd.read_csv(paths["summary"])
        pairs = pd.read_csv(paths["pairs"])
        directional = pd.read_csv(paths["directional"])
        # 2个标签(T/F) × 2个指定中心(00_00/00_01) = 4个实际样本。
        if len(summary) != 4:
            raise AssertionError(f"SELF-TEST summary行数错误: {len(summary)}")
        if set(summary["center_id"].astype(str)) != {"00_00", "00_01"}:
            raise AssertionError(f"SELF-TEST实际处理中心错误: {sorted(set(summary['center_id'].astype(str)))}")
        if len(pairs) != 256:
            raise AssertionError(f"SELF-TEST相反方向组合行数错误: {len(pairs)}")
        if len(directional) != 512:
            raise AssertionError(f"SELF-TEST八方向径向诊断行数错误: {len(directional)}")
        required = {
            "leak_type",
            "condition_relative_path",
            "worst_direction_margin_db",
            "center_rank_fraction",
            "radial_decay_direction_fraction",
            "max_radial_rebound_db",
                }
        if not required.issubset(summary.columns):
            raise AssertionError(f"SELF-TEST缺少列: {required - set(summary.columns)}")
        t_row = summary.loc[summary["label"] == "T"].select_dtypes(include=[np.number]).median(numeric_only=True)
        f_row = summary.loc[summary["label"] == "F"].select_dtypes(include=[np.number]).median(numeric_only=True)
        checks = [
            (float(t_row["worst_direction_margin_db"]) > float(f_row["worst_direction_margin_db"]), "worst_direction_margin_db"),
            (float(t_row["center_rank_fraction"]) > float(f_row["center_rank_fraction"]), "center_rank_fraction"),
            (float(t_row["radial_decay_direction_fraction"]) > float(f_row["radial_decay_direction_fraction"]), "radial_decay_direction_fraction"),
            (float(t_row["max_radial_rebound_db"]) < float(f_row["max_radial_rebound_db"]), "max_radial_rebound_db"),
        ]
        failed = [name for ok, name in checks if not ok]
        if failed:
            raise AssertionError(f"SELF-TEST四个方向特征预期关系失败: {failed}")
        protocol = json.loads(Path(paths["test_protocol"]).read_text(encoding="utf-8"))
        if protocol.get("training_performed") is not False or protocol.get("factory_data_role") != "TEST_ONLY":
            raise AssertionError("SELF-TEST测试协议错误：不应训练工厂数据")
        if safe_slug("快插_100kPa") != "快插_100kPa":
            raise AssertionError("SELF-TEST中文目录名未被保留")
        nested_root = ensure_dir(root / "recursive_scan" / "快插" / "100kPa_3770sccm_2m")
        wavfile.write(str(nested_root / "recursive_00_00_beamform_result.wav"), fs, leak.astype(np.float32))
        discovered = discover_center_condition_folders(root / "recursive_scan")
        if discovered != ["快插/100kPa_3770sccm_2m"]:
            raise AssertionError(f"SELF-TEST递归扫描错误: {discovered}")
        for dataset, folder in (("synthetic_T", "condition"), ("synthetic_F", "condition_null")):
            sample_dir = root / "out" / "samples" / dataset / folder / "center_00_00"
            for name in (
                "estimated_local_leak.wav",
                "estimated_background_remaining.wav",
                "spatial_local_excess_result.npz",
            ):
                if not (sample_dir / name).exists():
                    raise AssertionError(f"SELF-TEST缺少输出: {sample_dir / name}")
    print("SELF-TEST PASSED")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="空间局部超额分离 + 八方向测试特征提取 v3.3-2point")
    parser.add_argument("--config", type=str, default="spatial_directional_test_only_config_v3_3_two_points.json")
    parser.add_argument("--self-test", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if args.self_test:
        run_self_test()
        return
    cfg = load_config(Path(args.config))
    run_analysis(cfg)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n用户中止。")
        sys.exit(130)
    except Exception as exc:
        print(f"\n程序失败: {type(exc).__name__}: {exc}")
        traceback.print_exc()
        sys.exit(1)
