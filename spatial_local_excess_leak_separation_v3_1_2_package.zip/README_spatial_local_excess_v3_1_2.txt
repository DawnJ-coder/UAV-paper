空间局部超额泄漏分离 v3.1.2 修复说明

修复的问题
1. v3.1使用“WAV完整路径 -> role”的字典保存训练/验证归属。
   当0.5mm与0.1mm目录有包含关系、两个键误指向同一上级目录，
   同一个WAV会先标为train、后被validation覆盖，最终可能误报“没有可用的训练WAV”。
2. WAV扫描现在兼容 .wav/.WAV/混合大小写，并自动去掉配置路径两端的引号和空格。
3. 新增详细诊断文件：
   00_lab_path_diagnostics.csv
   00_lab_input_scan.csv
   01_lab_train_validation_split.csv
   99_errors_lab.csv
4. 如果训练和验证发现同一文件：
   - 路径中能明确识别0.5mm或0.1mm时，自动归入对应组；
   - 无法识别时，明确提示“目录重叠”，不再错误提示“没有WAV”。

正确配置示例
"lab_groups": {
  "0.1mm": ["D:\\anechoic\\0.1mm"],
  "0.5mm": ["D:\\anechoic\\0.5mm"]
}

两个键应分别指向各自孔径的子目录，不要都指向同一个总目录。

运行
python spatial_local_excess_leak_separation_v3_1_2.py --config spatial_local_excess_config_v3_1_2.json

若仍报错，错误信息会直接显示：配置路径、发现WAV数量、成功读取数量和首要读取错误。
