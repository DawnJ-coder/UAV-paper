v11 多场景冻结指纹外部验证
============================

一、文件放置
------------
请把以下文件放在同一目录：

1. v11_cross_scene_frozen_fingerprint_validation.py
2. leak_v9_local_background_residual_wav.py
3. leak_v10_fingerprint_similarity_blocked_seconds.py
4. v11_scene_config.json

二、先修改 v11_scene_config.json
--------------------------------
必须修改：

reference_fingerprint
    A场景生成的 v10_frozen_reference.npz

reference_v9_config
    A场景生成的 v9_run_config.json

output_root
    v11总输出目录

每个新场景的：
    scene
    v9_result_dir
    v10_output_dir
    TRUE/FALSE中心目录
    TRUE/FALSE偏移目录

B建议作为开发外部验证；C先设置 enabled=false，等B分析完成后再开启，作为最终盲测。

三、安装依赖
------------
pip install numpy pandas scipy matplotlib scikit-learn

四、自检
--------
python .\v11_cross_scene_frozen_fingerprint_validation.py --self-test

五、正式运行
------------
python .\v11_cross_scene_frozen_fingerprint_validation.py --config .\v11_scene_config.json

程序会先打印原始文件预解析结果，包括：
- 中心文件数量
- 偏移组合数量
- 00_00 / 00_01 秒编号解析率

然后才运行v9和冻结指纹外部验证。

六、已有新场景v9结果时
----------------------
把配置中的：
    "run_v9": false

并确保每个 v9_result_dir 中存在：
    v9_all_features.csv
    v9_run_config.json
    residual_npz/*.npz

七、最重要输出
--------------
v11_all_external_similarity.csv
    所有新场景逐样本相似度和分项Margin。

v11_scene_summary.csv
    每个场景的冻结阈值准确率、AUC、T/F Margin中位数。

v11_component_margin_summary.csv
    频谱、时间、空间和总Margin的分项统计。

v11_hardest_samples.csv
    最接近A冻结阈值的50个临界样本。

v11_v9_parameter_consistency.csv
    检查B/C是否使用了与A相同的v9算法参数；有不一致时该场景会停止验证。

v11_cross_scene_report.txt
    汇总报告。

八、原则
--------
- B/C不重新建立指纹。
- B/C不重新选阈值。
- B可用于分析和改进；一旦使用B改了算法，C必须保持未查看，作为最终验证。
- 如果B的频谱Margin正确但空间Margin错误，先检查反射、候选中心偏移和波束宽度，不要直接把B加入A模板。
