# -*- coding: utf-8 -*-
"""
v11_cross_scene_frozen_fingerprint_validation.py

第二阶段：冻结 A 场景指纹，对多个新场景做外部验证
====================================================

本程序不会用 B/C 场景重新训练、重新建立原型或重新选择阈值。
它会按照以下顺序执行：

1. 读取配置并检查 A 场景冻结指纹；
2. 先扫描每个新场景的中心 WAV、偏移 WAV 和 00_00/00_01 文件格式；
3. 使用 A 场景 v9_run_config.json 中冻结的 v9 参数处理新场景；
4. 调用 v10.1 external 模式，用 A 冻结指纹计算相似度；
5. 合并 B/C/... 场景结果，输出跨场景汇总、分项 Margin 和临界样本。

依赖文件（与本程序放在同一个目录）：
    leak_v9_local_background_residual_wav.py
    leak_v10_fingerprint_similarity_blocked_seconds.py

推荐运行：
    python v11_cross_scene_frozen_fingerprint_validation.py --config v11_scene_config.json

先做自检：
    python v11_cross_scene_frozen_fingerprint_validation.py --self-test
"""

from __future__ import annotations

import argparse
import importlib.util
import json
import math
import os
import shutil
import sys
import tempfile
import traceback
from dataclasses import fields, replace
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_CONFIG = SCRIPT_DIR / "v11_scene_config.json"
V9_MODULE_FILE = "leak_v9_local_background_residual_wav.py"
V10_MODULE_FILE = "leak_v10_fingerprint_similarity_blocked_seconds.py"

VALID_LABELS = {"TRUE_LEAK", "FALSE_LEAK", ""}

# 这些字段决定 v9 的实际残差，不允许在外部场景中单独调整。
V9_ALGORITHM_KEYS = [
    "freq_low_hz",
    "freq_high_hz",
    "nperseg",
    "hop_length",
    "nfft",
    "min_frames",
    "min_frequency_bins",
    "background_min_distance_quantile",
    "min_background_points",
    "point_huber_delta",
    "plane_improvement_ratio",
    "plane_clip_margin_db",
    "max_geometry_condition",
    "residual_thresholds_db",
    "minimum_required_neighbors",
    "minimum_complete_combo_ratio",
    "epsilon_power",
]


def load_python_module(path: Path, module_name: str):
    if not path.exists():
        raise FileNotFoundError(f"缺少依赖程序: {path}")
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"无法加载Python模块: {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def read_json(path: Path) -> Dict[str, Any]:
    if not path.exists():
        raise FileNotFoundError(f"找不到配置文件: {path}")
    with path.open("r", encoding="utf-8-sig") as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise ValueError(f"JSON顶层必须是对象: {path}")
    return data


def write_json(path: Path, data: Dict[str, Any]) -> None:
    ensure_dir(path.parent)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def normalize_path(value: Any, base_dir: Path) -> Path:
    text = str(value or "").strip()
    if not text:
        return Path()
    p = Path(os.path.expandvars(os.path.expanduser(text)))
    if not p.is_absolute():
        p = (base_dir / p).resolve()
    return p


def safe_float(value: Any, default: float = np.nan) -> float:
    try:
        out = float(value)
        return out if np.isfinite(out) else default
    except Exception:
        return default


def load_reference_v9_config(v9_module, config_path: Path):
    """从 A 场景 v9_run_config.json 恢复算法参数。"""
    raw = read_json(config_path)
    values = raw.get("config", raw)
    if not isinstance(values, dict):
        raise ValueError(f"参考v9配置中没有config对象: {config_path}")

    allowed = {f.name for f in fields(v9_module.V9Config)}
    kwargs = {k: v for k, v in values.items() if k in allowed}
    if "residual_thresholds_db" in kwargs:
        kwargs["residual_thresholds_db"] = tuple(kwargs["residual_thresholds_db"])

    reference = v9_module.V9Config(**kwargs)
    # 外部验证必须保存完整残差 NPZ。画图数量可以由 v11 配置覆盖。
    reference = replace(reference, save_residual_npz=True)
    return reference, values


def config_algorithm_subset(config_dict: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for key in V9_ALGORITHM_KEYS:
        if key in config_dict:
            value = config_dict[key]
            if isinstance(value, tuple):
                value = list(value)
            out[key] = value
    return out


def values_equal(a: Any, b: Any) -> bool:
    if isinstance(a, (list, tuple)) or isinstance(b, (list, tuple)):
        try:
            aa = np.asarray(a, dtype=float)
            bb = np.asarray(b, dtype=float)
            return aa.shape == bb.shape and bool(np.allclose(aa, bb, rtol=0, atol=1e-12))
        except Exception:
            return list(a) == list(b)
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return bool(math.isclose(float(a), float(b), rel_tol=0, abs_tol=1e-12))
    return a == b


def compare_v9_configs(reference_values: Dict[str, Any], result_config_path: Path) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    if not result_config_path.exists():
        return pd.DataFrame([
            {
                "parameter": "__config_file__",
                "reference_value": "exists",
                "external_value": "missing",
                "match": 0,
            }
        ])
    external_raw = read_json(result_config_path)
    external_values = external_raw.get("config", external_raw)
    for key in V9_ALGORITHM_KEYS:
        ref = reference_values.get(key, "<missing>")
        ext = external_values.get(key, "<missing>")
        rows.append(
            {
                "parameter": key,
                "reference_value": json.dumps(ref, ensure_ascii=False),
                "external_value": json.dumps(ext, ensure_ascii=False),
                "match": int(values_equal(ref, ext)),
            }
        )
    return pd.DataFrame(rows)


def validate_top_config(raw: Dict[str, Any], base_dir: Path) -> Dict[str, Any]:
    required = ["reference_fingerprint", "reference_v9_config", "output_root", "scenes"]
    missing = [k for k in required if k not in raw]
    if missing:
        raise ValueError(f"v11配置缺少字段: {missing}")

    scenes = raw.get("scenes")
    if not isinstance(scenes, list) or not scenes:
        raise ValueError("scenes 必须是非空列表")

    out = dict(raw)
    out["reference_fingerprint"] = normalize_path(raw["reference_fingerprint"], base_dir)
    out["reference_v9_config"] = normalize_path(raw["reference_v9_config"], base_dir)
    out["output_root"] = normalize_path(raw["output_root"], base_dir)
    out["run_v9"] = bool(raw.get("run_v9", True))
    out["skip_v9_if_complete"] = bool(raw.get("skip_v9_if_complete", True))
    out["save_diagnostic_plots"] = bool(raw.get("save_diagnostic_plots", True))
    out["diagnostic_plot_limit"] = max(0, int(raw.get("diagnostic_plot_limit", 20)))
    out["continue_after_scene_failure"] = bool(raw.get("continue_after_scene_failure", True))
    out["scenes"] = scenes
    return out


def normalize_scene_config(raw_scene: Dict[str, Any], base_dir: Path, output_root: Path) -> Dict[str, Any]:
    if not isinstance(raw_scene, dict):
        raise ValueError("每个scene配置必须是对象")
    name = str(raw_scene.get("name") or raw_scene.get("scene") or "").strip()
    scene = str(raw_scene.get("scene") or name).strip()
    if not name or not scene:
        raise ValueError("scene配置必须提供 name 或 scene")

    v9_dir_raw = raw_scene.get("v9_result_dir", str(output_root / name / "v9_results"))
    v10_dir_raw = raw_scene.get("v10_output_dir", str(output_root / name / "v10_external"))
    datasets_raw = raw_scene.get("datasets", [])
    if datasets_raw is None:
        datasets_raw = []
    if not isinstance(datasets_raw, list):
        raise ValueError(f"{name}.datasets 必须是列表")

    datasets: List[Dict[str, Any]] = []
    for idx, item in enumerate(datasets_raw, start=1):
        if not isinstance(item, dict):
            raise ValueError(f"{name}.datasets[{idx}] 必须是对象")
        label = str(item.get("label", "")).upper().strip()
        if label not in VALID_LABELS:
            raise ValueError(f"{name}.datasets[{idx}] label非法: {label}")
        dataset_name = str(item.get("name") or f"{name}_{label or idx}")
        datasets.append(
            {
                "name": dataset_name,
                "scene": scene,
                "label": label,
                "center_root_dir": str(normalize_path(item.get("center_root_dir", ""), base_dir)),
                "offset_root_dir": str(normalize_path(item.get("offset_root_dir", ""), base_dir)),
                "time_folders": list(item.get("time_folders", [])),
            }
        )

    return {
        "name": name,
        "scene": scene,
        "v9_result_dir": normalize_path(v9_dir_raw, base_dir),
        "v10_output_dir": normalize_path(v10_dir_raw, base_dir),
        "datasets": datasets,
        "enabled": bool(raw_scene.get("enabled", True)),
        "purpose": str(raw_scene.get("purpose", "external_validation")),
    }


def v9_result_is_complete(v9_dir: Path) -> Tuple[bool, str]:
    csv_path = v9_dir / "v9_all_features.csv"
    residual_dir = v9_dir / "residual_npz"
    if not csv_path.exists():
        return False, "缺少v9_all_features.csv"
    if not residual_dir.exists():
        return False, "缺少residual_npz文件夹"
    try:
        df = pd.read_csv(csv_path)
    except Exception as exc:
        return False, f"v9_all_features.csv无法读取: {exc}"
    n_rows = len(df)
    n_npz = len(list(residual_dir.glob("*.npz")))
    if n_rows == 0:
        return False, "v9_all_features.csv没有样本"
    if n_npz < n_rows:
        return False, f"NPZ数量不足: {n_npz}/{n_rows}"
    return True, f"完整: 样本{n_rows}, NPZ{n_npz}"


def preflight_raw_scene(
    scene_cfg: Dict[str, Any],
    v9_module,
    v10_module,
) -> Tuple[pd.DataFrame, List[str]]:
    """先解析原始目录与 00_00 文件格式，不做信号计算。"""
    rows: List[Dict[str, Any]] = []
    warnings: List[str] = []
    datasets = scene_cfg["datasets"]
    if not datasets:
        warnings.append("没有配置原始datasets；将直接使用已有v9结果目录。")
        return pd.DataFrame(), warnings

    for dataset in datasets:
        center_root = Path(dataset["center_root_dir"])
        offset_root = Path(dataset["offset_root_dir"])
        if not center_root.exists() or not offset_root.exists():
            rows.append(
                {
                    "scene": scene_cfg["scene"],
                    "dataset": dataset["name"],
                    "label": dataset["label"],
                    "time": "",
                    "center_root_exists": int(center_root.exists()),
                    "offset_root_exists": int(offset_root.exists()),
                    "n_centers": 0,
                    "n_offset_combos": 0,
                    "n_second_tokens_parsed": 0,
                    "parse_rate": 0.0,
                    "status": "MISSING_ROOT",
                    "message": f"{center_root} | {offset_root}",
                }
            )
            continue

        time_folders = dataset["time_folders"] or v9_module.common_time_folders(center_root, offset_root)
        if not time_folders:
            warnings.append(f"{dataset['name']} 没有找到中心/偏移共有时间文件夹。")

        for time_name in time_folders:
            center_dir = center_root / time_name
            offset_dir = offset_root / time_name
            if not center_dir.exists() or not offset_dir.exists():
                rows.append(
                    {
                        "scene": scene_cfg["scene"],
                        "dataset": dataset["name"],
                        "label": dataset["label"],
                        "time": time_name,
                        "center_root_exists": int(center_dir.exists()),
                        "offset_root_exists": int(offset_dir.exists()),
                        "n_centers": 0,
                        "n_offset_combos": 0,
                        "n_second_tokens_parsed": 0,
                        "parse_rate": 0.0,
                        "status": "MISSING_TIME_DIR",
                        "message": f"{center_dir} | {offset_dir}",
                    }
                )
                continue

            center_files = v9_module.detect_center_files(center_dir)
            offset_files = v9_module.parse_offset_files(offset_dir)
            representative_paths = [paths[0] for paths in center_files.values() if paths]
            parsed_count = 0
            parsed_examples: List[str] = []
            for path in representative_paths:
                parsed = v10_module.parse_second_from_center_file(str(path))
                if parsed is not None:
                    parsed_count += 1
                    if len(parsed_examples) < 5:
                        parsed_examples.append(
                            f"{Path(path).name}->{parsed['parsed_time_token']}"
                        )
            n_centers = len(center_files)
            rate = parsed_count / max(n_centers, 1)
            status = "OK" if n_centers > 0 and len(offset_files) > 0 else "EMPTY"
            rows.append(
                {
                    "scene": scene_cfg["scene"],
                    "dataset": dataset["name"],
                    "label": dataset["label"],
                    "time": time_name,
                    "center_root_exists": 1,
                    "offset_root_exists": 1,
                    "n_centers": n_centers,
                    "n_offset_combos": len(offset_files),
                    "n_second_tokens_parsed": parsed_count,
                    "parse_rate": rate,
                    "status": status,
                    "message": " | ".join(parsed_examples),
                }
            )
            if n_centers and rate < 0.8:
                warnings.append(
                    f"{dataset['name']}/{time_name} 的00_00秒标记解析率仅{rate:.1%}；"
                    "v9仍可运行，但秒编号报告可能不完整。"
                )

    df = pd.DataFrame(rows)
    return df, warnings


def print_preflight(scene_name: str, df: pd.DataFrame, warnings: Sequence[str]) -> None:
    print("\n" + "=" * 100)
    print(f"预解析场景: {scene_name}")
    print("=" * 100)
    if df.empty:
        print("没有原始目录预解析记录。")
    else:
        show = [
            c for c in [
                "dataset", "label", "time", "n_centers", "n_offset_combos",
                "n_second_tokens_parsed", "parse_rate", "status", "message"
            ] if c in df.columns
        ]
        print(df[show].to_string(index=False))
    for warning in warnings:
        print("[警告]", warning)


def run_v9_for_scene(
    scene_cfg: Dict[str, Any],
    v9_module,
    reference_v9_config,
    global_cfg: Dict[str, Any],
) -> Dict[str, Path]:
    if not scene_cfg["datasets"]:
        raise ValueError(
            f"{scene_cfg['name']} 没有datasets，无法生成v9结果。"
            "请配置原始目录，或把run_v9设为false并提供已有v9_result_dir。"
        )
    v9_dir = scene_cfg["v9_result_dir"]
    ensure_dir(v9_dir)
    run_config = replace(
        reference_v9_config,
        save_residual_npz=True,
        save_diagnostic_plots=global_cfg["save_diagnostic_plots"],
        diagnostic_plot_limit=global_cfg["diagnostic_plot_limit"],
    )
    return v9_module.process_all_datasets(scene_cfg["datasets"], v9_dir, run_config)


def aggregate_component_summary(df: pd.DataFrame, threshold: float) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame()
    rows: List[Dict[str, Any]] = []
    components = ["margin_spectral", "margin_temporal", "margin_spatial", "similarity_margin"]
    for (scene, label), sub in df.groupby(["scene", "true_label"], dropna=False):
        row: Dict[str, Any] = {
            "scene": scene,
            "true_label": label,
            "n_samples": len(sub),
        }
        for col in components:
            if col not in sub.columns:
                continue
            values = pd.to_numeric(sub[col], errors="coerce")
            row[f"{col}_median"] = float(values.median())
            row[f"{col}_mean"] = float(values.mean())
            compare_threshold = threshold if col == "similarity_margin" else 0.0
            row[f"{col}_positive_rate"] = float((values >= compare_threshold).mean())
        rows.append(row)
    return pd.DataFrame(rows)


def add_scene_diagnostics(summary: pd.DataFrame, threshold: float) -> pd.DataFrame:
    if summary.empty:
        return summary
    out = summary.copy()
    out["frozen_threshold"] = threshold
    out["true_median_on_true_side"] = (
        pd.to_numeric(out["true_margin_median"], errors="coerce") >= threshold
    ).astype(int)
    out["false_median_on_false_side"] = (
        pd.to_numeric(out["false_margin_median"], errors="coerce") < threshold
    ).astype(int)
    out["median_direction_consistent"] = (
        (out["true_median_on_true_side"] == 1)
        & (out["false_median_on_false_side"] == 1)
    ).astype(int)
    return out


def save_cross_scene_plots(output_root: Path, all_df: pd.DataFrame, component_df: pd.DataFrame) -> List[Path]:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception as exc:
        print(f"[警告] matplotlib不可用，跳过v11汇总图: {exc}")
        return []

    paths: List[Path] = []
    fig_dir = output_root / "figures"
    ensure_dir(fig_dir)

    if not all_df.empty and "similarity_margin" in all_df.columns:
        scenes = sorted(all_df["scene"].astype(str).unique())
        labels = ["FALSE_LEAK", "TRUE_LEAK"]
        x_positions: List[float] = []
        values: List[float] = []
        tick_positions: List[float] = []
        tick_labels: List[str] = []
        pos = 0.0
        for scene in scenes:
            for label in labels:
                sub = all_df[(all_df["scene"].astype(str) == scene) & (all_df["true_label"] == label)]
                vals = pd.to_numeric(sub["similarity_margin"], errors="coerce").dropna().to_numpy()
                x_positions.extend([pos] * len(vals))
                values.extend(vals.tolist())
                tick_positions.append(pos)
                tick_labels.append(f"{scene}\n{label[:1]}")
                pos += 1.0
            pos += 0.5
        if values:
            plt.figure(figsize=(max(10, len(tick_labels) * 1.2), 5.5))
            jitter = np.linspace(-0.12, 0.12, max(len(values), 1))
            # 使用确定性轻微抖动，避免点完全重叠。
            plt.scatter(np.asarray(x_positions) + jitter[: len(values)], values, alpha=0.8)
            plt.axhline(0.0, linestyle="--", linewidth=1)
            plt.xticks(tick_positions, tick_labels)
            plt.ylabel("Similarity margin")
            plt.title("Frozen A fingerprint: external scene margins")
            plt.grid(True, axis="y", alpha=0.3)
            plt.tight_layout()
            path = fig_dir / "v11_external_margin_by_scene.png"
            plt.savefig(path, dpi=170)
            plt.close()
            paths.append(path)

    if not component_df.empty:
        median_cols = [
            "margin_spectral_median",
            "margin_temporal_median",
            "margin_spatial_median",
            "similarity_margin_median",
        ]
        available = [c for c in median_cols if c in component_df.columns]
        if available:
            plot_df = component_df.copy()
            plot_df["group"] = plot_df["scene"].astype(str) + "|" + plot_df["true_label"].astype(str).str[0]
            x = np.arange(len(plot_df))
            width = 0.8 / max(len(available), 1)
            plt.figure(figsize=(max(11, len(plot_df) * 1.0), 5.8))
            for idx, col in enumerate(available):
                offset = (idx - (len(available) - 1) / 2.0) * width
                plt.bar(x + offset, plot_df[col], width=width, label=col.replace("_median", ""))
            plt.axhline(0.0, linestyle="--", linewidth=1)
            plt.xticks(x, plot_df["group"], rotation=35, ha="right")
            plt.ylabel("Median margin")
            plt.title("Spectral / temporal / spatial margin medians")
            plt.grid(True, axis="y", alpha=0.3)
            plt.legend()
            plt.tight_layout()
            path = fig_dir / "v11_component_margin_medians.png"
            plt.savefig(path, dpi=170)
            plt.close()
            paths.append(path)
    return paths


def make_v11_report(
    output_root: Path,
    reference_fingerprint: Path,
    reference_v9_config: Path,
    scene_summary: pd.DataFrame,
    component_summary: pd.DataFrame,
    failures: pd.DataFrame,
    threshold: float,
) -> Path:
    lines: List[str] = []
    lines.append("v11 多场景冻结指纹外部验证报告")
    lines.append("=" * 96)
    lines.append(f"A场景冻结指纹: {reference_fingerprint}")
    lines.append(f"A场景v9参数: {reference_v9_config}")
    lines.append(f"冻结Margin阈值: {threshold:.8f}")
    lines.append("")
    lines.append("原则:")
    lines.append("  1. B/C场景未参与原型建立、权重调整或阈值选择。")
    lines.append("  2. 所有新场景使用A场景v9_run_config.json中的同一套残差参数。")
    lines.append("  3. 先看频谱/时间/空间分项Margin，再看总准确率。")
    lines.append("")

    if scene_summary.empty:
        lines.append("没有生成可汇总的带标签外部结果。")
    else:
        lines.append("各外部scene结果:")
        for _, row in scene_summary.iterrows():
            auc = row.get("margin_auc", np.nan)
            lines.append(
                f"  {row['scene']}: n={int(row['n_samples'])}, "
                f"balanced_accuracy={safe_float(row.get('balanced_accuracy')):.4f}, "
                f"AUC={auc if np.isfinite(safe_float(auc)) else 'NA'}, "
                f"TRUE_margin_median={safe_float(row.get('true_margin_median')):.6f}, "
                f"FALSE_margin_median={safe_float(row.get('false_margin_median')):.6f}, "
                f"median_direction_consistent={int(row.get('median_direction_consistent', 0))}"
            )
        lines.append("")

    if not component_summary.empty:
        lines.append("分项Margin中位数:")
        for _, row in component_summary.iterrows():
            lines.append(
                f"  {row['scene']} / {row['true_label']}: "
                f"spectral={safe_float(row.get('margin_spectral_median')):.6f}, "
                f"temporal={safe_float(row.get('margin_temporal_median')):.6f}, "
                f"spatial={safe_float(row.get('margin_spatial_median')):.6f}, "
                f"overall={safe_float(row.get('similarity_margin_median')):.6f}"
            )
        lines.append("")

    if not failures.empty:
        lines.append("失败场景:")
        for _, row in failures.iterrows():
            lines.append(f"  {row.get('scene', '')}: {row.get('error_type', '')}: {row.get('error', '')}")
        lines.append("")

    lines.append("解释建议:")
    lines.append("  - B的T正、F负：A指纹第一次跨场景通过；若参数未改，继续盲测C。")
    lines.append("  - 频谱正但空间负：声谱可能稳定，定位/反射或波束宽度发生变化。")
    lines.append("  - 全部样本同向：A的FALSE原型可能只代表A场景干扰，不能覆盖新场景。")
    lines.append("  - B用于开发时可以分析失败原因；C作为最终验证时不要根据C重新调参。")

    path = output_root / "v11_cross_scene_report.txt"
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


def run_pipeline(config_path: Path) -> Dict[str, Path]:
    base_dir = config_path.resolve().parent
    raw = read_json(config_path)
    cfg = validate_top_config(raw, base_dir)
    output_root: Path = cfg["output_root"]
    ensure_dir(output_root)

    v9_module = load_python_module(SCRIPT_DIR / V9_MODULE_FILE, "v11_v9_module")
    v10_module = load_python_module(SCRIPT_DIR / V10_MODULE_FILE, "v11_v10_module")

    reference_fingerprint: Path = cfg["reference_fingerprint"]
    reference_v9_config_path: Path = cfg["reference_v9_config"]
    if not reference_fingerprint.exists():
        raise FileNotFoundError(f"找不到A冻结指纹: {reference_fingerprint}")
    if not reference_v9_config_path.exists():
        raise FileNotFoundError(f"找不到A的v9_run_config.json: {reference_v9_config_path}")

    bundle = v10_module.load_reference_bundle(reference_fingerprint)
    reference_v9_config, reference_v9_values = load_reference_v9_config(
        v9_module, reference_v9_config_path
    )
    reference_algo = config_algorithm_subset(reference_v9_values)

    normalized_scenes = [
        normalize_scene_config(x, base_dir, output_root)
        for x in cfg["scenes"]
    ]
    normalized_scenes = [x for x in normalized_scenes if x["enabled"]]
    if not normalized_scenes:
        raise ValueError("没有启用的外部scene")

    all_preflight: List[pd.DataFrame] = []
    all_results: List[pd.DataFrame] = []
    config_checks: List[pd.DataFrame] = []
    scene_failures: List[Dict[str, Any]] = []

    print("=" * 100)
    print("v11 第二阶段：冻结A指纹，多场景外部验证")
    print("=" * 100)
    print("A冻结指纹:", reference_fingerprint)
    print("A参考scene:", bundle.reference_scene)
    print("冻结阈值:", bundle.threshold)
    print("外部scene数量:", len(normalized_scenes))

    for scene_cfg in normalized_scenes:
        scene_name = scene_cfg["name"]
        try:
            preflight_df, preflight_warnings = preflight_raw_scene(
                scene_cfg, v9_module, v10_module
            )
            print_preflight(scene_name, preflight_df, preflight_warnings)
            if not preflight_df.empty:
                all_preflight.append(preflight_df)

            complete, reason = v9_result_is_complete(scene_cfg["v9_result_dir"])
            print(f"\n[{scene_name}] 现有v9结果检查: {reason}")

            should_run_v9 = cfg["run_v9"] and not (
                cfg["skip_v9_if_complete"] and complete
            )
            if should_run_v9:
                print(f"[{scene_name}] 使用A冻结参数运行v9……")
                run_v9_for_scene(
                    scene_cfg, v9_module, reference_v9_config, cfg
                )
            elif not complete:
                raise RuntimeError(
                    f"v9结果不完整且run_v9=false: {reason}"
                )
            else:
                print(f"[{scene_name}] 跳过v9，使用已有完整结果。")

            check_df = compare_v9_configs(
                reference_algo,
                scene_cfg["v9_result_dir"] / "v9_run_config.json",
            )
            check_df.insert(0, "scene", scene_cfg["scene"])
            config_checks.append(check_df)
            mismatches = check_df[check_df["match"] == 0]
            if not mismatches.empty:
                mismatch_keys = mismatches["parameter"].astype(str).tolist()
                raise RuntimeError(
                    "外部v9参数与A不一致，停止该场景验证: " + ", ".join(mismatch_keys)
                )

            print(f"[{scene_name}] 使用A冻结指纹运行v10 external……")
            v10_module.run_external_mode(
                scene_cfg["v9_result_dir"],
                scene_cfg["v10_output_dir"],
                reference_fingerprint,
            )
            result_path = scene_cfg["v10_output_dir"] / "v10_external_similarity.csv"
            result_df = pd.read_csv(result_path)
            result_df["v11_scene_name"] = scene_name
            result_df["v11_purpose"] = scene_cfg["purpose"]
            all_results.append(result_df)

        except Exception as exc:
            scene_failures.append(
                {
                    "scene": scene_cfg.get("scene", scene_name),
                    "name": scene_name,
                    "error_type": type(exc).__name__,
                    "error": str(exc),
                    "traceback": traceback.format_exc(),
                }
            )
            print(f"\n[{scene_name}] 失败: {type(exc).__name__}: {exc}")
            if not cfg["continue_after_scene_failure"]:
                raise

    preflight_all = pd.concat(all_preflight, ignore_index=True) if all_preflight else pd.DataFrame()
    all_df = pd.concat(all_results, ignore_index=True) if all_results else pd.DataFrame()
    check_all = pd.concat(config_checks, ignore_index=True) if config_checks else pd.DataFrame()
    failure_df = pd.DataFrame(scene_failures)

    preflight_path = output_root / "v11_raw_file_preflight.csv"
    all_path = output_root / "v11_all_external_similarity.csv"
    config_check_path = output_root / "v11_v9_parameter_consistency.csv"
    failure_path = output_root / "v11_scene_failures.csv"
    preflight_all.to_csv(preflight_path, index=False, encoding="utf-8-sig")
    all_df.to_csv(all_path, index=False, encoding="utf-8-sig")
    check_all.to_csv(config_check_path, index=False, encoding="utf-8-sig")
    failure_df.to_csv(failure_path, index=False, encoding="utf-8-sig")

    scene_summary = v10_module.summarize_similarity_results(
        all_df,
        pred_col="pred_frozen_threshold",
        group_col="scene",
    ) if not all_df.empty else pd.DataFrame()
    scene_summary = add_scene_diagnostics(scene_summary, bundle.threshold)
    scene_summary_path = output_root / "v11_scene_summary.csv"
    scene_summary.to_csv(scene_summary_path, index=False, encoding="utf-8-sig")

    component_summary = aggregate_component_summary(all_df, bundle.threshold)
    component_path = output_root / "v11_component_margin_summary.csv"
    component_summary.to_csv(component_path, index=False, encoding="utf-8-sig")

    hardest_path = output_root / "v11_hardest_samples.csv"
    if not all_df.empty and "similarity_margin" in all_df.columns:
        hardest = all_df.copy()
        hardest["distance_to_frozen_threshold"] = (
            pd.to_numeric(hardest["similarity_margin"], errors="coerce") - bundle.threshold
        ).abs()
        hardest = hardest.sort_values("distance_to_frozen_threshold").head(50)
    else:
        hardest = pd.DataFrame()
    hardest.to_csv(hardest_path, index=False, encoding="utf-8-sig")

    save_cross_scene_plots(output_root, all_df, component_summary)
    report_path = make_v11_report(
        output_root,
        reference_fingerprint,
        reference_v9_config_path,
        scene_summary,
        component_summary,
        failure_df,
        bundle.threshold,
    )

    print("\n" + "=" * 100)
    print("v11 全部完成")
    print("=" * 100)
    print("全部逐样本结果:", all_path)
    print("各场景汇总:", scene_summary_path)
    print("频谱/时间/空间分项:", component_path)
    print("最接近阈值样本:", hardest_path)
    print("v9参数一致性:", config_check_path)
    print("失败场景:", failure_path)
    print("报告:", report_path)

    return {
        "all": all_path,
        "summary": scene_summary_path,
        "component": component_path,
        "hardest": hardest_path,
        "preflight": preflight_path,
        "config_check": config_check_path,
        "failures": failure_path,
        "report": report_path,
    }


def make_synthetic_v9_dir(v10_module, root: Path, scene: str, shift: float, seed: int) -> Path:
    rng = np.random.default_rng(seed)
    v9_dir = root / scene / "v9_results"
    residual_dir = v9_dir / "residual_npz"
    ensure_dir(residual_dir)
    rows: List[Dict[str, Any]] = []
    for label in ["TRUE_LEAK", "FALSE_LEAK"]:
        for second_index in range(15):
            token = f"{second_index // 60:02d}_{second_index % 60:02d}"
            sample_id = f"{scene}_{label}_center_{second_index}"
            npz_path = residual_dir / f"{v10_module.safe_slug(sample_id)}.npz"
            v10_module._synthetic_sample_npz(npz_path, label, rng, shift)
            rows.append(
                {
                    "sample_id": sample_id,
                    "dataset": f"{scene}_{label}",
                    "scene": scene,
                    "time": f"{scene}_recording",
                    "center": str(second_index),
                    "center_file": str(root / f"raw_{scene}_{label}_{token}_beamform_result.wav"),
                    "label": label,
                }
            )
    pd.DataFrame(rows).to_csv(v9_dir / "v9_all_features.csv", index=False, encoding="utf-8-sig")
    return v9_dir


def run_self_test() -> None:
    v9_module = load_python_module(SCRIPT_DIR / V9_MODULE_FILE, "v11_self_v9")
    v10_module = load_python_module(SCRIPT_DIR / V10_MODULE_FILE, "v11_self_v10")
    with tempfile.TemporaryDirectory(prefix="v11_self_test_") as tmp:
        root = Path(tmp)
        a_v9 = make_synthetic_v9_dir(v10_module, root, "factory_A", 0.0, 11)
        b_v9 = make_synthetic_v9_dir(v10_module, root, "factory_B", 1200.0, 22)
        c_v9 = make_synthetic_v9_dir(v10_module, root, "factory_C", -1000.0, 33)

        a_v10 = root / "factory_A" / "v10_reference"
        paths = v10_module.run_all_mode(a_v9, a_v10, "factory_A", v10_module.V10Config())

        ref_v9_values = {
            f.name: getattr(v9_module.V9Config(), f.name)
            for f in fields(v9_module.V9Config)
        }
        ref_v9_values["residual_thresholds_db"] = list(ref_v9_values["residual_thresholds_db"])
        ref_v9_config = root / "factory_A" / "v9_run_config.json"
        write_json(ref_v9_config, {"config": ref_v9_values, "datasets": []})
        for v9_dir in [b_v9, c_v9]:
            write_json(v9_dir / "v9_run_config.json", {"config": ref_v9_values, "datasets": []})

        config = {
            "reference_fingerprint": str(paths["bundle"]),
            "reference_v9_config": str(ref_v9_config),
            "output_root": str(root / "v11_results"),
            "run_v9": False,
            "skip_v9_if_complete": True,
            "save_diagnostic_plots": False,
            "continue_after_scene_failure": False,
            "scenes": [
                {
                    "name": "factory_B",
                    "scene": "factory_B",
                    "v9_result_dir": str(b_v9),
                    "v10_output_dir": str(root / "factory_B" / "v10_external"),
                    "datasets": [],
                },
                {
                    "name": "factory_C",
                    "scene": "factory_C",
                    "v9_result_dir": str(c_v9),
                    "v10_output_dir": str(root / "factory_C" / "v10_external"),
                    "datasets": [],
                },
            ],
        }
        config_path = root / "v11_test_config.json"
        write_json(config_path, config)
        outputs = run_pipeline(config_path)
        summary = pd.read_csv(outputs["summary"])
        if len(summary) != 2:
            raise AssertionError(f"自检场景数错误: {len(summary)}")
        if float(summary["balanced_accuracy"].min()) < 0.80:
            raise AssertionError("自检外部平衡准确率过低")
        print("\nV11自检通过：多场景冻结指纹流程、参数一致性和汇总输出均正常。")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="v11 多场景冻结指纹外部验证")
    parser.add_argument(
        "--config",
        default=str(DEFAULT_CONFIG),
        help="v11 JSON配置文件",
    )
    parser.add_argument("--self-test", action="store_true", help="运行合成数据自检")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.self_test:
        run_self_test()
        return
    run_pipeline(Path(args.config))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n用户中止。")
        sys.exit(130)
    except Exception as exc:
        print(f"\n[程序失败] {type(exc).__name__}: {exc}")
        print(traceback.format_exc())
        sys.exit(1)
