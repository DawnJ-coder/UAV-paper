# -*- coding: utf-8 -*-
r"""
为每个文件的每个 center 样本，分别绘制一张“外圈40点空间影响权重热力图”。

默认绘制的权重：
    plane_absolute_influence_percent

它表示：
    每个外圈点对中心位置背景平面预测的实际影响，占外圈40点总影响的百分比。

推荐运行（直接读取 v9 输出）：
python plot_each_center_outer40_heatmap.py ^
  --v9-root "D:\wurenji\v9_ABCD_outer40_results" ^
  --output-dir "D:\wurenji\outer40_each_center_heatmaps"

也可以读取 v13 raw/plane 结果根目录：
python plot_each_center_outer40_heatmap.py ^
  --v13-result-root "D:\wurenji\v13_AB_train_CD_test_outer40_results" ^
  --output-dir "D:\wurenji\outer40_each_center_heatmaps"

说明：
1. plane 方法真实使用外圈40点拟合背景，因此这些权重会影响 plane 残差。
2. raw 方法直接使用中心点，不减背景，因此外圈40点权重不参与 raw 结果。
3. 所以本程序只画一套“plane实际影响权重图”，不会重复生成内容相同的 raw 图。
"""
from __future__ import annotations

import argparse
import sys
import tempfile
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import Normalize
    plt.rcParams["font.sans-serif"] = [
        "Microsoft YaHei", "SimHei", "Noto Sans CJK SC",
        "Arial Unicode MS", "DejaVu Sans",
    ]
    plt.rcParams["axes.unicode_minus"] = False
except Exception as exc:
    raise RuntimeError("缺少 matplotlib，请运行：pip install matplotlib") from exc


EPS = 1.0e-12
OUTER_ROLE = "USED_OUTER_40"
INNER_ROLE = "EXCLUDED_INNER_24"
CENTER_ROLE = "CENTER"

METRICS = {
    "influence": {
        "column": "plane_absolute_influence_percent",
        "title": "外圈40点对中心背景估计的实际影响权重",
        "colorbar": "实际影响权重 (%)",
        "suffix": "plane_influence_heatmap",
    },
    "robust": {
        "column": "robust_fit_weight_percent",
        "title": "外圈40点的鲁棒拟合权重",
        "colorbar": "鲁棒拟合权重 (%)",
        "suffix": "robust_weight_heatmap",
    },
}


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def safe_slug(value: object, max_len: int = 180) -> str:
    text = str(value).strip() or "unknown"
    chars: List[str] = []
    for char in text:
        chars.append(char if (char.isalnum() or char in "-_.") else "_")
    result = "".join(chars).strip("._")
    return (result or "unknown")[:max_len]


def first_nonempty(values: pd.Series, default: str = "") -> str:
    for value in values:
        if pd.notna(value) and str(value).strip():
            return str(value).strip()
    return default


def normalize_label(value: object) -> str:
    text = str(value).strip().upper()
    mapping = {
        "T": "TRUE_LEAK",
        "TRUE": "TRUE_LEAK",
        "TRUE_LEAK": "TRUE_LEAK",
        "1": "TRUE_LEAK",
        "F": "FALSE_LEAK",
        "FALSE": "FALSE_LEAK",
        "FALSE_LEAK": "FALSE_LEAK",
        "0": "FALSE_LEAK",
    }
    return mapping.get(text, text or "UNKNOWN_LABEL")


def require_columns(df: pd.DataFrame, columns: Sequence[str], source: Path) -> None:
    missing = [column for column in columns if column not in df.columns]
    if missing:
        raise ValueError(f"{source} 缺少必要列：{missing}")


def infer_role(df: pd.DataFrame) -> pd.Series:
    """兼容不同版本的权重表。"""
    if "role" in df.columns:
        role = df["role"].astype(str).str.strip()
    else:
        role = pd.Series([""] * len(df), index=df.index, dtype=object)

    if "used_for_background" in df.columns:
        used = pd.to_numeric(df["used_for_background"], errors="coerce").fillna(0).astype(int)
        role = role.where(role.ne(""), np.where(used.eq(1), OUTER_ROLE, ""))
    else:
        used = pd.Series(np.zeros(len(df), dtype=int), index=df.index)

    if "distance_cm" in df.columns:
        distance = pd.to_numeric(df["distance_cm"], errors="coerce")
        role = role.where(role.ne(""), np.where(distance.fillna(np.inf).abs() <= EPS, CENTER_ROLE, INNER_ROLE))
    else:
        role = role.where(role.ne(""), INNER_ROLE)

    return role


def read_weight_csv(path: Path, default_scene: str = "") -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"找不到权重文件：{path}")

    df = pd.read_csv(path, dtype={"sample_id": str, "point_id": str})
    require_columns(
        df,
        [
            "sample_id",
            "x_cm",
            "y_cm",
            "plane_absolute_influence_percent",
            "robust_fit_weight_percent",
        ],
        path,
    )

    if "point_id" not in df.columns:
        if "point_index" in df.columns:
            df["point_id"] = "point_" + pd.to_numeric(
                df["point_index"], errors="coerce"
            ).fillna(-1).astype(int).astype(str)
        else:
            df["point_id"] = "point_" + df.groupby("sample_id").cumcount().astype(str)

    if "scene" not in df.columns:
        df["scene"] = default_scene or path.parent.name
    else:
        df["scene"] = df["scene"].fillna("").astype(str)
        df.loc[df["scene"].str.strip().eq(""), "scene"] = default_scene or path.parent.name

    for column in [
        "x_cm",
        "y_cm",
        "distance_cm",
        "point_band_db",
        "plane_absolute_influence_percent",
        "robust_fit_weight_percent",
        "plane_influence_coefficient_signed",
        "robust_fit_weight_raw",
        "influence_rank_within_outer40",
        "used_for_background",
    ]:
        if column not in df.columns:
            df[column] = np.nan
        df[column] = pd.to_numeric(df[column], errors="coerce")

    df["role"] = infer_role(df)
    df["_source_weight_csv"] = str(path)
    return df


def merge_scene_metadata(weights: pd.DataFrame, scene_dir: Path) -> pd.DataFrame:
    """将 label、time、center、center_file 等信息合并到权重表。"""
    candidates = [
        scene_dir / "v9_all_features.csv",
        scene_dir / "methods" / "plane" / "v9_method_features.csv",
        scene_dir / "methods" / "raw" / "v9_method_features.csv",
    ]
    metadata_path = next((path for path in candidates if path.exists()), None)
    if metadata_path is None:
        return weights

    metadata = pd.read_csv(metadata_path, dtype={"sample_id": str, "center": str, "time": str})
    if "sample_id" not in metadata.columns:
        return weights

    keep = [
        column for column in [
            "sample_id", "dataset", "scene", "time", "center", "label",
            "center_file", "offset_dir",
        ]
        if column in metadata.columns
    ]
    metadata = metadata[keep].drop_duplicates("sample_id")
    duplicated = [column for column in keep if column != "sample_id" and column in weights.columns]
    if duplicated:
        metadata = metadata.rename(columns={column: f"_meta_{column}" for column in duplicated})

    merged = weights.merge(metadata, on="sample_id", how="left")
    for column in duplicated:
        meta_column = f"_meta_{column}"
        original = merged[column].fillna("").astype(str)
        replacement = merged[meta_column].fillna("").astype(str)
        merged[column] = original.where(original.str.strip().ne(""), replacement)
        merged.drop(columns=[meta_column], inplace=True)
    return merged


def discover_v9_weight_tables(v9_root: Path) -> pd.DataFrame:
    if not v9_root.exists():
        raise FileNotFoundError(f"v9根目录不存在：{v9_root}")

    if (v9_root / "v9_all_point_weights.csv").exists():
        paths = [v9_root / "v9_all_point_weights.csv"]
    else:
        paths = sorted(v9_root.rglob("v9_all_point_weights.csv"))

    if not paths:
        raise FileNotFoundError(
            f"{v9_root} 下没有找到 v9_all_point_weights.csv"
        )

    frames: List[pd.DataFrame] = []
    for path in paths:
        scene_dir = path.parent
        frame = read_weight_csv(path, default_scene=scene_dir.name)
        frame = merge_scene_metadata(frame, scene_dir)
        frames.append(frame)

    return pd.concat(frames, ignore_index=True)


def discover_scene_dirs(scene_dirs: Sequence[Path]) -> pd.DataFrame:
    """读取用户明确指定的多个 factory 场景目录。"""
    frames: List[pd.DataFrame] = []
    for scene_dir in scene_dirs:
        path = scene_dir / "v9_all_point_weights.csv"
        if not path.exists():
            raise FileNotFoundError(f"场景目录缺少 v9_all_point_weights.csv：{scene_dir}")
        frame = read_weight_csv(path, default_scene=scene_dir.name)
        frame = merge_scene_metadata(frame, scene_dir)
        frames.append(frame)
    if not frames:
        raise ValueError("--scene-dirs 至少需要一个场景目录")
    return pd.concat(frames, ignore_index=True)


def discover_v13_weight_tables(result_root: Path) -> pd.DataFrame:
    """
    只读取 plane 目录，避免 raw/plane 各存一份相同权重而重复绘图。
    """
    candidates = [
        result_root / "plane" / "train_AB" / "v13_train_all_point_weights.csv",
        result_root / "plane" / "test_CD" / "v13_external_test_all_point_weights.csv",
    ]
    existing = [path for path in candidates if path.exists()]
    if not existing:
        raise FileNotFoundError(
            "没有找到v13的plane权重文件。期望路径之一：\n"
            + "\n".join(str(path) for path in candidates)
        )

    frames: List[pd.DataFrame] = []
    for path in existing:
        stage = "AB_TRAIN" if "train_AB" in path.parts else "CD_TEST"
        frame = read_weight_csv(path)
        frame["stage"] = stage
        frames.append(frame)
    return pd.concat(frames, ignore_index=True)


def discover_input(
    v9_root: Optional[Path],
    scene_dirs: Optional[Sequence[Path]],
    v13_result_root: Optional[Path],
    weights_csv: Optional[Path],
) -> pd.DataFrame:
    provided = [
        v9_root is not None,
        bool(scene_dirs),
        v13_result_root is not None,
        weights_csv is not None,
    ]
    if sum(provided) != 1:
        raise ValueError(
            "请且只提供一个输入：--v9-root、--scene-dirs、"
            "--v13-result-root 或 --weights-csv"
        )

    if v9_root is not None:
        return discover_v9_weight_tables(v9_root)
    if scene_dirs:
        return discover_scene_dirs(scene_dirs)
    if v13_result_root is not None:
        return discover_v13_weight_tables(v13_result_root)
    assert weights_csv is not None
    return read_weight_csv(weights_csv, default_scene=weights_csv.parent.name)


def sample_metadata(group: pd.DataFrame) -> Dict[str, str]:
    result: Dict[str, str] = {}
    for column in [
        "scene", "stage", "dataset", "label", "time", "center",
        "center_file", "offset_dir", "sample_id",
    ]:
        result[column] = first_nonempty(group[column], "") if column in group.columns else ""
    result["label"] = normalize_label(result.get("label", ""))
    return result


def validate_sample(group: pd.DataFrame, sample_id: str) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    clean = group.copy()
    clean = clean[np.isfinite(clean["x_cm"]) & np.isfinite(clean["y_cm"])].copy()
    clean = clean.drop_duplicates(["point_id", "x_cm", "y_cm"], keep="first")

    center = clean[clean["role"].astype(str).eq(CENTER_ROLE)].copy()
    inner = clean[clean["role"].astype(str).eq(INNER_ROLE)].copy()
    outer = clean[
        clean["role"].astype(str).eq(OUTER_ROLE)
        | pd.to_numeric(clean["used_for_background"], errors="coerce").fillna(0).eq(1)
    ].copy()

    if center.empty:
        distance = np.hypot(clean["x_cm"], clean["y_cm"])
        center = clean.loc[[distance.idxmin()]].copy()

    if outer.empty:
        raise ValueError(f"sample_id={sample_id} 没有找到外圈背景点")

    return center, inner, outer


def annotation_offset(x: float, y: float) -> Tuple[float, float, str, str]:
    radius = float(np.hypot(x, y))
    if radius <= EPS:
        return 0.0, 8.0, "center", "bottom"
    dx = 8.0 * x / radius
    dy = 8.0 * y / radius
    horizontal = "left" if x >= 0 else "right"
    vertical = "bottom" if y >= 0 else "top"
    return dx, dy, horizontal, vertical


def plot_one_sample(
    group: pd.DataFrame,
    output_path: Path,
    metric_name: str,
    vmin: float,
    vmax: float,
    annotate_points: bool,
) -> Dict[str, object]:
    sample_id = first_nonempty(group["sample_id"], "unknown_sample")
    metadata = sample_metadata(group)
    center, inner, outer = validate_sample(group, sample_id)

    metric_info = METRICS[metric_name]
    value_column = metric_info["column"]
    values = pd.to_numeric(outer[value_column], errors="coerce").fillna(0.0).to_numpy(float)

    fig, ax = plt.subplots(figsize=(12, 10))

    # 内圈24点仅作为位置参照，不参与背景拟合。
    if not inner.empty:
        ax.scatter(
            inner["x_cm"].to_numpy(float),
            inner["y_cm"].to_numpy(float),
            s=36,
            facecolors="none",
            linewidths=0.8,
            alpha=0.45,
            label=f"排除的内圈点（{len(inner)}）",
        )

    norm = Normalize(vmin=vmin, vmax=max(vmax, vmin + EPS))
    scatter = ax.scatter(
        outer["x_cm"].to_numpy(float),
        outer["y_cm"].to_numpy(float),
        c=values,
        norm=norm,
        s=170,
        linewidths=0.7,
        label=f"使用的外圈点（{len(outer)}）",
    )

    center_x = float(center["x_cm"].iloc[0])
    center_y = float(center["y_cm"].iloc[0])
    ax.scatter(
        [center_x],
        [center_y],
        marker="x",
        s=210,
        linewidths=2.2,
        label="当前center",
    )

    if annotate_points:
        rank_column = (
            "influence_rank_within_outer40"
            if metric_name == "influence"
            else None
        )
        for _, row in outer.iterrows():
            x = float(row["x_cm"])
            y = float(row["y_cm"])
            value = float(row[value_column]) if pd.notna(row[value_column]) else 0.0
            point_id = str(row["point_id"])
            rank_text = ""
            if rank_column and rank_column in row and pd.notna(row[rank_column]):
                try:
                    rank = int(float(row[rank_column]))
                    if rank > 0:
                        rank_text = f"  #{rank}"
                except (TypeError, ValueError):
                    pass
            dx, dy, ha, va = annotation_offset(x, y)
            ax.annotate(
                f"{point_id}\n{value:.2f}%{rank_text}",
                xy=(x, y),
                xytext=(dx, dy),
                textcoords="offset points",
                fontsize=6.5,
                ha=ha,
                va=va,
            )

    max_row = outer.iloc[int(np.argmax(values))]
    weight_sum = float(np.sum(values))
    max_weight = float(np.max(values))
    median_weight = float(np.median(values))

    title_lines = [
        f"{metric_info['title']}｜{metadata.get('scene', '')}｜{metadata.get('label', '')}",
        f"sample_id={sample_id}",
    ]
    details = []
    for key, label in [
        ("time", "文件/时间"),
        ("center", "center"),
    ]:
        value = metadata.get(key, "")
        if value:
            details.append(f"{label}={value}")
    if details:
        title_lines.append("｜".join(details))

    center_file = metadata.get("center_file", "")
    if center_file:
        title_lines.append(f"中心文件：{Path(center_file).name}")

    ax.set_title("\n".join(title_lines), fontsize=11)
    ax.set_xlabel("x (cm)")
    ax.set_ylabel("y (cm)")
    ax.set_aspect("equal", adjustable="box")
    ax.grid(True, alpha=0.25)
    ax.legend(loc="upper right", fontsize=8)

    colorbar = fig.colorbar(scatter, ax=ax)
    colorbar.set_label(metric_info["colorbar"])

    summary_text = (
        f"外圈点数：{len(outer)}\n"
        f"权重合计：{weight_sum:.3f}%\n"
        f"最大点：{max_row['point_id']}\n"
        f"最大权重：{max_weight:.3f}%\n"
        f"中位权重：{median_weight:.3f}%"
    )
    ax.text(
        0.015,
        0.015,
        summary_text,
        transform=ax.transAxes,
        fontsize=8,
        va="bottom",
        ha="left",
        bbox={"boxstyle": "round", "alpha": 0.75},
    )

    # 让所有空间点周围留出足够的标注空间。
    all_x = pd.concat([center["x_cm"], inner["x_cm"], outer["x_cm"]]).to_numpy(float)
    all_y = pd.concat([center["y_cm"], inner["y_cm"], outer["y_cm"]]).to_numpy(float)
    max_radius = max(float(np.max(np.abs(all_x))), float(np.max(np.abs(all_y))), 1.0)
    margin = max_radius * 0.30
    ax.set_xlim(float(np.min(all_x)) - margin, float(np.max(all_x)) + margin)
    ax.set_ylim(float(np.min(all_y)) - margin, float(np.max(all_y)) + margin)

    ensure_dir(output_path.parent)
    fig.tight_layout()
    fig.savefig(output_path, dpi=190, bbox_inches="tight")
    plt.close(fig)

    return {
        **metadata,
        "sample_id": sample_id,
        "metric": metric_name,
        "metric_column": value_column,
        "n_all_points": int(len(group)),
        "n_center_points": int(len(center)),
        "n_inner_excluded_points": int(len(inner)),
        "n_outer_used_points": int(len(outer)),
        "outer_weight_sum_percent": weight_sum,
        "outer_weight_median_percent": median_weight,
        "max_influence_point_id": str(max_row["point_id"]),
        "max_influence_point_weight_percent": max_weight,
        "image_path": str(output_path),
    }


def global_metric_limits(weights: pd.DataFrame, metric_names: Sequence[str]) -> Dict[str, Tuple[float, float]]:
    limits: Dict[str, Tuple[float, float]] = {}
    outer = weights[
        weights["role"].astype(str).eq(OUTER_ROLE)
        | pd.to_numeric(weights["used_for_background"], errors="coerce").fillna(0).eq(1)
    ].copy()
    for metric_name in metric_names:
        column = METRICS[metric_name]["column"]
        values = pd.to_numeric(outer[column], errors="coerce")
        values = values[np.isfinite(values)]
        if values.empty:
            limits[metric_name] = (0.0, 1.0)
        else:
            limits[metric_name] = (0.0, max(float(values.max()), EPS))
    return limits


def run(
    weights: pd.DataFrame,
    output_dir: Path,
    metric_names: Sequence[str],
    annotate_points: bool,
    skip_existing: bool,
    max_samples: Optional[int],
) -> Dict[str, Path]:
    ensure_dir(output_dir)

    weights = weights.copy()
    weights["sample_id"] = weights["sample_id"].astype(str)
    if "label" not in weights.columns:
        weights["label"] = "UNKNOWN_LABEL"
    weights["label"] = weights["label"].map(normalize_label)
    if "scene" not in weights.columns:
        weights["scene"] = "unknown_scene"

    groups = list(weights.groupby(["scene", "sample_id"], sort=True, dropna=False))
    if max_samples is not None:
        groups = groups[: max(0, int(max_samples))]

    if not groups:
        raise RuntimeError("没有可绘制的样本")

    limits = global_metric_limits(weights, metric_names)
    index_rows: List[Dict[str, object]] = []
    failures: List[Dict[str, object]] = []

    total = len(groups) * len(metric_names)
    finished = 0
    print(f"共发现 {len(groups)} 个center样本，将生成 {total} 张图。")

    for (scene, sample_id), group in groups:
        metadata = sample_metadata(group)
        label = metadata.get("label", "UNKNOWN_LABEL")
        stage = metadata.get("stage", "")
        for metric_name in metric_names:
            metric_info = METRICS[metric_name]
            subdir_parts = [safe_slug(scene)]
            if stage:
                subdir_parts.append(safe_slug(stage))
            subdir_parts.append(safe_slug(label))
            image_dir = output_dir.joinpath(*subdir_parts)

            center_token = metadata.get("center", "")
            filename_parts = [safe_slug(sample_id)]
            if center_token:
                filename_parts.append("center_" + safe_slug(center_token))
            filename_parts.append(metric_info["suffix"])
            output_path = image_dir / ("__".join(filename_parts) + ".png")

            try:
                if skip_existing and output_path.exists():
                    row = {
                        **metadata,
                        "sample_id": sample_id,
                        "metric": metric_name,
                        "image_path": str(output_path),
                        "status": "SKIPPED_EXISTING",
                    }
                else:
                    vmin, vmax = limits[metric_name]
                    row = plot_one_sample(
                        group=group,
                        output_path=output_path,
                        metric_name=metric_name,
                        vmin=vmin,
                        vmax=vmax,
                        annotate_points=annotate_points,
                    )
                    row["status"] = "OK"
                index_rows.append(row)
            except Exception as exc:
                failures.append({
                    "scene": scene,
                    "sample_id": sample_id,
                    "metric": metric_name,
                    "error": f"{type(exc).__name__}: {exc}",
                })

            finished += 1
            if finished % 20 == 0 or finished == total:
                print(f"  已完成 {finished}/{total}")

    index_path = output_dir / "00_heatmap_image_index.csv"
    failure_path = output_dir / "00_heatmap_failures.csv"
    pd.DataFrame(index_rows).to_csv(index_path, index=False, encoding="utf-8-sig")
    pd.DataFrame(failures).to_csv(failure_path, index=False, encoding="utf-8-sig")

    readme = [
        "每个center的外圈40点空间影响权重热力图",
        "=" * 80,
        "",
        "怎么看图：",
        "1. 黑色×：当前中心点。",
        "2. 灰色空心点：排除的内圈24点，权重为0，不参与背景拟合。",
        "3. 彩色点：实际使用的外圈40点。",
        "4. 点旁数值：该点的影响权重百分比；#1表示该center中影响最大。",
        "5. 所有图使用同一套色条范围，便于不同center之间横向比较。",
        "",
        "默认权重：plane_absolute_influence_percent。",
        "它表示外圈点对中心位置背景平面预测的实际影响比例，40点合计约100%。",
        "",
        "注意：raw不减背景，因此外圈40点权重不参与raw结果；这些热力图对应plane背景拟合。",
        "",
        f"成功/跳过图片：{len(index_rows)}",
        f"失败图片：{len(failures)}",
        f"图片索引：{index_path}",
        f"失败明细：{failure_path}",
    ]
    readme_path = output_dir / "README_怎么看每个center热力图.txt"
    readme_path.write_text("\n".join(readme), encoding="utf-8")

    return {
        "index": index_path,
        "failures": failure_path,
        "readme": readme_path,
    }


def make_synthetic_scene(root: Path) -> Path:
    scene_dir = root / "factory_A"
    ensure_dir(scene_dir)
    rows: List[Dict[str, object]] = []
    meta_rows: List[Dict[str, object]] = []

    directions = np.linspace(0.0, 2.0 * np.pi, 8, endpoint=False)
    radii = np.arange(10.0, 90.0, 10.0)
    coords = [(0.0, 0.0)]
    ids = ["center"]
    for radius in radii:
        for d_idx, angle in enumerate(directions):
            coords.append((radius * np.cos(angle), radius * np.sin(angle)))
            ids.append(f"{radius:g}cm_d{d_idx}")

    rng = np.random.default_rng(42)
    for sample_idx in range(2):
        sample_id = f"factory_A_TRUE_center_{sample_idx}"
        outer_idx = np.arange(25, 65)
        raw = rng.uniform(0.2, 1.0, size=40)
        robust = raw / raw.sum()
        influence = rng.uniform(0.1, 1.0, size=40)
        influence = influence / influence.sum()
        rank_order = np.argsort(influence)[::-1]
        ranks = np.zeros(40, dtype=int)
        ranks[rank_order] = np.arange(1, 41)

        for point_idx, ((x, y), point_id) in enumerate(zip(coords, ids)):
            if point_idx == 0:
                role = CENTER_ROLE
            elif point_idx <= 24:
                role = INNER_ROLE
            else:
                role = OUTER_ROLE
            outer_position = point_idx - 25
            rows.append({
                "sample_id": sample_id,
                "point_index": point_idx,
                "point_id": point_id,
                "x_cm": x,
                "y_cm": y,
                "distance_cm": float(np.hypot(x, y)),
                "role": role,
                "used_for_background": int(role == OUTER_ROLE),
                "robust_fit_weight_percent": 100.0 * robust[outer_position] if role == OUTER_ROLE else 0.0,
                "plane_absolute_influence_percent": 100.0 * influence[outer_position] if role == OUTER_ROLE else 0.0,
                "plane_influence_coefficient_signed": influence[outer_position] if role == OUTER_ROLE else 0.0,
                "influence_rank_within_outer40": ranks[outer_position] if role == OUTER_ROLE else 0,
            })
        meta_rows.append({
            "sample_id": sample_id,
            "dataset": "factory_A_TRUE",
            "scene": "factory_A",
            "time": f"time_{sample_idx}",
            "center": str(sample_idx),
            "label": "TRUE_LEAK",
            "center_file": str(root / f"center_{sample_idx}.wav"),
        })

    pd.DataFrame(rows).to_csv(
        scene_dir / "v9_all_point_weights.csv",
        index=False,
        encoding="utf-8-sig",
    )
    pd.DataFrame(meta_rows).to_csv(
        scene_dir / "v9_all_features.csv",
        index=False,
        encoding="utf-8-sig",
    )
    return root


def self_test() -> None:
    with tempfile.TemporaryDirectory(prefix="outer40_center_heatmap_test_") as tmp:
        root = Path(tmp)
        v9_root = make_synthetic_scene(root / "v9")
        output = root / "figures"
        weights = discover_v9_weight_tables(v9_root)
        paths = run(
            weights=weights,
            output_dir=output,
            metric_names=["influence", "robust"],
            annotate_points=False,
            skip_existing=False,
            max_samples=None,
        )
        index = pd.read_csv(paths["index"])
        if len(index) != 4:
            raise AssertionError(f"预期4张图，实际={len(index)}")
        for image_path in index["image_path"]:
            if not Path(image_path).exists():
                raise AssertionError(f"图片没有生成：{image_path}")
        print("SELF-TEST PASSED")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="为每个文件的每个center绘制外圈40点空间影响权重热力图"
    )
    input_group = parser.add_mutually_exclusive_group()
    input_group.add_argument(
        "--v9-root",
        type=Path,
        help="v9总输出目录，或者单个factory场景目录",
    )
    input_group.add_argument(
        "--scene-dirs",
        type=Path,
        nargs="+",
        help="明确指定一个或多个factory场景目录，例如A、B、C、D四个目录",
    )
    input_group.add_argument(
        "--v13-result-root",
        type=Path,
        help="包含raw/plane/train_AB/test_CD的v13结果根目录",
    )
    input_group.add_argument(
        "--weights-csv",
        type=Path,
        help="直接指定一个v9_all_point_weights.csv或v13权重CSV",
    )

    parser.add_argument("--output-dir", type=Path, help="图片输出目录")
    parser.add_argument(
        "--metric",
        choices=["influence", "robust", "both"],
        default="influence",
        help="influence=实际影响权重；robust=鲁棒拟合权重；both=两种都画",
    )
    parser.add_argument(
        "--no-annotations",
        action="store_true",
        help="不在每个点旁标注点名和权重，可用于快速批量出图",
    )
    parser.add_argument(
        "--skip-existing",
        action="store_true",
        help="如果图片已经存在，则跳过",
    )
    parser.add_argument(
        "--max-samples",
        type=int,
        default=None,
        help="最多绘制多少个center，用于先小规模测试",
    )
    parser.add_argument("--self-test", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    if args.self_test:
        self_test()
        return 0

    if args.output_dir is None:
        raise ValueError("正式运行必须提供 --output-dir")

    weights = discover_input(
        v9_root=args.v9_root,
        scene_dirs=args.scene_dirs,
        v13_result_root=args.v13_result_root,
        weights_csv=args.weights_csv,
    )
    metric_names = ["influence", "robust"] if args.metric == "both" else [args.metric]
    paths = run(
        weights=weights,
        output_dir=args.output_dir,
        metric_names=metric_names,
        annotate_points=not args.no_annotations,
        skip_existing=args.skip_existing,
        max_samples=args.max_samples,
    )

    print("\n绘图完成")
    print("图片索引：", paths["index"])
    print("失败明细：", paths["failures"])
    print("说明文件：", paths["readme"])
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"\n[错误] {type(exc).__name__}: {exc}", file=sys.stderr)
        raise
