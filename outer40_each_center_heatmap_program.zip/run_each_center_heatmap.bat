@echo off
chcp 65001 >nul
setlocal

REM 修改为你自己的v9输出根目录
set "V9_ROOT=D:\wurenji\v9_ABCD_outer40_results"

REM 修改为你想保存图片的位置
set "OUTPUT_DIR=D:\wurenji\outer40_each_center_heatmaps"

python plot_each_center_outer40_heatmap.py ^
  --v9-root "%V9_ROOT%" ^
  --output-dir "%OUTPUT_DIR%" ^
  --metric influence

pause
