# 每个center外圈40点空间权重热力图

## 这张图画什么

每一个 `sample_id / center` 单独生成一张空间图：

- 中心点：`×`
- 内圈24点：空心点，仅作位置参照，权重为0
- 外圈40点：按影响权重着色
- 每个外圈点旁显示：
  - 点名
  - 权重百分比
  - 影响排名

默认画的是：

```text
plane_absolute_influence_percent
```

它最直接表示“这个外圈点对当前center的背景平面估计影响了多少”。

## 推荐运行

假设v9输出根目录为：

```text
D:\wurenji\v9_ABCD_outer40_results
```

运行：

```bat
python plot_each_center_outer40_heatmap.py ^
  --v9-root "D:\wurenji\v9_ABCD_outer40_results" ^
  --output-dir "D:\wurenji\outer40_each_center_heatmaps"
```

程序会自动寻找：

```text
factory_A\v9_all_point_weights.csv
factory_B\v9_all_point_weights.csv
factory_C\v9_all_point_weights.csv
factory_D\v9_all_point_weights.csv
```

## 先测试10个center

```bat
python plot_each_center_outer40_heatmap.py ^
  --v9-root "D:\wurenji\v9_ABCD_outer40_results" ^
  --output-dir "D:\wurenji\outer40_each_center_heatmaps_test" ^
  --max-samples 10
```

## 同时画两种权重

```bat
python plot_each_center_outer40_heatmap.py ^
  --v9-root "D:\wurenji\v9_ABCD_outer40_results" ^
  --output-dir "D:\wurenji\outer40_each_center_heatmaps" ^
  --metric both
```

- `influence`：对中心背景估计的实际影响，推荐
- `robust`：鲁棒平面拟合对该点的信任程度
- `both`：两种都画，每个center会生成两张图

## 从v13结果读取

```bat
python plot_each_center_outer40_heatmap.py ^
  --v13-result-root "D:\wurenji\v13_AB_train_CD_test_outer40_results" ^
  --output-dir "D:\wurenji\outer40_each_center_heatmaps"
```

程序只读取 `plane` 目录的权重，避免raw和plane重复出图。

## 输出

```text
输出目录
├─ factory_A
│  ├─ TRUE_LEAK
│  └─ FALSE_LEAK
├─ factory_B
├─ factory_C
├─ factory_D
├─ 00_heatmap_image_index.csv
├─ 00_heatmap_failures.csv
└─ README_怎么看每个center热力图.txt
```

`00_heatmap_image_index.csv` 可用于按：

- 场景
- TRUE/FALSE
- 时间
- center
- sample_id
- 最大影响点

快速查找图片。

## 为什么不分别生成raw和plane权重图

外圈40点的权重是为了拟合空间背景：

```text
plane = 中心点 - 外圈40点拟合背景
```

所以权重真实影响plane结果。

raw直接使用中心点：

```text
raw = 中心点原始信号
```

raw不使用外圈40点，因此所谓“raw权重图”不会影响raw结果，和plane权重表内容也会重复。


## A、B、C、D目录不在同一个输出根目录时

可以一次明确指定四个场景目录：

```bat
python plot_each_center_outer40_heatmap.py ^
  --scene-dirs ^
    "D:\wurenji\factory_A_v9_results" ^
    "D:\wurenji\factory_B_v9_results" ^
    "D:\wurenji\factory_C_v9_results" ^
    "D:\wurenji\factory_D_v9_results" ^
  --output-dir "D:\wurenji\outer40_each_center_heatmaps"
```
