@echo off
cd /d %~dp0
python AB_lab_raw_plane_group_correlation.py --self-test
pause
