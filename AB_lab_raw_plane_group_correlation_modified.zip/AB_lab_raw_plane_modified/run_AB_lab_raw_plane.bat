@echo off
cd /d %~dp0
python AB_lab_raw_plane_group_correlation.py --config AB_lab_raw_plane_config.json
pause
