AB_lab_raw_plane_group_correlation.py 使用说明
============================================================

一、为什么要修改旧程序
------------------------------------------------------------
旧程序：
1. 默认读取场景根目录 residual_npz，不能自动分别读取 methods/raw 与 methods/plane。
2. residual_variant 不支持 raw。
3. 会把全部实验室 WAV 合成一个总原型，不能输出每个 WAV 与 AB 共同部分的相关性。
4. 不能按 0.1mm、0.5mm 分组输出各自中位数和最大值。

本程序已改为：
1. raw读取：factory_X/methods/raw/residual_npz
2. plane读取：factory_X/methods/plane/residual_npz
3. raw、plane分别计算A和B之间的相似度。
4. 逐个读取0.1mm和0.5mm目录中的所有WAV。
5. 逐WAV计算与AB共同频谱的Pearson相关性。
6. 分别输出0.1mm、0.5mm相关性的中位数和最大值。

二、场景目录要求
------------------------------------------------------------
程序需要：

factory_A
├─ v9_all_features.csv                         推荐保留，包含sample_id和label
├─ methods
│  ├─ raw
│  │  ├─ v9_method_features.csv               可作为元数据备用
│  │  └─ residual_npz
│  └─ plane
│     ├─ v9_method_features.csv               可作为元数据备用
│     └─ residual_npz
└─ v9_all_point_weights.csv

注意：
v9_all_point_weights.csv只有点权重，没有可靠的TRUE/FALSE标签用途。
程序计算A_TRUE-A_FALSE、B_TRUE-B_FALSE时，必须从v9_all_features.csv
或methods/方法/v9_method_features.csv读取sample_id和label。

三、配置路径
------------------------------------------------------------
编辑 AB_lab_raw_plane_config.json：

scene_A.v9_dir = factory_A目录
scene_B.v9_dir = factory_B目录
lab_groups.0.1mm = 0.1mm WAV目录
lab_groups.0.5mm = 0.5mm WAV目录
output_dir = 输出目录

四、运行
------------------------------------------------------------
先自检：
python AB_lab_raw_plane_group_correlation.py --self-test

正式运行：
python AB_lab_raw_plane_group_correlation.py --config AB_lab_raw_plane_config.json

也可以双击 run_AB_lab_raw_plane.bat。

五、主要输出
------------------------------------------------------------
输出目录：

AB_lab_raw_plane_results
├─ raw
│  ├─ AB_similarity_metrics.csv
│  ├─ AB_common_spectrum.csv
│  ├─ lab_wav_correlation_details.csv
│  ├─ lab_group_correlation_summary.csv
│  └─ analysis_report.txt
├─ plane
│  └─ 同上
├─ raw_plane_AB_similarity_comparison.csv
└─ raw_plane_lab_group_correlation_summary.csv

1. raw_plane_AB_similarity_comparison.csv
   raw和plane各一行，包含A/B Pearson、Cosine、Overlap、JS相似度。

2. raw或plane/lab_wav_correlation_details.csv
   每个实验室WAV一行。
   重点列：pearson_correlation_to_AB_common。

3. raw_plane_lab_group_correlation_summary.csv
   raw/plane × 0.1mm/0.5mm，共4行。
   用户要求的主要列：
   pearson_correlation_to_AB_common_median
   pearson_correlation_to_AB_common_max

六、相关性的含义
------------------------------------------------------------
先在A内部计算A_TRUE-A_FALSE，在B内部计算B_TRUE-B_FALSE，
然后取A、B共同支持的正向频谱作为AB共同部分。

对每个实验室WAV切成多个时间段，提取每段频谱，取该WAV各段频谱中位数，
最后计算：
Pearson(AB共同频谱, 单个实验室WAV频谱)

因此一个WAV对应一个相关系数，不会因为长WAV切成很多段而在汇总时重复计数。
