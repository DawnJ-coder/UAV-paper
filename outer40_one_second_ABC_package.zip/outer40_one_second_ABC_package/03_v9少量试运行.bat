﻿@echo off
python v9_ABC_raw_plane_outer40_one_second.py --config v9_ABC_raw_plane_outer40_one_second_config.json --max-centers 2 --no-plots
pause
