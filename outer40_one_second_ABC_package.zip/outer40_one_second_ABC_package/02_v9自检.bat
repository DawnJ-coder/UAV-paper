﻿@echo off
python v9_ABC_raw_plane_outer40_one_second.py --self-test
pause
