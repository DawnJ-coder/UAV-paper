ABC三场景逐秒同步版：v9 + v12 + v13
======================================

固定流程
--------
- factory_A + factory_B：训练冻结模型。
- factory_C：完全独立外部测试。
- 00_00只读取原始WAV的[0,1)秒；00_01只读取[1,2)秒；依此类推。
- 同一center_id的中心点与64个偏移坐标使用完全相同的一秒。

文件
----
1. v9_ABC_raw_plane_outer40_one_second.py：读取A/B/C原始WAV并生成逐秒raw/plane结果。
2. v12_shared_leak_component_discovery.py：v13依赖文件，不单独运行。
3. v13_1_AB_train_C_test_outer40_one_second.py：A+B训练，冻结后只测试C。

运行顺序
--------
1. 编辑 v9_ABC_raw_plane_outer40_one_second_config.json 中6组原始WAV路径。
2. v9自检：
   python v9_ABC_raw_plane_outer40_one_second.py --self-test
3. 少量试运行：
   python v9_ABC_raw_plane_outer40_one_second.py --config v9_ABC_raw_plane_outer40_one_second_config.json --max-centers 2 --no-plots
4. 正式生成A/B/C逐秒结果：
   python v9_ABC_raw_plane_outer40_one_second.py --config v9_ABC_raw_plane_outer40_one_second_config.json --no-plots
5. 检查每个场景的v9_all_features.csv和v9_failures.csv。
6. v13自检：
   python v13_1_AB_train_C_test_outer40_one_second.py --self-test
7. 编辑 v13_1_train_AB_config.json，确认A/B的v9_dir。
8. A+B训练：
   python v13_1_AB_train_C_test_outer40_one_second.py train --config v13_1_train_AB_config.json
9. 编辑 v13_1_test_C_config.json，确认模型路径和C的v9_dir。
10. C外部测试：
   python v13_1_AB_train_C_test_outer40_one_second.py evaluate --config v13_1_test_C_config.json

严格限制
--------
- v9必须且只能配置factory_A、factory_B、factory_C。
- 三个场景都必须同时有TRUE_LEAK和FALSE_LEAK。
- v13训练必须且只能使用A+B，测试必须且只能使用C。
- 旧v9结果和旧v13模型不能继续使用，必须从v9重新生成。
