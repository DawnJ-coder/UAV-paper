﻿@echo off
python v13_1_AB_train_C_test_outer40_one_second.py --self-test
pause
