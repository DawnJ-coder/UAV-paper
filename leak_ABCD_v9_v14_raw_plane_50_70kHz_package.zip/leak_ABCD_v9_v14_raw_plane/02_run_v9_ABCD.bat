@echo off
cd /d "%~dp0"
python v9_ABCD_raw_plane.py --config v9_ABCD_raw_plane_config.json
pause
