@echo off
cd /d "%~dp0"
python v14_ABCD_lab_raw_plane_compare.py --config v14_ABCD_lab_raw_plane_config.json
pause
