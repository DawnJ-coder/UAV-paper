ABCD四场景：v9 raw/plane输出 + v14实验室纯泄漏对照
========================================================

这个版本只保留两个可比较的方法：

1. raw
   直接使用中心点原始功率，不做空间背景相减。

2. plane
   用周围点坐标拟合空间平面 B(x,y)=a+bx+cy，
   用中心预测背景a与中心功率相减，保留正残差。

说明：程序内部仍计算周围点中位数，只用于限制plane异常外推和计算
fit_median_mae_db；它不会作为第三种方法输出，也不会进入v14排名。

一、运行v9
==========

1. 修改 v9_ABCD_raw_plane_config.json 中A/B/C/D的8组路径。
2. 修改output_dir。
3. 双击 02_run_v9_ABCD.bat。

v9输出：

leak_v9_ABCD_raw_plane_results
├─ factory_A
│  ├─ v9_all_features.csv
│  ├─ residual_npz
│  └─ methods
│     ├─ raw/residual_npz
│     └─ plane/residual_npz
├─ factory_B
├─ factory_C
├─ factory_D
└─ v9_ABCD_manifest.json

合并NPZ中的主要字段：
- center_power_db / raw_power
- excess_power_plane
- background_power_db_plane
- residual_db_plane
- plane_valid / plane_geometry_ok
- fit_condition_number
- fit_median_mae_db / fit_plane_mae_db

无后缀 excess_power、background_power_db、residual_db 指向plane，
便于旧程序读取。

二、运行v14
===========

1. 修改 v14_ABCD_lab_raw_plane_config.json：
   - v9_abcd_root：v9输出根目录
   - lab_wavs：实验室真实泄漏WAV
   - output_dir：v14结果目录
2. 双击 03_run_v14_compare.bat。

三、结果只比较raw和plane
=======================

首先看：
1. v14_preflight_method_coverage.csv
   raw和plane在A/B/C/D的coverage应接近1。

2. v14_method_ranking.csv
   重点看：
   - worst_scene_lab_auc
   - worst_pair_transfer_auc
   - positive_lab_gap_scene_count
   - eligible_as_primary

3. v14_method_scene_summary.csv
   检查每个场景的lab_similarity_gap是否为正。

4. v14_pair_transfer_summary.csv
   检查AB→C/D与CD→A/B的迁移AUC。

5. v14_core_spectrum_raw.csv / v14_core_spectrum_plane.csv
   比较最终公共频谱和实验室锚定核心。

判断：
- plane明显优于raw：空间平面降噪有帮助。
- raw明显优于plane：空间相减可能误扣泄漏或引入场景偏差。
- 两者都差：问题不只是选择降噪方法，当前特征本身跨场景不稳定。

四、第一次运行顺序
=================

依次双击：
00_install_dependencies.bat
01_run_self_tests.bat
02_run_v9_ABCD.bat
03_run_v14_compare.bat

自检使用合成数据，不会读取或修改正式数据。

【50-70 kHz 专用修改】
- v9程序固定只保留 50,000-70,000 Hz。
- 50 kHz以下和70 kHz以上在STFT后立即丢弃，不参与raw、plane、特征或残差输出。
- 即使旧v9配置仍写20-80 kHz，程序也会强制使用50-70 kHz。
- v14配置已同步为50-70 kHz，便于后续实验室对比保持同一频带。
