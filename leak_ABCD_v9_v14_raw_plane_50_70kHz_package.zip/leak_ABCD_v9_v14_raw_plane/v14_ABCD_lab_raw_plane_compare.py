# -*- coding: utf-8 -*-
"""
v14_ABCD_lab_raw_plane_compare.py

实验室纯泄漏参考 × raw/plane双方法验证
============================================================

目标
----
本程序不是继续调分类阈值，而是验证：

    raw / plane

哪一种现场残差提取方法，能够同时满足：

    1. 每个场景的 TRUE 比本场景 FALSE 更像实验室纯泄漏；
    2. A、B 得到的共同成分能迁移到 C、D；
    3. C、D 得到的共同成分能迁移到 A、B；
    4. AB共同成分 与 CD共同成分仍有交集；
    5. 最终交集在频谱上也得到实验室纯泄漏参考支持。

完整逻辑
--------
    实验室纯泄漏 WAV
        -> 相同STFT参数
        -> 多个时间片的纯泄漏频谱参考

    A/B/C/D 每个现场样本
        -> 读取v9保存的 raw / plane
        -> 构造归一化频谱和时间包络指纹
        -> 与实验室参考比较

    每个场景内部
        TRUE指纹 - FALSE指纹
        -> 该场景泄漏候选成分

    A与B取共同部分 -> AB共同成分
    C与D取共同部分 -> CD共同成分
    AB与CD再取共同部分 -> ABCD现场公共成分
    ABCD现场公共成分 × 实验室参考 -> 实验室锚定泄漏核心

重要边界
--------
1. 输出的是“跨场景稳定、并受实验室参考支持的泄漏频谱成分”，不是带相位的纯净WAV。
2. 实验室只有一条WAV时，切片只能估计该录音内部波动，不能冒充多个独立实验。
3. 如果实验室和现场使用不同传感器/压力/孔径，频谱可能有偏移，因此程序允许小范围频移对齐。
4. 最终方法推荐不只看平均效果，还看最差场景和AB/CD跨组迁移结果。

运行
----
    python v14_ABCD_lab_raw_plane_compare.py --self-test

    python v14_ABCD_lab_raw_plane_compare.py \
        --config v14_lab_reference_config.json

依赖
----
    pip install numpy pandas scipy scikit-learn matplotlib
"""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import tempfile
import traceback
import wave
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    from scipy import signal
    from scipy.io import wavfile
    from scipy.spatial.distance import jensenshannon
    from scipy.stats import mannwhitneyu, wasserstein_distance
except Exception as exc:
    raise RuntimeError("缺少 scipy，请运行: pip install scipy") from exc

try:
    from sklearn.metrics import balanced_accuracy_score, confusion_matrix, roc_auc_score
except Exception as exc:
    raise RuntimeError("缺少 scikit-learn，请运行: pip install scikit-learn") from exc

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
except Exception as exc:
    raise RuntimeError("缺少 matplotlib，请运行: pip install matplotlib") from exc


# =============================================================================
# 1. 默认配置：也可以全部写入JSON
# =============================================================================

DEFAULT_SCENES = [
    {
        "name": "factory_A",
        "v9_dir": r"C:\Users\jiangxinru6\Desktop\wurenji\factory_A_v9_results",
        "group": "AB",
    },
    {
        "name": "factory_B",
        "v9_dir": r"C:\Users\jiangxinru6\Desktop\wurenji\factory_B_v9_results",
        "group": "AB",
    },
    {
        "name": "factory_C",
        "v9_dir": r"C:\Users\jiangxinru6\Desktop\wurenji\factory_C_v9_results",
        "group": "CD",
    },
    {
        "name": "factory_D",
        "v9_dir": r"C:\Users\jiangxinru6\Desktop\wurenji\factory_D_v9_results",
        "group": "CD",
    },
]

DEFAULT_LAB_WAVS = [
    r"C:\Users\jiangxinru6\Desktop\wurenji\lab_pure_leak.wav",
]

DEFAULT_OUTPUT_DIR = (
    r"C:\Users\jiangxinru6\Desktop\wurenji"
    r"\leak_v14_lab_reference_results"
)


@dataclass(frozen=True)
class Config:
    # 必须和v9使用相同的分析频带和STFT参数。
    freq_low_hz: float = 20_000.0
    freq_high_hz: float = 80_000.0
    nperseg: int = 4096
    hop_length: int = 2048
    nfft: int = 4096

    # 所有频谱插值到统一网格。
    n_spectral_bins: int = 256
    spectral_smooth_bins: int = 7

    # 实验室WAV切片。单条WAV会被切成多个片段，用来估计参考波动。
    lab_segment_seconds: float = 1.0
    lab_segment_hop_seconds: float = 1.0
    lab_min_segment_seconds: float = 0.40

    # 比较方法。
    methods: Tuple[str, ...] = ("raw", "plane")
    max_frequency_shift_hz: float = 1500.0
    wasserstein_scale_hz: float = 5000.0

    # 场景内部TRUE-FALSE稳定频率筛选。
    min_abs_effect: float = 0.35
    min_directional_auc: float = 0.58

    # 实验室软锚定。0表示严格乘实验室频谱；0.25表示保留25%现场共性，
    # 再由实验室频谱增强其余75%。
    lab_anchor_floor: float = 0.25
    lab_strict_quantile: float = 0.60

    # 连续频带提取。
    band_min_bins: int = 3
    band_relative_threshold: float = 0.15

    # 方法推荐：覆盖率过低的方法不应成为主方法。
    minimum_method_coverage: float = 0.80

    # 要求配置中的raw和plane都存在，防止不完整比较。
    require_all_methods: bool = True
    random_state: int = 42


VALID_LABELS = {"TRUE_LEAK", "FALSE_LEAK"}
EPS = 1.0e-20


# =============================================================================
# 2. 基础工具
# =============================================================================


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def safe_slug(value: Any, max_len: int = 180) -> str:
    text = str(value).strip() or "sample"
    text = re.sub(r"[^0-9A-Za-z_\-.]+", "_", text)
    return text.strip("._")[:max_len] or "sample"


def safe_array(values: Any) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    return np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)


def power_from_db(values: np.ndarray) -> np.ndarray:
    arr = np.clip(np.asarray(values, dtype=float), -300.0, 300.0)
    return np.power(10.0, arr / 10.0)


def db_from_power(values: np.ndarray) -> np.ndarray:
    return 10.0 * np.log10(np.maximum(np.asarray(values, dtype=float), EPS))


def moving_average(values: np.ndarray, window: int) -> np.ndarray:
    arr = safe_array(values).ravel()
    if window <= 1 or arr.size < 3:
        return arr
    window = min(int(window), arr.size)
    if window % 2 == 0:
        window += 1
    if window > arr.size:
        window = arr.size if arr.size % 2 == 1 else arr.size - 1
    if window <= 1:
        return arr
    pad = window // 2
    kernel = np.ones(window, dtype=float) / window
    padded = np.pad(arr, (pad, pad), mode="edge")
    return np.convolve(padded, kernel, mode="valid")


def normalize_nonnegative(values: np.ndarray) -> np.ndarray:
    arr = np.maximum(safe_array(values).ravel(), 0.0)
    total = float(np.sum(arr))
    if total <= EPS:
        return np.zeros_like(arr)
    return arr / total


def robust_mad(matrix: np.ndarray, axis: int = 0) -> np.ndarray:
    arr = safe_array(matrix)
    med = np.median(arr, axis=axis, keepdims=True)
    mad = np.median(np.abs(arr - med), axis=axis)
    return 1.4826 * mad


def safe_scale_floor(scale: np.ndarray) -> float:
    arr = np.asarray(scale, dtype=float).ravel()
    positive = arr[np.isfinite(arr) & (arr > 1.0e-12)]
    if positive.size == 0:
        return 1.0e-6
    return max(float(np.median(positive)) * 0.05, 1.0e-6)


def safe_auc(labels: Sequence[str], score: Sequence[float]) -> float:
    y = np.asarray([1 if str(x) == "TRUE_LEAK" else 0 for x in labels], dtype=int)
    s = np.asarray(score, dtype=float)
    valid = np.isfinite(s)
    try:
        if np.sum(valid) < 2 or np.unique(y[valid]).size < 2:
            return np.nan
        return float(roc_auc_score(y[valid], s[valid]))
    except Exception:
        return np.nan


def safe_p_value(true_values: np.ndarray, false_values: np.ndarray) -> float:
    try:
        if len(true_values) == 0 or len(false_values) == 0:
            return np.nan
        return float(mannwhitneyu(true_values, false_values, alternative="two-sided").pvalue)
    except Exception:
        return np.nan


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    x = safe_array(a).ravel()
    y = safe_array(b).ravel()
    denom = float(np.linalg.norm(x) * np.linalg.norm(y))
    if x.shape != y.shape or denom <= EPS:
        return 0.0
    return float(np.clip(np.dot(x, y) / denom, -1.0, 1.0))


def shape_similarity(a: np.ndarray, b: np.ndarray) -> float:
    x = safe_array(a).ravel()
    y = safe_array(b).ravel()
    if x.shape != y.shape or x.size == 0:
        return 0.0
    cos = 0.5 + 0.5 * cosine_similarity(x, y)
    l1 = 1.0 - float(np.mean(np.abs(x - y)))
    return float(np.clip(0.5 * cos + 0.5 * l1, 0.0, 1.0))


def shift_array(values: np.ndarray, shift_bins: int) -> np.ndarray:
    arr = safe_array(values).ravel()
    out = np.zeros_like(arr)
    if shift_bins == 0:
        return arr.copy()
    if abs(shift_bins) >= len(arr):
        return out
    if shift_bins > 0:
        out[shift_bins:] = arr[:-shift_bins]
    else:
        out[:shift_bins] = arr[-shift_bins:]
    return out


def spectral_similarity(
    sample: np.ndarray,
    reference: np.ndarray,
    freq_grid: np.ndarray,
    wasserstein_scale_hz: float,
) -> Dict[str, float]:
    x = normalize_nonnegative(sample)
    y = normalize_nonnegative(reference)
    if float(np.sum(x)) <= EPS or float(np.sum(y)) <= EPS:
        return {
            "cosine": 0.0,
            "js": 0.0,
            "wasserstein": 0.0,
            "combined": 0.0,
        }
    cosine = float(np.clip(cosine_similarity(x, y), 0.0, 1.0))
    try:
        js = float(np.clip(1.0 - jensenshannon(x, y, base=2.0), 0.0, 1.0))
    except Exception:
        js = 0.0
    try:
        wd = float(wasserstein_distance(freq_grid, freq_grid, u_weights=x, v_weights=y))
        ws = float(np.exp(-wd / max(wasserstein_scale_hz, 1.0)))
    except Exception:
        ws = 0.0
    return {
        "cosine": cosine,
        "js": js,
        "wasserstein": ws,
        "combined": float((cosine + js + ws) / 3.0),
    }


def best_shifted_spectral_similarity(
    sample: np.ndarray,
    reference: np.ndarray,
    freq_grid: np.ndarray,
    config: Config,
) -> Tuple[Dict[str, float], np.ndarray]:
    if len(freq_grid) < 2:
        metrics = spectral_similarity(sample, reference, freq_grid, config.wasserstein_scale_hz)
        metrics["best_shift_hz"] = 0.0
        return metrics, normalize_nonnegative(sample)

    df = float(np.median(np.diff(freq_grid)))
    max_bins = int(round(config.max_frequency_shift_hz / max(df, 1.0)))
    best_metrics: Optional[Dict[str, float]] = None
    best_spectrum = normalize_nonnegative(sample)
    best_shift = 0

    for shift in range(-max_bins, max_bins + 1):
        shifted = normalize_nonnegative(shift_array(sample, shift))
        metrics = spectral_similarity(shifted, reference, freq_grid, config.wasserstein_scale_hz)
        if best_metrics is None or metrics["combined"] > best_metrics["combined"]:
            best_metrics = metrics
            best_spectrum = shifted
            best_shift = shift

    assert best_metrics is not None
    best_metrics = dict(best_metrics)
    best_metrics["best_shift_hz"] = float(best_shift * df)
    return best_metrics, best_spectrum


# =============================================================================
# 3. WAV和实验室纯泄漏参考
# =============================================================================


def read_wav_preserve_scale(path: Path) -> Tuple[int, np.ndarray]:
    fs, raw = wavfile.read(str(path))
    dtype = raw.dtype
    if raw.ndim > 1:
        raw = np.mean(raw.astype(np.float64), axis=1)
    else:
        raw = raw.astype(np.float64, copy=False)
    if np.issubdtype(dtype, np.integer):
        info = np.iinfo(dtype)
        raw /= float(max(abs(info.min), abs(info.max), 1))
    finite = np.isfinite(raw)
    if not np.any(finite):
        raise ValueError(f"WAV全部无效: {path}")
    fill = float(np.median(raw[finite]))
    raw = np.where(finite, raw, fill)
    raw -= float(np.mean(raw))
    return int(fs), raw


def stft_power_from_signal(x: np.ndarray, fs: int, config: Config) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    if fs / 2.0 <= config.freq_high_hz:
        raise ValueError(
            f"实验室WAV采样率={fs} Hz，Nyquist={fs/2:g} Hz，"
            f"不足以分析到{config.freq_high_hz:g} Hz"
        )
    nperseg = min(config.nperseg, len(x))
    if nperseg < 256:
        raise ValueError("WAV片段太短，无法做稳定STFT")
    hop = min(config.hop_length, nperseg)
    noverlap = nperseg - hop
    nfft = max(config.nfft, nperseg)
    freq, time_s, z = signal.stft(
        x,
        fs=fs,
        window="hann",
        nperseg=nperseg,
        noverlap=noverlap,
        nfft=nfft,
        detrend=False,
        return_onesided=True,
        boundary=None,
        padded=False,
    )
    mask = (freq >= config.freq_low_hz) & (freq <= config.freq_high_hz)
    if np.sum(mask) < 30:
        raise ValueError("实验室WAV在目标频带内有效频点不足")
    return freq[mask].astype(float), time_s.astype(float), np.maximum(np.abs(z[mask]) ** 2, EPS)


def spectral_fingerprint(
    freq_hz: np.ndarray,
    component_power: np.ndarray,
    config: Config,
    target_grid: Optional[np.ndarray] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    freq = safe_array(freq_hz).ravel()
    power = np.maximum(safe_array(component_power), 0.0)
    if power.ndim != 2 or power.shape[0] != len(freq):
        raise ValueError(f"频谱矩阵维度不匹配: freq={freq.shape}, power={power.shape}")
    spectrum = np.mean(power, axis=1)
    # 压缩极强单线谱，降低机械窄带峰的统治作用。
    spectrum = np.sqrt(np.maximum(spectrum, 0.0))
    spectrum = moving_average(spectrum, config.spectral_smooth_bins)
    grid = (
        np.linspace(config.freq_low_hz, config.freq_high_hz, config.n_spectral_bins)
        if target_grid is None
        else safe_array(target_grid).ravel()
    )
    order = np.argsort(freq)
    interp = np.interp(grid, freq[order], spectrum[order], left=0.0, right=0.0)
    return normalize_nonnegative(interp), grid


def temporal_fingerprint(component_power: np.ndarray, n_quantiles: int = 64) -> np.ndarray:
    power = np.maximum(safe_array(component_power), 0.0)
    if power.ndim != 2:
        raise ValueError("时间指纹输入必须为frequency×time矩阵")
    envelope = np.sum(power, axis=0)
    envelope = np.log1p(envelope / (np.median(envelope) + EPS))
    q = np.quantile(envelope, np.linspace(0.0, 1.0, n_quantiles))
    scale = max(float(np.quantile(q, 0.95)), EPS)
    q = np.clip(q / scale, 0.0, 2.0) / 2.0
    q90 = max(float(np.quantile(envelope, 0.90)), EPS)
    extras = np.asarray([
        np.mean(envelope >= 0.10 * q90),
        np.mean(envelope >= 0.30 * q90),
        np.mean(envelope >= 0.50 * q90),
        np.std(envelope) / (np.mean(envelope) + EPS),
    ], dtype=float)
    extras[-1] = extras[-1] / (1.0 + extras[-1])
    return np.concatenate([q, extras])


def split_lab_segments(x: np.ndarray, fs: int, config: Config) -> List[Tuple[int, int]]:
    seg = max(int(round(config.lab_segment_seconds * fs)), 256)
    hop = max(int(round(config.lab_segment_hop_seconds * fs)), 1)
    min_len = max(int(round(config.lab_min_segment_seconds * fs)), 256)
    if len(x) <= seg:
        return [(0, len(x))] if len(x) >= min_len else []
    segments: List[Tuple[int, int]] = []
    for start in range(0, len(x) - min_len + 1, hop):
        end = min(start + seg, len(x))
        if end - start >= min_len:
            segments.append((start, end))
        if end >= len(x):
            break
    return segments


def build_lab_reference(
    lab_wavs: Sequence[str],
    config: Config,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, pd.DataFrame]:
    spectral_rows: List[np.ndarray] = []
    temporal_rows: List[np.ndarray] = []
    metadata: List[Dict[str, Any]] = []
    grid: Optional[np.ndarray] = None

    for raw_path in lab_wavs:
        path = Path(raw_path)
        if not path.exists():
            raise FileNotFoundError(f"找不到实验室纯泄漏WAV: {path}")
        fs, x = read_wav_preserve_scale(path)
        segments = split_lab_segments(x, fs, config)
        if not segments:
            raise ValueError(f"实验室WAV太短: {path}")
        for segment_index, (start, end) in enumerate(segments):
            freq, _, power = stft_power_from_signal(x[start:end], fs, config)
            spectrum, current_grid = spectral_fingerprint(freq, power, config, grid)
            if grid is None:
                grid = current_grid
            spectral_rows.append(spectrum)
            temporal_rows.append(temporal_fingerprint(power))
            metadata.append({
                "wav": str(path),
                "segment_index": segment_index,
                "start_seconds": start / fs,
                "end_seconds": end / fs,
                "duration_seconds": (end - start) / fs,
                "sampling_rate": fs,
            })

    if not spectral_rows or grid is None:
        raise RuntimeError("没有成功构造实验室纯泄漏参考")
    spectral_matrix = np.vstack(spectral_rows)
    temporal_matrix = np.vstack(temporal_rows)
    # 使用中位数避免单个片段中的瞬态峰污染参考。
    lab_spectrum = normalize_nonnegative(np.median(spectral_matrix, axis=0))
    lab_temporal = np.median(temporal_matrix, axis=0)
    return grid, lab_spectrum, lab_temporal, pd.DataFrame(metadata)


# =============================================================================
# 4. 读取v9三路残差
# =============================================================================


def read_v9_metadata(v9_dir: Path) -> pd.DataFrame:
    path = v9_dir / "v9_all_features.csv"
    if not path.exists():
        raise FileNotFoundError(f"找不到: {path}")
    df = pd.read_csv(path, dtype={"sample_id": str, "center": str, "time": str})
    required = ["sample_id", "label"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"{path.name}缺少列: {missing}")
    df["label"] = df["label"].astype(str)
    df = df[df["label"].isin(VALID_LABELS)].copy().reset_index(drop=True)
    if df.empty:
        raise ValueError(f"{path}中没有TRUE_LEAK/FALSE_LEAK")
    return df


def locate_npz(residual_dir: Path, sample_id: str) -> Optional[Path]:
    direct = residual_dir / f"{safe_slug(sample_id)}.npz"
    if direct.exists():
        return direct
    matches = list(residual_dir.glob(f"*{safe_slug(sample_id)}*.npz"))
    return matches[0] if len(matches) == 1 else None


def scalar_string(value: Any) -> str:
    arr = np.asarray(value)
    if arr.size == 0:
        return ""
    item = arr.reshape(-1)[0]
    if isinstance(item, bytes):
        return item.decode("utf-8", errors="replace")
    return str(item)


def method_keys(method: str) -> Tuple[str, Optional[str]]:
    method = method.lower().strip()
    if method == "raw":
        return "center_power_db", None
    if method == "plane":
        return "excess_power_plane", "background_power_db_plane"
    raise ValueError(f"未知方法: {method}")


def load_component_power(npz: Any, method: str) -> Tuple[np.ndarray, Dict[str, Any]]:
    method = method.lower().strip()
    info: Dict[str, Any] = {
        "method": method,
        "selected_method": scalar_string(npz["selected_method"]) if "selected_method" in npz.files else "",
        "primary_method": scalar_string(npz["primary_method"]) if "primary_method" in npz.files else "",
        "plane_valid": np.nan,
        "source_key": "",
    }
    if "plane_valid" in npz.files:
        try:
            info["plane_valid"] = int(np.asarray(npz["plane_valid"]).reshape(-1)[0])
        except Exception:
            pass
    elif "fit_plane_available" in npz.files:
        try:
            info["plane_valid"] = int(np.asarray(npz["fit_plane_available"]).reshape(-1)[0])
        except Exception:
            pass

    if method == "raw":
        if "center_power_db" not in npz.files:
            raise KeyError("NPZ缺少center_power_db，不能计算raw基线")
        component = power_from_db(npz["center_power_db"])
        info["source_key"] = "center_power_db"
        return np.maximum(component, 0.0), info

    preferred_key, _ = method_keys(method)
    candidates = [preferred_key]
    # 兼容旧版：无后缀字段代表当时保存的主方法。
    if method == "plane":
        primary = info["primary_method"].lower()
        if primary == method:
            candidates.append("excess_power")

    key = next((k for k in candidates if k in npz.files), None)
    if key is None:
        raise KeyError(f"NPZ缺少{method}残差字段，尝试过: {candidates}")
    component = np.asarray(npz[key], dtype=float)
    if component.ndim != 2:
        raise ValueError(f"{key}维度异常: {component.shape}")
    if not np.any(np.isfinite(component)):
        raise ValueError(f"{method}残差全部无效")
    if method == "plane" and np.isfinite(info["plane_valid"]) and int(info["plane_valid"]) != 1:
        raise ValueError("plane_valid=0")
    component = np.maximum(np.nan_to_num(component, nan=0.0, posinf=0.0, neginf=0.0), 0.0)
    if float(np.sum(component)) <= EPS:
        raise ValueError(f"{method}残差能量为0")
    info["source_key"] = key
    return component, info


def load_scene_samples(
    scene_name: str,
    group_name: str,
    v9_dir: Path,
    methods: Sequence[str],
    grid: np.ndarray,
    config: Config,
) -> Tuple[pd.DataFrame, Dict[Tuple[str, str, str], Dict[str, np.ndarray]], pd.DataFrame]:
    metadata = read_v9_metadata(v9_dir)
    residual_dir = v9_dir / "residual_npz"
    if not residual_dir.exists():
        raise FileNotFoundError(f"找不到: {residual_dir}")

    rows: List[Dict[str, Any]] = []
    fingerprints: Dict[Tuple[str, str, str], Dict[str, np.ndarray]] = {}
    failures: List[Dict[str, Any]] = []

    for _, row in metadata.iterrows():
        sample_id = str(row["sample_id"])
        npz_path = locate_npz(residual_dir, sample_id)
        if npz_path is None:
            failures.append({
                "scene": scene_name,
                "sample_id": sample_id,
                "method": "ALL",
                "error": "NPZ_NOT_FOUND",
            })
            continue
        try:
            with np.load(npz_path, allow_pickle=False) as npz:
                if "freq_hz" not in npz.files:
                    raise KeyError("NPZ缺少freq_hz")
                freq = np.asarray(npz["freq_hz"], dtype=float)
                for method in methods:
                    try:
                        component, info = load_component_power(npz, method)
                        spectrum, _ = spectral_fingerprint(freq, component, config, grid)
                        temporal = temporal_fingerprint(component)
                        fingerprints[(scene_name, sample_id, method)] = {
                            "spectral": spectrum,
                            "temporal": temporal,
                        }
                        rows.append({
                            "scene": scene_name,
                            "group": group_name,
                            "sample_id": sample_id,
                            "label": str(row["label"]),
                            "dataset": str(row.get("dataset", "")),
                            "time": str(row.get("time", "")),
                            "center": str(row.get("center", "")),
                            "method": method,
                            "npz_path": str(npz_path),
                            "source_key": info["source_key"],
                            "selected_method": info["selected_method"],
                            "primary_method": info["primary_method"],
                            "plane_valid": info["plane_valid"],
                        })
                    except Exception as exc:
                        failures.append({
                            "scene": scene_name,
                            "sample_id": sample_id,
                            "method": method,
                            "error": f"{type(exc).__name__}: {exc}",
                        })
        except Exception as exc:
            failures.append({
                "scene": scene_name,
                "sample_id": sample_id,
                "method": "ALL",
                "error": f"{type(exc).__name__}: {exc}",
            })

    return pd.DataFrame(rows), fingerprints, pd.DataFrame(failures)


# =============================================================================
# 5. 实验室相似度与场景内方法评价
# =============================================================================


def add_lab_similarity(
    sample_df: pd.DataFrame,
    fingerprints: Dict[Tuple[str, str, str], Dict[str, np.ndarray]],
    lab_spectrum: np.ndarray,
    lab_temporal: np.ndarray,
    grid: np.ndarray,
    config: Config,
) -> Tuple[pd.DataFrame, Dict[Tuple[str, str, str], np.ndarray]]:
    rows: List[Dict[str, Any]] = []
    aligned_spectra: Dict[Tuple[str, str, str], np.ndarray] = {}
    for _, row in sample_df.iterrows():
        key = (str(row["scene"]), str(row["sample_id"]), str(row["method"]))
        fp = fingerprints[key]
        spectral_metrics, aligned = best_shifted_spectral_similarity(
            fp["spectral"], lab_spectrum, grid, config
        )
        aligned_spectra[key] = aligned
        temporal_sim = shape_similarity(fp["temporal"], lab_temporal)
        lab_similarity = 0.80 * spectral_metrics["combined"] + 0.20 * temporal_sim
        out = dict(row)
        out.update({
            "lab_similarity_spectral": spectral_metrics["combined"],
            "lab_similarity_cosine": spectral_metrics["cosine"],
            "lab_similarity_js": spectral_metrics["js"],
            "lab_similarity_wasserstein": spectral_metrics["wasserstein"],
            "lab_similarity_temporal": temporal_sim,
            "lab_similarity_combined": lab_similarity,
            "best_frequency_shift_hz": spectral_metrics["best_shift_hz"],
        })
        rows.append(out)
    return pd.DataFrame(rows), aligned_spectra


def summarize_method_scene(sample_similarity: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for (method, scene), sub in sample_similarity.groupby(["method", "scene"], sort=True):
        true_values = sub.loc[sub["label"] == "TRUE_LEAK", "lab_similarity_combined"].to_numpy(float)
        false_values = sub.loc[sub["label"] == "FALSE_LEAK", "lab_similarity_combined"].to_numpy(float)
        n_expected = int(sub["sample_id"].nunique())
        rows.append({
            "method": method,
            "scene": scene,
            "n_available": len(sub),
            "n_true": len(true_values),
            "n_false": len(false_values),
            "true_lab_similarity_median": float(np.median(true_values)) if len(true_values) else np.nan,
            "false_lab_similarity_median": float(np.median(false_values)) if len(false_values) else np.nan,
            "lab_similarity_gap": (
                float(np.median(true_values) - np.median(false_values))
                if len(true_values) and len(false_values) else np.nan
            ),
            "lab_similarity_auc": safe_auc(sub["label"], sub["lab_similarity_combined"]),
            "mannwhitney_p": safe_p_value(true_values, false_values),
            "median_abs_frequency_shift_hz": float(np.median(np.abs(sub["best_frequency_shift_hz"]))) if len(sub) else np.nan,
        })
    return pd.DataFrame(rows)


# =============================================================================
# 6. 场景候选成分、AB/CD共同部分和跨组验证
# =============================================================================


def compute_scene_contrast(
    scene: str,
    method: str,
    sub: pd.DataFrame,
    aligned_spectra: Dict[Tuple[str, str, str], np.ndarray],
    grid: np.ndarray,
    config: Config,
) -> Dict[str, Any]:
    true_specs = np.vstack([
        aligned_spectra[(str(r.scene), str(r.sample_id), method)]
        for r in sub.itertuples() if r.label == "TRUE_LEAK"
    ])
    false_specs = np.vstack([
        aligned_spectra[(str(r.scene), str(r.sample_id), method)]
        for r in sub.itertuples() if r.label == "FALSE_LEAK"
    ])
    true_med = np.median(true_specs, axis=0)
    false_med = np.median(false_specs, axis=0)
    delta = true_med - false_med
    pooled = np.vstack([true_specs, false_specs])
    scale = robust_mad(pooled, axis=0)
    scale = np.maximum(scale, safe_scale_floor(scale))
    effect = np.clip(delta / scale, -20.0, 20.0)

    auc = np.zeros(len(grid), dtype=float)
    p = np.zeros(len(grid), dtype=float)
    labels = np.asarray([1] * len(true_specs) + [0] * len(false_specs), dtype=int)
    for i in range(len(grid)):
        values = np.concatenate([true_specs[:, i], false_specs[:, i]])
        try:
            auc[i] = roc_auc_score(labels, values)
        except Exception:
            auc[i] = np.nan
        p[i] = safe_p_value(true_specs[:, i], false_specs[:, i])

    positive_mask = (effect >= config.min_abs_effect) & (auc >= config.min_directional_auc)
    candidate = np.maximum(delta, 0.0)
    candidate[~positive_mask] = 0.0
    candidate = normalize_nonnegative(moving_average(candidate, config.spectral_smooth_bins))
    return {
        "scene": scene,
        "method": method,
        "true_median": true_med,
        "false_median": false_med,
        "delta": delta,
        "effect": effect,
        "auc": auc,
        "p_value": p,
        "positive_mask": positive_mask,
        "candidate": candidate,
        "n_true": len(true_specs),
        "n_false": len(false_specs),
    }


def geometric_common(spectra: Sequence[np.ndarray]) -> np.ndarray:
    valid = [normalize_nonnegative(x) for x in spectra if float(np.sum(x)) > EPS]
    if not valid:
        return np.zeros_like(np.asarray(spectra[0], dtype=float))
    stack = np.vstack(valid)
    # 几何平均：只有多方共同存在时才保持较高。
    common = np.exp(np.mean(np.log(stack + 1.0e-15), axis=0))
    return normalize_nonnegative(common)


def score_samples_against_core(
    sub: pd.DataFrame,
    method: str,
    core: np.ndarray,
    aligned_spectra: Dict[Tuple[str, str, str], np.ndarray],
    grid: np.ndarray,
    config: Config,
) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for r in sub.itertuples():
        spectrum = aligned_spectra[(str(r.scene), str(r.sample_id), method)]
        metrics = spectral_similarity(spectrum, core, grid, config.wasserstein_scale_hz)
        rows.append({
            "scene": r.scene,
            "group": r.group,
            "sample_id": r.sample_id,
            "label": r.label,
            "method": method,
            "core_similarity": metrics["combined"],
        })
    return pd.DataFrame(rows)


def group_transfer_analysis(
    sample_similarity: pd.DataFrame,
    aligned_spectra: Dict[Tuple[str, str, str], np.ndarray],
    scene_contrasts: Dict[Tuple[str, str], Dict[str, Any]],
    grid: np.ndarray,
    config: Config,
) -> Tuple[pd.DataFrame, Dict[str, Dict[str, np.ndarray]]]:
    transfer_rows: List[Dict[str, Any]] = []
    cores: Dict[str, Dict[str, np.ndarray]] = {}
    groups = sample_similarity[["scene", "group"]].drop_duplicates()
    ab_scenes = groups.loc[groups["group"] == "AB", "scene"].tolist()
    cd_scenes = groups.loc[groups["group"] == "CD", "scene"].tolist()
    if len(ab_scenes) < 2 or len(cd_scenes) < 2:
        raise ValueError("配置中AB组和CD组都至少需要两个场景")

    for method in sorted(sample_similarity["method"].unique()):
        available_ab = [scene_contrasts[(s, method)]["candidate"] for s in ab_scenes if (s, method) in scene_contrasts]
        available_cd = [scene_contrasts[(s, method)]["candidate"] for s in cd_scenes if (s, method) in scene_contrasts]
        if len(available_ab) < 2 or len(available_cd) < 2:
            continue
        ab_core = geometric_common(available_ab)
        cd_core = geometric_common(available_cd)
        field_common = geometric_common([ab_core, cd_core])
        cores[method] = {
            "AB": ab_core,
            "CD": cd_core,
            "FIELD_ABCD": field_common,
        }

        # AB核心测试C、D；CD核心测试A、B。
        for train_group, test_group, core in [
            ("AB", "CD", ab_core),
            ("CD", "AB", cd_core),
        ]:
            test_sub = sample_similarity[
                (sample_similarity["method"] == method)
                & (sample_similarity["group"] == test_group)
            ]
            scored = score_samples_against_core(test_sub, method, core, aligned_spectra, grid, config)
            for scene, scene_sub in scored.groupby("scene"):
                transfer_rows.append({
                    "method": method,
                    "train_group": train_group,
                    "test_group": test_group,
                    "test_scene": scene,
                    "n_samples": len(scene_sub),
                    "n_true": int((scene_sub["label"] == "TRUE_LEAK").sum()),
                    "n_false": int((scene_sub["label"] == "FALSE_LEAK").sum()),
                    "transfer_auc": safe_auc(scene_sub["label"], scene_sub["core_similarity"]),
                    "true_core_similarity_median": float(scene_sub.loc[scene_sub["label"] == "TRUE_LEAK", "core_similarity"].median()),
                    "false_core_similarity_median": float(scene_sub.loc[scene_sub["label"] == "FALSE_LEAK", "core_similarity"].median()),
                    "core_similarity_gap": float(
                        scene_sub.loc[scene_sub["label"] == "TRUE_LEAK", "core_similarity"].median()
                        - scene_sub.loc[scene_sub["label"] == "FALSE_LEAK", "core_similarity"].median()
                    ),
                })
    return pd.DataFrame(transfer_rows), cores


# =============================================================================
# 7. 最终实验室锚定核心和频带
# =============================================================================


def lab_anchor_core(field_common: np.ndarray, lab_spectrum: np.ndarray, config: Config) -> Tuple[np.ndarray, np.ndarray]:
    field = normalize_nonnegative(field_common)
    lab = normalize_nonnegative(lab_spectrum)
    lab_relative = lab / max(float(np.max(lab)), EPS)
    soft_factor = config.lab_anchor_floor + (1.0 - config.lab_anchor_floor) * lab_relative
    anchored = normalize_nonnegative(field * soft_factor)
    lab_threshold = float(np.quantile(lab, config.lab_strict_quantile))
    strict_mask = (field > 0) & (lab >= lab_threshold)
    strict = field.copy()
    strict[~strict_mask] = 0.0
    strict = normalize_nonnegative(strict)
    return anchored, strict


def extract_frequency_bands(
    spectrum: np.ndarray,
    grid: np.ndarray,
    config: Config,
) -> pd.DataFrame:
    x = normalize_nonnegative(spectrum)
    if float(np.max(x)) <= EPS:
        return pd.DataFrame(columns=["start_hz", "end_hz", "center_hz", "n_bins", "integrated_weight", "peak_weight"])
    mask = x >= config.band_relative_threshold * float(np.max(x))
    padded = np.concatenate([[False], mask, [False]]).astype(int)
    changes = np.diff(padded)
    starts = np.flatnonzero(changes == 1)
    ends = np.flatnonzero(changes == -1)
    rows: List[Dict[str, Any]] = []
    for start, end in zip(starts, ends):
        if end - start < config.band_min_bins:
            continue
        weights = x[start:end]
        freqs = grid[start:end]
        rows.append({
            "start_hz": float(freqs[0]),
            "end_hz": float(freqs[-1]),
            "start_khz": float(freqs[0] / 1000.0),
            "end_khz": float(freqs[-1] / 1000.0),
            "center_hz": float(np.sum(freqs * weights) / (np.sum(weights) + EPS)),
            "n_bins": int(end - start),
            "integrated_weight": float(np.sum(weights)),
            "peak_weight": float(np.max(weights)),
        })
    return pd.DataFrame(rows).sort_values("integrated_weight", ascending=False).reset_index(drop=True) if rows else pd.DataFrame()


# =============================================================================
# 8. 方法综合排序
# =============================================================================


def build_method_ranking(
    method_scene_summary: pd.DataFrame,
    transfer_summary: pd.DataFrame,
    preflight: pd.DataFrame,
    scene_count: int,
    config: Config,
) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    methods = sorted(set(method_scene_summary["method"]) | set(transfer_summary["method"]))
    for method in methods:
        scene_sub = method_scene_summary[method_scene_summary["method"] == method]
        transfer_sub = transfer_summary[transfer_summary["method"] == method]
        coverage_sub = preflight[preflight["method"] == method]
        coverage = float(coverage_sub["coverage"].mean()) if len(coverage_sub) else 0.0
        positive_gap_count = int((scene_sub["lab_similarity_gap"] > 0).sum())
        scene_aucs = scene_sub["lab_similarity_auc"].dropna().to_numpy(float)
        transfer_aucs = transfer_sub["transfer_auc"].dropna().to_numpy(float)
        scene_gaps = scene_sub["lab_similarity_gap"].dropna().to_numpy(float)
        transfer_gaps = transfer_sub["core_similarity_gap"].dropna().to_numpy(float)

        worst_scene_auc = float(np.min(scene_aucs)) if len(scene_aucs) else np.nan
        mean_scene_auc = float(np.mean(scene_aucs)) if len(scene_aucs) else np.nan
        worst_transfer_auc = float(np.min(transfer_aucs)) if len(transfer_aucs) else np.nan
        mean_transfer_auc = float(np.mean(transfer_aucs)) if len(transfer_aucs) else np.nan
        worst_scene_gap = float(np.min(scene_gaps)) if len(scene_gaps) else np.nan
        worst_transfer_gap = float(np.min(transfer_gaps)) if len(transfer_gaps) else np.nan

        # 排名分数强调“最差场景”，而不是让某一个特别好的场景掩盖失败场景。
        components = [
            worst_scene_auc if np.isfinite(worst_scene_auc) else 0.0,
            mean_scene_auc if np.isfinite(mean_scene_auc) else 0.0,
            worst_transfer_auc if np.isfinite(worst_transfer_auc) else 0.0,
            mean_transfer_auc if np.isfinite(mean_transfer_auc) else 0.0,
            positive_gap_count / max(scene_count, 1),
            min(max(coverage, 0.0), 1.0),
        ]
        recommendation_score = float(np.mean(components))
        eligible = int(
            coverage >= config.minimum_method_coverage
            and positive_gap_count == scene_count
            and len(scene_aucs) == scene_count
        )
        rows.append({
            "method": method,
            "coverage": coverage,
            "positive_lab_gap_scene_count": positive_gap_count,
            "n_expected_scenes": scene_count,
            "worst_scene_lab_auc": worst_scene_auc,
            "mean_scene_lab_auc": mean_scene_auc,
            "worst_scene_lab_gap": worst_scene_gap,
            "worst_pair_transfer_auc": worst_transfer_auc,
            "mean_pair_transfer_auc": mean_transfer_auc,
            "worst_pair_transfer_gap": worst_transfer_gap,
            "eligible_as_primary": eligible,
            "recommendation_score": recommendation_score,
        })
    result = pd.DataFrame(rows)
    if len(result):
        result = result.sort_values(
            ["eligible_as_primary", "recommendation_score", "worst_pair_transfer_auc", "worst_scene_lab_auc"],
            ascending=False,
        ).reset_index(drop=True)
        result["rank"] = np.arange(1, len(result) + 1)
    return result


# =============================================================================
# 9. 图表和报告
# =============================================================================


def plot_lab_and_cores(
    grid: np.ndarray,
    lab: np.ndarray,
    method: str,
    cores: Dict[str, np.ndarray],
    anchored: np.ndarray,
    strict: np.ndarray,
    output_dir: Path,
) -> Path:
    fig_dir = output_dir / "figures"
    ensure_dir(fig_dir)
    plt.figure(figsize=(13, 7))
    plt.plot(grid / 1000.0, lab, label="Laboratory pure leak")
    plt.plot(grid / 1000.0, cores["AB"], label="AB common")
    plt.plot(grid / 1000.0, cores["CD"], label="CD common")
    plt.plot(grid / 1000.0, cores["FIELD_ABCD"], label="AB ∩ CD field common")
    plt.plot(grid / 1000.0, anchored, label="Lab-anchored core")
    plt.plot(grid / 1000.0, strict, label="Strict lab overlap")
    plt.xlabel("Frequency (kHz)")
    plt.ylabel("Normalized weight")
    plt.title(f"Leak core discovery — {method}")
    plt.grid(True, alpha=0.25)
    plt.legend()
    plt.tight_layout()
    path = fig_dir / f"v14_core_{safe_slug(method)}.png"
    plt.savefig(path, dpi=170)
    plt.close()
    return path


def plot_method_scene_auc(summary: pd.DataFrame, output_dir: Path) -> Path:
    fig_dir = output_dir / "figures"
    ensure_dir(fig_dir)
    pivot = summary.pivot(index="scene", columns="method", values="lab_similarity_auc")
    ax = pivot.plot(kind="bar", figsize=(12, 6))
    ax.set_ylim(0.0, 1.05)
    ax.set_ylabel("AUC: similarity to laboratory leak")
    ax.set_title("TRUE vs FALSE laboratory-reference similarity by scene")
    ax.grid(True, axis="y", alpha=0.25)
    plt.tight_layout()
    path = fig_dir / "v14_method_scene_lab_auc.png"
    plt.savefig(path, dpi=170)
    plt.close()
    return path


def write_report(
    output_dir: Path,
    ranking: pd.DataFrame,
    method_scene_summary: pd.DataFrame,
    transfer_summary: pd.DataFrame,
    band_tables: Dict[str, pd.DataFrame],
    config: Config,
) -> Path:
    lines: List[str] = []
    lines.append("v14 实验室纯泄漏参考与现场降噪方法验证报告")
    lines.append("=" * 100)
    lines.append("")
    lines.append("核心判断标准:")
    lines.append("  1. 同一场景TRUE应比FALSE更像实验室纯泄漏。")
    lines.append("  2. AB共同成分应能在C、D中保持TRUE>FALSE。")
    lines.append("  3. CD共同成分应能在A、B中保持TRUE>FALSE。")
    lines.append("  4. AB与CD共同部分应与实验室纯泄漏频谱重叠。")
    lines.append("")
    if len(ranking):
        lines.append("方法综合排序:")
        for _, row in ranking.iterrows():
            lines.append(
                f"  #{int(row['rank'])} {row['method']}: "
                f"eligible={int(row['eligible_as_primary'])}, coverage={row['coverage']:.3f}, "
                f"scene_AUC_worst={row['worst_scene_lab_auc']:.4f}, "
                f"transfer_AUC_worst={row['worst_pair_transfer_auc']:.4f}, "
                f"positive_gap_scenes={int(row['positive_lab_gap_scene_count'])}/{int(row['n_expected_scenes'])}, "
                f"score={row['recommendation_score']:.4f}"
            )
        eligible = ranking[ranking["eligible_as_primary"] == 1]
        if len(eligible):
            recommended = str(eligible.iloc[0]["method"])
            lines.append("")
            lines.append(f"程序推荐的主方法: {recommended}")
        else:
            lines.append("")
            lines.append("没有任何方法同时通过全部场景正向差值和覆盖率要求。不要强行宣布已找到通用降噪方法。")
    lines.append("")
    lines.append("各场景实验室参考结果:")
    for _, row in method_scene_summary.sort_values(["method", "scene"]).iterrows():
        lines.append(
            f"  {row['method']} / {row['scene']}: AUC={row['lab_similarity_auc']:.4f}, "
            f"T_med={row['true_lab_similarity_median']:.4f}, "
            f"F_med={row['false_lab_similarity_median']:.4f}, "
            f"gap={row['lab_similarity_gap']:.4f}"
        )
    lines.append("")
    lines.append("AB/CD跨组迁移:")
    for _, row in transfer_summary.sort_values(["method", "test_scene"]).iterrows():
        lines.append(
            f"  {row['method']} / {row['train_group']}→{row['test_scene']}: "
            f"AUC={row['transfer_auc']:.4f}, gap={row['core_similarity_gap']:.4f}"
        )
    lines.append("")
    lines.append("实验室锚定核心频带:")
    for method, table in band_tables.items():
        lines.append(f"  {method}:")
        if table.empty:
            lines.append("    未发现满足连续频带条件的严格核心。")
        else:
            for _, row in table.head(10).iterrows():
                lines.append(
                    f"    {row['start_khz']:.2f}-{row['end_khz']:.2f} kHz, "
                    f"weight={row['integrated_weight']:.4f}"
                )
    lines.append("")
    lines.append("解释边界:")
    lines.append("  - 本结果验证的是频谱和时间形态，不是恢复带相位的纯净泄漏WAV。")
    lines.append("  - 如果TRUE与FALSE都很像实验室参考，说明仅靠实验室频谱不足以排除机械超声。")
    lines.append("  - 如果某方法在平均值上很好、但最差场景AUC接近0.5，该方法不应作为通用主方法。")
    lines.append("  - plane覆盖率低时，即使少量有效样本表现好，也不能直接用于全部场景。")
    lines.append("")
    lines.append("运行参数:")
    for key, value in asdict(config).items():
        lines.append(f"  {key}: {value}")
    path = output_dir / "v14_report.txt"
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


# =============================================================================
# 10. 主流程
# =============================================================================


def parse_config(path: Optional[str]) -> Tuple[List[Dict[str, str]], List[str], Path, Config]:
    """读取配置。

    支持两种v9路径写法：

    1. 推荐：配置顶层填写 ``v9_abcd_root``，scenes只填写name/group；
       程序自动解析为 ``v9_abcd_root/<scene_name>``。
    2. 兼容：每个scene单独填写 ``v9_dir``。
    """
    scenes = [dict(x) for x in DEFAULT_SCENES]
    lab_wavs = list(DEFAULT_LAB_WAVS)
    output_dir = Path(DEFAULT_OUTPUT_DIR)
    config = Config()
    v9_abcd_root: Optional[Path] = None

    if path:
        config_path = Path(path)
        if not config_path.exists():
            raise FileNotFoundError(f"找不到配置文件: {config_path}")
        payload = json.loads(config_path.read_text(encoding="utf-8"))
        scenes = payload.get("scenes", scenes)
        lab_wavs = payload.get("lab_wavs", lab_wavs)
        output_dir = Path(payload.get("output_dir", str(output_dir)))
        if payload.get("v9_abcd_root"):
            v9_abcd_root = Path(str(payload["v9_abcd_root"]))

        overrides = payload.get("algorithm", {})
        valid_fields = set(asdict(config))
        unknown = sorted(set(overrides) - valid_fields)
        if unknown:
            raise ValueError(f"未知algorithm参数: {unknown}")
        merged = {**asdict(config), **overrides}
        if isinstance(merged.get("methods"), list):
            merged["methods"] = tuple(merged["methods"])
        config = Config(**merged)

    if len(scenes) != 4:
        raise ValueError("当前AB/CD设计要求正好4个有标签场景：A、B、C、D")
    groups = [str(x.get("group", "")) for x in scenes]
    if groups.count("AB") != 2 or groups.count("CD") != 2:
        raise ValueError("scenes中必须有2个group=AB和2个group=CD")
    names = [str(x.get("name", "")).strip() for x in scenes]
    if any(not x for x in names) or len(set(names)) != 4:
        raise ValueError("四个场景name必须非空且唯一")
    if not lab_wavs:
        raise ValueError("至少需要一条实验室纯泄漏WAV")

    resolved_scenes: List[Dict[str, str]] = []
    manifest_scene_dirs: Dict[str, str] = {}
    if v9_abcd_root is not None:
        manifest_path = v9_abcd_root / "v9_ABCD_manifest.json"
        if manifest_path.exists():
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                for item in manifest.get("scenes", []):
                    name = str(item.get("scene", ""))
                    scene_dir = str(item.get("scene_dir", ""))
                    if name and scene_dir:
                        manifest_scene_dirs[name] = scene_dir
            except Exception as exc:
                raise ValueError(f"无法读取v9清单 {manifest_path}: {exc}") from exc

    for raw_scene in scenes:
        item = dict(raw_scene)
        name = str(item["name"])
        if not item.get("v9_dir"):
            if v9_abcd_root is None:
                raise ValueError(
                    f"场景{name}没有v9_dir；请在顶层填写v9_abcd_root，"
                    "或为每个场景单独填写v9_dir"
                )
            item["v9_dir"] = manifest_scene_dirs.get(name, str(v9_abcd_root / safe_slug(name)))
        resolved_scenes.append({
            "name": name,
            "group": str(item["group"]),
            "v9_dir": str(item["v9_dir"]),
        })

    return resolved_scenes, [str(x) for x in lab_wavs], output_dir, config


def run_analysis(
    scenes: Sequence[Dict[str, str]],
    lab_wavs: Sequence[str],
    output_dir: Path,
    config: Config,
) -> Dict[str, Path]:
    ensure_dir(output_dir)
    print("=" * 100)
    print("v14 实验室纯泄漏参考 × 现场降噪方法验证")
    print("=" * 100)

    print("\n第一步：构造实验室纯泄漏参考")
    grid, lab_spectrum, lab_temporal, lab_segments = build_lab_reference(lab_wavs, config)
    lab_segments.to_csv(output_dir / "v14_lab_segments.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame({
        "frequency_hz": grid,
        "frequency_khz": grid / 1000.0,
        "lab_reference_spectrum": lab_spectrum,
    }).to_csv(output_dir / "v14_lab_reference_spectrum.csv", index=False, encoding="utf-8-sig")
    print(f"  实验室WAV={len(lab_wavs)}，有效片段={len(lab_segments)}")

    print("\n第二步：读取A/B/C/D的raw和plane")
    all_rows: List[pd.DataFrame] = []
    all_failures: List[pd.DataFrame] = []
    fingerprints: Dict[Tuple[str, str, str], Dict[str, np.ndarray]] = {}
    expected_by_scene: Dict[str, int] = {}
    for scene_cfg in scenes:
        scene = str(scene_cfg["name"])
        group = str(scene_cfg["group"])
        v9_dir = Path(str(scene_cfg["v9_dir"]))
        metadata = read_v9_metadata(v9_dir)
        expected_by_scene[scene] = len(metadata)
        rows, fps, failures = load_scene_samples(scene, group, v9_dir, config.methods, grid, config)
        all_rows.append(rows)
        all_failures.append(failures)
        fingerprints.update(fps)
        print(f"  {scene}: 期望样本={len(metadata)}，成功方法记录={len(rows)}")

    sample_df = pd.concat(all_rows, ignore_index=True)
    failures_df = pd.concat(all_failures, ignore_index=True) if all_failures else pd.DataFrame()
    failures_df.to_csv(output_dir / "v14_failures.csv", index=False, encoding="utf-8-sig")

    preflight_rows: List[Dict[str, Any]] = []
    for scene in expected_by_scene:
        for method in config.methods:
            n = int(len(sample_df[(sample_df["scene"] == scene) & (sample_df["method"] == method)]))
            expected = expected_by_scene[scene]
            preflight_rows.append({
                "scene": scene,
                "method": method,
                "n_available": n,
                "n_expected": expected,
                "coverage": n / max(expected, 1),
            })
    preflight = pd.DataFrame(preflight_rows)
    preflight.to_csv(output_dir / "v14_preflight_method_coverage.csv", index=False, encoding="utf-8-sig")

    if config.require_all_methods:
        missing_rows = preflight[preflight["n_available"] <= 0].copy()
        if len(missing_rows):
            detail = missing_rows[["scene", "method", "n_available", "n_expected"]].to_string(index=False)
            raise RuntimeError(
                "v14要求raw和plane两种方法都存在，但发现缺失：\n"
                + detail
                + "\n请确认使用本程序包中的新版v9重新生成结果，而不是旧v9结果。"
            )

    print("\n第三步：每个现场样本与实验室纯泄漏比较")
    sample_similarity, aligned_spectra = add_lab_similarity(
        sample_df, fingerprints, lab_spectrum, lab_temporal, grid, config
    )
    sample_similarity.to_csv(output_dir / "v14_sample_lab_similarity.csv", index=False, encoding="utf-8-sig")
    method_scene_summary = summarize_method_scene(sample_similarity)
    method_scene_summary.to_csv(output_dir / "v14_method_scene_summary.csv", index=False, encoding="utf-8-sig")
    for _, row in method_scene_summary.iterrows():
        print(
            f"  {row['method']} / {row['scene']}: AUC={row['lab_similarity_auc']:.4f}, "
            f"gap={row['lab_similarity_gap']:.4f}"
        )

    print("\n第四步：每个场景内部TRUE-FALSE，构建泄漏候选成分")
    scene_contrasts: Dict[Tuple[str, str], Dict[str, Any]] = {}
    contrast_rows: List[Dict[str, Any]] = []
    for (scene, method), sub in sample_similarity.groupby(["scene", "method"]):
        if int((sub["label"] == "TRUE_LEAK").sum()) < 2 or int((sub["label"] == "FALSE_LEAK").sum()) < 2:
            continue
        contrast = compute_scene_contrast(scene, method, sub, aligned_spectra, grid, config)
        scene_contrasts[(scene, method)] = contrast
        for i, freq in enumerate(grid):
            contrast_rows.append({
                "scene": scene,
                "method": method,
                "frequency_hz": freq,
                "frequency_khz": freq / 1000.0,
                "true_median": contrast["true_median"][i],
                "false_median": contrast["false_median"][i],
                "delta_true_minus_false": contrast["delta"][i],
                "robust_effect": contrast["effect"][i],
                "auc_true_higher": contrast["auc"][i],
                "mannwhitney_p": contrast["p_value"][i],
                "selected_positive_component": int(contrast["positive_mask"][i]),
                "scene_candidate_weight": contrast["candidate"][i],
            })
    pd.DataFrame(contrast_rows).to_csv(
        output_dir / "v14_scene_internal_spectral_contrasts.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print("\n第五步：AB共同、CD共同、AB与CD共同，并做跨组验证")
    transfer_summary, cores_by_method = group_transfer_analysis(
        sample_similarity, aligned_spectra, scene_contrasts, grid, config
    )
    transfer_summary.to_csv(output_dir / "v14_pair_transfer_summary.csv", index=False, encoding="utf-8-sig")
    for _, row in transfer_summary.iterrows():
        print(
            f"  {row['method']} {row['train_group']}→{row['test_scene']}: "
            f"AUC={row['transfer_auc']:.4f}, gap={row['core_similarity_gap']:.4f}"
        )

    print("\n第六步：用实验室纯泄漏锚定最终核心")
    band_tables: Dict[str, pd.DataFrame] = {}
    for method, cores in cores_by_method.items():
        anchored, strict = lab_anchor_core(cores["FIELD_ABCD"], lab_spectrum, config)
        core_df = pd.DataFrame({
            "frequency_hz": grid,
            "frequency_khz": grid / 1000.0,
            "lab_reference": lab_spectrum,
            "AB_common": cores["AB"],
            "CD_common": cores["CD"],
            "field_ABCD_common": cores["FIELD_ABCD"],
            "lab_anchored_core": anchored,
            "strict_lab_overlap_core": strict,
        })
        core_df.to_csv(
            output_dir / f"v14_core_spectrum_{safe_slug(method)}.csv",
            index=False,
            encoding="utf-8-sig",
        )
        np.savez_compressed(
            output_dir / f"v14_core_spectrum_{safe_slug(method)}.npz",
            frequency_grid_hz=grid,
            lab_reference=lab_spectrum,
            AB_common=cores["AB"],
            CD_common=cores["CD"],
            field_ABCD_common=cores["FIELD_ABCD"],
            lab_anchored_core=anchored,
            strict_lab_overlap_core=strict,
            method=np.asarray(method),
            config_json=np.asarray(json.dumps(asdict(config), ensure_ascii=False)),
        )
        bands = extract_frequency_bands(strict, grid, config)
        band_tables[method] = bands
        bands.to_csv(
            output_dir / f"v14_strict_core_bands_{safe_slug(method)}.csv",
            index=False,
            encoding="utf-8-sig",
        )
        plot_lab_and_cores(grid, lab_spectrum, method, cores, anchored, strict, output_dir)
        print(f"  {method}: 严格连续核心频带={len(bands)}")

    ranking = build_method_ranking(
        method_scene_summary,
        transfer_summary,
        preflight,
        len(scenes),
        config,
    )
    ranking.to_csv(output_dir / "v14_method_ranking.csv", index=False, encoding="utf-8-sig")
    plot_method_scene_auc(method_scene_summary, output_dir)
    report = write_report(
        output_dir,
        ranking,
        method_scene_summary,
        transfer_summary,
        band_tables,
        config,
    )

    run_config = {
        "scenes": list(scenes),
        "lab_wavs": list(lab_wavs),
        "output_dir": str(output_dir),
        "algorithm": asdict(config),
    }
    (output_dir / "v14_run_config.json").write_text(
        json.dumps(run_config, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print("\n" + "=" * 100)
    print("v14处理完成")
    print("方法排序:", output_dir / "v14_method_ranking.csv")
    print("逐样本实验室相似度:", output_dir / "v14_sample_lab_similarity.csv")
    print("AB/CD跨组验证:", output_dir / "v14_pair_transfer_summary.csv")
    print("报告:", report)
    if len(ranking):
        print("当前排名第一:", ranking.iloc[0]["method"])
    print("=" * 100)

    return {
        "ranking": output_dir / "v14_method_ranking.csv",
        "method_scene_summary": output_dir / "v14_method_scene_summary.csv",
        "transfer_summary": output_dir / "v14_pair_transfer_summary.csv",
        "report": report,
    }


# =============================================================================
# 11. 合成数据自检
# =============================================================================


def write_float_wav(path: Path, fs: int, x: np.ndarray) -> None:
    wavfile.write(str(path), fs, np.asarray(x, dtype=np.float32))


def synthesize_lab_wav(path: Path, config: Config, rng: np.random.Generator) -> None:
    fs = 192_000
    duration = 6.0
    n = int(fs * duration)
    # 用随机噪声通过频域包络构造42-60kHz宽带泄漏。
    noise = rng.normal(size=n)
    freq = np.fft.rfftfreq(n, 1.0 / fs)
    envelope = (
        np.exp(-0.5 * ((freq - 48_000.0) / 5500.0) ** 2)
        + 0.75 * np.exp(-0.5 * ((freq - 57_000.0) / 4300.0) ** 2)
    )
    spectrum = np.fft.rfft(noise) * envelope
    x = np.fft.irfft(spectrum, n=n)
    x /= max(np.max(np.abs(x)), EPS)
    write_float_wav(path, fs, 0.5 * x)


def make_synthetic_scene(
    root: Path,
    name: str,
    group: str,
    scene_index: int,
    grid: np.ndarray,
    rng: np.random.Generator,
    n_each: int = 12,
) -> Dict[str, str]:
    v9_dir = root / f"{name}_v9"
    residual_dir = v9_dir / "residual_npz"
    ensure_dir(residual_dir)
    rows: List[Dict[str, Any]] = []
    n_time = 48
    # 与实验室泄漏相似的现场泄漏频谱。
    leak = (
        np.exp(-0.5 * ((grid - (48_000 + 250 * scene_index)) / 5500.0) ** 2)
        + 0.75 * np.exp(-0.5 * ((grid - (57_000 + 180 * scene_index)) / 4300.0) ** 2)
    )
    leak /= max(np.max(leak), EPS)
    # 场景私有窄带机械声。
    mech = np.exp(-0.5 * ((grid - (27_000 + 4500 * scene_index)) / 500.0) ** 2)
    time_env = 0.8 + 0.2 * np.sin(np.linspace(0, 5 * np.pi, n_time))

    for label in ["TRUE_LEAK", "FALSE_LEAK"]:
        for i in range(n_each):
            sample_id = f"{name}_{label}_{i:02d}"
            base = 1.0e-10 * (1.0 + 0.10 * rng.normal(size=(len(grid), n_time)))
            base = np.maximum(base, 1.0e-12)
            if label == "TRUE_LEAK":
                true_component = 5.0e-10 * leak[:, None] * time_env[None, :]
                false_component = 0.15e-10 * mech[:, None]
            else:
                true_component = 0.35e-10 * leak[:, None] * time_env[None, :]
                false_component = 3.5e-10 * mech[:, None]

            # plane在C/D中故意模拟一部分场景敏感性，用来检验排名逻辑。
            if group == "AB":
                plane = np.maximum(0.95 * true_component + 0.10 * false_component, 0.0)
            else:
                plane = np.maximum(0.18 * true_component + 0.55 * false_component, 0.0)
            plane_valid = 1
            raw = base + true_component + false_component
            np.savez_compressed(
                residual_dir / f"{safe_slug(sample_id)}.npz",
                freq_hz=grid,
                center_power_db=db_from_power(raw),
                raw_power=raw,
                excess_power_plane=plane,
                background_power_db_plane=db_from_power(base),
                excess_power=plane,
                background_power_db=db_from_power(base),
                primary_method=np.asarray("plane"),
                plane_valid=np.asarray(plane_valid),
                available_methods=np.asarray(["raw", "plane"]),
            )
            rows.append({
                "sample_id": sample_id,
                "label": label,
                "scene": name,
                "dataset": f"{name}_{label}",
                "time": name,
                "center": f"00_{i:02d}",
            })
    pd.DataFrame(rows).to_csv(v9_dir / "v9_all_features.csv", index=False, encoding="utf-8-sig")
    return {"name": name, "group": group, "v9_dir": str(v9_dir)}


def self_test() -> None:
    print("开始v14合成数据自检……")
    rng = np.random.default_rng(12345)
    config = Config()
    with tempfile.TemporaryDirectory(prefix="v14_selftest_") as temp:
        root = Path(temp)
        lab_path = root / "lab_pure_leak.wav"
        synthesize_lab_wav(lab_path, config, rng)
        grid = np.linspace(config.freq_low_hz, config.freq_high_hz, config.n_spectral_bins)
        scenes = [
            make_synthetic_scene(root, "factory_A", "AB", 0, grid, rng),
            make_synthetic_scene(root, "factory_B", "AB", 1, grid, rng),
            make_synthetic_scene(root, "factory_C", "CD", 2, grid, rng),
            make_synthetic_scene(root, "factory_D", "CD", 3, grid, rng),
        ]
        output = root / "output"
        results = run_analysis(scenes, [str(lab_path)], output, config)
        ranking = pd.read_csv(results["ranking"])
        if ranking.empty:
            raise AssertionError("自检没有生成方法排名")
        transfer = pd.read_csv(results["transfer_summary"])
        if set(ranking["method"]) != {"raw", "plane"}:
            raise AssertionError(f"自检方法不完整:\n{ranking}")
        if transfer.empty or not np.isfinite(transfer["transfer_auc"]).any():
            raise AssertionError("自检没有生成有效的AB/CD跨组AUC")
        if float(ranking.iloc[0]["recommendation_score"]) < 0.70:
            raise AssertionError(f"自检最高方法分数异常:\n{ranking}")
        print("\nV14自检通过：raw/plane读取、实验室相似度、AB/CD共同成分和跨组验证均正常。")
        print(ranking[["rank", "method", "worst_scene_lab_auc", "worst_pair_transfer_auc", "eligible_as_primary"]].to_string(index=False))


# =============================================================================
# 12. 命令行
# =============================================================================


def main() -> None:
    parser = argparse.ArgumentParser(description="实验室纯泄漏参考与现场降噪方法验证")
    parser.add_argument("--config", type=str, default=None, help="JSON配置文件")
    parser.add_argument("--output-dir", type=str, default=None, help="覆盖输出目录")
    parser.add_argument("--self-test", action="store_true", help="运行合成数据自检")
    args = parser.parse_args()

    if args.self_test:
        self_test()
        return

    scenes, lab_wavs, output_dir, config = parse_config(args.config)
    if args.output_dir:
        output_dir = Path(args.output_dir)
    run_analysis(scenes, lab_wavs, output_dir, config)


if __name__ == "__main__":
    main()
