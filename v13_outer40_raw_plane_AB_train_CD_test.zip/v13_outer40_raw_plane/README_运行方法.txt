V13 outer40：A+B训练，C/D分别测试，raw和plane都运行
========================================================

重要：请使用本文件夹中的两个新版程序：
1. v13_1_AB_train_CD_test_outer40_raw_plane.py
2. v12_shared_leak_component_discovery.py

旧版v13只能直接读取场景根目录的plane结果；这个新版增加了 methods/raw 和 methods/plane 的读取支持。

一、推荐：一条命令自动跑完
----------------------------
假设v9配置中的输出目录是：
D:\wurenji\v9_ABCD_outer40_results

打开CMD，进入本文件夹：
cd /d 你存放本文件夹的路径

运行：
python run_AB_train_CD_test_raw_plane.py ^
  --v9-root "D:\wurenji\v9_ABCD_outer40_results" ^
  --output-root "D:\wurenji\v13_AB_train_CD_test_outer40_results"

程序自动依次执行：
1. raw：A+B训练
2. raw：C和D分别测试
3. plane：A+B训练
4. plane：C和D分别测试

二、输出目录
------------
D:\wurenji\v13_AB_train_CD_test_outer40_results
├─ configs
│  ├─ v13_train_AB_raw.json
│  ├─ v13_test_CD_raw.json
│  ├─ v13_train_AB_plane.json
│  └─ v13_test_CD_plane.json
├─ raw
│  ├─ train_AB
│  └─ test_CD
└─ plane
   ├─ train_AB
   └─ test_CD

最重要结果：
raw\test_CD\v13_external_test_summary.csv
plane\test_CD\v13_external_test_summary.csv

逐样本结果：
raw\test_CD\v13_external_test_predictions.csv
plane\test_CD\v13_external_test_predictions.csv

三、只运行一种方法
------------------
只跑raw：
python run_AB_train_CD_test_raw_plane.py --v9-root "D:\wurenji\v9_ABCD_outer40_results" --output-root "D:\wurenji\v13_AB_train_CD_test_outer40_results" --methods raw

只跑plane：
python run_AB_train_CD_test_raw_plane.py --v9-root "D:\wurenji\v9_ABCD_outer40_results" --output-root "D:\wurenji\v13_AB_train_CD_test_outer40_results" --methods plane

四、手动运行四条命令
--------------------
一键运行器会先在输出目录的configs文件夹自动生成四个JSON。生成后也可以手动运行：

python v13_1_AB_train_CD_test_outer40_raw_plane.py train --config "D:\wurenji\v13_AB_train_CD_test_outer40_results\configs\v13_train_AB_raw.json"
python v13_1_AB_train_CD_test_outer40_raw_plane.py evaluate --config "D:\wurenji\v13_AB_train_CD_test_outer40_results\configs\v13_test_CD_raw.json"
python v13_1_AB_train_CD_test_outer40_raw_plane.py train --config "D:\wurenji\v13_AB_train_CD_test_outer40_results\configs\v13_train_AB_plane.json"
python v13_1_AB_train_CD_test_outer40_raw_plane.py evaluate --config "D:\wurenji\v13_AB_train_CD_test_outer40_results\configs\v13_test_CD_plane.json"

五、路径要求
------------
--v9-root下面必须是：
factory_A\methods\raw\residual_npz
factory_A\methods\plane\residual_npz
factory_B\methods\raw\residual_npz
factory_B\methods\plane\residual_npz
factory_C\methods\raw\residual_npz
factory_C\methods\plane\residual_npz
factory_D\methods\raw\residual_npz
factory_D\methods\plane\residual_npz

并且每个方法目录中应有 v9_method_features.csv。
