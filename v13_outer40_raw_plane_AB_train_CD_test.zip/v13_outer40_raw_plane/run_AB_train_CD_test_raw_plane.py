# -*- coding: utf-8 -*-
"""一次完成：A+B训练，C和D分别测试，依次运行 raw 和 plane。"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Dict, List

SCENES = ("factory_A", "factory_B", "factory_C", "factory_D")
METHODS = ("raw", "plane")


def ensure_method_input(v9_root: Path, scene: str, method: str) -> Path:
    method_dir = v9_root / scene / "methods" / method
    metadata = method_dir / "v9_method_features.csv"
    residual_dir = method_dir / "residual_npz"
    if not method_dir.exists():
        raise FileNotFoundError(f"找不到方法目录: {method_dir}")
    if not metadata.exists():
        raise FileNotFoundError(f"找不到方法元数据: {metadata}")
    if not residual_dir.exists():
        raise FileNotFoundError(f"找不到NPZ目录: {residual_dir}")
    n_npz = len(list(residual_dir.glob("*.npz")))
    if n_npz == 0:
        raise FileNotFoundError(f"目录中没有NPZ: {residual_dir}")
    return method_dir


def write_json(path: Path, payload: Dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def run_command(args: List[str], cwd: Path) -> None:
    print("\n执行命令:")
    print(" ".join(f'"{x}"' if " " in x else x for x in args))
    completed = subprocess.run(args, cwd=str(cwd), check=False)
    if completed.returncode != 0:
        raise RuntimeError(f"命令运行失败，退出码={completed.returncode}")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="outer40：分别使用raw和plane进行A+B训练、C/D独立测试"
    )
    parser.add_argument(
        "--v9-root",
        required=True,
        help="v9输出根目录；其下应包含 factory_A、factory_B、factory_C、factory_D",
    )
    parser.add_argument(
        "--output-root",
        required=True,
        help="v13结果输出根目录",
    )
    parser.add_argument(
        "--methods",
        nargs="+",
        choices=METHODS,
        default=list(METHODS),
        help="默认同时运行 raw plane；也可只写 raw 或 plane",
    )
    args = parser.parse_args()

    v9_root = Path(args.v9_root).expanduser().resolve()
    output_root = Path(args.output_root).expanduser().resolve()
    script_dir = Path(__file__).resolve().parent
    v13_script = script_dir / "v13_1_AB_train_CD_test_outer40_raw_plane.py"
    core_script = script_dir / "v12_shared_leak_component_discovery.py"

    if not v13_script.exists():
        raise FileNotFoundError(f"找不到v13程序: {v13_script}")
    if not core_script.exists():
        raise FileNotFoundError(f"找不到v12依赖: {core_script}")

    output_root.mkdir(parents=True, exist_ok=True)
    configs_dir = output_root / "configs"
    summary: Dict[str, Dict[str, str]] = {}

    for method in args.methods:
        print("\n" + "=" * 100)
        print(f"开始方法: {method}")
        print("=" * 100)

        method_dirs = {
            scene: ensure_method_input(v9_root, scene, method) for scene in SCENES
        }
        method_output = output_root / method
        train_output = method_output / "train_AB"
        test_output = method_output / "test_CD"

        train_cfg_path = configs_dir / f"v13_train_AB_{method}.json"
        train_cfg = {
            "scenes": [
                {"name": "factory_A", "v9_dir": str(method_dirs["factory_A"])},
                {"name": "factory_B", "v9_dir": str(method_dirs["factory_B"])},
            ],
            "output_dir": str(train_output),
            "algorithm": {
                "model_support_fraction": 1.0
            },
        }
        write_json(train_cfg_path, train_cfg)
        run_command(
            [sys.executable, str(v13_script), "train", "--config", str(train_cfg_path)],
            script_dir,
        )

        model_file = train_output / "v13_frozen_shared_leak_model.npz"
        if not model_file.exists():
            raise FileNotFoundError(f"训练结束后未找到模型: {model_file}")

        test_cfg_path = configs_dir / f"v13_test_CD_{method}.json"
        test_cfg = {
            "model_file": str(model_file),
            "test_scenes": [
                {"name": "factory_C", "v9_dir": str(method_dirs["factory_C"])},
                {"name": "factory_D", "v9_dir": str(method_dirs["factory_D"])},
            ],
            "output_dir": str(test_output),
        }
        write_json(test_cfg_path, test_cfg)
        run_command(
            [sys.executable, str(v13_script), "evaluate", "--config", str(test_cfg_path)],
            script_dir,
        )

        summary[method] = {
            "train_config": str(train_cfg_path),
            "test_config": str(test_cfg_path),
            "model": str(model_file),
            "train_summary": str(train_output / "v13_loso_calibrated_scene_summary.csv"),
            "test_summary": str(test_output / "v13_external_test_summary.csv"),
            "test_predictions": str(test_output / "v13_external_test_predictions.csv"),
        }

    summary_path = output_root / "raw_plane_run_manifest.json"
    write_json(summary_path, summary)

    print("\n" + "=" * 100)
    print("raw/plane全部运行完成")
    print("结果根目录:", output_root)
    for method, paths in summary.items():
        print(f"  {method}测试汇总: {paths['test_summary']}")
    print("运行清单:", summary_path)
    print("=" * 100)


if __name__ == "__main__":
    main()
