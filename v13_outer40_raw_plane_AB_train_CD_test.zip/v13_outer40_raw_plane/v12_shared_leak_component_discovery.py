# -*- coding: utf-8 -*-
"""
v12_shared_leak_component_discovery.py

v12：多场景公共泄漏成分发现 + 留一场景验证
================================================

核心思想
--------
不再使用 Factory A 的 TRUE/FALSE 指纹直接判断其他场景，而是：

    1. 每个样本先由 v9 完成“中心点 - 周围空间背景”，得到局部残差；
    2. 每个场景内部独立比较 TRUE 与 FALSE：
           scene_contrast = TRUE残差特征 - FALSE残差特征
       这样 A/B/C 分别使用自己的 FALSE 去除自己的场景噪声；
    3. 比较多个场景的 scene_contrast，只保留方向一致、每个场景都稳定的成分；
    4. 做留一场景验证：
           A+B 发现公共成分，C 只测试；
           A+C 发现公共成分，B 只测试；
           B+C 发现公共成分，A 只测试。

输入
----
每个场景均为 v9 输出目录，至少包含：
    v9_all_features.csv
    residual_npz/*.npz
可选：
    v9_run_config.json

运行
----
1. 修改本文件开头 SCENES 和 OUTPUT_DIR 后直接运行：
       python v12_shared_leak_component_discovery.py

2. 使用配置文件：
       python v12_shared_leak_component_discovery.py --config v12_scene_config.json

3. 自检：
       python v12_shared_leak_component_discovery.py --self-test

重要说明
--------
- 输出的“公共泄漏频谱”是跨场景稳定的【泄漏残差富集频谱】，不是带相位的纯净WAV。
- 最终使用全部场景生成的公共成分用于发现和展示；
  是否具备跨场景稳定性，以 leave-one-scene-out 结果为准。
- 留一场景测试时，测试场景标签只用于最后计算AUC/准确率，不参与训练场景公共成分生成。
- 测试场景样本会做无标签的场景内稳健中心化，用于消除整体基线漂移；
  因而LOSO主要评价“公共属性在新场景内能否把TRUE排在FALSE前面”。
"""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import shutil
import sys
import tempfile
import traceback
import zipfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    from scipy.stats import mannwhitneyu, spearmanr
except Exception as exc:
    raise RuntimeError("缺少 scipy，请运行: pip install scipy") from exc

try:
    from sklearn.metrics import (
        accuracy_score,
        balanced_accuracy_score,
        confusion_matrix,
        roc_auc_score,
    )
except Exception as exc:
    raise RuntimeError("缺少 scikit-learn，请运行: pip install scikit-learn") from exc

try:
    import matplotlib.pyplot as plt
except Exception as exc:
    raise RuntimeError("缺少 matplotlib，请运行: pip install matplotlib") from exc


# =============================================================================
# 1. 优先修改这里
# =============================================================================

SCENES: List[Dict[str, str]] = [
    {
        "name": "factory_A",
        "v9_dir": r"C:\Users\jiangxinru6\Desktop\wurenji\leak_v9_local_background_results",
    },
    {
        "name": "factory_B",
        "v9_dir": r"C:\Users\jiangxinru6\Desktop\wurenji\factory_B_v9_results",
    },
    {
        "name": "factory_C",
        "v9_dir": r"C:\Users\jiangxinru6\Desktop\wurenji\factory_C_v9_results",
    },
]

OUTPUT_DIR = r"C:\Users\jiangxinru6\Desktop\wurenji\leak_v12_shared_component_results"

# v10同类指纹参数。三场景必须统一。
FREQ_LOW_HZ = 20_000.0
FREQ_HIGH_HZ = 80_000.0
N_SPECTRAL_BINS = 256
N_TEMPORAL_QUANTILES = 64
N_SPATIAL_RINGS = 4
SPATIAL_DB_SCALE = 6.0
SPECTRAL_SMOOTH_BINS = 5

# 场景内 TRUE-FALSE 稳健效应量阈值。
# effect = (TRUE中位数-FALSE中位数) / pooled_MAD
MIN_ABS_EFFECT = 0.35

# 单维度场景内AUC至少偏离0.5多少才视为具有稳定方向。
# 0.58表示正向属性要求AUC>=0.58，负向属性要求AUC<=0.42。
MIN_DIRECTIONAL_AUC = 0.58

# 最终“严格公共成分”要求所有场景方向一致；
# “多数公共成分”默认要求至少2/3场景一致。
STRICT_SUPPORT_FRACTION = 1.0
MAJORITY_SUPPORT_FRACTION = 2.0 / 3.0

# 每个模块在LOSO总分中的权重。
SPECTRAL_SCORE_WEIGHT = 1.0
TEMPORAL_SCORE_WEIGHT = 1.0
SPATIAL_SCORE_WEIGHT = 1.0

# 每个模块最多保留多少个公共维度。None表示全部。
MAX_SELECTED_SPECTRAL_DIMS: Optional[int] = 100
MAX_SELECTED_TEMPORAL_DIMS: Optional[int] = 40
MAX_SELECTED_SPATIAL_DIMS: Optional[int] = None

# 稳健标准化常数。
EPS = 1.0e-12
ROBUST_Z_CLIP = 8.0

VALID_LABELS = {"TRUE_LEAK", "FALSE_LEAK"}
RANDOM_STATE = 42


# =============================================================================
# 2. 数据结构
# =============================================================================


@dataclass(frozen=True)
class V12Config:
    freq_low_hz: float = FREQ_LOW_HZ
    freq_high_hz: float = FREQ_HIGH_HZ
    n_spectral_bins: int = N_SPECTRAL_BINS
    n_temporal_quantiles: int = N_TEMPORAL_QUANTILES
    n_spatial_rings: int = N_SPATIAL_RINGS
    spatial_db_scale: float = SPATIAL_DB_SCALE
    spectral_smooth_bins: int = SPECTRAL_SMOOTH_BINS
    min_abs_effect: float = MIN_ABS_EFFECT
    min_directional_auc: float = MIN_DIRECTIONAL_AUC
    strict_support_fraction: float = STRICT_SUPPORT_FRACTION
    majority_support_fraction: float = MAJORITY_SUPPORT_FRACTION
    spectral_score_weight: float = SPECTRAL_SCORE_WEIGHT
    temporal_score_weight: float = TEMPORAL_SCORE_WEIGHT
    spatial_score_weight: float = SPATIAL_SCORE_WEIGHT
    max_selected_spectral_dims: Optional[int] = MAX_SELECTED_SPECTRAL_DIMS
    max_selected_temporal_dims: Optional[int] = MAX_SELECTED_TEMPORAL_DIMS
    max_selected_spatial_dims: Optional[int] = MAX_SELECTED_SPATIAL_DIMS
    robust_z_clip: float = ROBUST_Z_CLIP
    random_state: int = RANDOM_STATE


@dataclass
class Fingerprint:
    sample_id: str
    dataset: str
    scene: str
    time: str
    center: str
    label: str
    npz_path: str
    spectral: np.ndarray
    temporal: np.ndarray
    spatial: np.ndarray


@dataclass
class BlockContrast:
    block: str
    dim_names: List[str]
    true_median: np.ndarray
    false_median: np.ndarray
    delta: np.ndarray
    scale: np.ndarray
    effect: np.ndarray
    auc: np.ndarray
    p_value: np.ndarray
    n_true: int
    n_false: int


@dataclass
class SceneContrast:
    scene: str
    spectral: BlockContrast
    temporal: BlockContrast
    spatial: BlockContrast


# =============================================================================
# 3. 通用工具
# =============================================================================


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def safe_slug(value: Any, max_len: int = 180) -> str:
    text = str(value).strip() or "sample"
    text = re.sub(r"[^0-9A-Za-z_\-.]+", "_", text)
    return text.strip("._")[:max_len] or "sample"


def safe_array(values: Any) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    return np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)


def moving_average(values: np.ndarray, window: int) -> np.ndarray:
    arr = safe_array(values).ravel()
    if window <= 1 or arr.size < 3:
        return arr
    window = int(max(1, min(window, arr.size)))
    if window % 2 == 0:
        window += 1
    kernel = np.ones(window, dtype=float) / window
    padded = np.pad(arr, (window // 2, window // 2), mode="edge")
    return np.convolve(padded, kernel, mode="valid")


def normalize_probability(values: np.ndarray) -> np.ndarray:
    arr = np.maximum(safe_array(values).ravel(), 0.0)
    total = float(np.sum(arr))
    if total <= EPS:
        return np.zeros_like(arr)
    return arr / total


def power_from_db(values: np.ndarray) -> np.ndarray:
    arr = np.clip(safe_array(values), -300.0, 300.0)
    return np.power(10.0, arr / 10.0)


def robust_mad(matrix: np.ndarray, axis: int = 0) -> np.ndarray:
    arr = safe_array(matrix)
    med = np.median(arr, axis=axis, keepdims=True)
    mad = np.median(np.abs(arr - med), axis=axis)
    return 1.4826 * mad


def robust_scale_floor(scales: np.ndarray) -> float:
    arr = safe_array(scales).ravel()
    positive = arr[arr > EPS]
    if positive.size == 0:
        return 1.0e-6
    # 防止某些几乎常数维度因极小MAD产生虚高效应量。
    return max(float(np.median(positive)) * 0.05, 1.0e-6)


def robust_standardize_unlabeled(matrix: np.ndarray, clip: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """仅使用当前批次所有样本，不使用标签，消除场景整体基线。"""
    arr = safe_array(matrix)
    med = np.median(arr, axis=0)
    scale = robust_mad(arr, axis=0)
    floor = robust_scale_floor(scale)
    scale = np.maximum(scale, floor)
    z = (arr - med) / scale
    return np.clip(z, -clip, clip), med, scale


def safe_auc(y_true: np.ndarray, score: np.ndarray) -> float:
    y = np.asarray(y_true, dtype=int)
    s = np.asarray(score, dtype=float)
    try:
        if len(np.unique(y)) < 2:
            return np.nan
        return float(roc_auc_score(y, s))
    except Exception:
        return np.nan


def safe_mannwhitney_p(true_values: np.ndarray, false_values: np.ndarray) -> float:
    try:
        if len(true_values) == 0 or len(false_values) == 0:
            return np.nan
        return float(mannwhitneyu(true_values, false_values, alternative="two-sided").pvalue)
    except Exception:
        return np.nan


def confusion_metrics(y_true: np.ndarray, score: np.ndarray, threshold: float = 0.0) -> Dict[str, Any]:
    y = np.asarray(y_true, dtype=int)
    pred = (np.asarray(score, dtype=float) >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {
        "accuracy": float(accuracy_score(y, pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y, pred)),
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp),
    }


def cosine_signed(a: np.ndarray, b: np.ndarray) -> float:
    x = safe_array(a).ravel()
    y = safe_array(b).ravel()
    if x.shape != y.shape or x.size == 0:
        return np.nan
    denom = float(np.linalg.norm(x) * np.linalg.norm(y))
    if denom <= EPS:
        return np.nan
    return float(np.clip(np.dot(x, y) / denom, -1.0, 1.0))


def weighted_block_score(z: np.ndarray, weights: np.ndarray) -> np.ndarray:
    matrix = safe_array(z)
    w = safe_array(weights).ravel()
    if matrix.ndim != 2 or matrix.shape[1] != w.size:
        raise ValueError(f"分数维度不一致: matrix={matrix.shape}, weights={w.shape}")
    denom = float(np.sum(np.abs(w)))
    if denom <= EPS:
        return np.zeros(matrix.shape[0], dtype=float)
    return matrix @ w / denom


def combine_scores(score_dict: Dict[str, np.ndarray], config: V12Config) -> np.ndarray:
    blocks: List[np.ndarray] = []
    weights: List[float] = []
    mapping = {
        "spectral": config.spectral_score_weight,
        "temporal": config.temporal_score_weight,
        "spatial": config.spatial_score_weight,
    }
    for block, weight in mapping.items():
        arr = score_dict.get(block)
        if arr is not None and np.any(np.abs(arr) > EPS) and weight > 0:
            blocks.append(np.asarray(arr, dtype=float))
            weights.append(float(weight))
    if not blocks:
        first = next(iter(score_dict.values()))
        return np.zeros_like(first, dtype=float)
    matrix = np.vstack(blocks)
    return np.average(matrix, axis=0, weights=np.asarray(weights, dtype=float))


# =============================================================================
# 4. 从v9残差构造频谱、时间、空间指纹
# =============================================================================


def locate_npz_file(residual_dir: Path, sample_id: str) -> Optional[Path]:
    direct = residual_dir / f"{safe_slug(sample_id)}.npz"
    if direct.exists():
        return direct
    matches = list(residual_dir.glob(f"*{safe_slug(sample_id)}*.npz"))
    if len(matches) == 1:
        return matches[0]
    return None


def build_spectral_fingerprint(
    freq_hz: np.ndarray,
    excess_power: np.ndarray,
    config: V12Config,
) -> Tuple[np.ndarray, np.ndarray]:
    freq = safe_array(freq_hz).ravel()
    excess = np.maximum(safe_array(excess_power), 0.0)
    if excess.ndim != 2 or excess.shape[0] != freq.size:
        raise ValueError(f"频谱维度异常: freq={freq.shape}, excess={excess.shape}")

    spectrum = np.mean(excess, axis=1)
    # 压缩极强窄带峰，避免机械单线谱完全支配结果。
    spectrum = np.sqrt(np.maximum(spectrum, 0.0))
    spectrum = moving_average(spectrum, config.spectral_smooth_bins)

    grid = np.linspace(config.freq_low_hz, config.freq_high_hz, config.n_spectral_bins)
    valid = np.isfinite(freq) & np.isfinite(spectrum)
    if np.sum(valid) < 2:
        raise ValueError("有效频率点不足")
    order = np.argsort(freq[valid])
    interp = np.interp(
        grid,
        freq[valid][order],
        spectrum[valid][order],
        left=0.0,
        right=0.0,
    )
    return normalize_probability(interp), grid


def build_temporal_fingerprint(
    excess_power: np.ndarray,
    background_power_db: np.ndarray,
    config: V12Config,
) -> np.ndarray:
    excess = np.maximum(safe_array(excess_power), 0.0)
    bg_db = safe_array(background_power_db)
    if excess.ndim != 2 or bg_db.shape != excess.shape:
        raise ValueError(f"时间维度异常: excess={excess.shape}, bg={bg_db.shape}")

    bg_power = power_from_db(bg_db)
    ratio = np.sum(excess, axis=0) / (np.sum(bg_power, axis=0) + 1.0e-20)
    ratio = np.maximum(np.nan_to_num(ratio, nan=0.0, posinf=0.0, neginf=0.0), 0.0)
    log_ratio = np.log1p(ratio)

    q_grid = np.linspace(0.0, 1.0, config.n_temporal_quantiles)
    curve = np.quantile(log_ratio, q_grid)
    scale = float(np.quantile(curve, 0.95))
    if scale <= EPS:
        scaled_curve = np.zeros_like(curve)
    else:
        scaled_curve = np.clip(curve / scale, 0.0, 1.5) / 1.5

    q90 = max(float(np.quantile(ratio, 0.90)), 1.0e-20)
    active_10 = float(np.mean(ratio >= 0.10 * q90))
    active_30 = float(np.mean(ratio >= 0.30 * q90))
    active_50 = float(np.mean(ratio >= 0.50 * q90))
    cv = float(np.std(ratio) / (np.mean(ratio) + 1.0e-20))
    cv_bounded = float(cv / (1.0 + cv))

    return np.concatenate([scaled_curve, [active_10, active_30, active_50, cv_bounded]])


def fill_missing(values: np.ndarray) -> np.ndarray:
    arr = safe_array(values).ravel()
    valid = np.isfinite(arr)
    if np.all(valid):
        return arr
    if not np.any(valid):
        return np.zeros_like(arr)
    idx = np.arange(arr.size)
    return np.interp(idx, idx[valid], arr[valid])


def build_spatial_fingerprint(
    xy: np.ndarray,
    point_band_db: np.ndarray,
    background_indices: np.ndarray,
    config: V12Config,
) -> np.ndarray:
    coords = safe_array(xy)
    values = safe_array(point_band_db).ravel()
    bg_idx = np.asarray(background_indices, dtype=int).ravel()

    if coords.ndim != 2 or coords.shape[1] != 2 or coords.shape[0] != values.size:
        raise ValueError(f"空间维度异常: xy={coords.shape}, values={values.shape}")

    distances = np.linalg.norm(coords, axis=1)
    center_index = int(np.argmin(distances))
    neighbor_mask = np.arange(values.size) != center_index
    if int(np.sum(neighbor_mask)) < config.n_spatial_rings:
        raise ValueError("空间邻居数量不足")

    bg_idx = bg_idx[(bg_idx >= 0) & (bg_idx < values.size)]
    baseline = (
        float(np.median(values[bg_idx]))
        if bg_idx.size
        else float(np.median(values[neighbor_mask]))
    )

    neighbor_dist = distances[neighbor_mask]
    neighbor_values = values[neighbor_mask]
    max_radius = max(float(np.max(neighbor_dist)), EPS)
    norm_r = neighbor_dist / max_radius

    edges = np.linspace(0.0, 1.0, config.n_spatial_rings + 1)
    rings: List[float] = []
    for i in range(config.n_spatial_rings):
        left, right = edges[i], edges[i + 1]
        if i == config.n_spatial_rings - 1:
            mask = (norm_r >= left) & (norm_r <= right + EPS)
        else:
            mask = (norm_r >= left) & (norm_r < right)
        rings.append(float(np.median(neighbor_values[mask])) if np.any(mask) else np.nan)

    profile_db = np.concatenate([[values[center_index]], fill_missing(np.asarray(rings))]) - baseline
    mapped = 0.5 + 0.5 * np.tanh(profile_db / max(config.spatial_db_scale, EPS))

    center_rank = float(np.mean(values <= values[center_index]))
    try:
        corr, _ = spearmanr(neighbor_dist, neighbor_values)
        corr = float(corr) if np.isfinite(corr) else 0.0
    except Exception:
        corr = 0.0
    radial_decay = float(np.clip((1.0 - corr) / 2.0, 0.0, 1.0))
    return np.clip(np.concatenate([mapped, [center_rank, radial_decay]]), 0.0, 1.0)


def temporal_dim_names(config: V12Config) -> List[str]:
    names = [f"temporal_quantile_{i:03d}" for i in range(config.n_temporal_quantiles)]
    names.extend(["temporal_active_10", "temporal_active_30", "temporal_active_50", "temporal_cv"])
    return names


def spatial_dim_names(config: V12Config) -> List[str]:
    names = ["spatial_center"]
    names.extend([f"spatial_ring_{i + 1}" for i in range(config.n_spatial_rings)])
    names.extend(["spatial_center_rank", "spatial_radial_decay"])
    return names


# =============================================================================
# 5. 文件预检、参数一致性和数据读取
# =============================================================================


def locate_v9_metadata_csv(v9_dir: Path) -> Path:
    """同时支持场景根目录和 methods/raw、methods/plane 方法目录。"""
    candidates = [
        v9_dir / "v9_all_features.csv",
        v9_dir / "v9_method_features.csv",
    ]
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(
        f"找不到元数据CSV，已检查: {candidates[0]} 和 {candidates[1]}"
    )


def read_v9_metadata(v9_dir: Path) -> pd.DataFrame:
    csv_path = locate_v9_metadata_csv(v9_dir)
    df = pd.read_csv(
        csv_path,
        dtype={"sample_id": str, "center": str, "time": str, "center_file": str},
    )
    required = ["sample_id", "dataset", "scene", "time", "center", "label"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"{csv_path.name} 缺少列: {missing}")
    df["label"] = df["label"].astype(str)
    df = df[df["label"].isin(VALID_LABELS)].copy().reset_index(drop=True)
    if df.empty:
        raise ValueError(f"{csv_path} 没有TRUE_LEAK/FALSE_LEAK样本")
    return df


def load_v9_config(v9_dir: Path) -> Optional[Dict[str, Any]]:
    # 方法目录 methods/raw 或 methods/plane 中通常没有配置文件，向上回到场景根目录查找。
    candidates = [v9_dir / "v9_run_config.json"]
    if v9_dir.parent.name == "methods":
        candidates.append(v9_dir.parent.parent / "v9_run_config.json")
    path = next((x for x in candidates if x.exists()), None)
    if path is None:
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        cfg = payload.get("config", payload)
        return cfg if isinstance(cfg, dict) else None
    except Exception:
        return None


def flatten_dict(data: Dict[str, Any], prefix: str = "") -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    for key, value in data.items():
        full = f"{prefix}.{key}" if prefix else str(key)
        if isinstance(value, dict):
            out.update(flatten_dict(value, full))
        elif isinstance(value, (str, int, float, bool)) or value is None:
            out[full] = value
    return out


def compare_v9_configs(scene_configs: Dict[str, Optional[Dict[str, Any]]]) -> pd.DataFrame:
    valid = {k: v for k, v in scene_configs.items() if v is not None}
    if len(valid) < 2:
        return pd.DataFrame(columns=["parameter", "reference_scene", "scene", "reference_value", "scene_value", "match"])
    ref_scene = next(iter(valid))
    ref = flatten_dict(valid[ref_scene])
    rows: List[Dict[str, Any]] = []
    # 与结果无关或必然因目录变化而不同的字段不比较。
    ignore_tokens = {"output", "path", "root", "dataset", "created", "time_folder"}
    for scene, cfg in valid.items():
        if scene == ref_scene:
            continue
        flat = flatten_dict(cfg)
        keys = sorted(set(ref) | set(flat))
        for key in keys:
            if any(token in key.lower() for token in ignore_tokens):
                continue
            rv = ref.get(key, "<MISSING>")
            sv = flat.get(key, "<MISSING>")
            if isinstance(rv, float) or isinstance(sv, float):
                try:
                    match = bool(np.isclose(float(rv), float(sv), rtol=1e-9, atol=1e-12))
                except Exception:
                    match = rv == sv
            else:
                match = rv == sv
            rows.append({
                "parameter": key,
                "reference_scene": ref_scene,
                "scene": scene,
                "reference_value": rv,
                "scene_value": sv,
                "match": int(match),
            })
    return pd.DataFrame(rows)


def preflight_scene(scene_name: str, v9_dir: Path) -> Tuple[pd.DataFrame, pd.DataFrame]:
    metadata = read_v9_metadata(v9_dir)
    residual_dir = v9_dir / "residual_npz"
    rows: List[Dict[str, Any]] = []
    for _, row in metadata.iterrows():
        sample_id = str(row["sample_id"])
        npz = locate_npz_file(residual_dir, sample_id) if residual_dir.exists() else None
        npz_ok = 0
        npz_error = ""
        keys = ""
        if npz is None:
            npz_error = "NPZ_NOT_FOUND"
        else:
            try:
                with np.load(npz, allow_pickle=False) as data:
                    required = {
                        "freq_hz",
                        "background_power_db",
                        "xy",
                        "point_band_db",
                        "background_indices",
                    }
                    missing = sorted(required - set(data.files))
                    component_ok = any(
                        key in data.files for key in ("excess_power", "component_power", "raw_power")
                    )
                    if not component_ok:
                        missing.append("excess_power|component_power|raw_power")
                    if missing:
                        npz_error = f"MISSING_KEYS:{missing}"
                    else:
                        npz_ok = 1
                    keys = ",".join(data.files)
            except Exception as exc:
                npz_error = f"{type(exc).__name__}:{exc}"
        rows.append({
            "configured_scene": scene_name,
            "sample_id": sample_id,
            "csv_scene": str(row["scene"]),
            "label": str(row["label"]),
            "time": str(row["time"]),
            "center": str(row["center"]),
            "center_file": str(row.get("center_file", "")),
            "npz_path": str(npz) if npz else "",
            "npz_ok": npz_ok,
            "npz_error": npz_error,
            "npz_keys": keys,
        })
    report = pd.DataFrame(rows)
    summary = pd.DataFrame([{
        "scene": scene_name,
        "v9_dir": str(v9_dir),
        "n_samples": len(metadata),
        "n_true": int((metadata["label"] == "TRUE_LEAK").sum()),
        "n_false": int((metadata["label"] == "FALSE_LEAK").sum()),
        "n_npz_ok": int(report["npz_ok"].sum()),
        "npz_success_rate": float(report["npz_ok"].mean()) if len(report) else 0.0,
        "n_csv_scene_values": int(metadata["scene"].nunique()),
        "csv_scene_values": "|".join(sorted(metadata["scene"].astype(str).unique().tolist())),
    }])
    return report, summary


def load_scene_fingerprints(
    configured_scene: str,
    v9_dir: Path,
    config: V12Config,
) -> Tuple[List[Fingerprint], np.ndarray, pd.DataFrame]:
    metadata = read_v9_metadata(v9_dir)
    residual_dir = v9_dir / "residual_npz"
    if not residual_dir.exists():
        raise FileNotFoundError(
            f"找不到 {residual_dir}。请先用v9参数 --save-residual-npz 生成完整残差。"
        )

    fps: List[Fingerprint] = []
    failures: List[Dict[str, Any]] = []
    frequency_grid: Optional[np.ndarray] = None

    for _, row in metadata.iterrows():
        sample_id = str(row["sample_id"])
        npz_path = locate_npz_file(residual_dir, sample_id)
        if npz_path is None:
            failures.append({"scene": configured_scene, "sample_id": sample_id, "error": "找不到NPZ", "traceback": ""})
            continue
        try:
            with np.load(npz_path, allow_pickle=False) as data:
                if "excess_power" in data.files:
                    component_power = np.asarray(data["excess_power"], dtype=float)
                elif "component_power" in data.files:
                    component_power = np.asarray(data["component_power"], dtype=float)
                elif "raw_power" in data.files:
                    component_power = np.asarray(data["raw_power"], dtype=float)
                else:
                    raise KeyError("NPZ缺少 excess_power/component_power/raw_power")
                spectral, grid = build_spectral_fingerprint(data["freq_hz"], component_power, config)
                temporal = build_temporal_fingerprint(component_power, data["background_power_db"], config)
                spatial = build_spatial_fingerprint(
                    data["xy"], data["point_band_db"], data["background_indices"], config
                )
            if frequency_grid is None:
                frequency_grid = grid
            elif not np.allclose(frequency_grid, grid):
                raise ValueError("统一频率网格不一致")
            fps.append(Fingerprint(
                sample_id=sample_id,
                dataset=str(row["dataset"]),
                scene=configured_scene,
                time=str(row["time"]),
                center=str(row["center"]),
                label=str(row["label"]),
                npz_path=str(npz_path),
                spectral=spectral,
                temporal=temporal,
                spatial=spatial,
            ))
        except Exception as exc:
            failures.append({
                "scene": configured_scene,
                "sample_id": sample_id,
                "error": f"{type(exc).__name__}: {exc}",
                "traceback": traceback.format_exc(),
            })

    if not fps:
        raise RuntimeError(f"场景 {configured_scene} 没有成功构造任何指纹")
    labels = {fp.label for fp in fps}
    if labels != VALID_LABELS:
        raise ValueError(f"场景 {configured_scene} 必须同时包含TRUE/FALSE，当前={sorted(labels)}")
    return fps, np.asarray(frequency_grid), pd.DataFrame(failures)


# =============================================================================
# 6. 场景内TRUE-FALSE差异提取
# =============================================================================


def block_matrix(fps: Sequence[Fingerprint], block: str) -> np.ndarray:
    return np.vstack([safe_array(getattr(fp, block)).ravel() for fp in fps])


def compute_block_contrast(
    fps: Sequence[Fingerprint],
    block: str,
    dim_names: Sequence[str],
) -> BlockContrast:
    matrix = block_matrix(fps, block)
    labels = np.asarray([fp.label for fp in fps])
    true_mask = labels == "TRUE_LEAK"
    false_mask = labels == "FALSE_LEAK"
    t = matrix[true_mask]
    f = matrix[false_mask]
    if len(t) == 0 or len(f) == 0:
        raise ValueError(f"{block} 缺少TRUE或FALSE")

    true_median = np.median(t, axis=0)
    false_median = np.median(f, axis=0)
    delta = true_median - false_median
    pooled = np.vstack([t, f])
    scale = robust_mad(pooled, axis=0)
    scale = np.maximum(scale, robust_scale_floor(scale))
    effect = np.clip(delta / scale, -20.0, 20.0)

    y = np.concatenate([np.ones(len(t), dtype=int), np.zeros(len(f), dtype=int)])
    auc = np.zeros(matrix.shape[1], dtype=float)
    p_value = np.zeros(matrix.shape[1], dtype=float)
    for j in range(matrix.shape[1]):
        scores = np.concatenate([t[:, j], f[:, j]])
        auc[j] = safe_auc(y, scores)
        p_value[j] = safe_mannwhitney_p(t[:, j], f[:, j])

    return BlockContrast(
        block=block,
        dim_names=list(dim_names),
        true_median=true_median,
        false_median=false_median,
        delta=delta,
        scale=scale,
        effect=effect,
        auc=auc,
        p_value=p_value,
        n_true=len(t),
        n_false=len(f),
    )


def compute_scene_contrast(
    scene: str,
    fps: Sequence[Fingerprint],
    frequency_grid: np.ndarray,
    config: V12Config,
) -> SceneContrast:
    spectral_names = [f"spectral_{hz:.2f}Hz" for hz in frequency_grid]
    return SceneContrast(
        scene=scene,
        spectral=compute_block_contrast(fps, "spectral", spectral_names),
        temporal=compute_block_contrast(fps, "temporal", temporal_dim_names(config)),
        spatial=compute_block_contrast(fps, "spatial", spatial_dim_names(config)),
    )


def contrast_to_rows(scene_contrast: SceneContrast, frequency_grid: np.ndarray) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for block_name in ["spectral", "temporal", "spatial"]:
        bc: BlockContrast = getattr(scene_contrast, block_name)
        for i, dim in enumerate(bc.dim_names):
            row = {
                "scene": scene_contrast.scene,
                "block": block_name,
                "dimension_index": i,
                "dimension": dim,
                "true_median": bc.true_median[i],
                "false_median": bc.false_median[i],
                "delta_true_minus_false": bc.delta[i],
                "pooled_robust_scale": bc.scale[i],
                "robust_effect": bc.effect[i],
                "auc_true_higher": bc.auc[i],
                "auc_oriented": max(bc.auc[i], 1.0 - bc.auc[i]) if np.isfinite(bc.auc[i]) else np.nan,
                "direction": "TRUE_HIGHER" if bc.delta[i] > 0 else ("TRUE_LOWER" if bc.delta[i] < 0 else "EQUAL"),
                "mannwhitney_p": bc.p_value[i],
                "n_true": bc.n_true,
                "n_false": bc.n_false,
            }
            if block_name == "spectral":
                row["frequency_hz"] = float(frequency_grid[i])
            rows.append(row)
    return pd.DataFrame(rows)


# =============================================================================
# 7. 多场景公共成分
# =============================================================================


def dimension_is_valid(effect: np.ndarray, auc: np.ndarray, config: V12Config) -> np.ndarray:
    positive = (effect >= config.min_abs_effect) & (auc >= config.min_directional_auc)
    negative = (effect <= -config.min_abs_effect) & (auc <= 1.0 - config.min_directional_auc)
    return positive | negative


def build_shared_block(
    scene_contrasts: Sequence[SceneContrast],
    block: str,
    support_fraction: float,
    config: V12Config,
    max_selected_dims: Optional[int],
) -> Dict[str, Any]:
    bcs: List[BlockContrast] = [getattr(sc, block) for sc in scene_contrasts]
    effects = np.vstack([bc.effect for bc in bcs])
    aucs = np.vstack([bc.auc for bc in bcs])
    deltas = np.vstack([bc.delta for bc in bcs])
    true_medians = np.vstack([bc.true_median for bc in bcs])
    false_medians = np.vstack([bc.false_median for bc in bcs])

    valid = np.vstack([dimension_is_valid(bc.effect, bc.auc, config) for bc in bcs])
    signs = np.sign(effects)
    consensus_sign = np.sign(np.median(effects, axis=0))
    consensus_sign[consensus_sign == 0] = np.sign(np.mean(effects[:, consensus_sign == 0], axis=0))

    same_sign_valid = valid & (signs == consensus_sign[None, :])
    support_count = np.sum(same_sign_valid, axis=0)
    required = max(1, int(math.ceil(len(bcs) * support_fraction - 1.0e-12)))
    selected = support_count >= required
    # common_selected用于完整展示“发现了哪些公共属性”；selected稍后可为评分截断。
    common_selected = selected.copy()

    # 公共权重：方向由共识决定，大小取各支持场景绝对效应中位数，
    # 再乘以支持比例，避免仅少数场景出现的维度过强。
    magnitudes = np.zeros(effects.shape[1], dtype=float)
    for j in range(effects.shape[1]):
        vals = np.abs(effects[same_sign_valid[:, j], j])
        magnitudes[j] = float(np.median(vals)) if vals.size else 0.0
    support_ratio = support_count / max(len(bcs), 1)
    weights = consensus_sign * magnitudes * support_ratio
    weights[~selected] = 0.0

    # 限制维度数量时按|权重|选最稳的维度。
    if max_selected_dims is not None and int(np.sum(selected)) > max_selected_dims:
        keep_idx = np.argsort(np.abs(weights))[::-1][: int(max_selected_dims)]
        keep_mask = np.zeros_like(selected, dtype=bool)
        keep_mask[keep_idx] = True
        selected &= keep_mask
        weights[~selected] = 0.0

    return {
        "block": block,
        "dim_names": bcs[0].dim_names,
        "effects": effects,
        "aucs": aucs,
        "deltas": deltas,
        "true_medians": true_medians,
        "false_medians": false_medians,
        "valid": valid,
        "consensus_sign": consensus_sign,
        "support_count": support_count,
        "support_ratio": support_ratio,
        "required_support_count": required,
        "common_selected": common_selected,
        "selected": selected,
        "weights": weights,
        "common_effect": consensus_sign * magnitudes,
    }


def build_shared_components(
    scene_contrasts: Sequence[SceneContrast],
    support_fraction: float,
    config: V12Config,
) -> Dict[str, Dict[str, Any]]:
    return {
        "spectral": build_shared_block(
            scene_contrasts,
            "spectral",
            support_fraction,
            config,
            config.max_selected_spectral_dims,
        ),
        "temporal": build_shared_block(
            scene_contrasts,
            "temporal",
            support_fraction,
            config,
            config.max_selected_temporal_dims,
        ),
        "spatial": build_shared_block(
            scene_contrasts,
            "spatial",
            support_fraction,
            config,
            config.max_selected_spatial_dims,
        ),
    }


def shared_rows(
    shared: Dict[str, Dict[str, Any]],
    scene_names: Sequence[str],
    frequency_grid: np.ndarray,
    label: str,
) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for block, info in shared.items():
        for i, dim in enumerate(info["dim_names"]):
            row: Dict[str, Any] = {
                "component_set": label,
                "block": block,
                "dimension_index": i,
                "dimension": dim,
                "common_selected": int(info["common_selected"][i]),
                "selected_for_score": int(info["selected"][i]),
                "consensus_direction": (
                    "TRUE_HIGHER" if info["consensus_sign"][i] > 0
                    else "TRUE_LOWER" if info["consensus_sign"][i] < 0
                    else "NO_DIRECTION"
                ),
                "support_count": int(info["support_count"][i]),
                "support_ratio": float(info["support_ratio"][i]),
                "required_support_count": int(info["required_support_count"]),
                "common_effect": float(info["common_effect"][i]),
                "shared_weight": float(info["weights"][i]),
            }
            if block == "spectral":
                row["frequency_hz"] = float(frequency_grid[i])
            for s_idx, scene in enumerate(scene_names):
                row[f"{scene}__effect"] = float(info["effects"][s_idx, i])
                row[f"{scene}__auc"] = float(info["aucs"][s_idx, i])
                row[f"{scene}__delta"] = float(info["deltas"][s_idx, i])
                row[f"{scene}__valid"] = int(info["valid"][s_idx, i])
            rows.append(row)
    return pd.DataFrame(rows)


def build_shared_positive_spectrum(
    scene_contrasts: Sequence[SceneContrast],
    shared_spectral: Dict[str, Any],
) -> np.ndarray:
    """
    仅保留所有支持场景中 TRUE>FALSE 的频率，作为“公共泄漏残差富集频谱”。
    负方向属性另在common_attributes中保留，不混入干净富集频谱。
    """
    positive_selected = shared_spectral["common_selected"] & (shared_spectral["consensus_sign"] > 0)
    scene_profiles: List[np.ndarray] = []
    for sc in scene_contrasts:
        delta = np.maximum(sc.spectral.delta, 0.0)
        delta[~positive_selected] = 0.0
        scene_profiles.append(normalize_probability(delta))
    if not scene_profiles:
        return np.zeros(len(shared_spectral["dim_names"]), dtype=float)
    median_profile = np.median(np.vstack(scene_profiles), axis=0)
    median_profile[~positive_selected] = 0.0
    return normalize_probability(median_profile)


# =============================================================================
# 8. 留一场景验证
# =============================================================================


def scene_matrices(fps: Sequence[Fingerprint]) -> Dict[str, np.ndarray]:
    return {
        "spectral": block_matrix(fps, "spectral"),
        "temporal": block_matrix(fps, "temporal"),
        "spatial": block_matrix(fps, "spatial"),
    }


def contrast_similarity_on_selected(
    train_shared: Dict[str, Any],
    test_contrast: BlockContrast,
) -> Dict[str, float]:
    selected = np.asarray(train_shared["selected"], dtype=bool)
    if not np.any(selected):
        return {"effect_cosine": np.nan, "sign_agreement": np.nan, "n_selected": 0}
    train_effect = np.asarray(train_shared["common_effect"])[selected]
    test_effect = np.asarray(test_contrast.effect)[selected]
    cosine = cosine_signed(train_effect, test_effect)
    valid = np.abs(test_effect) >= 0.05
    if np.any(valid):
        sign_agreement = float(np.mean(np.sign(train_effect[valid]) == np.sign(test_effect[valid])))
    else:
        sign_agreement = np.nan
    return {
        "effect_cosine": cosine,
        "sign_agreement": sign_agreement,
        "n_selected": int(np.sum(selected)),
    }


def leave_one_scene_out_validation(
    all_fps: Dict[str, List[Fingerprint]],
    all_contrasts: Dict[str, SceneContrast],
    config: V12Config,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    scenes = list(all_fps)
    sample_rows: List[Dict[str, Any]] = []
    summary_rows: List[Dict[str, Any]] = []

    for test_scene in scenes:
        train_scenes = [s for s in scenes if s != test_scene]
        train_contrasts = [all_contrasts[s] for s in train_scenes]
        # LOSO严格要求所有训练场景都支持该维度。
        shared = build_shared_components(train_contrasts, 1.0, config)

        test_fps = all_fps[test_scene]
        matrices = scene_matrices(test_fps)
        labels = np.asarray([fp.label for fp in test_fps])
        y = (labels == "TRUE_LEAK").astype(int)

        block_scores: Dict[str, np.ndarray] = {}
        block_auc: Dict[str, float] = {}
        for block in ["spectral", "temporal", "spatial"]:
            z, _, _ = robust_standardize_unlabeled(matrices[block], config.robust_z_clip)
            scores = weighted_block_score(z, shared[block]["weights"])
            block_scores[block] = scores
            block_auc[block] = safe_auc(y, scores)

        overall = combine_scores(block_scores, config)
        metrics = confusion_metrics(y, overall, threshold=0.0)
        auc = safe_auc(y, overall)

        test_contrast = all_contrasts[test_scene]
        contrast_checks: Dict[str, Dict[str, float]] = {}
        for block in ["spectral", "temporal", "spatial"]:
            contrast_checks[block] = contrast_similarity_on_selected(
                shared[block], getattr(test_contrast, block)
            )

        for i, fp in enumerate(test_fps):
            sample_rows.append({
                "test_scene": test_scene,
                "train_scenes": "|".join(train_scenes),
                "sample_id": fp.sample_id,
                "dataset": fp.dataset,
                "time": fp.time,
                "center": fp.center,
                "true_label": fp.label,
                "score_spectral": float(block_scores["spectral"][i]),
                "score_temporal": float(block_scores["temporal"][i]),
                "score_spatial": float(block_scores["spatial"][i]),
                "shared_leak_score": float(overall[i]),
                "pred_at_zero": "TRUE_LEAK" if overall[i] >= 0 else "FALSE_LEAK",
                "correct_at_zero": int((overall[i] >= 0) == bool(y[i])),
            })

        true_scores = overall[y == 1]
        false_scores = overall[y == 0]
        summary_rows.append({
            "test_scene": test_scene,
            "train_scenes": "|".join(train_scenes),
            "n_samples": len(test_fps),
            "n_true": int(np.sum(y == 1)),
            "n_false": int(np.sum(y == 0)),
            "shared_score_auc": auc,
            "score0_accuracy": metrics["accuracy"],
            "score0_balanced_accuracy": metrics["balanced_accuracy"],
            "tn": metrics["tn"],
            "fp": metrics["fp"],
            "fn": metrics["fn"],
            "tp": metrics["tp"],
            "true_score_median": float(np.median(true_scores)) if true_scores.size else np.nan,
            "false_score_median": float(np.median(false_scores)) if false_scores.size else np.nan,
            "spectral_auc": block_auc["spectral"],
            "temporal_auc": block_auc["temporal"],
            "spatial_auc": block_auc["spatial"],
            "spectral_contrast_cosine": contrast_checks["spectral"]["effect_cosine"],
            "spectral_sign_agreement": contrast_checks["spectral"]["sign_agreement"],
            "spectral_selected_dims": contrast_checks["spectral"]["n_selected"],
            "temporal_contrast_cosine": contrast_checks["temporal"]["effect_cosine"],
            "temporal_sign_agreement": contrast_checks["temporal"]["sign_agreement"],
            "temporal_selected_dims": contrast_checks["temporal"]["n_selected"],
            "spatial_contrast_cosine": contrast_checks["spatial"]["effect_cosine"],
            "spatial_sign_agreement": contrast_checks["spatial"]["sign_agreement"],
            "spatial_selected_dims": contrast_checks["spatial"]["n_selected"],
        })

    return pd.DataFrame(sample_rows), pd.DataFrame(summary_rows)


# =============================================================================
# 9. 图表与报告
# =============================================================================


def plot_scene_spectral_contrasts(
    scene_contrasts: Dict[str, SceneContrast],
    frequency_grid: np.ndarray,
    output_dir: Path,
) -> Path:
    fig_dir = output_dir / "figures"
    ensure_dir(fig_dir)
    plt.figure(figsize=(12, 6))
    for scene, contrast in scene_contrasts.items():
        plt.plot(frequency_grid / 1000.0, contrast.spectral.effect, label=scene)
    plt.axhline(0.0, linewidth=1)
    plt.xlabel("Frequency (kHz)")
    plt.ylabel("Robust TRUE-FALSE effect")
    plt.title("Scene-specific spectral leak contrasts")
    plt.legend()
    plt.grid(True, alpha=0.25)
    plt.tight_layout()
    path = fig_dir / "v12_scene_spectral_contrasts.png"
    plt.savefig(path, dpi=160)
    plt.close()
    return path


def plot_shared_spectrum(
    frequency_grid: np.ndarray,
    strict_spectrum: np.ndarray,
    majority_spectrum: np.ndarray,
    output_dir: Path,
) -> Path:
    fig_dir = output_dir / "figures"
    ensure_dir(fig_dir)
    plt.figure(figsize=(12, 6))
    plt.plot(frequency_grid / 1000.0, strict_spectrum, label="Strict common (all scenes)")
    plt.plot(frequency_grid / 1000.0, majority_spectrum, label="Majority common")
    plt.xlabel("Frequency (kHz)")
    plt.ylabel("Normalized common leak enrichment")
    plt.title("Cross-scene shared leak residual spectrum")
    plt.legend()
    plt.grid(True, alpha=0.25)
    plt.tight_layout()
    path = fig_dir / "v12_shared_leak_spectrum.png"
    plt.savefig(path, dpi=160)
    plt.close()
    return path


def plot_loso_scores(sample_df: pd.DataFrame, output_dir: Path) -> Path:
    fig_dir = output_dir / "figures"
    ensure_dir(fig_dir)
    scenes = sample_df["test_scene"].astype(str).unique().tolist()
    positions: List[float] = []
    values: List[np.ndarray] = []
    labels: List[str] = []
    pos = 1.0
    for scene in scenes:
        sub = sample_df[sample_df["test_scene"] == scene]
        for cls in ["FALSE_LEAK", "TRUE_LEAK"]:
            arr = sub.loc[sub["true_label"] == cls, "shared_leak_score"].to_numpy(dtype=float)
            values.append(arr)
            positions.append(pos)
            labels.append(f"{scene}\n{cls.replace('_LEAK', '')}")
            pos += 1.0
        pos += 0.5
    plt.figure(figsize=(max(10, len(labels) * 1.3), 6))
    plt.boxplot(values, positions=positions, widths=0.65, showfliers=True)
    plt.axhline(0.0, linewidth=1)
    plt.xticks(positions, labels, rotation=30, ha="right")
    plt.ylabel("LOSO shared leak score")
    plt.title("Leave-one-scene-out shared-component scores")
    plt.grid(True, axis="y", alpha=0.25)
    plt.tight_layout()
    path = fig_dir / "v12_loso_score_distribution.png"
    plt.savefig(path, dpi=160)
    plt.close()
    return path


def write_report(
    output_dir: Path,
    preflight_summary: pd.DataFrame,
    config_consistency: pd.DataFrame,
    strict_shared: Dict[str, Dict[str, Any]],
    majority_shared: Dict[str, Dict[str, Any]],
    loso_summary: pd.DataFrame,
    config: V12Config,
) -> Path:
    lines: List[str] = []
    lines.append("v12 多场景公共泄漏成分发现报告")
    lines.append("=" * 96)
    lines.append("")
    lines.append("方法:")
    lines.append("  1. v9先对每个样本执行中心点减周围空间背景，得到局部残差。")
    lines.append("  2. 每个场景内部独立计算TRUE-FALSE稳健差异，使用自己的FALSE去除自己的场景干扰。")
    lines.append("  3. 只保留多个场景方向一致且效应足够的频谱、时间、空间维度。")
    lines.append("  4. 使用两个场景发现公共成分，第三场景只做测试，循环留一场景验证。")
    lines.append("")
    lines.append("输入质量:")
    for _, row in preflight_summary.iterrows():
        lines.append(
            f"  {row['scene']}: n={int(row['n_samples'])}, "
            f"TRUE={int(row['n_true'])}, FALSE={int(row['n_false'])}, "
            f"NPZ成功率={row['npz_success_rate']:.3f}"
        )
    if config_consistency.empty:
        lines.append("  v9参数一致性: 未能比较（可能缺少v9_run_config.json）。")
    else:
        n_bad = int((config_consistency["match"] == 0).sum())
        lines.append(f"  v9参数不一致项: {n_bad}")
    lines.append("")
    lines.append("公共属性数量:")
    for block in ["spectral", "temporal", "spatial"]:
        lines.append(
            f"  {block}: 严格公共={int(np.sum(strict_shared[block]['common_selected']))}, "
            f"严格评分使用={int(np.sum(strict_shared[block]['selected']))}, "
            f"多数公共={int(np.sum(majority_shared[block]['common_selected']))}, "
            f"多数评分使用={int(np.sum(majority_shared[block]['selected']))}"
        )
    lines.append("")
    lines.append("留一场景验证（AUC是主要指标，0阈值准确率仅作辅助）:")
    for _, row in loso_summary.iterrows():
        lines.append(
            f"  test={row['test_scene']}, train={row['train_scenes']}, "
            f"overall_AUC={row['shared_score_auc']:.4f}, "
            f"spectral_AUC={row['spectral_auc']:.4f}, "
            f"temporal_AUC={row['temporal_auc']:.4f}, "
            f"spatial_AUC={row['spatial_auc']:.4f}, "
            f"bal_acc@0={row['score0_balanced_accuracy']:.4f}, "
            f"T_med={row['true_score_median']:.5f}, F_med={row['false_score_median']:.5f}"
        )
    lines.append("")
    lines.append("如何解释:")
    lines.append("  - LOSO AUC高：训练场景发现的公共方向在新场景仍能把TRUE排在FALSE前面。")
    lines.append("  - 频谱AUC高而空间AUC低：频谱共性稳定，空间结构更受场景传播和定位影响。")
    lines.append("  - strict公共频谱为空：当前阈值下不存在所有场景都稳定增强的同一频率，不应强行宣称纯净频谱。")
    lines.append("  - 本程序得到的是跨场景稳定泄漏残差属性，不是带相位、可试听的纯净泄漏WAV。")
    lines.append("")
    lines.append("关键参数:")
    for key, value in asdict(config).items():
        lines.append(f"  {key}: {value}")

    path = output_dir / "v12_report.txt"
    path.write_text("\n".join(lines), encoding="utf-8")
    return path


# =============================================================================
# 10. 主流程
# =============================================================================


def parse_scene_config(config_path: Optional[str]) -> Tuple[List[Dict[str, str]], str, V12Config]:
    scenes = [dict(x) for x in SCENES]
    output_dir = OUTPUT_DIR
    config = V12Config()
    if config_path:
        path = Path(config_path)
        if not path.exists():
            raise FileNotFoundError(f"找不到配置文件: {path}")
        payload = json.loads(path.read_text(encoding="utf-8"))
        scenes = payload.get("scenes", scenes)
        output_dir = payload.get("output_dir", output_dir)
        overrides = payload.get("algorithm", {})
        valid_fields = set(asdict(config))
        unknown = sorted(set(overrides) - valid_fields)
        if unknown:
            raise ValueError(f"配置中存在未知algorithm字段: {unknown}")
        config = V12Config(**{**asdict(config), **overrides})
    if len(scenes) < 3:
        raise ValueError("至少需要3个同时包含TRUE/FALSE的场景，才能做两场景发现、第三场景验证")
    names = [str(s.get("name", "")).strip() for s in scenes]
    if any(not x for x in names) or len(names) != len(set(names)):
        raise ValueError("每个scene必须有非空且唯一的name")
    for scene in scenes:
        if not str(scene.get("v9_dir", "")).strip():
            raise ValueError(f"scene {scene.get('name')} 缺少v9_dir")
    return scenes, output_dir, config


def run_analysis(
    scenes: Sequence[Dict[str, str]],
    output_dir: Path,
    config: V12Config,
) -> Dict[str, Path]:
    ensure_dir(output_dir)
    print("=" * 100)
    print("v12 多场景公共泄漏成分发现")
    print("=" * 100)
    print("\n第一步：文件格式、标签、NPZ字段和v9参数预检")

    preflight_reports: List[pd.DataFrame] = []
    preflight_summaries: List[pd.DataFrame] = []
    v9_configs: Dict[str, Optional[Dict[str, Any]]] = {}

    for item in scenes:
        name = str(item["name"])
        v9_dir = Path(str(item["v9_dir"]))
        report, summary = preflight_scene(name, v9_dir)
        preflight_reports.append(report)
        preflight_summaries.append(summary)
        v9_configs[name] = load_v9_config(v9_dir)
        row = summary.iloc[0]
        print(
            f"  {name}: n={int(row['n_samples'])}, TRUE={int(row['n_true'])}, "
            f"FALSE={int(row['n_false'])}, NPZ={int(row['n_npz_ok'])}/{int(row['n_samples'])}"
        )
        if int(row["n_true"]) < 2 or int(row["n_false"]) < 2:
            raise ValueError(f"场景{name}每类至少需要2个样本")
        if float(row["npz_success_rate"]) < 1.0:
            raise ValueError(f"场景{name}存在缺失或异常NPZ，请先查看v12_preflight_samples.csv")

    preflight_df = pd.concat(preflight_reports, ignore_index=True)
    preflight_summary = pd.concat(preflight_summaries, ignore_index=True)
    preflight_df.to_csv(output_dir / "v12_preflight_samples.csv", index=False, encoding="utf-8-sig")
    preflight_summary.to_csv(output_dir / "v12_preflight_summary.csv", index=False, encoding="utf-8-sig")

    consistency = compare_v9_configs(v9_configs)
    consistency.to_csv(output_dir / "v12_v9_parameter_consistency.csv", index=False, encoding="utf-8-sig")
    if not consistency.empty:
        bad = consistency[consistency["match"] == 0]
        print(f"  v9参数不一致项: {len(bad)}")
        if len(bad):
            print("  [警告] v9参数存在差异。结果仍会生成，但应优先查看v12_v9_parameter_consistency.csv。")
    else:
        print("  v9参数一致性：缺少足够的v9_run_config.json，无法自动比较。")

    print("\n第二步：读取每个场景v9残差并构造指纹")
    all_fps: Dict[str, List[Fingerprint]] = {}
    all_contrasts: Dict[str, SceneContrast] = {}
    failure_frames: List[pd.DataFrame] = []
    frequency_grid: Optional[np.ndarray] = None

    for item in scenes:
        name = str(item["name"])
        fps, grid, failures = load_scene_fingerprints(name, Path(str(item["v9_dir"])), config)
        if frequency_grid is None:
            frequency_grid = grid
        elif not np.allclose(frequency_grid, grid):
            raise ValueError(f"场景{name}统一频率网格与其他场景不一致")
        all_fps[name] = fps
        all_contrasts[name] = compute_scene_contrast(name, fps, grid, config)
        failure_frames.append(failures)
        n_t = sum(fp.label == "TRUE_LEAK" for fp in fps)
        n_f = sum(fp.label == "FALSE_LEAK" for fp in fps)
        print(f"  {name}: 成功={len(fps)}, TRUE={n_t}, FALSE={n_f}")

    failure_df = pd.concat(failure_frames, ignore_index=True) if failure_frames else pd.DataFrame()
    failure_df.to_csv(output_dir / "v12_fingerprint_failures.csv", index=False, encoding="utf-8-sig")
    assert frequency_grid is not None

    print("\n第三步：每个场景独立执行TRUE-FALSE，提取本场景泄漏候选成分")
    contrast_df = pd.concat(
        [contrast_to_rows(all_contrasts[s], frequency_grid) for s in all_contrasts],
        ignore_index=True,
    )
    contrast_df.to_csv(output_dir / "v12_scene_internal_contrasts.csv", index=False, encoding="utf-8-sig")
    for scene, sc in all_contrasts.items():
        sc_rows = contrast_to_rows(sc, frequency_grid)
        sc_rows.to_csv(
            output_dir / f"v12_{safe_slug(scene)}_leak_contrast.csv",
            index=False,
            encoding="utf-8-sig",
        )
        n_spec_pos = int(np.sum((sc.spectral.effect >= config.min_abs_effect) & (sc.spectral.auc >= config.min_directional_auc)))
        print(f"  {scene}: TRUE高于FALSE的稳定频率维度={n_spec_pos}")

    print("\n第四步：寻找所有场景严格公共成分和多数公共成分")
    scene_names = list(all_contrasts)
    contrast_list = [all_contrasts[s] for s in scene_names]
    strict_shared = build_shared_components(contrast_list, config.strict_support_fraction, config)
    majority_shared = build_shared_components(contrast_list, config.majority_support_fraction, config)

    strict_rows = shared_rows(strict_shared, scene_names, frequency_grid, "strict_all_scenes")
    majority_rows = shared_rows(majority_shared, scene_names, frequency_grid, "majority_scenes")
    common_attributes = pd.concat([strict_rows, majority_rows], ignore_index=True)
    common_attributes.to_csv(output_dir / "v12_cross_scene_common_attributes.csv", index=False, encoding="utf-8-sig")

    strict_spectrum = build_shared_positive_spectrum(contrast_list, strict_shared["spectral"])
    majority_spectrum = build_shared_positive_spectrum(contrast_list, majority_shared["spectral"])
    spectrum_df = pd.DataFrame({
        "frequency_hz": frequency_grid,
        "frequency_khz": frequency_grid / 1000.0,
        "strict_common_leak_enrichment": strict_spectrum,
        "majority_common_leak_enrichment": majority_spectrum,
        "strict_common_selected": strict_shared["spectral"]["common_selected"].astype(int),
        "strict_score_selected": strict_shared["spectral"]["selected"].astype(int),
        "strict_consensus_direction": strict_shared["spectral"]["consensus_sign"],
        "strict_shared_weight": strict_shared["spectral"]["weights"],
        "strict_support_ratio": strict_shared["spectral"]["support_ratio"],
        "majority_common_selected": majority_shared["spectral"]["common_selected"].astype(int),
        "majority_score_selected": majority_shared["spectral"]["selected"].astype(int),
        "majority_shared_weight": majority_shared["spectral"]["weights"],
        "majority_support_ratio": majority_shared["spectral"]["support_ratio"],
    })
    spectrum_df.to_csv(output_dir / "v12_shared_leak_spectrum.csv", index=False, encoding="utf-8-sig")

    np.savez_compressed(
        output_dir / "v12_shared_leak_component.npz",
        frequency_grid_hz=frequency_grid,
        strict_shared_spectrum=strict_spectrum,
        majority_shared_spectrum=majority_spectrum,
        strict_spectral_weights=strict_shared["spectral"]["weights"],
        strict_temporal_weights=strict_shared["temporal"]["weights"],
        strict_spatial_weights=strict_shared["spatial"]["weights"],
        majority_spectral_weights=majority_shared["spectral"]["weights"],
        majority_temporal_weights=majority_shared["temporal"]["weights"],
        majority_spatial_weights=majority_shared["spatial"]["weights"],
        scene_names=np.asarray(scene_names),
        config_json=np.asarray(json.dumps(asdict(config), ensure_ascii=False)),
    )

    for block in ["spectral", "temporal", "spatial"]:
        print(
            f"  {block}: 严格公共={int(np.sum(strict_shared[block]['common_selected']))}, "
            f"严格评分使用={int(np.sum(strict_shared[block]['selected']))}, "
            f"多数公共={int(np.sum(majority_shared[block]['common_selected']))}, "
            f"多数评分使用={int(np.sum(majority_shared[block]['selected']))}"
        )

    print("\n第五步：两个场景发现公共成分，第三场景验证")
    loso_samples, loso_summary = leave_one_scene_out_validation(all_fps, all_contrasts, config)
    loso_samples.to_csv(output_dir / "v12_loso_sample_scores.csv", index=False, encoding="utf-8-sig")
    loso_summary.to_csv(output_dir / "v12_loso_validation_summary.csv", index=False, encoding="utf-8-sig")
    for _, row in loso_summary.iterrows():
        print(
            f"  test={row['test_scene']}: overall_AUC={row['shared_score_auc']:.4f}, "
            f"spectral={row['spectral_auc']:.4f}, temporal={row['temporal_auc']:.4f}, "
            f"spatial={row['spatial_auc']:.4f}, bal_acc@0={row['score0_balanced_accuracy']:.4f}"
        )

    # 保存样本指纹，方便后续研究而无需重读NPZ。
    fp_rows: List[Dict[str, Any]] = []
    for scene, fps in all_fps.items():
        for fp in fps:
            row: Dict[str, Any] = {
                "scene": scene,
                "sample_id": fp.sample_id,
                "label": fp.label,
                "dataset": fp.dataset,
                "time": fp.time,
                "center": fp.center,
            }
            for i, value in enumerate(fp.spectral):
                row[f"spectral_{i:03d}"] = value
            for i, value in enumerate(fp.temporal):
                row[f"temporal_{i:03d}"] = value
            for i, value in enumerate(fp.spatial):
                row[f"spatial_{i:03d}"] = value
            fp_rows.append(row)
    pd.DataFrame(fp_rows).to_csv(output_dir / "v12_all_sample_fingerprints.csv", index=False, encoding="utf-8-sig")

    plot_scene_spectral_contrasts(all_contrasts, frequency_grid, output_dir)
    plot_shared_spectrum(frequency_grid, strict_spectrum, majority_spectrum, output_dir)
    plot_loso_scores(loso_samples, output_dir)

    report_path = write_report(
        output_dir,
        preflight_summary,
        consistency,
        strict_shared,
        majority_shared,
        loso_summary,
        config,
    )
    config_path = output_dir / "v12_run_config.json"
    config_path.write_text(
        json.dumps({"scenes": list(scenes), "output_dir": str(output_dir), "algorithm": asdict(config)}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print("\n" + "=" * 100)
    print("v12处理完成")
    print("输出目录:", output_dir)
    print("场景内差异:", output_dir / "v12_scene_internal_contrasts.csv")
    print("公共属性:", output_dir / "v12_cross_scene_common_attributes.csv")
    print("公共泄漏频谱:", output_dir / "v12_shared_leak_spectrum.csv")
    print("留一场景验证:", output_dir / "v12_loso_validation_summary.csv")
    print("报告:", report_path)
    print("=" * 100)

    return {
        "report": report_path,
        "shared_spectrum": output_dir / "v12_shared_leak_spectrum.csv",
        "common_attributes": output_dir / "v12_cross_scene_common_attributes.csv",
        "loso_summary": output_dir / "v12_loso_validation_summary.csv",
        "shared_npz": output_dir / "v12_shared_leak_component.npz",
    }


# =============================================================================
# 11. 合成数据自检
# =============================================================================


def make_synthetic_v9_scene(
    root: Path,
    scene: str,
    scene_index: int,
    rng: np.random.Generator,
    n_each: int = 12,
) -> Path:
    v9_dir = root / f"{scene}_v9"
    residual_dir = v9_dir / "residual_npz"
    ensure_dir(residual_dir)

    freq = np.linspace(20_000.0, 80_000.0, 256)
    time_s = np.linspace(0.0, 1.0, 48)
    # 中心 + 8圈*8方向（满足outer40：排除内圈24点、使用外圈40点）
    coords = [(0.0, 0.0)]
    for radius in [5.0, 10.0, 15.0, 20.0, 25.0, 30.0, 35.0, 40.0]:
        for angle in np.linspace(0, 2 * np.pi, 8, endpoint=False):
            coords.append((radius * np.cos(angle), radius * np.sin(angle)))
    xy = np.asarray(coords, dtype=float)
    bg_idx = np.argsort(np.linalg.norm(xy, axis=1))[::-1][:40]

    rows: List[Dict[str, Any]] = []
    for label in ["TRUE_LEAK", "FALSE_LEAK"]:
        for i in range(n_each):
            sample_id = f"{scene}_{label}_{i:02d}"
            base_db = -70.0 + 2.0 * scene_index
            bg_shape = 1.5 * np.sin((freq - 20_000.0) / 8000.0 + scene_index)
            bg_db = base_db + bg_shape[:, None] + rng.normal(0, 0.5, size=(len(freq), len(time_s)))
            bg_power = power_from_db(bg_db)

            # 共同泄漏成分：42-60kHz宽带 + 持续；场景间略有频移。
            common = (
                np.exp(-0.5 * ((freq - (48_000 + 600 * scene_index)) / 5200.0) ** 2)
                + 0.7 * np.exp(-0.5 * ((freq - (57_000 + 350 * scene_index)) / 4200.0) ** 2)
            )
            common /= max(float(common.max()), EPS)
            persistent = 0.8 + 0.2 * np.sin(2 * np.pi * (1.5 + 0.1 * scene_index) * time_s + 0.2 * i)

            # 场景私有机械干扰：每个场景频率不同，FALSE中更明显。
            mechanical_freq = 27_000 + scene_index * 6500
            mechanical = np.exp(-0.5 * ((freq - mechanical_freq) / 450.0) ** 2)
            transient = np.zeros_like(time_s)
            transient[(i * 3) % len(time_s): ((i * 3) % len(time_s)) + 4] = 1.0

            if label == "TRUE_LEAK":
                excess = bg_power * (0.55 + 0.08 * rng.normal()) * common[:, None] * persistent[None, :]
                excess += bg_power * 0.03 * mechanical[:, None]
                center_boost = 6.0
                radial_slope = -0.11
            else:
                excess = bg_power * (0.16 + 0.04 * rng.normal()) * common[:, None] * persistent[None, :]
                excess += bg_power * 1.2 * mechanical[:, None] * transient[None, :]
                center_boost = 2.0
                radial_slope = -0.01
            excess = np.maximum(excess * (1.0 + 0.08 * rng.normal(size=excess.shape)), 0.0)

            point_db = base_db + center_boost + radial_slope * np.linalg.norm(xy, axis=1)
            point_db += 0.03 * xy[:, 0] - 0.02 * xy[:, 1]
            point_db += rng.normal(0, 0.35, size=len(xy))

            np.savez_compressed(
                residual_dir / f"{safe_slug(sample_id)}.npz",
                freq_hz=freq,
                time_s=time_s,
                center_power_db=bg_db + 10 * np.log10(1.0 + excess / (bg_power + 1e-30)),
                background_power_db=bg_db,
                residual_db=10 * np.log10(1.0 + excess / (bg_power + 1e-30)),
                excess_power=excess,
                xy=xy,
                point_band_db=point_db,
                background_indices=bg_idx,
                point_weights=np.ones(len(xy)),
            )
            rows.append({
                "sample_id": sample_id,
                "dataset": f"{scene}_{label}",
                "scene": scene,
                "time": f"synthetic_{scene}",
                "center": f"00_{i:02d}",
                "label": label,
                "center_file": f"synthetic_{scene}_00_{i:02d}_beamform_result.wav",
            })

    pd.DataFrame(rows).to_csv(v9_dir / "v9_all_features.csv", index=False, encoding="utf-8-sig")
    (v9_dir / "v9_run_config.json").write_text(
        json.dumps({
            "config": {
                "freq_low_hz": 20000.0,
                "freq_high_hz": 80000.0,
                "stft_nperseg": 4096,
                "stft_noverlap": 2048,
                "background_outer_fraction": 0.65,
            },
            "datasets": [],
        }, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return v9_dir


def self_test() -> None:
    print("开始v12合成数据自检……")
    rng = np.random.default_rng(12345)
    with tempfile.TemporaryDirectory(prefix="v12_selftest_") as temp:
        root = Path(temp)
        scenes: List[Dict[str, str]] = []
        for idx, scene in enumerate(["factory_A", "factory_B", "factory_C"]):
            v9_dir = make_synthetic_v9_scene(root, scene, idx, rng)
            scenes.append({"name": scene, "v9_dir": str(v9_dir)})
        output = root / "output"
        results = run_analysis(scenes, output, V12Config())
        summary = pd.read_csv(results["loso_summary"])
        if len(summary) != 3:
            raise AssertionError("LOSO结果不是3折")
        if float(summary["shared_score_auc"].min()) < 0.80:
            raise AssertionError(f"合成自检LOSO AUC过低:\n{summary}")
        shared = pd.read_csv(results["shared_spectrum"])
        if int(shared["majority_common_selected"].sum()) == 0:
            raise AssertionError("合成自检没有发现多数公共频谱")
        print("\nV12自检通过。")
        print(summary[["test_scene", "shared_score_auc", "spectral_auc", "temporal_auc", "spatial_auc"]].to_string(index=False))


# =============================================================================
# 12. 命令行
# =============================================================================


def main() -> None:
    parser = argparse.ArgumentParser(description="v12多场景公共泄漏成分发现")
    parser.add_argument("--config", type=str, default=None, help="JSON配置文件")
    parser.add_argument("--output-dir", type=str, default=None, help="覆盖输出目录")
    parser.add_argument("--self-test", action="store_true", help="运行合成数据自检")
    args = parser.parse_args()

    if args.self_test:
        self_test()
        return

    scenes, output_dir, config = parse_scene_config(args.config)
    if args.output_dir:
        output_dir = args.output_dir
    run_analysis(scenes, Path(output_dir), config)


if __name__ == "__main__":
    main()
