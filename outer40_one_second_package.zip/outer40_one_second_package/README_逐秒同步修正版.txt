逐秒同步修正版：v9 + v12 + v13
=================================

一、必须修改哪一层
------------------

1. v9必须修改。
   v9直接读取原始WAV并计算STFT、空间背景、残差和NPZ。
   本修正版严格执行：

       center00_00 -> 所有坐标读取[0,1)秒
       center00_01 -> 所有坐标读取[1,2)秒
       center00_02 -> 所有坐标读取[2,3)秒

   中心点和同一center_id下的全部偏移点使用完全相同的1秒。

2. v13不直接读取WAV，所以不需要在v13中再次切WAV。
   但必须删除旧模型并用新v9结果重新训练。

3. v12/v13增加了输入检查。
   若v9_all_features.csv没有second_index、segment_start_second、
   segment_end_second，或每个样本不是严格1秒，程序会停止，避免误用旧NPZ。

二、运行顺序
------------

1. 删除或换一个新的v9输出目录，不能混用旧NPZ。
2. 运行逐秒修正版v9：

   python v9_ABCD_raw_plane_outer40.py --config v9_ABCD_raw_plane_outer40_config_example.json

3. 确认v9_all_features.csv含有：

   time_folder
   second_index
   segment_start_second
   segment_end_second

4. 删除旧v13模型，重新训练A+B。
5. 使用重新训练的模型测试C和D。

三、v13中的时间维度
------------------

v13读取的是v9生成的每秒NPZ。
每个样本只包含该1秒内部的STFT短帧，因此：

    v9样本00_01 = 原始WAV的1到2秒
    v13的temporal特征 = 这一秒内部约20 ms短窗的变化

v13不会再跨越整个长WAV。

四、重要提醒
------------

旧v9的v9_all_features.csv、residual_npz和旧v13模型全部基于原来的时间处理，
不能只替换程序文件后继续用旧结果。必须从v9开始全部重新生成。
