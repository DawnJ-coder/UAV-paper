@echo off
chcp 65001 >nul
python -m pip install --upgrade numpy pandas matplotlib
pause
