@echo off
chcp 65001 >nul
setlocal

echo ==============================================================
echo v22 结果报告绘图
echo ==============================================================
echo.
set /p RESULT_ROOT=请输入 v22 总输出目录（例如 D:\gas\v22_EFG_raw_plane_results）：
if "%RESULT_ROOT%"=="" (
    echo 未输入目录，程序结束。
    pause
    exit /b 1
)

python "%~dp0v22_result_report_plots.py" --root "%RESULT_ROOT%" --reference ALL_LEAKS --formats png pdf svg --dpi 300
if errorlevel 1 (
    echo.
    echo 运行失败，请查看上面的错误信息。
) else (
    echo.
    echo 运行完成。图表位于：%RESULT_ROOT%\v22_报告图表
)
pause
