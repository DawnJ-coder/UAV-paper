v22 运行结果报告绘图程序
========================================

一、最简单的运行方式
--------------------
1. 先正常运行 v22，确保已经生成：
   RAW_vs_PLANE_classification
   RAW_PLANE_vs_anechoic

2. 双击：
   run_v22_report_plots.bat

3. 粘贴 v22 总输出目录，例如：
   D:\gas\v22_EFG_raw_plane_results

4. 输出位置：
   D:\gas\v22_EFG_raw_plane_results\v22_报告图表

二、命令行运行
--------------
python v22_result_report_plots.py --root "D:\gas\v22_EFG_raw_plane_results"

也可以直接读取原 v22 配置文件：
python v22_result_report_plots.py --config "v22_EFG_raw_plane_anechoic_config.json"

三、输出内容
------------
01_数据质量与空间拟合
    第1步样本量、PLANE有效率、残差强度、失败原因等。

02_工厂跨场景分类
    平衡准确率、AUC、灵敏度、特异度、FP/FN、概率分布、
    同一样本变化、特征选择稳定性等。

03_RAW_PLANE与消声室比较
    TRUE/FALSE距离、相似度、场景分离、RAW→PLANE变化、
    逐样本散点、五维特征差异、消声室参考模型质量等。

每张图同时保存：
    PNG：300 dpi，适合Word和PPT
    PDF：矢量格式，适合论文和正式报告
    SVG：矢量格式，便于后期编辑

根目录还会生成：
    00_图表索引.csv
    01_图表与结果详细说明.md
    01_图表与结果详细说明.txt
    02_自动结果摘要.txt
    99_绘图警告.txt

四、报告中最推荐的图
--------------------
1. 各场景平衡准确率 RAW vs PLANE
2. 各场景 PLANE-RAW 平衡准确率
3. 各场景灵敏度与特异度
4. 总体距离分离改善
5. 总体频谱相似度分离改善
6. ALL_LEAKS 下 TRUE/FALSE 距离变化
7. ALL_LEAKS 下同一样本距离散点
8. ALL_LEAKS 下五维特征绝对 z 差异

五、重要说明
------------
1. 消声室距离越小，只表示更接近消声室参考特征。
2. 相似度越大，只表示频谱形状更接近。
3. 距离和相似度都不是泄漏概率。
4. 必须同时比较 TRUE 和 FALSE。
5. 必须检查不同场景方向是否一致。
6. 99_errors.csv 或 99_读取错误.csv 非空时，应先处理错误。

六、依赖
--------
numpy
pandas
matplotlib

如果缺少依赖，双击 install_plot_requirements.bat。
