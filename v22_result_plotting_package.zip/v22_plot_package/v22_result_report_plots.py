#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
v22 运行结果报告绘图程序
=================================
适用结果：
1) RAW_vs_PLANE_classification
2) RAW_PLANE_vs_anechoic
3) v22_EFG_all_features.csv（若存在）

主要功能：
- 自动寻找 v22 输出目录和结果 CSV；
- 生成报告级 PNG（300 dpi）、PDF、SVG；
- 生成图表索引 CSV；
- 生成逐文件、逐图说明 Markdown/TXT；
- 自动给出谨慎的结果摘要，不把“相似度”误写成“泄漏概率”。

推荐命令：
python v22_result_report_plots.py --root "D:\\gas\\v22_EFG_raw_plane_results"

也支持直接读取 v22 配置：
python v22_result_report_plots.py --config "v22_EFG_raw_plane_anechoic_config.json"
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.lines import Line2D
from matplotlib.patches import Patch


# =============================================================================
# 0. 基础配置
# =============================================================================

VERSION = "v22-report-plots-1.0"

CLASSIFICATION_FILES = {
    "summary": "00_最先看这个.csv",
    "scene": "01_每个场景_RAW_vs_PLANE.csv",
    "fold": "02_完整跨场景指标.csv",
    "predictions": "03_全部样本预测_long.csv",
    "paired": "04_同一样本_RAW_vs_PLANE.csv",
    "features": "05_每折模型选中的特征.csv",
    "samples": "06_实际使用的配对样本.csv",
    "errors": "99_读取错误.csv",
}

ANECHOIC_FILES = {
    "summary": "00_最先看这个.csv",
    "long": "01_每个样本_距离与相似度_long.csv",
    "scene": "02_每个场景_TRUE_FALSE分离.csv",
    "compare": "03_RAW变PLANE后的场景变化.csv",
    "paired": "04_同一样本_RAW变PLANE后的变化.csv",
    "features": "05_每个特征与消声室差异.csv",
    "lab": "06_消声室参考模型摘要.csv",
    "lab_files": "07_消声室WAV处理清单.csv",
    "windows": "08_窗口距离明细.csv",
    "errors": "99_errors.csv",
    "run_info": "10_run_info.json",
}

SOURCE_DESCRIPTIONS = {
    "classification/00_最先看这个.csv": (
        "工厂跨场景分类的总体结论。包含 RAW/PLANE 三个留一场景测试的平均平衡准确率、平均 AUC、"
        "样本修正/破坏数量，以及 PLANE-RAW 平衡准确率差值的分层 bootstrap 置信区间。"
    ),
    "classification/01_每个场景_RAW_vs_PLANE.csv": (
        "逐测试场景比较 RAW 与 PLANE。最重要的是 plane_minus_raw_balanced_accuracy："
        "大于 0 表示 PLANE 在该未知场景提升，小于 0 表示下降。"
    ),
    "classification/02_完整跨场景指标.csv": (
        "每个测试场景、每种方法的完整分类指标，包括训练 OOF 指标、冻结阈值、测试 AUC、"
        "平衡准确率、灵敏度、特异度以及 TN/FP/FN/TP。用于诊断提升来自减少漏检还是减少误报。"
    ),
    "classification/03_全部样本预测_long.csv": (
        "每个样本在 RAW 或 PLANE 方法下的 TRUE 概率、冻结阈值、预测结果和正误。"
        "它适合查看概率分布、阈值偏移和具体错误样本。"
    ),
    "classification/04_同一样本_RAW_vs_PLANE.csv": (
        "将同一样本的 RAW 和 PLANE 结果配对。change_category 可直接统计 PLANE 修正了多少 RAW 错误、"
        "又破坏了多少 RAW 正确样本；plane_minus_raw_probability 显示概率如何移动。"
    ),
    "classification/05_每折模型选中的特征.csv": (
        "每个留一场景模型最终选中的特征和逻辑回归系数。特征出现频次反映跨折稳定性，"
        "但系数大小只在同一标准化模型内解释，不能简单等同于物理重要性。"
    ),
    "classification/06_实际使用的配对样本.csv": (
        "实际进入公平对照的样本清单。用于核对每场景、每类别样本数，并检查 plane_valid 与"
        "plane_geometry_ok，防止分类结果建立在大量无效空间拟合上。"
    ),
    "classification/99_读取错误.csv": (
        "分类阶段读取失败记录。正常应为空；非空时必须先处理错误，再解释分类指标。"
    ),
    "anechoic/00_最先看这个.csv": (
        "消声室比较总体摘要。并排给出 TRUE/FALSE 在 RAW/PLANE 下的中位距离、相对距离、综合频谱相似度，"
        "以及 PLANE 是否扩大真假分离。建议优先看 ALL_LEAKS。"
    ),
    "anechoic/01_每个样本_距离与相似度_long.csv": (
        "每个工厂样本、每种方法、每个消声室参考组的完整距离与相似度。"
        "median_distance/p90_distance 越小越接近参考；combined_similarity 越大频谱形状越接近。"
        "这些量不是泄漏概率。"
    ),
    "anechoic/02_每个场景_TRUE_FALSE分离.csv": (
        "按场景、参考组、方法统计 TRUE 与 FALSE。核心量为 distance_separation_false_minus_true"
        "和 spectral_similarity_separation_true_minus_false，二者越大越有利。"
    ),
    "anechoic/03_RAW变PLANE后的场景变化.csv": (
        "最关键的公平变化表。它直接比较同一场景中 RAW 到 PLANE 后的真假分离变化，"
        "还能分别查看 TRUE 与 FALSE 的距离和相似度如何变化。"
    ),
    "anechoic/04_同一样本_RAW变PLANE后的变化.csv": (
        "逐样本配对变化。距离变化为 PLANE-RAW，负值表示更靠近消声室；相似度变化为 PLANE-RAW，"
        "正值表示更相似。必须同时结合真实 TRUE/FALSE 标签解释。"
    ),
    "anechoic/05_每个特征与消声室差异.csv": (
        "五维特征逐项相对消声室的标准化偏差。absolute_z_difference 越小表示该单项特征越接近消声室。"
        "可定位总距离差异主要来自平坦度、频谱展宽、自适应 SNR，还是时间波动。"
    ),
    "anechoic/06_消声室参考模型摘要.csv": (
        "0.1mm、0.5mm、ALL_LEAKS 参考模型的数据规模、参考距离阈值、五维特征均值和标准差。"
        "用于检查参考模型是否由足够 WAV 和时间窗组成。"
    ),
    "anechoic/07_消声室WAV处理清单.csv": (
        "每个消声室 WAV 的处理状态、时长和有效时间窗数。应检查是否有文件失败，以及不同孔径的数据量是否失衡。"
    ),
    "anechoic/08_窗口距离明细.csv": (
        "每个 100ms 时间窗的马氏距离、距离相似度和是否进入参考范围。只有配置 save_window_details=true 时生成。"
        "用于检查某个样本是持续接近消声室，还是只有极少数时间窗偶然接近。"
    ),
    "anechoic/99_errors.csv": (
        "消声室或工厂样本处理错误。正常应为空；非空时需先排除文件、采样率、NPZ 字段等问题。"
    ),
    "anechoic/10_run_info.json": (
        "本次消声室比较的输入目录、参考目录、参数和成功/失败数量，便于报告中记录实验可复现信息。"
    ),
    "extraction/v22_EFG_all_features.csv": (
        "第 1 步空间拟合与特征提取的全场景样本表。可检查样本数量、PLANE 是否有效、几何条件和残差强度。"
    ),
    "extraction/v22_EFG_failures.csv": (
        "第 1 步处理失败记录。正常应为空；若非空，应先处理后再解释后续结果。"
    ),
    "extraction/v22_EFG_all_point_weights.csv": (
        "空间平面拟合中各周围点的鲁棒权重。用于诊断某些点是否频繁被降权，以及背景平面是否被少数异常点支配。"
    ),
}

FEATURE_LABELS = {
    "spectral_flatness": "频谱平坦度",
    "spectral_spread_hz": "频谱展宽",
    "adaptive_snr_db": "自适应SNR",
    "flatness_local_std": "平坦度时间波动",
    "spread_local_std_hz": "展宽时间波动",
}

CHANGE_LABELS = {
    "BOTH_CORRECT": "RAW与PLANE都正确",
    "PLANE_FIXED_RAW_ERROR": "PLANE修正RAW错误",
    "PLANE_BROKE_RAW_CORRECT": "PLANE破坏RAW正确",
    "BOTH_WRONG": "RAW与PLANE都错误",
}


@dataclass
class FigureRecord:
    number: int
    group: str
    title: str
    base_name: str
    source_files: str
    caption: str
    interpretation: str


# =============================================================================
# 1. 工具函数
# =============================================================================

def configure_matplotlib() -> str:
    candidates = [
        "Microsoft YaHei",
        "SimHei",
        "Noto Sans CJK SC",
        "Source Han Sans SC",
        "WenQuanYi Micro Hei",
        "Arial Unicode MS",
        "AR PL UMing CN",
        "DejaVu Sans",
    ]
    # Matplotlib 的字体缓存有时不会自动识别 TTC 中文字体，因此先尝试注册常见系统字体。
    common_font_files = [
        Path(r"C:\\Windows\\Fonts\\msyh.ttc"),
        Path(r"C:\\Windows\\Fonts\\msyhbd.ttc"),
        Path(r"C:\\Windows\\Fonts\\simhei.ttf"),
        Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
        Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"),
        Path("/usr/share/fonts/truetype/arphic/uming.ttc"),
    ]
    for font_path in common_font_files:
        if font_path.exists():
            try:
                font_manager.fontManager.addfont(str(font_path))
            except Exception:
                pass
    available = {f.name for f in font_manager.fontManager.ttflist}
    chosen = next((name for name in candidates if name in available), "DejaVu Sans")
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": [chosen, "DejaVu Sans"],
        "axes.unicode_minus": False,
        "figure.dpi": 120,
        "savefig.dpi": 300,
        "axes.titlesize": 14,
        "axes.labelsize": 11,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "legend.fontsize": 9,
        "figure.titlesize": 15,
    })
    return chosen


def safe_slug(text: Any) -> str:
    s = str(text).strip()
    keep = []
    for ch in s:
        if ch.isalnum() or ch in "._-()（）":
            keep.append(ch)
        else:
            keep.append("_")
    out = "".join(keep).strip("_")
    return out or "figure"


def display_scene(value: Any) -> str:
    s = str(value)
    return s.replace("factory_", "场景")


def display_label(value: Any) -> str:
    s = str(value).upper()
    if "TRUE" in s or s == "1":
        return "TRUE"
    if "FALSE" in s or s == "0":
        return "FALSE"
    return str(value)


def display_method(value: Any) -> str:
    s = str(value).upper()
    return "PLANE" if "PLANE" in s else "RAW" if "RAW" in s else str(value)


def read_csv_safe(path: Optional[Path], warnings: List[str]) -> pd.DataFrame:
    if path is None or not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path, encoding="utf-8-sig")
    except pd.errors.EmptyDataError:
        return pd.DataFrame()
    except UnicodeDecodeError:
        try:
            return pd.read_csv(path, encoding="gb18030")
        except Exception as exc:
            warnings.append(f"读取失败 {path}: {type(exc).__name__}: {exc}")
            return pd.DataFrame()
    except Exception as exc:
        warnings.append(f"读取失败 {path}: {type(exc).__name__}: {exc}")
        return pd.DataFrame()


def require_columns(df: pd.DataFrame, columns: Sequence[str], name: str, warnings: List[str]) -> bool:
    missing = [c for c in columns if c not in df.columns]
    if missing:
        warnings.append(f"{name} 缺少列：{missing}")
        return False
    return True


def numeric(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def finite_values(values: Iterable[Any]) -> np.ndarray:
    arr = pd.to_numeric(pd.Series(list(values)), errors="coerce").to_numpy(dtype=float)
    return arr[np.isfinite(arr)]


def boxplot_compat(ax: plt.Axes, data: Sequence[Any], labels: Sequence[str], **kwargs: Any) -> Dict[str, Any]:
    """兼容 Matplotlib 3.6 至新版本的箱线图标签参数。"""
    try:
        return ax.boxplot(data, tick_labels=labels, **kwargs)
    except TypeError:
        return ax.boxplot(data, labels=labels, **kwargs)


def annotate_bars(ax: plt.Axes, bars: Iterable[Any], fmt: str = ".3f", fontsize: int = 8) -> None:
    for bar in bars:
        try:
            h = float(bar.get_height())
        except Exception:
            continue
        if not np.isfinite(h):
            continue
        offset = 3 if h >= 0 else -12
        va = "bottom" if h >= 0 else "top"
        ax.annotate(
            format(h, fmt),
            (bar.get_x() + bar.get_width() / 2, h),
            xytext=(0, offset),
            textcoords="offset points",
            ha="center",
            va=va,
            fontsize=fontsize,
        )


def set_y_zero_one(ax: plt.Axes) -> None:
    ax.set_ylim(0.0, 1.05)
    ax.axhline(0.5, linewidth=0.8, linestyle="--", alpha=0.45)


def maybe_log_y(ax: plt.Axes, values: Sequence[float]) -> None:
    arr = finite_values(values)
    arr = arr[arr > 0]
    if len(arr) >= 3 and np.nanmax(arr) / max(np.nanmedian(arr), 1e-12) > 100:
        ax.set_yscale("log")


def save_figure(
    fig: plt.Figure,
    out_base: Path,
    formats: Sequence[str],
    dpi: int,
) -> List[Path]:
    out_base.parent.mkdir(parents=True, exist_ok=True)
    saved = []
    for fmt in formats:
        fmt = fmt.lower().lstrip(".")
        path = out_base.with_suffix(f".{fmt}")
        kwargs: Dict[str, Any] = {"bbox_inches": "tight"}
        if fmt == "png":
            kwargs["dpi"] = dpi
        fig.savefig(path, **kwargs)
        saved.append(path)
    plt.close(fig)
    return saved


def find_dir_with_file(root: Path, file_name: str, preferred: Sequence[str]) -> Optional[Path]:
    direct = [root / p for p in preferred]
    for d in direct:
        if (d / file_name).exists():
            return d
    if (root / file_name).exists():
        return root
    matches = [p.parent for p in root.rglob(file_name)]
    if not matches:
        return None
    matches.sort(key=lambda p: (len(p.parts), len(str(p))))
    return matches[0]


def resolve_paths(
    root: Optional[Path],
    config_path: Optional[Path],
    output_override: Optional[Path],
) -> Tuple[Path, Optional[Path], Optional[Path], Path, Dict[str, Any]]:
    config: Dict[str, Any] = {}
    if config_path:
        config = json.loads(config_path.read_text(encoding="utf-8-sig"))
        root_from_cfg = Path(str(config.get("output_dir", "")))
        if root is None and str(root_from_cfg):
            root = root_from_cfg
    if root is None:
        root = Path.cwd()
    root = root.expanduser().resolve()

    cls_dir: Optional[Path] = None
    an_dir: Optional[Path] = None
    if config:
        cmp_value = config.get("comparison", {}).get("output_dir")
        an_value = config.get("anechoic_comparison", {}).get("output_dir")
        if cmp_value:
            p = Path(str(cmp_value)).expanduser()
            if p.exists():
                cls_dir = p.resolve()
        if an_value:
            p = Path(str(an_value)).expanduser()
            if p.exists():
                an_dir = p.resolve()

    if cls_dir is None:
        cls_dir = find_dir_with_file(
            root,
            CLASSIFICATION_FILES["scene"],
            ["RAW_vs_PLANE_classification", "RAW_vs_PLANE_comparison"],
        )
    if an_dir is None:
        an_dir = find_dir_with_file(
            root,
            ANECHOIC_FILES["long"],
            ["RAW_PLANE_vs_anechoic"],
        )

    output_dir = (output_override or (root / "v22_报告图表")).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    return root, cls_dir, an_dir, output_dir, config


def pick_reference(df: pd.DataFrame, requested: str) -> str:
    if "reference_group" not in df.columns or df.empty:
        return requested
    values = [str(v) for v in df["reference_group"].dropna().unique()]
    if requested in values:
        return requested
    if "ALL_LEAKS" in values:
        return "ALL_LEAKS"
    return values[0] if values else requested


def add_record(
    records: List[FigureRecord],
    group: str,
    title: str,
    base_name: str,
    source_files: Sequence[str],
    caption: str,
    interpretation: str,
) -> None:
    records.append(FigureRecord(
        number=len(records) + 1,
        group=group,
        title=title,
        base_name=base_name,
        source_files="；".join(source_files),
        caption=caption,
        interpretation=interpretation,
    ))


# =============================================================================
# 2. 分类结果绘图
# =============================================================================

def plot_classification(
    cls_dir: Path,
    out_dir: Path,
    formats: Sequence[str],
    dpi: int,
    records: List[FigureRecord],
    warnings: List[str],
    top_features: int,
) -> Dict[str, pd.DataFrame]:
    out_dir.mkdir(parents=True, exist_ok=True)
    dfs = {key: read_csv_safe(cls_dir / name, warnings) for key, name in CLASSIFICATION_FILES.items()}

    # C01 总体平均指标
    df = dfs["summary"]
    req = ["RAW三场景平均平衡准确率", "PLANE三场景平均平衡准确率", "RAW三场景平均AUC", "PLANE三场景平均AUC"]
    if require_columns(df, req, CLASSIFICATION_FILES["summary"], warnings) and not df.empty:
        row = df.iloc[0]
        categories = ["平衡准确率", "AUC"]
        raw = [float(row[req[0]]), float(row[req[2]])]
        plane = [float(row[req[1]]), float(row[req[3]])]
        x = np.arange(len(categories), dtype=float)
        width = 0.34
        fig, ax = plt.subplots(figsize=(8.5, 5.2), constrained_layout=True)
        b1 = ax.bar(x - width / 2, raw, width, label="RAW", hatch="//")
        b2 = ax.bar(x + width / 2, plane, width, label="PLANE", hatch="..")
        ax.set_xticks(x, categories)
        ax.set_ylabel("指标值")
        set_y_zero_one(ax)
        conclusion = str(row.get("最终结论", ""))
        ax.set_title(f"工厂跨场景分类总体结果\n{conclusion}")
        ax.grid(axis="y", alpha=0.25)
        ax.legend()
        annotate_bars(ax, b1)
        annotate_bars(ax, b2)
        base = out_dir / "C01_总体平均指标_RAW_vs_PLANE"
        save_figure(fig, base, formats, dpi)
        add_record(records, "工厂分类", "总体平均指标 RAW vs PLANE", base.name,
                   [CLASSIFICATION_FILES["summary"]],
                   "比较三个整场景留出测试的平均平衡准确率和平均 AUC。",
                   "平衡准确率更接近实际分类效果；AUC 主要反映排序能力。AUC 高但平衡准确率低时，通常说明冻结阈值在新场景发生偏移。")

        # C02 bootstrap CI
        ci_cols = ["bootstrap_delta_balacc_mean", "bootstrap_delta_balacc_ci_low", "bootstrap_delta_balacc_ci_high"]
        if all(c in df.columns for c in ci_cols):
            mean = float(row[ci_cols[0]])
            low = float(row[ci_cols[1]])
            high = float(row[ci_cols[2]])
            fig, ax = plt.subplots(figsize=(8.5, 3.8), constrained_layout=True)
            ax.errorbar(mean, [0], xerr=[[mean - low], [high - mean]], fmt="o", capsize=8)
            ax.axvline(0.0, linewidth=1.0, linestyle="--")
            ax.set_yticks([0], ["PLANE - RAW"])
            ax.set_xlabel("三场景平均平衡准确率差值")
            ax.set_title("PLANE 相对 RAW 的 bootstrap 95% 置信区间")
            ax.grid(axis="x", alpha=0.25)
            ax.text(mean, 0.12, f"均值={mean:+.4f}\n95%CI=[{low:+.4f}, {high:+.4f}]", ha="center", fontsize=9)
            base = out_dir / "C02_PLANE减RAW平衡准确率_Bootstrap置信区间"
            save_figure(fig, base, formats, dpi)
            interpretation = (
                "置信区间不跨 0 才能较有力地支持整体稳定提升或下降；跨 0 表示现有样本不足以证明总体差异稳定。"
            )
            add_record(records, "工厂分类", "PLANE-RAW 平衡准确率 bootstrap 置信区间", base.name,
                       [CLASSIFICATION_FILES["summary"]],
                       "显示 PLANE 相对 RAW 的平均平衡准确率变化及其分层 bootstrap 95% 置信区间。",
                       interpretation)

    # C03 / C04 场景平衡准确率和 AUC
    df = dfs["scene"]
    req = ["test_scene", "raw_balanced_accuracy", "plane_balanced_accuracy", "raw_auc", "plane_auc"]
    if require_columns(df, req, CLASSIFICATION_FILES["scene"], warnings) and not df.empty:
        scene_order = list(df["test_scene"].astype(str))
        labels = [display_scene(s) for s in scene_order]
        x = np.arange(len(labels), dtype=float)
        width = 0.34
        for suffix, raw_col, plane_col, ylabel, title in [
            ("C03_各场景平衡准确率_RAW_vs_PLANE", "raw_balanced_accuracy", "plane_balanced_accuracy", "平衡准确率", "各未知场景的平衡准确率"),
            ("C04_各场景AUC_RAW_vs_PLANE", "raw_auc", "plane_auc", "AUC", "各未知场景的 AUC"),
        ]:
            raw = numeric(df[raw_col]).to_numpy(float)
            plane = numeric(df[plane_col]).to_numpy(float)
            fig, ax = plt.subplots(figsize=(9.2, 5.4), constrained_layout=True)
            b1 = ax.bar(x - width / 2, raw, width, label="RAW", hatch="//")
            b2 = ax.bar(x + width / 2, plane, width, label="PLANE", hatch="..")
            ax.set_xticks(x, labels)
            ax.set_ylabel(ylabel)
            set_y_zero_one(ax)
            ax.set_title(title)
            ax.grid(axis="y", alpha=0.25)
            ax.legend()
            annotate_bars(ax, b1)
            annotate_bars(ax, b2)
            base = out_dir / suffix
            save_figure(fig, base, formats, dpi)
            add_record(records, "工厂分类", title, base.name,
                       [CLASSIFICATION_FILES["scene"]],
                       f"逐场景比较 RAW 与 PLANE 的{ylabel}。",
                       "重点看不同场景的变化方向是否一致。一个场景提高、另一个场景下降，说明方法跨场景不稳定，不能只用平均值掩盖。")

        # C05 场景变化值
        if "plane_minus_raw_balanced_accuracy" in df.columns:
            vals = numeric(df["plane_minus_raw_balanced_accuracy"]).to_numpy(float)
            fig, ax = plt.subplots(figsize=(8.8, 4.8), constrained_layout=True)
            bars = ax.bar(labels, vals, hatch="..")
            ax.axhline(0.0, linewidth=1.0)
            ax.axhline(0.05, linewidth=0.8, linestyle="--", alpha=0.6)
            ax.axhline(-0.05, linewidth=0.8, linestyle="--", alpha=0.6)
            ax.set_ylabel("PLANE - RAW 平衡准确率")
            ax.set_title("PLANE 对各未知场景的实际增益")
            ax.grid(axis="y", alpha=0.25)
            annotate_bars(ax, bars, fmt="+.3f")
            base = out_dir / "C05_各场景_PLANE减RAW平衡准确率"
            save_figure(fig, base, formats, dpi)
            add_record(records, "工厂分类", "各场景 PLANE-RAW 平衡准确率", base.name,
                       [CLASSIFICATION_FILES["scene"]],
                       "正值表示 PLANE 提升，负值表示 PLANE 下降；±0.05 虚线对应 v22 的明显变化判据。",
                       "这是判断 PLANE 是否能作为统一方法的核心图。至少多数场景同向提升，且不能存在明显下降场景。")

    # C06 灵敏度/特异度，C07 FP/FN
    df = dfs["fold"]
    req = ["method", "test_scene", "sensitivity_TRUE", "specificity_FALSE", "fp", "fn"]
    if require_columns(df, req, CLASSIFICATION_FILES["fold"], warnings) and not df.empty:
        tmp = df.copy()
        tmp["category"] = tmp.apply(lambda r: f"{display_scene(r['test_scene'])}-{display_method(r['method'])}", axis=1)
        tmp = tmp.sort_values(["test_scene", "method"])
        x = np.arange(len(tmp), dtype=float)
        width = 0.34
        fig, ax = plt.subplots(figsize=(11.0, 5.6), constrained_layout=True)
        b1 = ax.bar(x - width / 2, numeric(tmp["sensitivity_TRUE"]), width, label="TRUE召回率", hatch="//")
        b2 = ax.bar(x + width / 2, numeric(tmp["specificity_FALSE"]), width, label="FALSE特异度", hatch="..")
        ax.set_xticks(x, tmp["category"], rotation=20, ha="right")
        ax.set_ylabel("比例")
        set_y_zero_one(ax)
        ax.set_title("各场景与方法的漏检/误报能力分解")
        ax.grid(axis="y", alpha=0.25)
        ax.legend()
        annotate_bars(ax, b1)
        annotate_bars(ax, b2)
        base = out_dir / "C06_各场景灵敏度与特异度"
        save_figure(fig, base, formats, dpi)
        add_record(records, "工厂分类", "各场景灵敏度与特异度", base.name,
                   [CLASSIFICATION_FILES["fold"]],
                   "TRUE 召回率反映漏检，FALSE 特异度反映误报。",
                   "平衡准确率的变化可能来自两种完全不同的原因：减少漏检或减少误报。报告中应明确是哪一项发生变化。")

        fig, ax = plt.subplots(figsize=(11.0, 5.2), constrained_layout=True)
        b1 = ax.bar(x - width / 2, numeric(tmp["fp"]), width, label="FP误报", hatch="//")
        b2 = ax.bar(x + width / 2, numeric(tmp["fn"]), width, label="FN漏检", hatch="..")
        ax.set_xticks(x, tmp["category"], rotation=20, ha="right")
        ax.set_ylabel("样本数")
        ax.set_title("各场景与方法的误报和漏检数量")
        ax.grid(axis="y", alpha=0.25)
        ax.legend()
        annotate_bars(ax, b1, fmt=".0f")
        annotate_bars(ax, b2, fmt=".0f")
        base = out_dir / "C07_各场景误报FP与漏检FN"
        save_figure(fig, base, formats, dpi)
        add_record(records, "工厂分类", "各场景误报与漏检数量", base.name,
                   [CLASSIFICATION_FILES["fold"]],
                   "直接显示每个场景、每种方法的 FP 和 FN 数量。",
                   "工程高精度检测不能只看 AUC；应结合部署要求分别控制误报和漏检。")

    # C08 每样本预测概率分布
    df = dfs["predictions"]
    req = ["scene", "label", "method", "probability_TRUE"]
    if require_columns(df, req, CLASSIFICATION_FILES["predictions"], warnings) and not df.empty:
        scenes = sorted(df["scene"].astype(str).unique())
        categories: List[str] = []
        datasets: List[np.ndarray] = []
        for scene in scenes:
            for label in ["FALSE_LEAK", "TRUE_LEAK"]:
                for method in ["RAW", "PLANE"]:
                    mask = (
                        (df["scene"].astype(str) == scene)
                        & (df["label"].astype(str).str.upper() == label)
                        & (df["method"].astype(str).str.upper() == method)
                    )
                    vals = finite_values(df.loc[mask, "probability_TRUE"])
                    if len(vals):
                        categories.append(f"{display_scene(scene)}\n{display_label(label)}-{method}")
                        datasets.append(vals)
        if datasets:
            fig, ax = plt.subplots(figsize=(14.0, 6.0), constrained_layout=True)
            bp = boxplot_compat(ax, datasets, categories, patch_artist=True, showfliers=True)
            for i, box in enumerate(bp["boxes"]):
                box.set_hatch("//" if "RAW" in categories[i] else "..")
            ax.set_ylabel("模型输出的 TRUE 概率")
            set_y_zero_one(ax)
            ax.set_title("每个场景、类别与方法的预测概率分布")
            ax.tick_params(axis="x", rotation=35)
            ax.grid(axis="y", alpha=0.25)
            ax.legend(handles=[Patch(fill=False, hatch="//", label="RAW"), Patch(fill=False, hatch="..", label="PLANE")])
            base = out_dir / "C08_各场景_TRUE概率分布"
            save_figure(fig, base, formats, dpi)
            add_record(records, "工厂分类", "各场景 TRUE 概率分布", base.name,
                       [CLASSIFICATION_FILES["predictions"]],
                       "按场景、真实类别和方法展示模型输出概率的分布。",
                       "TRUE 与 FALSE 分布分开但整体跨过冻结阈值时，可能出现 AUC 很高而实际分类失败；该图可发现整体概率偏移。")

    # C09/C10 配对概率与变化类型
    df = dfs["paired"]
    req = ["raw_probability_TRUE", "plane_probability_TRUE", "label", "scene", "change_category"]
    if require_columns(df, req, CLASSIFICATION_FILES["paired"], warnings) and not df.empty:
        fig, ax = plt.subplots(figsize=(7.2, 6.4), constrained_layout=True)
        for label, marker in [("FALSE_LEAK", "o"), ("TRUE_LEAK", "^")]:
            sub = df[df["label"].astype(str).str.upper() == label]
            ax.scatter(numeric(sub["raw_probability_TRUE"]), numeric(sub["plane_probability_TRUE"]),
                       alpha=0.7, marker=marker, label=display_label(label))
        ax.plot([0, 1], [0, 1], linestyle="--", linewidth=1.0)
        ax.set_xlim(-0.02, 1.02)
        ax.set_ylim(-0.02, 1.02)
        ax.set_xlabel("RAW 的 TRUE 概率")
        ax.set_ylabel("PLANE 的 TRUE 概率")
        ax.set_title("同一样本：RAW 与 PLANE 的概率变化")
        ax.grid(alpha=0.25)
        ax.legend()
        base = out_dir / "C09_同一样本_RAW与PLANE概率散点"
        save_figure(fig, base, formats, dpi)
        add_record(records, "工厂分类", "同一样本 RAW 与 PLANE 概率散点", base.name,
                   [CLASSIFICATION_FILES["paired"]],
                   "横轴为 RAW 概率，纵轴为 PLANE 概率；虚线表示概率不变。",
                   "TRUE 点最好位于虚线上方，FALSE 点最好位于虚线下方。若 TRUE/FALSE 同向整体移动，可能只是场景偏移而非分离改善。")

        order = ["BOTH_CORRECT", "PLANE_FIXED_RAW_ERROR", "PLANE_BROKE_RAW_CORRECT", "BOTH_WRONG"]
        counts = [int((df["change_category"].astype(str) == key).sum()) for key in order]
        labels = [CHANGE_LABELS[key] for key in order]
        fig, ax = plt.subplots(figsize=(10.0, 5.2), constrained_layout=True)
        bars = ax.bar(labels, counts, hatch="//")
        ax.set_ylabel("样本数")
        ax.set_title("同一样本从 RAW 换成 PLANE 后发生了什么")
        ax.tick_params(axis="x", rotation=12)
        ax.grid(axis="y", alpha=0.25)
        annotate_bars(ax, bars, fmt=".0f")
        base = out_dir / "C10_同一样本预测变化类别"
        save_figure(fig, base, formats, dpi)
        add_record(records, "工厂分类", "同一样本预测变化类别", base.name,
                   [CLASSIFICATION_FILES["paired"]],
                   "统计 PLANE 修正 RAW 错误、破坏 RAW 正确以及两者均对/均错的样本数。",
                   "PLANE_FIXED_RAW_ERROR 应明显多于 PLANE_BROKE_RAW_CORRECT，才能说明 PLANE 在样本层面有净收益。")

        if "plane_minus_raw_probability" in df.columns:
            categories = []
            datasets = []
            for scene in sorted(df["scene"].astype(str).unique()):
                for label in ["FALSE_LEAK", "TRUE_LEAK"]:
                    mask = ((df["scene"].astype(str) == scene) & (df["label"].astype(str).str.upper() == label))
                    vals = finite_values(df.loc[mask, "plane_minus_raw_probability"])
                    if len(vals):
                        categories.append(f"{display_scene(scene)}-{display_label(label)}")
                        datasets.append(vals)
            if datasets:
                fig, ax = plt.subplots(figsize=(10.5, 5.5), constrained_layout=True)
                boxplot_compat(ax, datasets, categories, showfliers=True)
                ax.axhline(0.0, linewidth=1.0)
                ax.set_ylabel("PLANE - RAW 的 TRUE 概率")
                ax.set_title("PLANE 对不同场景与类别的概率推动方向")
                ax.tick_params(axis="x", rotation=20)
                ax.grid(axis="y", alpha=0.25)
                base = out_dir / "C11_各场景类别_概率变化分布"
                save_figure(fig, base, formats, dpi)
                add_record(records, "工厂分类", "各场景类别的概率变化分布", base.name,
                           [CLASSIFICATION_FILES["paired"]],
                           "正值表示 PLANE 提高 TRUE 概率，负值表示降低。",
                           "理想情况下 TRUE 多为正、FALSE 多为负；若一个场景所有类别都同向移动，说明可能存在整体标度偏移。")

    # C12/C13 特征稳定性
    df = dfs["features"]
    req = ["method", "feature", "absolute_coefficient"]
    if require_columns(df, req, CLASSIFICATION_FILES["features"], warnings) and not df.empty:
        freq = df.groupby(["feature", "method"]).size().unstack(fill_value=0)
        freq["_total"] = freq.sum(axis=1)
        freq = freq.sort_values("_total", ascending=False).head(top_features).drop(columns="_total")
        freq = freq.iloc[::-1]
        fig, ax = plt.subplots(figsize=(11.0, max(5.0, 0.38 * len(freq) + 1.8)), constrained_layout=True)
        y = np.arange(len(freq))
        methods = [m for m in ["RAW", "PLANE"] if m in freq.columns] + [m for m in freq.columns if m not in ["RAW", "PLANE"]]
        width = 0.36 if len(methods) <= 2 else 0.8 / max(len(methods), 1)
        for i, method in enumerate(methods):
            offset = (i - (len(methods) - 1) / 2) * width
            bars = ax.barh(y + offset, freq[method], height=width, label=method, hatch="//" if method == "RAW" else "..")
        ax.set_yticks(y, freq.index)
        ax.set_xlabel("被不同留一场景模型选中的次数")
        ax.set_title(f"跨折特征选择稳定性（Top {len(freq)}）")
        ax.grid(axis="x", alpha=0.25)
        ax.legend()
        base = out_dir / "C12_模型特征选择频次"
        save_figure(fig, base, formats, dpi)
        add_record(records, "工厂分类", "模型特征选择频次", base.name,
                   [CLASSIFICATION_FILES["features"]],
                   "统计同一特征在不同留一场景模型中被选中的次数。",
                   "频繁出现的特征更稳定，但仍需结合系数方向、跨场景效果和物理意义，不能只凭出现次数认定为泄漏本征。")

        coef = df.copy()
        coef["absolute_coefficient"] = numeric(coef["absolute_coefficient"])
        coef = coef.groupby(["feature", "method"], as_index=False)["absolute_coefficient"].median()
        total = coef.groupby("feature")["absolute_coefficient"].max().sort_values(ascending=False).head(top_features)
        coef = coef[coef["feature"].isin(total.index)]
        pivot = coef.pivot(index="feature", columns="method", values="absolute_coefficient").fillna(0)
        pivot["_order"] = pivot.max(axis=1)
        pivot = pivot.sort_values("_order", ascending=True).drop(columns="_order")
        fig, ax = plt.subplots(figsize=(11.0, max(5.0, 0.38 * len(pivot) + 1.8)), constrained_layout=True)
        y = np.arange(len(pivot))
        methods = [m for m in ["RAW", "PLANE"] if m in pivot.columns] + [m for m in pivot.columns if m not in ["RAW", "PLANE"]]
        width = 0.36 if len(methods) <= 2 else 0.8 / max(len(methods), 1)
        for i, method in enumerate(methods):
            offset = (i - (len(methods) - 1) / 2) * width
            ax.barh(y + offset, pivot[method], height=width, label=method, hatch="//" if method == "RAW" else "..")
        ax.set_yticks(y, pivot.index)
        ax.set_xlabel("绝对系数中位数")
        ax.set_title(f"模型选中特征的系数强度（Top {len(pivot)}）")
        ax.grid(axis="x", alpha=0.25)
        ax.legend()
        base = out_dir / "C13_模型特征绝对系数"
        save_figure(fig, base, formats, dpi)
        add_record(records, "工厂分类", "模型特征绝对系数", base.name,
                   [CLASSIFICATION_FILES["features"]],
                   "展示不同留一场景模型中各特征绝对系数的中位数。",
                   "绝对系数表示模型依赖程度，不表示正负方向，也不直接证明物理因果。")

    # C14/C15 实际样本与 PLANE 质量
    df = dfs["samples"]
    req = ["scene", "label"]
    if require_columns(df, req, CLASSIFICATION_FILES["samples"], warnings) and not df.empty:
        counts = df.groupby(["scene", "label"]).size().unstack(fill_value=0)
        labels = [display_scene(s) for s in counts.index]
        x = np.arange(len(labels))
        methods = list(counts.columns)
        width = 0.8 / max(len(methods), 1)
        fig, ax = plt.subplots(figsize=(8.8, 5.0), constrained_layout=True)
        for i, label in enumerate(methods):
            offset = (i - (len(methods) - 1) / 2) * width
            bars = ax.bar(x + offset, counts[label], width, label=display_label(label), hatch="//" if "FALSE" in str(label) else "..")
            annotate_bars(ax, bars, fmt=".0f")
        ax.set_xticks(x, labels)
        ax.set_ylabel("配对样本数")
        ax.set_title("实际进入 RAW/PLANE 公平对照的样本数量")
        ax.grid(axis="y", alpha=0.25)
        ax.legend()
        base = out_dir / "C14_实际配对样本数量"
        save_figure(fig, base, formats, dpi)
        add_record(records, "工厂分类", "实际配对样本数量", base.name,
                   [CLASSIFICATION_FILES["samples"]],
                   "按场景和 TRUE/FALSE 统计实际进入模型的配对样本。",
                   "不同场景或类别严重不平衡会影响平均指标；必须确认所有比较都基于同一批 RAW/PLANE 配对样本。")

        quality_cols = [c for c in ["plane_valid", "plane_geometry_ok"] if c in df.columns]
        if quality_cols:
            quality = df.groupby("scene")[quality_cols].mean()
            labels = [display_scene(s) for s in quality.index]
            x = np.arange(len(labels))
            width = 0.34
            fig, ax = plt.subplots(figsize=(8.8, 5.0), constrained_layout=True)
            for i, col in enumerate(quality_cols):
                offset = (i - (len(quality_cols) - 1) / 2) * width
                bars = ax.bar(x + offset, quality[col], width, label=col, hatch="//" if i == 0 else "..")
                annotate_bars(ax, bars)
            ax.set_xticks(x, labels)
            ax.set_ylabel("有效比例")
            set_y_zero_one(ax)
            ax.set_title("各场景 PLANE 拟合有效率与几何有效率")
            ax.grid(axis="y", alpha=0.25)
            ax.legend()
            base = out_dir / "C15_PLANE拟合质量"
            save_figure(fig, base, formats, dpi)
            add_record(records, "工厂分类", "PLANE 拟合质量", base.name,
                       [CLASSIFICATION_FILES["samples"]],
                       "统计 plane_valid 和 plane_geometry_ok 的场景平均值。",
                       "若有效率明显低于 1，后续分类提升可能只来自少数可拟合样本，应先排查空间坐标、点数和几何条件。")

    # C16 错误分布（非空时）
    df = dfs["errors"]
    if not df.empty:
        col = "error_type" if "error_type" in df.columns else "error" if "error" in df.columns else None
        if col:
            counts = df[col].astype(str).value_counts().head(15).sort_values()
            fig, ax = plt.subplots(figsize=(10.0, max(4.5, 0.35 * len(counts) + 1.5)), constrained_layout=True)
            bars = ax.barh(counts.index, counts.values, hatch="//")
            ax.set_xlabel("错误数")
            ax.set_title("分类阶段读取错误分布")
            ax.grid(axis="x", alpha=0.25)
            base = out_dir / "C16_分类阶段错误分布"
            save_figure(fig, base, formats, dpi)
            add_record(records, "工厂分类", "分类阶段读取错误分布", base.name,
                       [CLASSIFICATION_FILES["errors"]],
                       "统计分类阶段的错误类型或错误信息。",
                       "存在错误时应先解决数据读取问题；否则样本数和结果可能不完整。")

    return dfs


# =============================================================================
# 3. 消声室比较绘图
# =============================================================================

def classify_anechoic_change(distance_change: float, similarity_change: float,
                              distance_threshold: float, similarity_threshold: float) -> str:
    d_good = np.isfinite(distance_change) and distance_change <= -abs(distance_threshold)
    d_bad = np.isfinite(distance_change) and distance_change >= abs(distance_threshold)
    s_good = np.isfinite(similarity_change) and similarity_change >= abs(similarity_threshold)
    s_bad = np.isfinite(similarity_change) and similarity_change <= -abs(similarity_threshold)
    if d_good and s_good:
        return "明显改善"
    if d_bad and s_bad:
        return "明显变差"
    if (d_good and not s_bad) or (s_good and not d_bad):
        return "部分改善"
    if (d_bad and not s_good) or (s_bad and not d_good):
        return "部分变差"
    return "变化小或指标矛盾"


def plot_anechoic(
    an_dir: Path,
    out_dir: Path,
    formats: Sequence[str],
    dpi: int,
    records: List[FigureRecord],
    warnings: List[str],
    requested_reference: str,
) -> Tuple[Dict[str, pd.DataFrame], str, Dict[str, Any]]:
    out_dir.mkdir(parents=True, exist_ok=True)
    dfs: Dict[str, pd.DataFrame] = {}
    for key, name in ANECHOIC_FILES.items():
        if name.lower().endswith(".csv"):
            dfs[key] = read_csv_safe(an_dir / name, warnings)
    run_info: Dict[str, Any] = {}
    run_path = an_dir / ANECHOIC_FILES["run_info"]
    if run_path.exists():
        try:
            run_info = json.loads(run_path.read_text(encoding="utf-8-sig"))
        except Exception as exc:
            warnings.append(f"读取 {run_path} 失败：{exc}")

    reference = requested_reference
    for key in ["summary", "long", "scene", "compare", "paired", "features", "windows"]:
        if key in dfs and not dfs[key].empty and "reference_group" in dfs[key].columns:
            reference = pick_reference(dfs[key], requested_reference)
            break

    # A01/A02 总体距离与相似度
    df = dfs.get("summary", pd.DataFrame())
    req = [
        "reference_group", "raw_true_median_distance", "plane_true_median_distance",
        "raw_false_median_distance", "plane_false_median_distance",
        "raw_true_combined_similarity", "plane_true_combined_similarity",
        "raw_false_combined_similarity", "plane_false_combined_similarity",
    ]
    if require_columns(df, req, ANECHOIC_FILES["summary"], warnings) and not df.empty:
        refs = df["reference_group"].astype(str).tolist()
        x = np.arange(len(refs), dtype=float)
        width = 0.2
        distance_series = [
            ("RAW-TRUE", "raw_true_median_distance", "//"),
            ("PLANE-TRUE", "plane_true_median_distance", ".."),
            ("RAW-FALSE", "raw_false_median_distance", "xx"),
            ("PLANE-FALSE", "plane_false_median_distance", "\\\\"),
        ]
        fig, ax = plt.subplots(figsize=(11.0, 5.8), constrained_layout=True)
        all_values: List[float] = []
        for i, (label, col, hatch) in enumerate(distance_series):
            vals = numeric(df[col]).to_numpy(float)
            all_values.extend(vals.tolist())
            offset = (i - 1.5) * width
            ax.bar(x + offset, vals, width, label=label, hatch=hatch)
        ax.set_xticks(x, refs)
        ax.set_ylabel("中位马氏距离（越小越接近消声室）")
        ax.set_title("不同消声室参考下 TRUE/FALSE 的总体距离")
        ax.grid(axis="y", alpha=0.25)
        ax.legend(ncol=2)
        maybe_log_y(ax, all_values)
        base = out_dir / "A01_总体中位距离_TRUE_FALSE_RAW_PLANE"
        save_figure(fig, base, formats, dpi)
        add_record(records, "消声室比较", "总体中位距离", base.name,
                   [ANECHOIC_FILES["summary"]],
                   "同时比较各参考模型下 TRUE/FALSE、RAW/PLANE 的总体中位马氏距离。",
                   "理想结果不是只有 TRUE 距离下降，而是 TRUE 比 FALSE 更近，且 PLANE 后 TRUE/FALSE 的距离差扩大。不同参考模型绝对距离不宜硬比较。")

        similarity_series = [
            ("RAW-TRUE", "raw_true_combined_similarity", "//"),
            ("PLANE-TRUE", "plane_true_combined_similarity", ".."),
            ("RAW-FALSE", "raw_false_combined_similarity", "xx"),
            ("PLANE-FALSE", "plane_false_combined_similarity", "\\\\"),
        ]
        fig, ax = plt.subplots(figsize=(11.0, 5.8), constrained_layout=True)
        for i, (label, col, hatch) in enumerate(similarity_series):
            vals = numeric(df[col]).to_numpy(float)
            offset = (i - 1.5) * width
            ax.bar(x + offset, vals, width, label=label, hatch=hatch)
        ax.set_xticks(x, refs)
        ax.set_ylabel("综合频谱相似度（越大越接近）")
        set_y_zero_one(ax)
        ax.set_title("不同消声室参考下 TRUE/FALSE 的总体频谱相似度")
        ax.grid(axis="y", alpha=0.25)
        ax.legend(ncol=2)
        base = out_dir / "A02_总体综合相似度_TRUE_FALSE_RAW_PLANE"
        save_figure(fig, base, formats, dpi)
        add_record(records, "消声室比较", "总体综合频谱相似度", base.name,
                   [ANECHOIC_FILES["summary"]],
                   "同时比较 TRUE/FALSE 在 RAW/PLANE 下与不同消声室参考的综合频谱相似度。",
                   "相似度越高只表示频谱形状更接近，不是泄漏概率。真正有效应表现为 TRUE 相似度高于 FALSE，且 PLANE 后差距扩大。")

        # A03/A04 总体分离改善
        if "mean_plane_minus_raw_distance_separation" in df.columns:
            vals = numeric(df["mean_plane_minus_raw_distance_separation"]).to_numpy(float)
            fig, ax = plt.subplots(figsize=(8.8, 4.8), constrained_layout=True)
            bars = ax.bar(refs, vals, hatch="..")
            ax.axhline(0.0, linewidth=1.0)
            ax.set_ylabel("PLANE分离 - RAW分离")
            ax.set_title("PLANE 对 TRUE/FALSE 距离分离的平均改善")
            ax.grid(axis="y", alpha=0.25)
            annotate_bars(ax, bars, fmt="+.3f")
            base = out_dir / "A03_总体距离分离改善"
            save_figure(fig, base, formats, dpi)
            add_record(records, "消声室比较", "总体距离分离改善", base.name,
                       [ANECHOIC_FILES["summary"]],
                       "正值表示 PLANE 后 FALSE距离-TRUE距离 变大。",
                       "这是比单看 TRUE 距离更重要的总体指标；正值说明真假更易分开，但仍需检查是否所有场景方向一致。")
        if "mean_plane_minus_raw_spectral_similarity_separation" in df.columns:
            vals = numeric(df["mean_plane_minus_raw_spectral_similarity_separation"]).to_numpy(float)
            fig, ax = plt.subplots(figsize=(8.8, 4.8), constrained_layout=True)
            bars = ax.bar(refs, vals, hatch="..")
            ax.axhline(0.0, linewidth=1.0)
            ax.set_ylabel("PLANE分离 - RAW分离")
            ax.set_title("PLANE 对 TRUE/FALSE 频谱相似度分离的平均改善")
            ax.grid(axis="y", alpha=0.25)
            annotate_bars(ax, bars, fmt="+.3f")
            base = out_dir / "A04_总体频谱相似度分离改善"
            save_figure(fig, base, formats, dpi)
            add_record(records, "消声室比较", "总体频谱相似度分离改善", base.name,
                       [ANECHOIC_FILES["summary"]],
                       "正值表示 PLANE 后 TRUE相似度-FALSE相似度 变大。",
                       "该值通常比距离变化小，适合作为辅助证据；应与距离分离和跨场景一致性共同判断。")

    # A05-A10 每个参考组的场景分离图
    df = dfs.get("scene", pd.DataFrame())
    req = ["scene", "reference_group", "method", "distance_separation_false_minus_true", "spectral_similarity_separation_true_minus_false"]
    if require_columns(df, req, ANECHOIC_FILES["scene"], warnings) and not df.empty:
        ref_values = [str(v) for v in df["reference_group"].dropna().unique()]
        for ref in ref_values:
            sub = df[df["reference_group"].astype(str) == ref].copy()
            scenes = sorted(sub["scene"].astype(str).unique())
            labels = [display_scene(s) for s in scenes]
            x = np.arange(len(scenes), dtype=float)
            width = 0.34
            for metric, ylabel, title_tag, code in [
                ("distance_separation_false_minus_true", "FALSE距离 - TRUE距离（越大越好）", "距离分离", "A05"),
                ("spectral_similarity_separation_true_minus_false", "TRUE相似度 - FALSE相似度（越大越好）", "频谱相似度分离", "A06"),
            ]:
                raw = []
                plane = []
                for scene in scenes:
                    for method, target in [("raw", raw), ("plane", plane)]:
                        values = sub[(sub["scene"].astype(str) == scene) & (sub["method"].astype(str).str.lower() == method)][metric]
                        target.append(float(numeric(values).iloc[0]) if len(values) else np.nan)
                fig, ax = plt.subplots(figsize=(9.2, 5.2), constrained_layout=True)
                b1 = ax.bar(x - width / 2, raw, width, label="RAW", hatch="//")
                b2 = ax.bar(x + width / 2, plane, width, label="PLANE", hatch="..")
                ax.axhline(0.0, linewidth=1.0)
                ax.set_xticks(x, labels)
                ax.set_ylabel(ylabel)
                ax.set_title(f"{ref}：各场景的{title_tag}")
                ax.grid(axis="y", alpha=0.25)
                ax.legend()
                annotate_bars(ax, b1, fmt="+.3f")
                annotate_bars(ax, b2, fmt="+.3f")
                base = out_dir / f"{code}_{safe_slug(ref)}_各场景{title_tag}_RAW_vs_PLANE"
                save_figure(fig, base, formats, dpi)
                add_record(records, "消声室比较", f"{ref} 各场景{title_tag}", base.name,
                           [ANECHOIC_FILES["scene"]],
                           f"比较 {ref} 参考下，RAW 与 PLANE 在每个场景的{title_tag}。",
                           "柱高大于 0 表示 TRUE/FALSE 方向正确；PLANE 柱应高于 RAW，并且多个场景方向一致，才支持稳定收益。")

        # A07 选择参考的绝对距离水平
        ref = pick_reference(df, reference)
        sub = df[df["reference_group"].astype(str) == ref].copy()
        if not sub.empty and all(c in sub.columns for c in ["true_median_distance", "false_median_distance"]):
            categories = []
            true_vals = []
            false_vals = []
            for scene in sorted(sub["scene"].astype(str).unique()):
                for method in ["raw", "plane"]:
                    one = sub[(sub["scene"].astype(str) == scene) & (sub["method"].astype(str).str.lower() == method)]
                    if not one.empty:
                        categories.append(f"{display_scene(scene)}-{method.upper()}")
                        true_vals.append(float(numeric(one["true_median_distance"]).iloc[0]))
                        false_vals.append(float(numeric(one["false_median_distance"]).iloc[0]))
            x = np.arange(len(categories), dtype=float)
            width = 0.34
            fig, ax = plt.subplots(figsize=(12.0, 5.6), constrained_layout=True)
            b1 = ax.bar(x - width / 2, true_vals, width, label="TRUE", hatch="//")
            b2 = ax.bar(x + width / 2, false_vals, width, label="FALSE", hatch="..")
            ax.set_xticks(x, categories, rotation=20, ha="right")
            ax.set_ylabel("中位马氏距离")
            ax.set_title(f"{ref}：各场景 TRUE/FALSE 的绝对距离水平")
            ax.grid(axis="y", alpha=0.25)
            ax.legend()
            maybe_log_y(ax, true_vals + false_vals)
            base = out_dir / f"A07_{safe_slug(ref)}_各场景_TRUE_FALSE绝对距离"
            save_figure(fig, base, formats, dpi)
            add_record(records, "消声室比较", f"{ref} 各场景 TRUE/FALSE 绝对距离", base.name,
                       [ANECHOIC_FILES["scene"]],
                       "显示每个场景和方法下 TRUE/FALSE 的绝对中位距离。",
                       "它解释分离改善究竟来自 TRUE 更靠近、FALSE 更远离，还是两者共同移动。")

    # A08/A09 场景变化表
    df = dfs.get("compare", pd.DataFrame())
    req = ["scene", "reference_group", "plane_minus_raw_distance_separation", "plane_minus_raw_spectral_similarity_separation"]
    if require_columns(df, req, ANECHOIC_FILES["compare"], warnings) and not df.empty:
        tmp = df.copy()
        tmp["category"] = tmp.apply(lambda r: f"{display_scene(r['scene'])}\n{r['reference_group']}", axis=1)
        x = np.arange(len(tmp), dtype=float)
        for metric, ylabel, title, code in [
            ("plane_minus_raw_distance_separation", "距离分离改善", "各场景与参考组：PLANE 对距离分离的改善", "A08"),
            ("plane_minus_raw_spectral_similarity_separation", "频谱相似度分离改善", "各场景与参考组：PLANE 对频谱分离的改善", "A09"),
        ]:
            vals = numeric(tmp[metric]).to_numpy(float)
            fig, ax = plt.subplots(figsize=(12.5, 5.3), constrained_layout=True)
            bars = ax.bar(x, vals, hatch="..")
            ax.axhline(0.0, linewidth=1.0)
            ax.set_xticks(x, tmp["category"], rotation=25, ha="right")
            ax.set_ylabel(ylabel)
            ax.set_title(title)
            ax.grid(axis="y", alpha=0.25)
            annotate_bars(ax, bars, fmt="+.3f", fontsize=7)
            base = out_dir / f"{code}_各场景参考组_PLANE分离改善"
            save_figure(fig, base, formats, dpi)
            add_record(records, "消声室比较", title, base.name,
                       [ANECHOIC_FILES["compare"]],
                       "每根柱表示一个场景和消声室参考组的 PLANE-RAW 分离变化。",
                       "正负混杂说明跨场景或跨参考组不稳定；不能只报告平均正值。")

        # A10 TRUE/FALSE 距离变化（选择参考）
        ref = pick_reference(df, reference)
        sub = df[df["reference_group"].astype(str) == ref].copy()
        true_col = "true_distance_change_plane_minus_raw"
        false_col = "false_distance_change_plane_minus_raw"
        if all(c in sub.columns for c in [true_col, false_col]) and not sub.empty:
            scenes = sub["scene"].astype(str).tolist()
            labels = [display_scene(s) for s in scenes]
            x = np.arange(len(labels), dtype=float)
            width = 0.34
            true_vals = numeric(sub[true_col]).to_numpy(float)
            false_vals = numeric(sub[false_col]).to_numpy(float)
            fig, ax = plt.subplots(figsize=(9.2, 5.2), constrained_layout=True)
            b1 = ax.bar(x - width / 2, true_vals, width, label="TRUE距离变化", hatch="//")
            b2 = ax.bar(x + width / 2, false_vals, width, label="FALSE距离变化", hatch="..")
            ax.axhline(0.0, linewidth=1.0)
            ax.set_xticks(x, labels)
            ax.set_ylabel("PLANE距离 - RAW距离")
            ax.set_title(f"{ref}：PLANE 分别如何移动 TRUE 与 FALSE")
            ax.grid(axis="y", alpha=0.25)
            ax.legend()
            annotate_bars(ax, b1, fmt="+.3f")
            annotate_bars(ax, b2, fmt="+.3f")
            base = out_dir / f"A10_{safe_slug(ref)}_TRUE_FALSE距离变化"
            save_figure(fig, base, formats, dpi)
            add_record(records, "消声室比较", f"{ref} TRUE/FALSE 距离变化", base.name,
                       [ANECHOIC_FILES["compare"]],
                       "负值表示更靠近消声室，正值表示更远离。",
                       "最理想是 TRUE 为负、FALSE 为正；若 TRUE 与 FALSE 都为负，说明 PLANE 可能把所有局部异常都拉近消声室。")

    # A11-A14 逐样本配对变化
    df = dfs.get("paired", pd.DataFrame())
    req = ["reference_group", "label", "scene", "median_distance_raw", "median_distance_plane", "combined_similarity_raw", "combined_similarity_plane"]
    if require_columns(df, req, ANECHOIC_FILES["paired"], warnings) and not df.empty:
        ref = pick_reference(df, reference)
        sub = df[df["reference_group"].astype(str) == ref].copy()
        if not sub.empty:
            # 距离散点
            fig, ax = plt.subplots(figsize=(7.2, 6.4), constrained_layout=True)
            all_x: List[float] = []
            all_y: List[float] = []
            for label, marker in [("FALSE_LEAK", "o"), ("TRUE_LEAK", "^")]:
                one = sub[sub["label"].astype(str).str.upper() == label]
                xval = numeric(one["median_distance_raw"])
                yval = numeric(one["median_distance_plane"])
                all_x.extend(xval.tolist()); all_y.extend(yval.tolist())
                ax.scatter(xval, yval, marker=marker, alpha=0.7, label=display_label(label))
            vals = finite_values(all_x + all_y)
            if len(vals):
                low, high = float(np.min(vals)), float(np.max(vals))
                ax.plot([low, high], [low, high], linestyle="--", linewidth=1.0)
            ax.set_xlabel("RAW 中位距离")
            ax.set_ylabel("PLANE 中位距离")
            ax.set_title(f"{ref}：同一样本的距离变化")
            ax.grid(alpha=0.25)
            ax.legend()
            base = out_dir / f"A11_{safe_slug(ref)}_同一样本距离散点"
            save_figure(fig, base, formats, dpi)
            add_record(records, "消声室比较", f"{ref} 同一样本距离散点", base.name,
                       [ANECHOIC_FILES["paired"]],
                       "横轴 RAW、纵轴 PLANE；点位于虚线下方表示 PLANE 后更靠近消声室。",
                       "应分别观察 TRUE 与 FALSE：只有 TRUE 更多位于下方、FALSE 不同程度跟随，才支持提纯。")

            # 相似度散点
            fig, ax = plt.subplots(figsize=(7.2, 6.4), constrained_layout=True)
            for label, marker in [("FALSE_LEAK", "o"), ("TRUE_LEAK", "^")]:
                one = sub[sub["label"].astype(str).str.upper() == label]
                ax.scatter(numeric(one["combined_similarity_raw"]), numeric(one["combined_similarity_plane"]),
                           marker=marker, alpha=0.7, label=display_label(label))
            ax.plot([0, 1], [0, 1], linestyle="--", linewidth=1.0)
            ax.set_xlim(-0.02, 1.02); ax.set_ylim(-0.02, 1.02)
            ax.set_xlabel("RAW 综合相似度")
            ax.set_ylabel("PLANE 综合相似度")
            ax.set_title(f"{ref}：同一样本的频谱相似度变化")
            ax.grid(alpha=0.25)
            ax.legend()
            base = out_dir / f"A12_{safe_slug(ref)}_同一样本相似度散点"
            save_figure(fig, base, formats, dpi)
            add_record(records, "消声室比较", f"{ref} 同一样本相似度散点", base.name,
                       [ANECHOIC_FILES["paired"]],
                       "横轴 RAW、纵轴 PLANE；点位于虚线上方表示 PLANE 后频谱更相似。",
                       "TRUE 与 FALSE 同时位于上方并不能证明有效；关键是 TRUE 的提升应明显大于 FALSE。")

            # 样本变化类别
            distance_threshold = 0.15
            similarity_threshold = 0.02
            cfg = run_info.get("config", {}) if isinstance(run_info, dict) else {}
            try:
                distance_threshold = float(cfg.get("distance_gain_threshold", distance_threshold))
                similarity_threshold = float(cfg.get("similarity_gain_threshold", similarity_threshold))
            except Exception:
                pass
            dcol = "median_distance_change_plane_minus_raw"
            scol = "combined_similarity_change_plane_minus_raw"
            if all(c in sub.columns for c in [dcol, scol]):
                categories = []
                for _, row in sub.iterrows():
                    categories.append(classify_anechoic_change(
                        float(row[dcol]) if pd.notna(row[dcol]) else np.nan,
                        float(row[scol]) if pd.notna(row[scol]) else np.nan,
                        distance_threshold,
                        similarity_threshold,
                    ))
                sub = sub.copy()
                sub["change_group"] = categories
                order = ["明显改善", "部分改善", "明显变差", "部分变差", "变化小或指标矛盾"]
                counts = [int((sub["change_group"] == c).sum()) for c in order]
                fig, ax = plt.subplots(figsize=(10.5, 5.2), constrained_layout=True)
                bars = ax.bar(order, counts, hatch="//")
                ax.set_ylabel("样本数")
                ax.set_title(f"{ref}：同一样本 RAW→PLANE 的综合变化类别")
                ax.tick_params(axis="x", rotation=12)
                ax.grid(axis="y", alpha=0.25)
                annotate_bars(ax, bars, fmt=".0f")
                base = out_dir / f"A13_{safe_slug(ref)}_样本变化类别"
                save_figure(fig, base, formats, dpi)
                add_record(records, "消声室比较", f"{ref} 样本变化类别", base.name,
                           [ANECHOIC_FILES["paired"], ANECHOIC_FILES["run_info"]],
                           f"按距离阈值 {distance_threshold:g}、相似度阈值 {similarity_threshold:g} 将逐样本变化分为五类。",
                           "这是描述性统计，不是新的分类准确率。变化小或指标矛盾较多，表示 PLANE 的逐样本作用不稳定。")

                # 分场景和标签的中位变化
                agg = sub.groupby(["scene", "label"])[[dcol, scol]].median().reset_index()
                agg["category"] = agg.apply(lambda r: f"{display_scene(r['scene'])}-{display_label(r['label'])}", axis=1)
                fig, ax = plt.subplots(figsize=(10.5, 5.0), constrained_layout=True)
                vals = numeric(agg[dcol]).to_numpy(float)
                bars = ax.bar(agg["category"], vals, hatch="//")
                ax.axhline(0.0, linewidth=1.0)
                ax.set_ylabel("中位距离变化（PLANE-RAW）")
                ax.set_title(f"{ref}：各场景和标签的逐样本距离变化")
                ax.tick_params(axis="x", rotation=20)
                ax.grid(axis="y", alpha=0.25)
                annotate_bars(ax, bars, fmt="+.3f")
                base = out_dir / f"A14_{safe_slug(ref)}_场景标签_样本距离变化"
                save_figure(fig, base, formats, dpi)
                add_record(records, "消声室比较", f"{ref} 场景标签逐样本距离变化", base.name,
                           [ANECHOIC_FILES["paired"]],
                           "按场景和真实标签统计同一样本距离变化的中位数。",
                           "可直接判断某场景中 PLANE 是主要拉近 TRUE、推远 FALSE，还是让两类一起移动。")

    # A15 单项特征 z 偏差
    df = dfs.get("features", pd.DataFrame())
    req = ["reference_group", "feature", "method", "label", "absolute_z_difference"]
    if require_columns(df, req, ANECHOIC_FILES["features"], warnings) and not df.empty:
        ref = pick_reference(df, reference)
        sub = df[df["reference_group"].astype(str) == ref].copy()
        if not sub.empty:
            sub["series"] = sub.apply(lambda r: f"{display_method(r['method'])}-{display_label(r['label'])}", axis=1)
            agg = sub.groupby(["feature", "series"])["absolute_z_difference"].median().unstack()
            feature_order = [f for f in FEATURE_LABELS if f in agg.index] + [f for f in agg.index if f not in FEATURE_LABELS]
            agg = agg.loc[feature_order]
            labels = [FEATURE_LABELS.get(f, f) for f in agg.index]
            x = np.arange(len(labels), dtype=float)
            series = list(agg.columns)
            width = 0.8 / max(len(series), 1)
            fig, ax = plt.subplots(figsize=(12.0, 5.8), constrained_layout=True)
            for i, s in enumerate(series):
                offset = (i - (len(series) - 1) / 2) * width
                ax.bar(x + offset, agg[s], width, label=s, hatch=["//", "..", "xx", "\\\\"][i % 4])
            ax.set_xticks(x, labels, rotation=15)
            ax.set_ylabel("相对消声室的绝对 z 偏差（越小越接近）")
            ax.set_title(f"{ref}：五维特征中差异来自哪里")
            ax.grid(axis="y", alpha=0.25)
            ax.legend(ncol=2)
            maybe_log_y(ax, agg.to_numpy().ravel())
            base = out_dir / f"A15_{safe_slug(ref)}_五维特征绝对Z差异"
            save_figure(fig, base, formats, dpi)
            add_record(records, "消声室比较", f"{ref} 五维特征绝对 z 差异", base.name,
                       [ANECHOIC_FILES["features"]],
                       "比较 RAW/PLANE、TRUE/FALSE 在五维特征上相对消声室的标准化偏差。",
                       "某一特征偏差特别大，说明总体马氏距离主要被该维度支配；应检查物理下限、量纲和场景传播影响。")

    # A16-A18 消声室参考模型
    df = dfs.get("lab", pd.DataFrame())
    req = ["reference_group", "lab_wav_count", "lab_window_count", "window_distance_threshold"]
    if require_columns(df, req, ANECHOIC_FILES["lab"], warnings) and not df.empty:
        refs = df["reference_group"].astype(str).tolist()
        fig, ax = plt.subplots(figsize=(8.8, 4.8), constrained_layout=True)
        bars = ax.bar(refs, numeric(df["lab_window_count"]), hatch="//")
        ax.set_ylabel("参考时间窗数")
        ax.set_title("消声室参考模型的数据规模")
        ax.grid(axis="y", alpha=0.25)
        annotate_bars(ax, bars, fmt=".0f")
        for bar, wav_count in zip(bars, numeric(df["lab_wav_count"])):
            ax.text(bar.get_x() + bar.get_width()/2, bar.get_height()/2, f"{int(wav_count)}个WAV", ha="center", va="center", fontsize=9)
        base = out_dir / "A16_消声室参考模型数据规模"
        save_figure(fig, base, formats, dpi)
        add_record(records, "消声室比较", "消声室参考模型数据规模", base.name,
                   [ANECHOIC_FILES["lab"]],
                   "显示每个参考组的有效时间窗数，并在柱内标注 WAV 文件数。",
                   "参考数据量太少或组间严重不平衡会使协方差、阈值和距离不稳定。")

        fig, ax = plt.subplots(figsize=(8.8, 4.8), constrained_layout=True)
        bars = ax.bar(refs, numeric(df["window_distance_threshold"]), hatch="..")
        ax.set_ylabel("消声室内部参考距离阈值")
        ax.set_title("各消声室参考模型的 99% 距离边界")
        ax.grid(axis="y", alpha=0.25)
        annotate_bars(ax, bars)
        base = out_dir / "A17_消声室参考距离阈值"
        save_figure(fig, base, formats, dpi)
        add_record(records, "消声室比较", "消声室参考距离阈值", base.name,
                   [ANECHOIC_FILES["lab"]],
                   "显示各参考模型内部的距离边界。",
                   "阈值只描述消声室内部波动，不能自动成为工厂泄漏判定阈值；不同参考组的绝对距离也不宜直接硬比较。")

        mean_cols = [c for c in df.columns if c.startswith("mean_")]
        if mean_cols:
            matrix = df[mean_cols].apply(pd.to_numeric, errors="coerce").to_numpy(float)
            col_mean = np.nanmean(matrix, axis=0)
            col_std = np.nanstd(matrix, axis=0)
            col_std[col_std < 1e-12] = 1.0
            z = (matrix - col_mean) / col_std
            fig, ax = plt.subplots(figsize=(10.5, 4.8), constrained_layout=True)
            im = ax.imshow(z, aspect="auto")
            labels = [FEATURE_LABELS.get(c.replace("mean_", ""), c.replace("mean_", "")) for c in mean_cols]
            ax.set_xticks(np.arange(len(labels)), labels, rotation=20, ha="right")
            ax.set_yticks(np.arange(len(refs)), refs)
            ax.set_title("消声室参考组五维特征均值（按特征标准化）")
            for i in range(z.shape[0]):
                for j in range(z.shape[1]):
                    if np.isfinite(z[i, j]):
                        ax.text(j, i, f"{z[i,j]:+.2f}", ha="center", va="center", fontsize=8)
            fig.colorbar(im, ax=ax, label="同一特征内的标准化值")
            base = out_dir / "A18_消声室参考组五维特征热图"
            save_figure(fig, base, formats, dpi)
            add_record(records, "消声室比较", "消声室参考组五维特征热图", base.name,
                       [ANECHOIC_FILES["lab"]],
                       "对每个特征跨参考组标准化，展示 0.1mm、0.5mm、ALL_LEAKS 的相对差异。",
                       "该图只比较参考组之间的相对结构，不保留原量纲；用于判断不同孔径是否具有明显不同的统计特征。")

    # A19 消声室 WAV 清单
    df = dfs.get("lab_files", pd.DataFrame())
    req = ["reference_group", "n_windows", "duration_seconds", "status"]
    if require_columns(df, req, ANECHOIC_FILES["lab_files"], warnings) and not df.empty:
        ok = df[df["status"].astype(str).str.upper() == "OK"].copy()
        if not ok.empty:
            fig, ax = plt.subplots(figsize=(8.2, 5.8), constrained_layout=True)
            for ref, marker in zip(sorted(ok["reference_group"].astype(str).unique()), ["o", "^", "s", "D"]):
                sub = ok[ok["reference_group"].astype(str) == ref]
                ax.scatter(numeric(sub["duration_seconds"]), numeric(sub["n_windows"]), label=ref, marker=marker, alpha=0.8)
            ax.set_xlabel("WAV 时长（秒）")
            ax.set_ylabel("有效时间窗数")
            ax.set_title("消声室 WAV 时长与有效时间窗")
            ax.grid(alpha=0.25)
            ax.legend()
            base = out_dir / "A19_消声室WAV时长与窗口数"
            save_figure(fig, base, formats, dpi)
            add_record(records, "消声室比较", "消声室 WAV 时长与窗口数", base.name,
                       [ANECHOIC_FILES["lab_files"]],
                       "每个点是一条成功处理的消声室 WAV。",
                       "同组文件应具有合理的一致性；异常短文件、窗口数过少或失败文件可能影响参考模型。")

    # A20 窗口进入比例（来自 long）
    df = dfs.get("long", pd.DataFrame())
    req = ["reference_group", "scene", "label", "method", "window_inside_fraction"]
    if require_columns(df, req, ANECHOIC_FILES["long"], warnings) and not df.empty:
        ref = pick_reference(df, reference)
        sub = df[df["reference_group"].astype(str) == ref].copy()
        if not sub.empty:
            agg = sub.groupby(["scene", "label", "method"])["window_inside_fraction"].mean().reset_index()
            agg["category"] = agg.apply(lambda r: f"{display_scene(r['scene'])}-{display_label(r['label'])}-{display_method(r['method'])}", axis=1)
            fig, ax = plt.subplots(figsize=(13.0, 5.2), constrained_layout=True)
            bars = ax.bar(agg["category"], numeric(agg["window_inside_fraction"]), hatch="//")
            ax.set_ylabel("平均窗口进入参考区比例")
            set_y_zero_one(ax)
            ax.set_title(f"{ref}：不同场景、类别和方法进入消声室参考区的比例")
            ax.tick_params(axis="x", rotation=28)
            ax.grid(axis="y", alpha=0.25)
            base = out_dir / f"A20_{safe_slug(ref)}_窗口进入参考区比例"
            save_figure(fig, base, formats, dpi)
            add_record(records, "消声室比较", f"{ref} 窗口进入参考区比例", base.name,
                       [ANECHOIC_FILES["long"]],
                       "统计每个样本中落入消声室内部参考距离范围的时间窗比例，再按场景/类别/方法取平均。",
                       "它比只看中位距离更关注时间稳定性；TRUE 比 FALSE 高才有判别意义。")

    # A21 窗口距离分布（可选）
    df = dfs.get("windows", pd.DataFrame())
    req = ["reference_group", "scene", "label", "method", "mahalanobis_distance"]
    if not df.empty and require_columns(df, req, ANECHOIC_FILES["windows"], warnings):
        ref = pick_reference(df, reference)
        sub = df[df["reference_group"].astype(str) == ref].copy()
        categories: List[str] = []
        data: List[np.ndarray] = []
        for scene in sorted(sub["scene"].astype(str).unique()):
            for label in ["FALSE_LEAK", "TRUE_LEAK"]:
                for method in ["raw", "plane"]:
                    mask = ((sub["scene"].astype(str) == scene)
                            & (sub["label"].astype(str).str.upper() == label)
                            & (sub["method"].astype(str).str.lower() == method))
                    vals = finite_values(sub.loc[mask, "mahalanobis_distance"])
                    if len(vals):
                        # 防止极大明细表导致绘图过慢；箱线图统计只需有限抽样。
                        if len(vals) > 5000:
                            idx = np.linspace(0, len(vals) - 1, 5000).astype(int)
                            vals = np.sort(vals)[idx]
                        categories.append(f"{display_scene(scene)}\n{display_label(label)}-{method.upper()}")
                        data.append(vals)
        if data:
            fig, ax = plt.subplots(figsize=(14.0, 6.0), constrained_layout=True)
            bp = boxplot_compat(ax, data, categories, showfliers=False, patch_artist=True)
            for i, box in enumerate(bp["boxes"]):
                box.set_hatch("//" if "RAW" in categories[i] else "..")
            ax.set_ylabel("100ms 窗口马氏距离")
            ax.set_title(f"{ref}：窗口级距离分布")
            ax.tick_params(axis="x", rotation=35)
            ax.grid(axis="y", alpha=0.25)
            maybe_log_y(ax, np.concatenate(data) if data else [])
            ax.legend(handles=[Patch(fill=False, hatch="//", label="RAW"), Patch(fill=False, hatch="..", label="PLANE")])
            base = out_dir / f"A21_{safe_slug(ref)}_窗口级距离分布"
            save_figure(fig, base, formats, dpi)
            add_record(records, "消声室比较", f"{ref} 窗口级距离分布", base.name,
                       [ANECHOIC_FILES["windows"]],
                       "展示每个场景、标签和方法下 100ms 时间窗距离的分布。",
                       "箱体整体较低且较窄表示持续稳定地接近消声室；只有少量低距离离群点不能证明整段声音像泄漏。")

    # A22 错误图
    df = dfs.get("errors", pd.DataFrame())
    if not df.empty:
        col = "error_type" if "error_type" in df.columns else "error" if "error" in df.columns else None
        if col:
            counts = df[col].astype(str).value_counts().head(15).sort_values()
            fig, ax = plt.subplots(figsize=(10.0, max(4.5, 0.35 * len(counts) + 1.5)), constrained_layout=True)
            ax.barh(counts.index, counts.values, hatch="//")
            ax.set_xlabel("错误数")
            ax.set_title("消声室比较阶段错误分布")
            ax.grid(axis="x", alpha=0.25)
            base = out_dir / "A22_消声室比较阶段错误分布"
            save_figure(fig, base, formats, dpi)
            add_record(records, "消声室比较", "消声室比较阶段错误分布", base.name,
                       [ANECHOIC_FILES["errors"]],
                       "统计消声室或工厂数据处理错误。",
                       "结果文件非空时应先排查错误，避免报告使用不完整样本。")

    return dfs, reference, run_info


# =============================================================================
# 4. 第一步空间拟合与数据质量图
# =============================================================================

def find_extraction_file(root: Path, name: str) -> Optional[Path]:
    p = root / name
    if p.exists():
        return p
    matches = list(root.rglob(name))
    matches.sort(key=lambda x: (len(x.parts), len(str(x))))
    return matches[0] if matches else None


def plot_extraction(
    root: Path,
    out_dir: Path,
    formats: Sequence[str],
    dpi: int,
    records: List[FigureRecord],
    warnings: List[str],
) -> Dict[str, pd.DataFrame]:
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = {
        "features": find_extraction_file(root, "v22_EFG_all_features.csv"),
        "failures": find_extraction_file(root, "v22_EFG_failures.csv"),
        "weights": find_extraction_file(root, "v22_EFG_all_point_weights.csv"),
    }
    dfs = {key: read_csv_safe(path, warnings) for key, path in paths.items()}
    df = dfs["features"]
    if not df.empty and all(c in df.columns for c in ["scene", "label"]):
        counts = df.groupby(["scene", "label"]).size().unstack(fill_value=0)
        labels = [display_scene(s) for s in counts.index]
        x = np.arange(len(labels), dtype=float)
        cols = list(counts.columns)
        width = 0.8 / max(len(cols), 1)
        fig, ax = plt.subplots(figsize=(8.8, 5.0), constrained_layout=True)
        for i, col in enumerate(cols):
            offset = (i - (len(cols)-1)/2) * width
            bars = ax.bar(x + offset, counts[col], width, label=display_label(col), hatch="//" if "FALSE" in str(col) else "..")
            annotate_bars(ax, bars, fmt=".0f")
        ax.set_xticks(x, labels)
        ax.set_ylabel("成功提取样本数")
        ax.set_title("第 1 步空间拟合成功样本数量")
        ax.grid(axis="y", alpha=0.25)
        ax.legend()
        base = out_dir / "D01_空间拟合成功样本数量"
        save_figure(fig, base, formats, dpi)
        add_record(records, "数据质量", "空间拟合成功样本数量", base.name,
                   ["v22_EFG_all_features.csv"],
                   "按场景和标签统计第 1 步成功提取的样本。",
                   "该数量应与后续实际配对样本基本一致；差异过大说明中间读取或配对阶段丢失样本。")

        quality_cols = [c for c in ["plane_valid", "plane_geometry_ok", "fit_use_plane", "fit_geometry_ok"] if c in df.columns]
        if quality_cols:
            quality = df.groupby("scene")[quality_cols].mean()
            labels = [display_scene(s) for s in quality.index]
            x = np.arange(len(labels))
            width = 0.8 / len(quality_cols)
            fig, ax = plt.subplots(figsize=(10.0, 5.2), constrained_layout=True)
            for i, col in enumerate(quality_cols):
                offset = (i - (len(quality_cols)-1)/2) * width
                ax.bar(x + offset, quality[col], width, label=col, hatch=["//", "..", "xx", "\\\\"][i % 4])
            ax.set_xticks(x, labels)
            ax.set_ylabel("平均有效比例")
            set_y_zero_one(ax)
            ax.set_title("第 1 步空间平面拟合质量")
            ax.grid(axis="y", alpha=0.25)
            ax.legend(ncol=2)
            base = out_dir / "D02_空间平面拟合质量"
            save_figure(fig, base, formats, dpi)
            add_record(records, "数据质量", "空间平面拟合质量", base.name,
                       ["v22_EFG_all_features.csv"],
                       "展示空间平面拟合是否有效、几何条件是否满足以及是否实际采用平面方法。",
                       "任何场景有效率明显偏低，都可能导致该场景的 PLANE 结果不可与其他场景公平比较。")

        for col, ylabel, title, code in [
            ("residual_integrated_excess_ratio", "正残差/背景功率比", "空间拟合后的正残差强度分布", "D03"),
            ("residual_integrated_snr_db", "中心/背景积分SNR（dB）", "中心相对空间背景的积分 SNR", "D04"),
            ("fit_plane_improvement_db", "PLANE相对常数背景的拟合改善（dB）", "空间平面拟合自身的误差改善", "D05"),
        ]:
            if col not in df.columns:
                continue
            categories = []
            data = []
            for scene in sorted(df["scene"].astype(str).unique()):
                for label in ["FALSE_LEAK", "TRUE_LEAK"]:
                    mask = ((df["scene"].astype(str) == scene) & (df["label"].astype(str).str.upper() == label))
                    vals = finite_values(df.loc[mask, col])
                    if len(vals):
                        categories.append(f"{display_scene(scene)}-{display_label(label)}")
                        data.append(vals)
            if data:
                fig, ax = plt.subplots(figsize=(10.5, 5.4), constrained_layout=True)
                boxplot_compat(ax, data, categories, showfliers=True)
                ax.set_ylabel(ylabel)
                ax.set_title(title)
                ax.tick_params(axis="x", rotation=20)
                ax.grid(axis="y", alpha=0.25)
                maybe_log_y(ax, np.concatenate(data))
                base = out_dir / f"{code}_{safe_slug(title)}"
                save_figure(fig, base, formats, dpi)
                add_record(records, "数据质量", title, base.name,
                           ["v22_EFG_all_features.csv"],
                           f"按场景和标签展示{ylabel}的分布。",
                           "该图描述空间拟合和残差本身，不等同于最终泄漏检测能力；TRUE/FALSE 是否分开仍需看后续独立验证。")

    # 失败文件
    df = dfs["failures"]
    if not df.empty:
        col = "error_type" if "error_type" in df.columns else "error" if "error" in df.columns else None
        if col:
            counts = df[col].astype(str).value_counts().head(15).sort_values()
            fig, ax = plt.subplots(figsize=(10.0, max(4.5, 0.35 * len(counts) + 1.5)), constrained_layout=True)
            ax.barh(counts.index, counts.values, hatch="//")
            ax.set_xlabel("失败样本数")
            ax.set_title("第 1 步空间拟合失败原因")
            ax.grid(axis="x", alpha=0.25)
            base = out_dir / "D06_空间拟合失败原因"
            save_figure(fig, base, formats, dpi)
            add_record(records, "数据质量", "空间拟合失败原因", base.name,
                       ["v22_EFG_failures.csv"],
                       "统计第 1 步失败原因。",
                       "失败记录非空时，应先解决路径、点数、采样率和时间切片问题。")

    # 点权重
    df = dfs["weights"]
    if not df.empty:
        weight_col = next((c for c in ["point_weight", "weight", "robust_weight"] if c in df.columns), None)
        scene_col = "scene" if "scene" in df.columns else None
        if weight_col:
            if scene_col:
                categories = []
                data = []
                for scene in sorted(df[scene_col].astype(str).unique()):
                    vals = finite_values(df.loc[df[scene_col].astype(str) == scene, weight_col])
                    if len(vals):
                        categories.append(display_scene(scene)); data.append(vals)
            else:
                categories = ["全部点"]
                data = [finite_values(df[weight_col])]
            fig, ax = plt.subplots(figsize=(8.8, 5.0), constrained_layout=True)
            boxplot_compat(ax, data, categories, showfliers=True)
            ax.set_ylabel("鲁棒空间拟合权重")
            ax.set_title("外圈背景点权重分布")
            ax.grid(axis="y", alpha=0.25)
            base = out_dir / "D07_外圈背景点权重分布"
            save_figure(fig, base, formats, dpi)
            add_record(records, "数据质量", "外圈背景点权重分布", base.name,
                       ["v22_EFG_all_point_weights.csv"],
                       "展示鲁棒平面拟合对外圈点分配的权重。",
                       "大量接近 0 的权重表示很多背景点被判为异常；需要检查周围点是否包含局部声源、坏点或坐标错误。")

    return dfs


# =============================================================================
# 5. 自动摘要与说明文档
# =============================================================================

def build_findings(
    cls_dfs: Mapping[str, pd.DataFrame],
    an_dfs: Mapping[str, pd.DataFrame],
    extraction_dfs: Mapping[str, pd.DataFrame],
    reference: str,
) -> List[str]:
    lines: List[str] = []
    cls = cls_dfs.get("summary", pd.DataFrame())
    if not cls.empty:
        r = cls.iloc[0]
        lines.append(f"工厂跨场景分类结论：{r.get('最终结论', '未提供')}。{r.get('人话解释', '')}")
        for raw_col, plane_col, name in [
            ("RAW三场景平均平衡准确率", "PLANE三场景平均平衡准确率", "平均平衡准确率"),
            ("RAW三场景平均AUC", "PLANE三场景平均AUC", "平均AUC"),
        ]:
            if raw_col in r and plane_col in r:
                raw = float(r[raw_col]); plane = float(r[plane_col])
                lines.append(f"{name}：RAW={raw:.4f}，PLANE={plane:.4f}，变化={plane-raw:+.4f}。")
        if all(c in r for c in ["bootstrap_delta_balacc_ci_low", "bootstrap_delta_balacc_ci_high"]):
            low = float(r["bootstrap_delta_balacc_ci_low"]); high = float(r["bootstrap_delta_balacc_ci_high"])
            if low <= 0 <= high:
                lines.append(f"PLANE-RAW 平衡准确率的 bootstrap 95%CI=[{low:+.4f},{high:+.4f}]，区间跨 0，现有样本不足以证明总体稳定提升。")
            else:
                direction = "提升" if low > 0 else "下降"
                lines.append(f"PLANE-RAW 平衡准确率的 bootstrap 95%CI=[{low:+.4f},{high:+.4f}]，区间不跨 0，支持总体{direction}。")

    scene = cls_dfs.get("scene", pd.DataFrame())
    if not scene.empty and "plane_minus_raw_balanced_accuracy" in scene.columns:
        for _, r in scene.iterrows():
            lines.append(
                f"{display_scene(r['test_scene'])}：平衡准确率 PLANE-RAW={float(r['plane_minus_raw_balanced_accuracy']):+.4f}，"
                f"判断={r.get('scene_judgement','')}。"
            )

    an = an_dfs.get("summary", pd.DataFrame())
    if not an.empty and "reference_group" in an.columns:
        sub = an[an["reference_group"].astype(str) == reference]
        if sub.empty:
            sub = an.head(1)
        r = sub.iloc[0]
        lines.append(f"消声室比较重点参考组：{r.get('reference_group', reference)}；总体结论：{r.get('final_conclusion','未提供')}。")
        keys = [
            ("raw_true_median_distance", "plane_true_median_distance", "TRUE中位距离"),
            ("raw_false_median_distance", "plane_false_median_distance", "FALSE中位距离"),
            ("raw_true_combined_similarity", "plane_true_combined_similarity", "TRUE综合相似度"),
            ("raw_false_combined_similarity", "plane_false_combined_similarity", "FALSE综合相似度"),
        ]
        for a, b, name in keys:
            if a in r and b in r:
                av = float(r[a]); bv = float(r[b])
                lines.append(f"{name}：RAW={av:.4f}，PLANE={bv:.4f}，变化={bv-av:+.4f}。")
        if "mean_plane_minus_raw_distance_separation" in r:
            lines.append(f"平均距离分离改善={float(r['mean_plane_minus_raw_distance_separation']):+.4f}；正值表示 PLANE 扩大 FALSE-TRUE 距离差。")
        if "mean_plane_minus_raw_spectral_similarity_separation" in r:
            lines.append(f"平均频谱相似度分离改善={float(r['mean_plane_minus_raw_spectral_similarity_separation']):+.4f}；正值表示 PLANE 扩大 TRUE-FALSE 相似度差。")

    errors: List[Tuple[str, pd.DataFrame]] = [
        ("第1步", extraction_dfs.get("failures", pd.DataFrame())),
        ("分类阶段", cls_dfs.get("errors", pd.DataFrame())),
        ("消声室阶段", an_dfs.get("errors", pd.DataFrame())),
    ]
    for name, df in errors:
        if df is None or df.empty:
            lines.append(f"{name}错误文件为空或无记录。")
        else:
            lines.append(f"{name}存在 {len(df)} 条错误记录，必须先检查错误文件再解释最终结果。")

    lines.append("所有消声室距离与相似度均为参考接近程度，不是泄漏概率，也不能单独替代真实跨场景分类验证。")
    return lines


def write_documentation(
    output_dir: Path,
    root: Path,
    cls_dir: Optional[Path],
    an_dir: Optional[Path],
    records: Sequence[FigureRecord],
    findings: Sequence[str],
    warnings: Sequence[str],
    font_name: str,
    formats: Sequence[str],
    reference: str,
) -> None:
    index_rows = [r.__dict__ for r in records]
    pd.DataFrame(index_rows).to_csv(output_dir / "00_图表索引.csv", index=False, encoding="utf-8-sig")

    lines: List[str] = [
        "# v22 结果图表与逐文件说明",
        "",
        f"- 绘图程序版本：`{VERSION}`",
        f"- v22 根目录：`{root}`",
        f"- 分类结果目录：`{cls_dir or '未找到'}`",
        f"- 消声室结果目录：`{an_dir or '未找到'}`",
        f"- 重点消声室参考组：`{reference}`",
        f"- 中文字体：`{font_name}`",
        f"- 输出格式：{', '.join(formats)}",
        "",
        "## 一、自动提取的主要结果",
        "",
    ]
    lines.extend([f"- {x}" for x in findings])
    lines.extend(["", "## 二、报告中推荐优先使用的图", ""])
    preferred = [
        "C03_各场景平衡准确率_RAW_vs_PLANE",
        "C05_各场景_PLANE减RAW平衡准确率",
        "C06_各场景灵敏度与特异度",
        "A03_总体距离分离改善",
        "A04_总体频谱相似度分离改善",
        f"A10_{safe_slug(reference)}_TRUE_FALSE距离变化",
        f"A11_{safe_slug(reference)}_同一样本距离散点",
        f"A15_{safe_slug(reference)}_五维特征绝对Z差异",
    ]
    existing = {r.base_name: r for r in records}
    for name in preferred:
        if name in existing:
            r = existing[name]
            lines.append(f"- **{r.title}**：`{r.base_name}.png`。{r.interpretation}")

    lines.extend(["", "## 三、每张图的含义", ""])
    for r in records:
        lines.extend([
            f"### 图 {r.number}：{r.title}",
            "",
            f"- 文件名：`{r.base_name}.png/.pdf/.svg`",
            f"- 来源：`{r.source_files}`",
            f"- 图注建议：{r.caption}",
            f"- 结果解释：{r.interpretation}",
            "",
        ])

    lines.extend(["## 四、v22 每个结果文件的详细说明", ""])
    for key, desc in SOURCE_DESCRIPTIONS.items():
        lines.extend([f"### `{key}`", "", desc, ""])

    lines.extend([
        "## 五、报告解读原则",
        "",
        "1. **分类主指标优先看冻结阈值下的平衡准确率、灵敏度和特异度。** AUC 只表示排序，不保证新场景阈值有效。",
        "2. **消声室比较必须同时看 TRUE 和 FALSE。** TRUE 更近但 FALSE 也同样变近，不能证明提取出了纯泄漏。",
        "3. **距离越小、相似度越大仅表示更接近消声室参考。** 它们不是泄漏概率。",
        "4. **场景一致性比总体平均值更重要。** 有的场景提高、有的场景下降，应结论为跨场景不稳定。",
        "5. **先看错误文件和样本数量。** 数据不完整时，图形再漂亮也不能支持可靠结论。",
        "",
        "## 六、运行警告",
        "",
    ])
    if warnings:
        lines.extend([f"- {w}" for w in warnings])
    else:
        lines.append("- 未发现影响绘图的结构性问题。")

    md = "\n".join(lines)
    (output_dir / "01_图表与结果详细说明.md").write_text(md, encoding="utf-8")
    (output_dir / "01_图表与结果详细说明.txt").write_text(md.replace("#", ""), encoding="utf-8")
    (output_dir / "02_自动结果摘要.txt").write_text("\n".join(findings), encoding="utf-8")
    (output_dir / "99_绘图警告.txt").write_text("\n".join(warnings) if warnings else "无", encoding="utf-8")


# =============================================================================
# 6. 主程序
# =============================================================================

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="对 v22 RAW/PLANE 分类与消声室比较结果生成报告级图表。",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--root", type=str, default=None, help="v22 总输出目录")
    parser.add_argument("--config", type=str, default=None, help="v22 配置 JSON；可自动读取三个输出路径")
    parser.add_argument("--output", type=str, default=None, help="图表输出目录")
    parser.add_argument("--reference", type=str, default="ALL_LEAKS", help="重点绘图参考组")
    parser.add_argument("--formats", nargs="+", default=["png", "pdf", "svg"], choices=["png", "pdf", "svg"])
    parser.add_argument("--dpi", type=int, default=300, help="PNG 分辨率")
    parser.add_argument("--top-features", type=int, default=15, help="特征图显示前多少项")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    font_name = configure_matplotlib()
    root, cls_dir, an_dir, output_dir, _ = resolve_paths(
        Path(args.root) if args.root else None,
        Path(args.config) if args.config else None,
        Path(args.output) if args.output else None,
    )

    warnings: List[str] = []
    records: List[FigureRecord] = []
    cls_dfs: Dict[str, pd.DataFrame] = {}
    an_dfs: Dict[str, pd.DataFrame] = {}
    extraction_dfs: Dict[str, pd.DataFrame] = {}
    reference = args.reference

    print("=" * 78)
    print("v22 结果报告绘图")
    print("根目录:", root)
    print("分类目录:", cls_dir or "未找到")
    print("消声室目录:", an_dir or "未找到")
    print("输出目录:", output_dir)
    print("=" * 78)

    try:
        extraction_dfs = plot_extraction(
            root, output_dir / "01_数据质量与空间拟合", args.formats, args.dpi,
            records, warnings,
        )
    except Exception as exc:
        warnings.append(f"数据质量绘图失败：{type(exc).__name__}: {exc}\n{traceback.format_exc()}")

    if cls_dir is not None:
        try:
            cls_dfs = plot_classification(
                cls_dir, output_dir / "02_工厂跨场景分类", args.formats, args.dpi,
                records, warnings, args.top_features,
            )
        except Exception as exc:
            warnings.append(f"分类结果绘图失败：{type(exc).__name__}: {exc}\n{traceback.format_exc()}")
    else:
        warnings.append(f"未找到 {CLASSIFICATION_FILES['scene']}，跳过工厂分类图。")

    if an_dir is not None:
        try:
            an_dfs, reference, _ = plot_anechoic(
                an_dir, output_dir / "03_RAW_PLANE与消声室比较", args.formats, args.dpi,
                records, warnings, args.reference,
            )
        except Exception as exc:
            warnings.append(f"消声室比较绘图失败：{type(exc).__name__}: {exc}\n{traceback.format_exc()}")
    else:
        warnings.append(f"未找到 {ANECHOIC_FILES['long']}，跳过消声室比较图。")

    findings = build_findings(cls_dfs, an_dfs, extraction_dfs, reference)
    write_documentation(
        output_dir, root, cls_dir, an_dir, records, findings, warnings,
        font_name, args.formats, reference,
    )

    print(f"\n完成：共生成 {len(records)} 张独立图表。")
    print("图表索引:", output_dir / "00_图表索引.csv")
    print("详细说明:", output_dir / "01_图表与结果详细说明.md")
    print("自动摘要:", output_dir / "02_自动结果摘要.txt")
    if warnings:
        print(f"注意：有 {len(warnings)} 条警告，请查看 {output_dir / '99_绘图警告.txt'}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n用户中止。")
        raise SystemExit(130)
    except Exception as exc:
        print("\n程序失败:", f"{type(exc).__name__}: {exc}")
        traceback.print_exc()
        raise SystemExit(1)
