@echo off
chcp 65001 >nul
cd /d "%~dp0"
python ABC_lab_raw_plane_each_second_similarity.py --self-test
pause
