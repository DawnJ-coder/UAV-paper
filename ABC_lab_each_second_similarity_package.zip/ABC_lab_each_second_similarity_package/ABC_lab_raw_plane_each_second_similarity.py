# -*- coding: utf-8 -*-
"""
ABC_lab_raw_plane_each_second_similarity.py

用途
----
1. 分别读取 factory_A、factory_B、factory_C 的逐秒 v9 结果；
2. 对 raw、plane 分别计算 A、B、C 三个场景的 TRUE-FALSE 稳定正差异；
3. 构建 A∩B∩C 的严格共同泄漏候选频谱；
4. 检查每个工厂样本确实对应严格 1 秒；
5. 将实验室长 WAV 严格切成不重叠的 [0,1)、[1,2)、... 秒片段；
6. 对每个实验室 WAV 的每一秒分别计算与 ABC 共同频谱的相似度；
7. 额外输出逐 WAV 汇总、实验室组汇总、工厂逐秒稳定性和 raw/plane 对比。

运行
----
python ABC_lab_raw_plane_each_second_similarity.py --self-test
python ABC_lab_raw_plane_each_second_similarity.py --config ABC_lab_raw_plane_config.json
"""

from __future__ import annotations

import argparse
import json
import tempfile
import traceback
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    from scipy.io import wavfile
except Exception as exc:
    raise RuntimeError("缺少 scipy，请运行: pip install scipy") from exc

try:
    import ABC_lab_commonality_multiscale as core
except Exception as exc:
    raise RuntimeError(
        "无法导入 ABC_lab_commonality_multiscale.py，请把两个程序放在同一目录。"
    ) from exc

EPS = 1.0e-20
VALID_LABELS = {"TRUE_LEAK", "FALSE_LEAK"}
SUPPORTED_METHODS = ("raw", "plane")


@dataclass
class SceneInput:
    name: str
    v9_dir: str


@dataclass
class RunConfig:
    scene_A: SceneInput
    scene_B: SceneInput
    scene_C: SceneInput
    lab_groups: Dict[str, List[str]]
    output_dir: str

    factory_methods: List[str] = field(default_factory=lambda: ["raw", "plane"])

    freq_low_hz: float = 20_000.0
    freq_high_hz: float = 80_000.0
    n_spectral_bins: int = 256
    n_temporal_quantiles: int = 64
    spectral_smooth_bins: int = 5

    bootstrap_iterations: int = 500
    bootstrap_positive_probability: float = 0.90
    min_robust_effect: float = 0.25
    random_state: int = 42

    coarse_bandwidths_hz: List[float] = field(
        default_factory=lambda: [5_000.0, 10_000.0]
    )

    # 工厂 v9 输入必须是逐秒版本。
    require_factory_one_second: bool = True
    factory_slice_seconds: float = 1.0
    time_tolerance_seconds: float = 1.0e-6

    # 实验室 WAV 严格按不重叠 1 秒切片。
    require_lab_one_second: bool = True
    lab_segment_seconds: float = 1.0
    lab_segment_hop_seconds: float = 1.0
    lab_nperseg: int = 4096
    lab_hop_length: int = 2048
    lab_nfft: int = 4096
    min_segments_per_wav: int = 1

    save_figures: bool = True


# =============================================================================
# 基础工具
# =============================================================================


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def load_config(path: Path) -> RunConfig:
    payload = json.loads(path.read_text(encoding="utf-8"))
    try:
        scene_a = SceneInput(**payload.pop("scene_A"))
        scene_b = SceneInput(**payload.pop("scene_B"))
        scene_c = SceneInput(**payload.pop("scene_C"))
        cfg = RunConfig(
            scene_A=scene_a,
            scene_B=scene_b,
            scene_C=scene_c,
            **payload,
        )
    except TypeError as exc:
        raise ValueError(f"配置字段错误: {exc}") from exc

    methods = [str(x).strip().lower() for x in cfg.factory_methods]
    unknown = sorted(set(methods) - set(SUPPORTED_METHODS))
    if unknown:
        raise ValueError(f"factory_methods只支持raw、plane，当前未知值={unknown}")
    cfg.factory_methods = list(dict.fromkeys(methods))

    if not cfg.factory_methods:
        raise ValueError("factory_methods不能为空")
    if not cfg.lab_groups:
        raise ValueError("lab_groups不能为空")
    if cfg.freq_high_hz <= cfg.freq_low_hz:
        raise ValueError("freq_high_hz必须大于freq_low_hz")
    if cfg.n_spectral_bins < 16:
        raise ValueError("n_spectral_bins不能小于16")
    if cfg.factory_slice_seconds <= 0:
        raise ValueError("factory_slice_seconds必须大于0")
    if cfg.lab_segment_seconds <= 0 or cfg.lab_segment_hop_seconds <= 0:
        raise ValueError("实验室切片长度和步长必须大于0")

    if cfg.require_factory_one_second and not np.isclose(
        cfg.factory_slice_seconds, 1.0, atol=cfg.time_tolerance_seconds
    ):
        raise ValueError("require_factory_one_second=true时，factory_slice_seconds必须为1.0")

    if cfg.require_lab_one_second:
        if not np.isclose(cfg.lab_segment_seconds, 1.0, atol=cfg.time_tolerance_seconds):
            raise ValueError("require_lab_one_second=true时，lab_segment_seconds必须为1.0")
        if not np.isclose(
            cfg.lab_segment_hop_seconds,
            cfg.lab_segment_seconds,
            atol=cfg.time_tolerance_seconds,
        ):
            raise ValueError(
                "实验室逐秒比较要求不重叠切片：lab_segment_hop_seconds必须等于lab_segment_seconds"
            )

    scene_names = [cfg.scene_A.name, cfg.scene_B.name, cfg.scene_C.name]
    if len(set(scene_names)) != 3:
        raise ValueError(f"A、B、C场景名称必须互不相同，当前={scene_names}")
    return cfg


def core_config(cfg: RunConfig, output_dir: Path) -> core.AnalysisConfig:
    """复用原多尺度程序中的频谱、相似度和场景对比函数。"""
    return core.AnalysisConfig(
        scene_A=core.SceneInput(name=cfg.scene_A.name, v9_dir=cfg.scene_A.v9_dir),
        scene_B=core.SceneInput(name=cfg.scene_B.name, v9_dir=cfg.scene_B.v9_dir),
        lab_wav_paths=[],
        output_dir=str(output_dir),
        residual_variant="plane",
        factory_representation="excess_power",
        freq_low_hz=cfg.freq_low_hz,
        freq_high_hz=cfg.freq_high_hz,
        n_spectral_bins=cfg.n_spectral_bins,
        n_temporal_quantiles=cfg.n_temporal_quantiles,
        spectral_smooth_bins=cfg.spectral_smooth_bins,
        bootstrap_iterations=cfg.bootstrap_iterations,
        bootstrap_positive_probability=cfg.bootstrap_positive_probability,
        min_robust_effect=cfg.min_robust_effect,
        random_state=cfg.random_state,
        coarse_bandwidths_hz=tuple(float(x) for x in cfg.coarse_bandwidths_hz),
        lab_segment_seconds=cfg.lab_segment_seconds,
        lab_segment_hop_seconds=cfg.lab_segment_hop_seconds,
        lab_nperseg=cfg.lab_nperseg,
        lab_hop_length=cfg.lab_hop_length,
        lab_nfft=cfg.lab_nfft,
        min_lab_segments=max(1, cfg.min_segments_per_wav),
        save_figures=cfg.save_figures,
    )


def metric_columns(cfg: RunConfig) -> List[str]:
    columns = [
        "pearson_correlation_to_ABC_common",
        "cosine_similarity_to_ABC_common",
        "overlap_similarity_to_ABC_common",
        "js_similarity_to_ABC_common",
    ]
    for width in cfg.coarse_bandwidths_hz:
        tag = f"{float(width) / 1000:g}kHz"
        columns.extend(
            [
                f"pearson_correlation_{tag}_to_ABC_common",
                f"cosine_similarity_{tag}_to_ABC_common",
            ]
        )
    return columns


def similarity_metrics(
    abc_profile: np.ndarray,
    spectrum: np.ndarray,
    freq_grid: np.ndarray,
    cfg: RunConfig,
) -> Dict[str, float]:
    result: Dict[str, float] = {
        "pearson_correlation_to_ABC_common": core.pearson_safe(abc_profile, spectrum),
        "cosine_similarity_to_ABC_common": core.cosine_similarity(abc_profile, spectrum),
        "overlap_similarity_to_ABC_common": core.overlap_coefficient(abc_profile, spectrum),
        "js_similarity_to_ABC_common": core.js_similarity(abc_profile, spectrum),
    }
    for width in cfg.coarse_bandwidths_hz:
        tag = f"{float(width) / 1000:g}kHz"
        _, abc_coarse = core.coarse_profile(freq_grid, abc_profile, float(width))
        _, x_coarse = core.coarse_profile(freq_grid, spectrum, float(width))
        result[f"pearson_correlation_{tag}_to_ABC_common"] = core.pearson_safe(
            abc_coarse, x_coarse
        )
        result[f"cosine_similarity_{tag}_to_ABC_common"] = core.cosine_similarity(
            abc_coarse, x_coarse
        )
    return result


# =============================================================================
# 工厂逐秒 v9 读取
# =============================================================================


def metadata_path(scene_root: Path, method: str) -> Path:
    candidates = [
        scene_root / "v9_all_features.csv",
        scene_root / "methods" / method / "v9_method_features.csv",
    ]
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(
        "场景目录缺少标签元数据。至少需要以下文件之一：\n"
        + "\n".join(f"  {p}" for p in candidates)
    )


def method_npz_dir(scene_root: Path, method: str) -> Path:
    path = scene_root / "methods" / method / "residual_npz"
    if not path.exists():
        raise FileNotFoundError(f"找不到{method}方法NPZ目录: {path}")
    return path


def build_npz_index(npz_dir: Path) -> Dict[str, Path]:
    index: Dict[str, Path] = {}
    for path in sorted(npz_dir.glob("*.npz")):
        index[path.stem] = path
        index[core.safe_slug(path.stem)] = path
    if not index:
        raise FileNotFoundError(f"目录中没有NPZ: {npz_dir}")
    return index


def resolve_npz(sample_id: str, index: Mapping[str, Path]) -> Optional[Path]:
    sid = str(sample_id).strip()
    slug = core.safe_slug(sid)
    for key in (sid, slug):
        if key in index:
            return index[key]
    unique = sorted(
        {p for stem, p in index.items() if slug and (slug in stem or stem in slug)}
    )
    return unique[0] if len(unique) == 1 else None


def choose_component_key(data: Mapping[str, Any], method: str) -> str:
    if method == "raw":
        candidates = ("component_power", "raw_power")
    elif method == "plane":
        candidates = ("component_power", "excess_power_plane", "excess_power")
    else:
        raise ValueError(f"未知方法: {method}")
    for key in candidates:
        if key in data:
            return key
    raise KeyError(
        f"{method} NPZ缺少功率字段，尝试过{candidates}，现有字段={list(data.keys())}"
    )


def orient_tf(matrix: np.ndarray, n_freq: int) -> np.ndarray:
    arr = np.asarray(matrix, dtype=float)
    if arr.ndim == 1:
        if arr.size != n_freq:
            raise ValueError(f"一维功率长度{arr.size}与频率长度{n_freq}不一致")
        return arr[:, None]
    if arr.ndim != 2:
        raise ValueError(f"功率矩阵应为二维，当前shape={arr.shape}")
    if arr.shape[0] == n_freq:
        return arr
    if arr.shape[1] == n_freq:
        return arr.T
    raise ValueError(f"无法判断频率轴: matrix={arr.shape}, n_freq={n_freq}")


def validate_factory_one_second_metadata(
    df: pd.DataFrame,
    csv_path: Path,
    cfg: RunConfig,
) -> pd.DataFrame:
    if not cfg.require_factory_one_second:
        return df

    required = ["second_index", "segment_start_second", "segment_end_second"]
    missing = [name for name in required if name not in df.columns]
    if missing:
        raise ValueError(
            f"{csv_path}缺少逐秒字段{missing}。这通常说明仍在使用旧v9结果，"
            "请先运行ABC逐秒修正版v9。"
        )

    out = df.copy()
    for name in required:
        out[name] = pd.to_numeric(out[name], errors="coerce")

    invalid_numeric = out[required].isna().any(axis=1)
    if invalid_numeric.any():
        bad = out.loc[invalid_numeric, ["sample_id", *required]].head(10)
        raise ValueError(f"{csv_path}存在无法解析的逐秒字段，例如:\n{bad}")

    duration = out["segment_end_second"] - out["segment_start_second"]
    expected_start = out["second_index"] * float(cfg.factory_slice_seconds)
    duration_ok = np.isclose(
        duration.to_numpy(dtype=float),
        float(cfg.factory_slice_seconds),
        atol=cfg.time_tolerance_seconds,
    )
    start_ok = np.isclose(
        out["segment_start_second"].to_numpy(dtype=float),
        expected_start.to_numpy(dtype=float),
        atol=cfg.time_tolerance_seconds,
    )
    second_integer_ok = np.isclose(
        out["second_index"].to_numpy(dtype=float),
        np.round(out["second_index"].to_numpy(dtype=float)),
        atol=cfg.time_tolerance_seconds,
    )

    invalid = ~(duration_ok & start_ok & second_integer_ok)
    if np.any(invalid):
        bad = out.loc[
            invalid,
            [
                "sample_id",
                "second_index",
                "segment_start_second",
                "segment_end_second",
            ],
        ].head(20)
        raise ValueError(
            f"{csv_path}不是严格逐秒结果。要求second_index=s时区间为[s,s+1)，例如:\n{bad}"
        )
    out["second_index"] = out["second_index"].astype(int)
    return out


def sample_fingerprint(
    npz_path: Path,
    method: str,
    freq_grid: np.ndarray,
    cfg: RunConfig,
) -> Tuple[np.ndarray, np.ndarray, str, str]:
    with np.load(npz_path, allow_pickle=False) as data:
        if "freq_hz" not in data:
            raise KeyError("NPZ缺少freq_hz")
        freq = np.asarray(data["freq_hz"], dtype=float).ravel()
        key = choose_component_key(data, method)
        matrix = orient_tf(np.asarray(data[key]), len(freq))
        matrix = np.maximum(
            np.nan_to_num(matrix, nan=0.0, posinf=0.0, neginf=0.0), 0.0
        )

        mask = (freq >= cfg.freq_low_hz) & (freq <= cfg.freq_high_hz)
        if int(np.sum(mask)) < 5:
            raise ValueError("NPZ在目标频带内频点不足")
        f = freq[mask]
        m = matrix[mask]

        spectrum_native = np.sqrt(np.maximum(np.mean(m, axis=1), 0.0))
        spectrum_native = core.smooth_1d(
            spectrum_native, cfg.spectral_smooth_bins
        )
        spectrum = core.normalize_nonnegative(
            core.interp_vector(f, spectrum_native, freq_grid)
        )

        frame_signal = np.sum(m, axis=0)
        bg_key = ""
        if method == "plane":
            for candidate in ("background_power_db", "background_power_db_plane"):
                if candidate in data:
                    bg_key = candidate
                    break
        if bg_key:
            bg_db = orient_tf(np.asarray(data[bg_key]), len(freq))[mask]
            bg_power = np.power(10.0, np.clip(bg_db, -300.0, 300.0) / 10.0)
            frame_bg = np.sum(bg_power, axis=0)
            frame_measure = np.log1p(frame_signal / (frame_bg + EPS))
        else:
            positive = frame_signal[frame_signal > 0]
            scale = float(np.median(positive)) if positive.size else 1.0
            frame_measure = np.log1p(frame_signal / max(scale, EPS))

        frame_measure = np.nan_to_num(
            frame_measure, nan=0.0, posinf=0.0, neginf=0.0
        )
        temporal = np.quantile(
            frame_measure, np.linspace(0.0, 1.0, cfg.n_temporal_quantiles)
        )
        q95 = float(np.quantile(temporal, 0.95)) if temporal.size else 0.0
        if q95 > EPS:
            temporal = np.clip(temporal / q95, 0.0, None)
    return spectrum, temporal, key, bg_key


def load_scene_method(
    scene: SceneInput,
    method: str,
    freq_grid: np.ndarray,
    cfg: RunConfig,
) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray, pd.DataFrame]:
    root = Path(scene.v9_dir)
    csv_path = metadata_path(root, method)
    npz_dir = method_npz_dir(root, method)
    index = build_npz_index(npz_dir)

    df = pd.read_csv(
        csv_path,
        dtype={"sample_id": str, "center": str, "time": str},
    )
    required = ["sample_id", "label"]
    missing = [name for name in required if name not in df.columns]
    if missing:
        raise ValueError(f"{csv_path}缺少列: {missing}")

    df["label"] = df["label"].astype(str).str.upper().str.strip()
    df = (
        df[df["label"].isin(VALID_LABELS)]
        .drop_duplicates("sample_id")
        .reset_index(drop=True)
    )
    if df.empty:
        raise ValueError(f"{csv_path}没有TRUE_LEAK/FALSE_LEAK样本")
    df = validate_factory_one_second_metadata(df, csv_path, cfg)

    used_rows: List[Dict[str, Any]] = []
    spectra: List[np.ndarray] = []
    temporals: List[np.ndarray] = []
    log_rows: List[Dict[str, Any]] = []

    for _, row in df.iterrows():
        sample_id = str(row["sample_id"])
        npz_path = resolve_npz(sample_id, index)
        if npz_path is None:
            log_rows.append(
                {
                    "scene": scene.name,
                    "method": method,
                    "sample_id": sample_id,
                    "label": row["label"],
                    "status": "FAILED",
                    "error": "找不到对应NPZ",
                }
            )
            continue
        try:
            spec, temp, matrix_key, bg_key = sample_fingerprint(
                npz_path, method, freq_grid, cfg
            )
            spectra.append(spec)
            temporals.append(temp)
            used_rows.append(
                {
                    "sample_id": sample_id,
                    "label": row["label"],
                    "dataset": str(row.get("dataset", "")),
                    "scene": scene.name,
                    "time": str(row.get("time", "")),
                    "center": str(row.get("center", "")),
                    "second_index": int(row.get("second_index", -1)),
                    "segment_start_second": float(
                        row.get("segment_start_second", np.nan)
                    ),
                    "segment_end_second": float(
                        row.get("segment_end_second", np.nan)
                    ),
                    "npz_path": str(npz_path),
                }
            )
            log_rows.append(
                {
                    "scene": scene.name,
                    "method": method,
                    "sample_id": sample_id,
                    "label": row["label"],
                    "status": "OK",
                    "npz_path": str(npz_path),
                    "matrix_key": matrix_key,
                    "background_key": bg_key,
                    "second_index": int(row.get("second_index", -1)),
                    "segment_start_second": float(
                        row.get("segment_start_second", np.nan)
                    ),
                    "segment_end_second": float(
                        row.get("segment_end_second", np.nan)
                    ),
                    "error": "",
                }
            )
        except Exception as exc:
            log_rows.append(
                {
                    "scene": scene.name,
                    "method": method,
                    "sample_id": sample_id,
                    "label": row["label"],
                    "status": "FAILED",
                    "npz_path": str(npz_path),
                    "error": f"{type(exc).__name__}: {exc}",
                    "traceback": traceback.format_exc(),
                }
            )

    used = pd.DataFrame(used_rows)
    if used.empty:
        raise RuntimeError(f"{scene.name}的{method}没有成功读取任何样本")
    labels = set(used["label"])
    if labels != VALID_LABELS:
        raise ValueError(
            f"{scene.name}的{method}必须同时包含TRUE/FALSE，当前={sorted(labels)}"
        )
    return used, np.vstack(spectra), np.vstack(temporals), pd.DataFrame(log_rows)


# =============================================================================
# ABC共同频谱
# =============================================================================


def build_abc_common(
    a: Dict[str, np.ndarray],
    b: Dict[str, np.ndarray],
    c: Dict[str, np.ndarray],
) -> Dict[str, Any]:
    profiles = np.vstack(
        [
            core.normalize_nonnegative(a["weighted_positive"]),
            core.normalize_nonnegative(b["weighted_positive"]),
            core.normalize_nonnegative(c["weighted_positive"]),
        ]
    )
    strict = (
        a["stable_positive"].astype(bool)
        & b["stable_positive"].astype(bool)
        & c["stable_positive"].astype(bool)
    )

    # 三个场景软共性使用几何平均：只有三个场景都较高时才会较高。
    soft_common = np.power(np.prod(np.maximum(profiles, 0.0), axis=0), 1.0 / 3.0)
    strict_common = np.where(strict, soft_common, 0.0)
    strict_available = bool(np.sum(strict_common) > EPS)
    common = core.normalize_nonnegative(
        strict_common if strict_available else soft_common
    )
    return {
        "a_profile": profiles[0],
        "b_profile": profiles[1],
        "c_profile": profiles[2],
        "strict_mask": strict.astype(int),
        "soft_common": core.normalize_nonnegative(soft_common),
        "common": common,
        "common_source": "STRICT_ABC_INTERSECTION"
        if strict_available
        else "SOFT_ABC_GEOMETRIC_FALLBACK",
    }


def pair_similarity_rows(
    freq_grid: np.ndarray,
    name_x: str,
    x: np.ndarray,
    name_y: str,
    y: np.ndarray,
    cfg: RunConfig,
) -> Dict[str, float]:
    prefix = f"{name_x}_{name_y}"
    result: Dict[str, float] = {
        f"{prefix}_pearson_fine": core.pearson_safe(x, y),
        f"{prefix}_cosine_fine": core.cosine_similarity(x, y),
        f"{prefix}_overlap_fine": core.overlap_coefficient(x, y),
        f"{prefix}_js_similarity_fine": core.js_similarity(x, y),
    }
    for width in cfg.coarse_bandwidths_hz:
        tag = f"{float(width) / 1000:g}kHz"
        _, x_c = core.coarse_profile(freq_grid, x, float(width))
        _, y_c = core.coarse_profile(freq_grid, y, float(width))
        result[f"{prefix}_pearson_{tag}"] = core.pearson_safe(x_c, y_c)
        result[f"{prefix}_cosine_{tag}"] = core.cosine_similarity(x_c, y_c)
    return result


def factory_each_second_similarity(
    method: str,
    abc_profile: np.ndarray,
    freq_grid: np.ndarray,
    cfg: RunConfig,
    scene_data: Sequence[Tuple[pd.DataFrame, np.ndarray]],
) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for metadata, spectra in scene_data:
        if len(metadata) != len(spectra):
            raise ValueError("工厂元数据行数与频谱矩阵行数不一致")
        for idx, row in metadata.reset_index(drop=True).iterrows():
            rows.append(
                {
                    "method": method,
                    "comparison_unit": "ONE_FACTORY_SECOND",
                    "scene": str(row["scene"]),
                    "sample_id": str(row["sample_id"]),
                    "label": str(row["label"]),
                    "dataset": str(row.get("dataset", "")),
                    "time": str(row.get("time", "")),
                    "center": str(row.get("center", "")),
                    "second_index": int(row.get("second_index", -1)),
                    "segment_start_second": float(
                        row.get("segment_start_second", np.nan)
                    ),
                    "segment_end_second": float(
                        row.get("segment_end_second", np.nan)
                    ),
                    **similarity_metrics(
                        abc_profile, spectra[idx], freq_grid, cfg
                    ),
                }
            )
    return pd.DataFrame(rows)


# =============================================================================
# 实验室WAV逐秒
# =============================================================================


def iter_exact_segments(
    x: np.ndarray,
    fs: int,
    seconds: float,
    hop_seconds: float,
) -> Iterable[Tuple[int, float, float, np.ndarray]]:
    seg_len = int(round(float(seconds) * fs))
    hop = int(round(float(hop_seconds) * fs))
    if seg_len < 256 or hop < 1:
        return
    segment_index = 0
    for start_sample in range(0, max(len(x) - seg_len + 1, 0), hop):
        end_sample = start_sample + seg_len
        if end_sample > len(x):
            break
        yield (
            segment_index,
            start_sample / float(fs),
            end_sample / float(fs),
            x[start_sample:end_sample],
        )
        segment_index += 1


def lab_wav_segments(
    wav_path: Path,
    freq_grid: np.ndarray,
    cfg: RunConfig,
    algorithm_cfg: core.AnalysisConfig,
) -> Tuple[List[Dict[str, Any]], List[np.ndarray]]:
    fs, x = core.read_wav_preserve_scale(wav_path)
    rows: List[Dict[str, Any]] = []
    spectra: List[np.ndarray] = []
    for segment_index, start_s, end_s, segment in iter_exact_segments(
        x,
        fs,
        cfg.lab_segment_seconds,
        cfg.lab_segment_hop_seconds,
    ):
        try:
            fp = core.lab_segment_fingerprint(
                segment, fs, freq_grid, algorithm_cfg
            )
            spectrum = np.asarray(fp["spectrum"], dtype=float)
            spectra.append(spectrum)
            rows.append(
                {
                    "segment_index": int(segment_index),
                    "segment_start_second": float(start_s),
                    "segment_end_second": float(end_s),
                    "sample_rate_hz": int(fs),
                    "status": "OK",
                    "error": "",
                }
            )
        except Exception as exc:
            rows.append(
                {
                    "segment_index": int(segment_index),
                    "segment_start_second": float(start_s),
                    "segment_end_second": float(end_s),
                    "sample_rate_hz": int(fs),
                    "status": "FAILED",
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )

    n_valid = sum(str(row["status"]) == "OK" for row in rows)
    if n_valid < max(1, int(cfg.min_segments_per_wav)):
        raise ValueError(
            f"有效完整1秒切片只有{n_valid}个，少于min_segments_per_wav={cfg.min_segments_per_wav}"
        )
    return rows, spectra


def summarize_one_wav(
    method: str,
    lab_group: str,
    wav: Path,
    segment_rows: pd.DataFrame,
    cfg: RunConfig,
) -> Dict[str, Any]:
    ok = segment_rows[segment_rows["status"].astype(str).eq("OK")].copy()
    row: Dict[str, Any] = {
        "method": method,
        "lab_group": lab_group,
        "wav_name": wav.name,
        "wav_stem": wav.stem,
        "wav_file": str(wav),
        "comparison_unit": "ONE_WAV_SUMMARY_FROM_ONE_SECOND_SEGMENTS",
        "status": "OK" if not ok.empty else "FAILED",
        "n_valid_seconds": int(len(ok)),
        "n_failed_seconds": int(
            sum(~segment_rows["status"].astype(str).eq("OK"))
        ),
    }
    for metric in metric_columns(cfg):
        values = pd.to_numeric(ok.get(metric, pd.Series(dtype=float)), errors="coerce")
        valid = values[np.isfinite(values)]
        row[f"{metric}_median"] = float(valid.median()) if len(valid) else np.nan
        row[f"{metric}_q25"] = float(valid.quantile(0.25)) if len(valid) else np.nan
        row[f"{metric}_q75"] = float(valid.quantile(0.75)) if len(valid) else np.nan
        row[f"{metric}_max"] = float(valid.max()) if len(valid) else np.nan
        if len(valid):
            best_idx = valid.idxmax()
            row[f"{metric}_best_second_index"] = int(
                ok.loc[best_idx, "segment_index"]
            )
            row[f"{metric}_best_second_start"] = float(
                ok.loc[best_idx, "segment_start_second"]
            )
        else:
            row[f"{metric}_best_second_index"] = np.nan
            row[f"{metric}_best_second_start"] = np.nan
    return row


def summarize_lab_groups(
    method: str,
    file_summary: pd.DataFrame,
    discovered_counts: Mapping[str, int],
    cfg: RunConfig,
) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    targets: List[Tuple[str, Optional[str]]] = [
        (str(group), str(group)) for group in cfg.lab_groups
    ]
    targets.append(("ALL_FILES", None))

    success = file_summary[file_summary["status"].astype(str).eq("OK")].copy()
    for output_group, group_filter in targets:
        if group_filter is None:
            part = success
            discovered = int(sum(discovered_counts.values()))
        else:
            part = success[success["lab_group"].astype(str).eq(group_filter)]
            discovered = int(discovered_counts.get(group_filter, 0))

        out: Dict[str, Any] = {
            "method": method,
            "summary_scope": "ALL_LAB_WAV_FILES"
            if group_filter is None
            else "ONE_LAB_GROUP",
            "lab_group": output_group,
            "n_wavs_discovered": discovered,
            "n_wavs_success": int(len(part)),
            "n_wavs_failed": int(max(discovered - len(part), 0)),
            "n_valid_seconds_total": int(
                pd.to_numeric(part["n_valid_seconds"], errors="coerce")
                .fillna(0)
                .sum()
            ) if "n_valid_seconds" in part.columns else 0,
        }

        for metric in metric_columns(cfg):
            source_col = f"{metric}_median"
            values = pd.to_numeric(part.get(source_col, pd.Series(dtype=float)), errors="coerce")
            valid = values[np.isfinite(values)]
            out[f"{metric}_wav_median_of_medians"] = (
                float(valid.median()) if len(valid) else np.nan
            )
            out[f"{metric}_wav_max_of_medians"] = (
                float(valid.max()) if len(valid) else np.nan
            )
            if len(valid):
                best_idx = valid.idxmax()
                out[f"{metric}_best_wav_name"] = str(part.loc[best_idx, "wav_name"])
                out[f"{metric}_best_wav_file"] = str(part.loc[best_idx, "wav_file"])
            else:
                out[f"{metric}_best_wav_name"] = ""
                out[f"{metric}_best_wav_file"] = ""
        rows.append(out)
    return pd.DataFrame(rows)


def analyze_lab_groups(
    method: str,
    abc_profile: np.ndarray,
    freq_grid: np.ndarray,
    cfg: RunConfig,
    algorithm_cfg: core.AnalysisConfig,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, Dict[str, np.ndarray]]:
    second_rows: List[Dict[str, Any]] = []
    file_rows: List[Dict[str, Any]] = []
    discovered_counts: Dict[str, int] = {}
    group_spectra: Dict[str, List[np.ndarray]] = {}

    for group, paths in cfg.lab_groups.items():
        group_name = str(group)
        wavs = core.discover_wavs(paths)
        discovered_counts[group_name] = len(wavs)
        group_spectra[group_name] = []

        for wav_index, wav in enumerate(wavs, start=1):
            try:
                segment_meta, spectra = lab_wav_segments(
                    wav, freq_grid, cfg, algorithm_cfg
                )
                spectrum_iter = iter(spectra)
                wav_rows: List[Dict[str, Any]] = []
                for meta in segment_meta:
                    base: Dict[str, Any] = {
                        "method": method,
                        "lab_group": group_name,
                        "wav_index_in_group": int(wav_index),
                        "wav_name": wav.name,
                        "wav_stem": wav.stem,
                        "wav_file": str(wav),
                        "comparison_unit": "ONE_LAB_WAV_SECOND",
                        **meta,
                    }
                    if meta["status"] == "OK":
                        spectrum = next(spectrum_iter)
                        group_spectra[group_name].append(spectrum)
                        base.update(
                            similarity_metrics(
                                abc_profile, spectrum, freq_grid, cfg
                            )
                        )
                    else:
                        for metric in metric_columns(cfg):
                            base[metric] = np.nan
                    wav_rows.append(base)
                    second_rows.append(base)

                wav_df = pd.DataFrame(wav_rows)
                file_rows.append(
                    summarize_one_wav(method, group_name, wav, wav_df, cfg)
                )
            except Exception as exc:
                error_row = {
                    "method": method,
                    "lab_group": group_name,
                    "wav_index_in_group": int(wav_index),
                    "wav_name": wav.name,
                    "wav_stem": wav.stem,
                    "wav_file": str(wav),
                    "comparison_unit": "ONE_LAB_WAV_SECOND",
                    "segment_index": np.nan,
                    "segment_start_second": np.nan,
                    "segment_end_second": np.nan,
                    "sample_rate_hz": np.nan,
                    "status": "FAILED",
                    "error": f"{type(exc).__name__}: {exc}",
                }
                for metric in metric_columns(cfg):
                    error_row[metric] = np.nan
                second_rows.append(error_row)
                file_rows.append(
                    {
                        "method": method,
                        "lab_group": group_name,
                        "wav_name": wav.name,
                        "wav_stem": wav.stem,
                        "wav_file": str(wav),
                        "comparison_unit": "ONE_WAV_SUMMARY_FROM_ONE_SECOND_SEGMENTS",
                        "status": "FAILED",
                        "n_valid_seconds": 0,
                        "n_failed_seconds": 0,
                        "error": f"{type(exc).__name__}: {exc}",
                    }
                )

    second_detail = pd.DataFrame(second_rows)
    file_summary = pd.DataFrame(file_rows)
    for metric in metric_columns(cfg):
        if metric not in second_detail.columns:
            second_detail[metric] = np.nan
    group_summary = summarize_lab_groups(
        method, file_summary, discovered_counts, cfg
    )

    prototypes: Dict[str, np.ndarray] = {}
    for group, spectra in group_spectra.items():
        if spectra:
            prototypes[group] = core.normalize_nonnegative(
                np.median(np.vstack(spectra), axis=0)
            )
    return second_detail, file_summary, group_summary, prototypes


# =============================================================================
# 输出与主流程
# =============================================================================


def save_method_figure(
    output_dir: Path,
    method: str,
    freq_grid: np.ndarray,
    abc: Dict[str, Any],
    group_prototypes: Mapping[str, np.ndarray],
) -> Optional[Path]:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig_dir = output_dir / "figures"
        ensure_dir(fig_dir)
        plt.figure(figsize=(12, 6))
        plt.plot(freq_grid / 1000.0, abc["a_profile"], label="A TRUE-FALSE")
        plt.plot(freq_grid / 1000.0, abc["b_profile"], label="B TRUE-FALSE")
        plt.plot(freq_grid / 1000.0, abc["c_profile"], label="C TRUE-FALSE")
        plt.plot(
            freq_grid / 1000.0,
            abc["common"],
            linewidth=2.5,
            label="ABC common",
        )
        for group, spectrum in group_prototypes.items():
            plt.plot(
                freq_grid / 1000.0,
                spectrum,
                linestyle="--",
                label=f"Lab {group} median of seconds",
            )
        plt.xlabel("Frequency (kHz)")
        plt.ylabel("Normalized spectrum")
        plt.title(f"{method}: ABC common vs laboratory one-second segments")
        plt.grid(True, alpha=0.25)
        plt.legend()
        plt.tight_layout()
        path = fig_dir / f"{method}_ABC_vs_lab_groups.png"
        plt.savefig(path, dpi=160)
        plt.close()
        return path
    except Exception as exc:
        print(f"  [图失败] {method}: {exc}")
        return None


def run_method(
    method: str,
    cfg: RunConfig,
    root_output: Path,
    freq_grid: np.ndarray,
) -> Dict[str, Path]:
    output_dir = root_output / method
    ensure_dir(output_dir)
    algorithm_cfg = core_config(cfg, output_dir)

    print("\n" + "=" * 100)
    print(f"方法: {method} | A、B、C共同频谱 + 实验室逐秒相似度")
    print("=" * 100)

    scene_inputs = [cfg.scene_A, cfg.scene_B, cfg.scene_C]
    loaded = [load_scene_method(scene, method, freq_grid, cfg) for scene in scene_inputs]
    (a_df, a_spec, a_temp, a_log), (b_df, b_spec, b_temp, b_log), (
        c_df,
        c_spec,
        c_temp,
        c_log,
    ) = loaded

    for tag, frame in zip(("A", "B", "C"), (a_df, b_df, c_df)):
        print(
            f"  {tag}成功样本={len(frame)}，"
            f"TRUE={sum(frame.label == 'TRUE_LEAK')}，"
            f"FALSE={sum(frame.label == 'FALSE_LEAK')}"
        )

    # 每个场景用独立随机流，避免计算顺序影响bootstrap结果。
    contrasts = []
    for offset, (frame, spectra) in enumerate(
        ((a_df, a_spec), (b_df, b_spec), (c_df, c_spec))
    ):
        rng = np.random.default_rng(cfg.random_state + offset)
        contrasts.append(
            core.scene_contrast(
                spectra,
                frame["label"].to_numpy(),
                algorithm_cfg,
                rng,
            )
        )
    a_contrast, b_contrast, c_contrast = contrasts
    abc = build_abc_common(a_contrast, b_contrast, c_contrast)

    metrics: Dict[str, Any] = {
        "method": method,
        "A_stable_TRUE_bins": int(np.sum(a_contrast["stable_positive"])),
        "B_stable_TRUE_bins": int(np.sum(b_contrast["stable_positive"])),
        "C_stable_TRUE_bins": int(np.sum(c_contrast["stable_positive"])),
        "ABC_strict_common_bins": int(np.sum(abc["strict_mask"])),
        "ABC_common_source": str(abc["common_source"]),
    }
    metrics.update(
        pair_similarity_rows(
            freq_grid, "A", abc["a_profile"], "B", abc["b_profile"], cfg
        )
    )
    metrics.update(
        pair_similarity_rows(
            freq_grid, "A", abc["a_profile"], "C", abc["c_profile"], cfg
        )
    )
    metrics.update(
        pair_similarity_rows(
            freq_grid, "B", abc["b_profile"], "C", abc["c_profile"], cfg
        )
    )

    factory_seconds = factory_each_second_similarity(
        method,
        abc["common"],
        freq_grid,
        cfg,
        [(a_df, a_spec), (b_df, b_spec), (c_df, c_spec)],
    )

    lab_seconds, lab_files, lab_summary, prototypes = analyze_lab_groups(
        method,
        abc["common"],
        freq_grid,
        cfg,
        algorithm_cfg,
    )

    metrics_path = output_dir / "ABC_similarity_metrics.csv"
    spectrum_path = output_dir / "ABC_common_spectrum.csv"
    factory_seconds_path = output_dir / "factory_each_second_similarity.csv"
    lab_seconds_path = output_dir / "lab_wav_similarity_each_second.csv"
    lab_files_path = output_dir / "lab_wav_similarity_each_file.csv"
    lab_summary_path = output_dir / "lab_wav_similarity_statistics.csv"
    mapping_path = output_dir / "factory_input_mapping_and_quality.csv"
    report_path = output_dir / "analysis_report.txt"

    pd.DataFrame([metrics]).to_csv(
        metrics_path, index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(
        {
            "frequency_hz": freq_grid,
            "frequency_khz": freq_grid / 1000.0,
            "A_positive_profile": abc["a_profile"],
            "B_positive_profile": abc["b_profile"],
            "C_positive_profile": abc["c_profile"],
            "ABC_strict_supported": abc["strict_mask"].astype(int),
            "ABC_soft_common": abc["soft_common"],
            "ABC_common": abc["common"],
            "ABC_common_source": str(abc["common_source"]),
        }
    ).to_csv(spectrum_path, index=False, encoding="utf-8-sig")
    factory_seconds.to_csv(
        factory_seconds_path, index=False, encoding="utf-8-sig"
    )
    lab_seconds.to_csv(lab_seconds_path, index=False, encoding="utf-8-sig")
    lab_files.to_csv(lab_files_path, index=False, encoding="utf-8-sig")
    lab_summary.to_csv(lab_summary_path, index=False, encoding="utf-8-sig")
    pd.concat([a_log, b_log, c_log], ignore_index=True).to_csv(
        mapping_path, index=False, encoding="utf-8-sig"
    )

    lines = [
        f"ABC与实验室逐秒相似度分析报告 | method={method}",
        "=" * 100,
        f"A目录: {cfg.scene_A.v9_dir}",
        f"B目录: {cfg.scene_B.v9_dir}",
        f"C目录: {cfg.scene_C.v9_dir}",
        f"ABC严格共同频点: {metrics['ABC_strict_common_bins']}",
        f"ABC共同频谱来源: {metrics['ABC_common_source']}",
        f"A/B Pearson: {metrics['A_B_pearson_fine']:.6f}",
        f"A/C Pearson: {metrics['A_C_pearson_fine']:.6f}",
        f"B/C Pearson: {metrics['B_C_pearson_fine']:.6f}",
        "",
        "工厂输入：每个NPZ必须对应严格1秒。",
        "实验室输入：每个WAV严格按[0,1)、[1,2)、...不重叠切片。",
        "实验室逐秒明细：一行=method × WAV × 1秒。",
        "实验室逐WAV汇总：由该WAV全部有效1秒的相似度统计得到。",
        "",
        "实验室组统计：",
    ]
    for _, row in lab_summary.iterrows():
        pearson_col = "pearson_correlation_to_ABC_common_wav_median_of_medians"
        lines.append(
            f"  {row['lab_group']}: 成功WAV={int(row['n_wavs_success'])}, "
            f"有效秒={int(row['n_valid_seconds_total'])}, "
            f"Pearson逐WAV中位数的中位数={row.get(pearson_col, np.nan):.6f}"
        )
    report_path.write_text("\n".join(lines), encoding="utf-8")

    if cfg.save_figures:
        save_method_figure(output_dir, method, freq_grid, abc, prototypes)

    print(
        f"  ABC严格共同频点={metrics['ABC_strict_common_bins']}，"
        f"来源={metrics['ABC_common_source']}"
    )
    return {
        "metrics": metrics_path,
        "spectrum": spectrum_path,
        "factory_seconds": factory_seconds_path,
        "lab_seconds": lab_seconds_path,
        "lab_files": lab_files_path,
        "lab_summary": lab_summary_path,
        "report": report_path,
    }


def make_wide(
    df: pd.DataFrame,
    index_columns: Sequence[str],
    value_columns: Sequence[str],
    path: Path,
) -> None:
    if df.empty:
        pd.DataFrame().to_csv(path, index=False, encoding="utf-8-sig")
        return
    if "status" in df.columns:
        ok = df[df["status"].astype(str).eq("OK")].copy()
    else:
        ok = df.copy()
    available_values = [name for name in value_columns if name in ok.columns]
    available_index = [name for name in index_columns if name in ok.columns]
    if ok.empty or not available_values or not available_index:
        pd.DataFrame().to_csv(path, index=False, encoding="utf-8-sig")
        return
    wide = ok.pivot_table(
        index=available_index,
        columns="method",
        values=available_values,
        aggfunc="first",
    )
    wide.columns = [
        f"{method}_{metric}" for metric, method in wide.columns.to_flat_index()
    ]
    wide.reset_index().to_csv(path, index=False, encoding="utf-8-sig")


def run_analysis(cfg: RunConfig) -> Dict[str, Path]:
    output_root = Path(cfg.output_dir)
    ensure_dir(output_root)
    freq_grid = np.linspace(
        cfg.freq_low_hz, cfg.freq_high_hz, cfg.n_spectral_bins
    )

    method_outputs: Dict[str, Dict[str, Path]] = {}
    for method in cfg.factory_methods:
        method_outputs[method] = run_method(method, cfg, output_root, freq_grid)

    metric_frames = [pd.read_csv(v["metrics"]) for v in method_outputs.values()]
    factory_frames = [
        pd.read_csv(v["factory_seconds"]) for v in method_outputs.values()
    ]
    lab_second_frames = [
        pd.read_csv(v["lab_seconds"]) for v in method_outputs.values()
    ]
    lab_file_frames = [pd.read_csv(v["lab_files"]) for v in method_outputs.values()]
    lab_summary_frames = [
        pd.read_csv(v["lab_summary"]) for v in method_outputs.values()
    ]

    combined_metrics = output_root / "raw_plane_ABC_similarity_comparison.csv"
    combined_factory = output_root / "all_methods_factory_each_second_similarity.csv"
    combined_lab_seconds = (
        output_root / "all_methods_lab_wav_similarity_each_second.csv"
    )
    combined_lab_files = output_root / "all_methods_lab_wav_similarity_each_file.csv"
    combined_lab_summary = (
        output_root / "all_methods_lab_wav_similarity_statistics.csv"
    )
    factory_wide = output_root / "factory_each_second_similarity_raw_plane_wide.csv"
    lab_seconds_wide = output_root / "lab_wav_each_second_similarity_raw_plane_wide.csv"
    lab_files_wide = output_root / "lab_wav_each_file_similarity_raw_plane_wide.csv"

    metrics_all = pd.concat(metric_frames, ignore_index=True)
    factory_all = pd.concat(factory_frames, ignore_index=True)
    lab_seconds_all = pd.concat(lab_second_frames, ignore_index=True)
    lab_files_all = pd.concat(lab_file_frames, ignore_index=True)
    lab_summary_all = pd.concat(lab_summary_frames, ignore_index=True)

    metrics_all.to_csv(combined_metrics, index=False, encoding="utf-8-sig")
    factory_all.to_csv(combined_factory, index=False, encoding="utf-8-sig")
    lab_seconds_all.to_csv(
        combined_lab_seconds, index=False, encoding="utf-8-sig"
    )
    lab_files_all.to_csv(combined_lab_files, index=False, encoding="utf-8-sig")
    lab_summary_all.to_csv(
        combined_lab_summary, index=False, encoding="utf-8-sig"
    )

    make_wide(
        factory_all,
        [
            "scene",
            "sample_id",
            "label",
            "second_index",
            "segment_start_second",
            "segment_end_second",
        ],
        metric_columns(cfg),
        factory_wide,
    )
    make_wide(
        lab_seconds_all,
        [
            "lab_group",
            "wav_name",
            "wav_file",
            "segment_index",
            "segment_start_second",
            "segment_end_second",
        ],
        metric_columns(cfg),
        lab_seconds_wide,
    )
    file_metric_columns: List[str] = []
    for metric in metric_columns(cfg):
        file_metric_columns.extend(
            [
                f"{metric}_median",
                f"{metric}_q25",
                f"{metric}_q75",
                f"{metric}_max",
            ]
        )
    make_wide(
        lab_files_all,
        ["lab_group", "wav_name", "wav_file", "n_valid_seconds"],
        file_metric_columns,
        lab_files_wide,
    )

    (output_root / "ABC_lab_raw_plane_run_config.json").write_text(
        json.dumps(asdict(cfg), ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print("\n" + "=" * 100)
    print("ABC raw/plane逐秒分析完成")
    print("ABC方法对比:", combined_metrics)
    print("工厂逐秒相似度:", combined_factory)
    print("实验室逐秒相似度:", combined_lab_seconds)
    print("实验室逐WAV汇总:", combined_lab_files)
    print("实验室组统计:", combined_lab_summary)
    print("=" * 100)
    return {
        "combined_metrics": combined_metrics,
        "combined_factory": combined_factory,
        "combined_lab_seconds": combined_lab_seconds,
        "combined_lab_files": combined_lab_files,
        "combined_lab_summary": combined_lab_summary,
        "factory_wide": factory_wide,
        "lab_seconds_wide": lab_seconds_wide,
        "lab_files_wide": lab_files_wide,
    }


# =============================================================================
# 自检
# =============================================================================


def synthetic_npz(
    path: Path,
    label: str,
    method: str,
    scene_shift: float,
    rng: np.random.Generator,
) -> None:
    freq = np.linspace(20_000.0, 80_000.0, 256)
    n_frames = 30
    base = 0.05 + 0.01 * rng.random((len(freq), n_frames))
    center_freq = 57_000.0 + scene_shift
    leak_shape = np.exp(-0.5 * ((freq - center_freq) / 3_000.0) ** 2)[:, None]
    boost = 0.32 if label == "TRUE_LEAK" else 0.02
    if method == "raw":
        matrix = base + boost * leak_shape
        bg_db = np.full_like(matrix, -300.0)
    else:
        matrix = 0.30 * base + boost * leak_shape
        bg_db = 10.0 * np.log10(base + EPS)
    ensure_dir(path.parent)
    payload = {
        "freq_hz": freq,
        "component_power": matrix,
        "background_power_db": bg_db,
        "method": np.asarray(method),
    }
    if method == "raw":
        payload["raw_power"] = matrix
    else:
        payload["excess_power_plane"] = matrix
    np.savez_compressed(path, **payload)


def synthetic_wav(path: Path, diameter: str, rng: np.random.Generator) -> None:
    fs = 192_000
    seconds = 3.0
    t = np.arange(int(fs * seconds)) / fs
    amp = 0.65 if diameter == "0.5mm" else 0.40
    envelope = np.ones_like(t)
    envelope[(t >= 1.0) & (t < 2.0)] = 0.70
    envelope[(t >= 2.0)] = 1.15
    x = (
        amp * envelope * np.sin(2 * np.pi * 57_000.0 * t)
        + 0.25 * np.sin(2 * np.pi * 61_000.0 * t)
        + 0.04 * rng.standard_normal(len(t))
    )
    x = np.clip(x / max(np.max(np.abs(x)), EPS), -1.0, 1.0)
    ensure_dir(path.parent)
    wavfile.write(str(path), fs, (x * 32767).astype(np.int16))


def run_self_test() -> None:
    rng = np.random.default_rng(123)
    with tempfile.TemporaryDirectory(prefix="abc_lab_each_second_") as tmp:
        root = Path(tmp)
        scene_defs = [
            ("factory_A", -200.0),
            ("factory_B", 0.0),
            ("factory_C", 200.0),
        ]
        for scene, scene_shift in scene_defs:
            scene_root = root / scene
            metadata: List[Dict[str, Any]] = []
            for label in ("TRUE_LEAK", "FALSE_LEAK"):
                for second_index in range(4):
                    sid = f"{scene}_{label}_{second_index}"
                    metadata.append(
                        {
                            "sample_id": sid,
                            "dataset": scene,
                            "scene": scene,
                            "time": f"synthetic__sec_{second_index:06d}",
                            "center": f"00_{second_index:02d}",
                            "label": label,
                            "second_index": second_index,
                            "segment_start_second": float(second_index),
                            "segment_end_second": float(second_index + 1),
                        }
                    )
                    for method in SUPPORTED_METHODS:
                        synthetic_npz(
                            scene_root
                            / "methods"
                            / method
                            / "residual_npz"
                            / f"{core.safe_slug(sid)}.npz",
                            label,
                            method,
                            scene_shift,
                            rng,
                        )
            ensure_dir(scene_root)
            pd.DataFrame(metadata).to_csv(
                scene_root / "v9_all_features.csv",
                index=False,
                encoding="utf-8-sig",
            )

        for group in ("0.1mm", "0.5mm"):
            for i in range(3):
                synthetic_wav(
                    root / "lab" / group / f"{group}_{i}.wav",
                    group,
                    rng,
                )

        cfg = RunConfig(
            scene_A=SceneInput("factory_A", str(root / "factory_A")),
            scene_B=SceneInput("factory_B", str(root / "factory_B")),
            scene_C=SceneInput("factory_C", str(root / "factory_C")),
            lab_groups={
                "0.1mm": [str(root / "lab" / "0.1mm")],
                "0.5mm": [str(root / "lab" / "0.5mm")],
            },
            output_dir=str(root / "out"),
            bootstrap_iterations=30,
            save_figures=False,
        )
        paths = run_analysis(cfg)

        metrics = pd.read_csv(paths["combined_metrics"])
        factory = pd.read_csv(paths["combined_factory"])
        lab_seconds = pd.read_csv(paths["combined_lab_seconds"])
        lab_files = pd.read_csv(paths["combined_lab_files"])
        lab_summary = pd.read_csv(paths["combined_lab_summary"])

        if set(metrics["method"]) != {"raw", "plane"}:
            raise AssertionError("自检失败：缺少raw或plane结果")
        if not {"A_B_pearson_fine", "A_C_pearson_fine", "B_C_pearson_fine"}.issubset(
            metrics.columns
        ):
            raise AssertionError("自检失败：缺少ABC两两相似度")

        expected_factory = 2 * 3 * 2 * 4
        if len(factory) != expected_factory:
            raise AssertionError(
                f"自检失败：工厂逐秒行数应为{expected_factory}，实际={len(factory)}"
            )

        ok_lab_seconds = lab_seconds[lab_seconds["status"].astype(str).eq("OK")]
        expected_lab_seconds = 2 * 2 * 3 * 3
        if len(ok_lab_seconds) != expected_lab_seconds:
            raise AssertionError(
                f"自检失败：实验室逐秒行数应为{expected_lab_seconds}，实际={len(ok_lab_seconds)}"
            )
        if ok_lab_seconds.duplicated(
            ["method", "wav_file", "segment_index"]
        ).any():
            raise AssertionError("自检失败：实验室同一秒重复")

        expected_lab_files = 2 * 2 * 3
        if len(lab_files) != expected_lab_files:
            raise AssertionError(
                f"自检失败：逐WAV汇总应有{expected_lab_files}行，实际={len(lab_files)}"
            )
        if len(lab_summary) != 6:
            raise AssertionError(
                f"自检失败：实验室组汇总应有6行，实际={len(lab_summary)}"
            )
        if set(lab_summary["lab_group"]) != {"0.1mm", "0.5mm", "ALL_FILES"}:
            raise AssertionError("自检失败：实验室组汇总范围错误")

        # 验证旧v9元数据会被拒绝。
        bad = pd.DataFrame(
            {
                "sample_id": ["bad"],
                "label": ["TRUE_LEAK"],
            }
        )
        try:
            validate_factory_one_second_metadata(
                bad, root / "bad.csv", cfg
            )
        except ValueError:
            pass
        else:
            raise AssertionError("自检失败：旧v9元数据未被拒绝")

        print("SELF-TEST PASSED")
        print("  ABC三场景读取：通过")
        print("  工厂严格逐秒检查：通过")
        print("  实验室不重叠逐秒切片：通过")
        print("  raw/plane并行输出：通过")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="raw/plane下构建ABC共同频谱，并逐秒比较实验室WAV"
    )
    parser.add_argument("--config", type=str, help="配置JSON")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        run_self_test()
        return
    if not args.config:
        parser.error("请提供--config，或使用--self-test")
    run_analysis(load_config(Path(args.config)))


if __name__ == "__main__":
    main()
