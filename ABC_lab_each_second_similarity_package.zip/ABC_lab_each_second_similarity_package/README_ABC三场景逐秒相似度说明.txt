ABC三个工厂场景与实验室WAV逐秒相似度程序
================================================

一、这版解决什么问题
--------------------

本版固定使用三个工厂场景：

    factory_A
    factory_B
    factory_C

对 raw 和 plane 分别执行：

    A场景 TRUE-FALSE 稳定正差异
    B场景 TRUE-FALSE 稳定正差异
    C场景 TRUE-FALSE 稳定正差异
                    ↓
              A ∩ B ∩ C
                    ↓
            ABC共同泄漏候选频谱
                    ↓
       与实验室WAV的每一个完整1秒比较

注意：这里不是“A+B训练、C测试”的分类程序。
这里的用途是寻找A、B、C三个场景都支持的共同频谱，再与实验室真实泄漏逐秒比较。


二、工厂数据必须来自逐秒修正版v9
--------------------------------

scene_A、scene_B、scene_C的v9_dir必须分别指向：

    ...\factory_A
    ...\factory_B
    ...\factory_C

每个目录至少需要：

    v9_all_features.csv
    methods\raw\residual_npz
    methods\plane\residual_npz

程序会强制检查v9_all_features.csv中存在：

    second_index
    segment_start_second
    segment_end_second

并要求：

    second_index = 0  -> [0,1)秒
    second_index = 1  -> [1,2)秒
    second_index = 2  -> [2,3)秒

如果输入还是旧v9的整段WAV结果，程序会停止，不会继续计算。


三、实验室WAV怎样切片
--------------------

实验室长WAV严格切成不重叠的完整1秒：

    [0,1)秒
    [1,2)秒
    [2,3)秒
    ...

不足1秒的尾部不会拿来代替完整1秒。

配置必须保持：

    "require_lab_one_second": true
    "lab_segment_seconds": 1.0
    "lab_segment_hop_seconds": 1.0

因此不会出现原版的0.5秒重叠切片，也不会先把整条长WAV平均后只输出一个结果。


四、修改配置
------------

打开：

    ABC_lab_raw_plane_config.json

修改三个工厂场景路径：

    "scene_A": {
      "name": "factory_A",
      "v9_dir": "D:\\wurenji\\v9_ABC_outer40_one_second_results\\factory_A"
    }

    "scene_B": {
      "name": "factory_B",
      "v9_dir": "D:\\wurenji\\v9_ABC_outer40_one_second_results\\factory_B"
    }

    "scene_C": {
      "name": "factory_C",
      "v9_dir": "D:\\wurenji\\v9_ABC_outer40_one_second_results\\factory_C"
    }

修改实验室WAV目录：

    "lab_groups": {
      "0.1mm": ["D:\\wurenji\\0.1mm"],
      "0.5mm": ["D:\\wurenji\\0.5mm"]
    }

修改输出目录：

    "output_dir": "D:\\wurenji\\ABC_lab_each_second_similarity_results"

Windows JSON路径中的反斜杠必须写成双反斜杠：\\


五、运行顺序
------------

1. 安装依赖：

    双击 install_requirements.bat

2. 运行自检：

    双击 run_self_test.bat

看到：

    SELF-TEST PASSED

再运行真实数据。

3. 正式运行：

    双击 run_ABC_lab_raw_plane.bat

也可以在命令行运行：

    python ABC_lab_raw_plane_each_second_similarity.py --self-test

    python ABC_lab_raw_plane_each_second_similarity.py --config ABC_lab_raw_plane_config.json


六、最重要的输出
----------------

输出根目录中：

1. raw_plane_ABC_similarity_comparison.csv

   raw与plane下：
   - A/B相似度
   - A/C相似度
   - B/C相似度
   - A、B、C各自稳定频点数
   - ABC严格共同频点数
   - ABC共同频谱来源

2. all_methods_factory_each_second_similarity.csv

   一行 = method × 一个工厂1秒样本

   用于检查ABC共同模板是否只适合少数工厂秒，还是对A、B、C多数秒都稳定。

3. all_methods_lab_wav_similarity_each_second.csv

   一行 = method × 一个实验室WAV × 一个完整1秒

   主要列：
   - method
   - lab_group
   - wav_name
   - segment_index
   - segment_start_second
   - segment_end_second
   - pearson_correlation_to_ABC_common
   - cosine_similarity_to_ABC_common
   - overlap_similarity_to_ABC_common
   - js_similarity_to_ABC_common
   - 5kHz与10kHz粗频带相似度

4. all_methods_lab_wav_similarity_each_file.csv

   一行 = method × 一个实验室WAV

   由该WAV所有完整1秒结果汇总，输出：
   - 中位数
   - 25%分位数
   - 75%分位数
   - 最大值
   - 相似度最高的秒

5. all_methods_lab_wav_similarity_statistics.csv

   分别汇总：
   - 每个实验室组
   - ALL_FILES

6. 三个raw/plane并排宽表：

   factory_each_second_similarity_raw_plane_wide.csv
   lab_wav_each_second_similarity_raw_plane_wide.csv
   lab_wav_each_file_similarity_raw_plane_wide.csv


七、raw和plane子目录
-------------------

raw目录和plane目录会分别输出：

    ABC_similarity_metrics.csv
    ABC_common_spectrum.csv
    factory_each_second_similarity.csv
    lab_wav_similarity_each_second.csv
    lab_wav_similarity_each_file.csv
    lab_wav_similarity_statistics.csv
    factory_input_mapping_and_quality.csv
    analysis_report.txt
    figures\...


八、ABC共同频谱的含义
--------------------

每个场景先计算：

    场景稳定正差异 = TRUE的稳健频谱 - FALSE的稳健频谱

ABC严格共同部分要求同一个频率维度同时满足：

    A稳定为正
    B稳定为正
    C稳定为正

三个场景的软共性使用几何平均：

    ABC_soft = (A_profile × B_profile × C_profile)^(1/3)

如果存在严格交集，最终使用严格交集；
如果严格交集为空，程序会明确记录：

    SOFT_ABC_GEOMETRIC_FALLBACK

不会把软共性伪装成严格交集。


九、正确运行顺序
----------------

    ABC逐秒修正版v9重新生成A/B/C结果
                    ↓
    本程序读取A/B/C的raw与plane逐秒NPZ
                    ↓
    构建ABC共同频谱
                    ↓
    实验室WAV严格逐秒比较

不能把旧v9整段平均结果和这套程序混用。
