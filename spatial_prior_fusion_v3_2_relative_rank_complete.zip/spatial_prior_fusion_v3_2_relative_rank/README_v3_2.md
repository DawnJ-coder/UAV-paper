# spatial_prior_fusion v3.2：T-only 字典 + 同时刻相对相似度排序

## 这版为什么改

v3.1 的最终判定仍然是“单样本分数 vs 一个由消声室 T 标定的绝对阈值”。同时，旧分数中有一项是：

```text
样本 -> 固定 T-NMF 字典重构 -> 原样本与重构结果做 frame cosine
```

当 NMF 字典原子较多、覆盖较宽时，很多非泄漏/假泄漏频谱也能被非负组合近似，因此 T 和 F 都可能得到很高、很接近的重构 cosine。这会导致“分数都挤在一起”。

v3.2 不学习 F，也不再依赖绝对 T/F 阈值。

## v3.2 的判定原则

工厂单个样本只输出一个量：

```text
similarity_decision_score = 该样本与冻结 T 字典的直接相似度
```

它不是概率。

所有同一 `pair_key` 的候选计算完成后再排序：

```text
相似度最高 -> T
其余更低 -> F
```

若组内只有一个有效样本，则输出 `UNPAIRED`；若最高分在设定容差内完全并列，则输出 `AMBIGUOUS_TIE`，不靠文件名或中心编号偷偷打破并列。

`pair_key` 仍由：

```text
canonical_condition + center_id
```

组成。`pairing_remove_tokens` 只用于把同一时刻/工况的不同命名归一到一起，不用于告诉程序哪个是 T、哪个是 F。

## 新的 T-only 相似度

v3.2 不再把“自重构 cosine”作为主判据，而改成三项直接匹配：

1. `dictionary_atom_similarity`
   - 工厂样本代表频谱直接和冻结 T 字典原子比较。
   - 不先用字典把当前样本重构成一个“像自己”的结果。

2. `reference_spectrum_similarity`
   - 工厂样本代表频谱直接与留出的真实 T 参照频谱比较。
   - 不经过当前样本的字典自重构，因此不会因为“字典太能拟合”而虚高。

3. `t_envelope_similarity`
   - 只由 T 训练集学习稳定的平滑 log 频谱包络和显著性权重。
   - 它保留稳定的带宽/谱形，同时抑制宽带随机泄漏中不稳定的细小谱纹理。

最终做加权几何平均：

```text
score = atom^0.25 * reference_spectrum^0.40 * t_envelope^0.35
```

因此任意一个关键 T 结构明显不匹配时，总分会真正下降。

## 字典为什么收紧

默认参数也同步收紧：

- 原子数候选：`[4, 6, 8]`，不再默认到 12。
- 默认 `dictionary_augment_copies = 0`，不再主动把 T 频响/频移扩得过宽。
- 提高低能量帧过滤分位数到 `0.35`。
- 使用更强一点的激活 L1 候选：`1e-5 / 1e-4`。

目的不是“让所有 T 都能被任何方式重构”，而是让冻结字典更接近“真实泄漏 T 的稳定公共结构”。

## 预训练数据约束

所有 `lab_groups` 必须是真实消声室泄漏 T。

每个孔径至少 3 个完整 WAV，分别用于：

- `T_DICTIONARY_TRAIN`
- `T_SIMILARITY_REFERENCE`
- `T_HELDOUT_VALIDATION`

留出验证只检查 T 的覆盖和一致性，不生成 T/F 阈值，也不会读取任何 F。

## 运行方法

先修改：

```text
spatial_prior_fusion_v3_2_config.json
```

填写真实路径。

第一次运行或消声室 T 数据改变后：

```powershell
python spatial_prior_fusion_v3_2.py --pretrain-dictionary --config spatial_prior_fusion_v3_2_config.json
```

然后运行工厂数据：

```powershell
python spatial_prior_fusion_v3_2.py --config spatial_prior_fusion_v3_2_config.json
```

自检：

```powershell
python spatial_prior_fusion_v3_2.py --self-test
```

## 最重要的输出

### `13_relative_similarity_ranking.csv`

这是最终主判定表。重点看：

- `pair_key`
- `similarity_decision_score`
- `similarity_decision`
- `relative_similarity_rank`
- `relative_top_minus_second`
- `relative_score_gap_to_best`
- `similarity_dictionary_atom_score`
- `similarity_reference_spectrum_score`
- `similarity_t_envelope_score`

### `10_factory_sample_summary.csv`

v3.2 会在所有样本跑完后覆盖写回，因此这个总表也包含最终的相对 T/F 判定。

## 如何判断是否真的改善

不要只看单个绝对分数多高，而要看同一 `pair_key` 内：

```text
T 候选 similarity_decision_score - F 候选 similarity_decision_score
```

是否稳定为正，以及 `relative_top_minus_second` 是否形成明显间隔。

由于没有 F 参与训练，程序无法从离线 T-only 数据保证所有未来 F 都一定低分；v3.2 的目标是通过更紧致的 T 表征和同场相对排序，让“未知 F 千变万化”这件事不再要求建立 F 模型。
