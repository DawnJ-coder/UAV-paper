@echo off
cd /d %~dp0
python spatial_prior_fusion_v3_2.py --self-test
pause
