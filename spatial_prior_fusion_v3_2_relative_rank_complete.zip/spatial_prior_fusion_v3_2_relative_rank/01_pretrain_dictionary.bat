@echo off
cd /d %~dp0
python spatial_prior_fusion_v3_2.py --pretrain-dictionary --config spatial_prior_fusion_v3_2_config.json
pause
