# -*- coding: utf-8 -*-
"""v3.2：只使用真实泄漏 T 的离线字典预训练与冻结字典加载。

核心约束：
- 不读取、学习或构造工厂 F 标签。
- 不训练 T/F 分类器，不输出 T 概率。
- 字典仅学习 T 的稳定谱结构；工厂阶段只计算与冻结 T 字典的相似度。
- 最终 T/F 判定由同一 pair_key 内的相似度相对排序完成。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import warnings
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from sklearn.decomposition import NMF, non_negative_factorization
from sklearn.exceptions import ConvergenceWarning
from scipy.ndimage import gaussian_filter1d

import _spatial_v3_engine as core


EPS = core.EPS


DICTIONARY_DEFAULTS: Dict[str, Any] = {
    "pretrained_dictionary_path": "pretrained_t_dictionary_v3_2.npz",
    # 空列表表示自动使用 lab_groups 中全部孔径；这些录音必须全部是真实泄漏 T。
    "dictionary_positive_groups": [],
    "dictionary_reference_fraction": 0.20,
    "dictionary_validation_fraction": 0.20,
    "dictionary_similarity_top_fraction": 0.25,
    "dictionary_candidate_components": [4, 6, 8],
    "dictionary_candidate_beta_losses": ["kullback-leibler"],
    "dictionary_candidate_activation_l1": [1.0e-5, 1.0e-4],
    "dictionary_candidate_seeds": [23, 42],
    "dictionary_energy_quantile": 0.35,
    "dictionary_window_seconds": 5.0,
    "dictionary_max_windows_per_file": 12,
    "dictionary_max_frames_per_file": 1600,
    "dictionary_max_total_frames": 24000,
    # v3.2 默认不做频响/频移扩张，避免把 T 字典人为训练得过宽，导致 F 也容易高相似。
    "dictionary_augment_copies": 0,
    "dictionary_augment_max_db": 1.5,
    "dictionary_augment_max_shift_bins": 1,
    # 只由 T 学习的相似度模型：强调稳定窄带/谱纹理，而不是“样本被自己重构得多好”。
    "dictionary_signature_smooth_sigma_bins": 3.0,
    "dictionary_saliency_floor": 0.10,
    "dictionary_saliency_cap_quantile": 0.95,
    "dictionary_score_atom_weight": 0.25,
    "dictionary_score_reference_weight": 0.40,
    "dictionary_score_signature_weight": 0.35,
}


def _resolve_bundle_path(value: str, config_path: Optional[Path]) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute() and config_path is not None:
        path = config_path.resolve().parent / path
    return path.resolve()


def attach_dictionary_config(
    cfg: core.RunConfig,
    raw_algorithm: Optional[Mapping[str, Any]] = None,
    config_path: Optional[Path] = None,
) -> None:
    """向兼容引擎的 AlgorithmConfig 附加 T-only 预训练参数。"""
    raw = dict(raw_algorithm or {})
    a = cfg.algorithm

    path_value = str(raw.get(
        "pretrained_dictionary_path",
        DICTIONARY_DEFAULTS["pretrained_dictionary_path"],
    ))
    setattr(a, "pretrained_dictionary_path", str(_resolve_bundle_path(path_value, config_path)))

    list_types = {
        "dictionary_positive_groups": str,
        "dictionary_candidate_components": int,
        "dictionary_candidate_beta_losses": str,
        "dictionary_candidate_activation_l1": float,
        "dictionary_candidate_seeds": int,
    }
    for key, default in DICTIONARY_DEFAULTS.items():
        if key == "pretrained_dictionary_path":
            continue
        value = raw.get(key, default)
        if key in list_types:
            value = [list_types[key](item) for item in value]
        setattr(a, key, value)

    _validate_dictionary_config(cfg)


def _validate_dictionary_config(cfg: core.RunConfig) -> None:
    a = cfg.algorithm
    if not 0.0 < float(a.dictionary_reference_fraction) < 1.0:
        raise ValueError("dictionary_reference_fraction 必须位于(0,1)")
    if not 0.0 < float(a.dictionary_validation_fraction) < 1.0:
        raise ValueError("dictionary_validation_fraction 必须位于(0,1)")
    if float(a.dictionary_reference_fraction) + float(a.dictionary_validation_fraction) >= 1.0:
        raise ValueError("dictionary_reference_fraction + dictionary_validation_fraction 必须<1")
    if not 0.0 < float(a.dictionary_similarity_top_fraction) <= 1.0:
        raise ValueError("dictionary_similarity_top_fraction 必须位于(0,1]")
    if float(a.dictionary_signature_smooth_sigma_bins) <= 0:
        raise ValueError("dictionary_signature_smooth_sigma_bins 必须>0")
    if not 0.0 <= float(a.dictionary_saliency_floor) <= 1.0:
        raise ValueError("dictionary_saliency_floor 必须位于[0,1]")
    if not 0.5 <= float(a.dictionary_saliency_cap_quantile) <= 1.0:
        raise ValueError("dictionary_saliency_cap_quantile 必须位于[0.5,1]")
    score_weights = np.asarray([
        a.dictionary_score_atom_weight,
        a.dictionary_score_reference_weight,
        a.dictionary_score_signature_weight,
    ], dtype=float)
    if np.any(score_weights < 0) or float(np.sum(score_weights)) <= 0:
        raise ValueError("dictionary_score_*_weight 必须非负且总和>0")
    missing = [group for group in a.dictionary_positive_groups if group not in cfg.lab_groups]
    if missing:
        raise ValueError(f"dictionary_positive_groups 不存在于lab_groups: {missing}")
    if not a.dictionary_candidate_components or min(a.dictionary_candidate_components) < 2:
        raise ValueError("dictionary_candidate_components 至少包含一个>=2的整数")
    allowed_beta = {"frobenius", "kullback-leibler", "itakura-saito"}
    unknown = set(a.dictionary_candidate_beta_losses) - allowed_beta
    if unknown:
        raise ValueError(f"不支持的 dictionary_candidate_beta_losses: {sorted(unknown)}")
    if not a.dictionary_candidate_activation_l1 or min(a.dictionary_candidate_activation_l1) < 0:
        raise ValueError("dictionary_candidate_activation_l1 必须为非负列表")
    if not a.dictionary_candidate_seeds:
        raise ValueError("dictionary_candidate_seeds 不能为空")
    if not 0.0 <= float(a.dictionary_energy_quantile) < 1.0:
        raise ValueError("dictionary_energy_quantile 必须位于[0,1)")
    for key in (
        "dictionary_window_seconds",
        "dictionary_max_windows_per_file",
        "dictionary_max_frames_per_file",
        "dictionary_max_total_frames",
    ):
        if float(getattr(a, key)) <= 0:
            raise ValueError(f"{key} 必须>0")
    if int(a.dictionary_augment_copies) < 0:
        raise ValueError("dictionary_augment_copies 必须>=0")


def _stable_file_score(path: Path, seed: int) -> int:
    token = f"{seed}|{path.parent.name.casefold()}/{path.name.casefold()}".encode("utf-8")
    return int(hashlib.sha256(token).hexdigest()[:16], 16)


def _file_fingerprint(path: Path) -> str:
    stat = path.stat()
    token = f"{path.resolve()}|{stat.st_size}|{stat.st_mtime_ns}".encode("utf-8")
    return hashlib.sha256(token).hexdigest()


def split_positive_files_by_group(
    files_by_group: Mapping[str, Sequence[Path]],
    reference_fraction: float,
    validation_fraction: float,
    seed: int,
) -> Tuple[List[Path], List[Path], List[Path]]:
    """每个孔径分别拆分，保证训练、参照和留出验证都覆盖各种孔径。"""
    train: List[Path] = []
    reference: List[Path] = []
    validation: List[Path] = []
    for group, files in sorted(files_by_group.items()):
        ordered = sorted(set(files), key=lambda path: _stable_file_score(path, seed))
        if len(ordered) < 3:
            raise RuntimeError(
                f"孔径组 {group!r} 只有{len(ordered)}个WAV；"
                "至少需要3个完整WAV，分别用于训练、相似度参照和T留出验证"
            )
        n_reference = max(1, int(round(len(ordered) * reference_fraction)))
        n_validation = max(1, int(round(len(ordered) * validation_fraction)))
        while n_reference + n_validation >= len(ordered):
            if n_reference >= n_validation and n_reference > 1:
                n_reference -= 1
            elif n_validation > 1:
                n_validation -= 1
            else:
                break
        if n_reference + n_validation >= len(ordered):
            raise RuntimeError(f"孔径组 {group!r} 无法保留至少1个训练WAV")
        reference.extend(ordered[:n_reference])
        validation.extend(ordered[n_reference : n_reference + n_validation])
        train.extend(ordered[n_reference + n_validation :])
    return train, reference, validation


def _uniform_windows(x: np.ndarray, fs: int, seconds: float, count: int) -> List[np.ndarray]:
    window_samples = min(len(x), max(256, int(round(seconds * fs))))
    if len(x) <= window_samples or count <= 1:
        starts = np.asarray([0], dtype=int)
    else:
        starts = np.linspace(0, len(x) - window_samples, count, dtype=int)
        starts = np.unique(starts)
    return [x[start : start + window_samples] for start in starts]


def extract_file_power(
    path: Path,
    cfg: core.AlgorithmConfig,
    seed: int,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
    """从整段T录音均匀取窗，先过滤低能量帧，再按文件平衡抽样。"""
    fs, x, dtype_name, duration = core.read_lab_wav(path, 0.0)
    if fs != int(cfg.expected_sample_rate_hz):
        raise ValueError(
            f"实验室WAV采样率不匹配: {path}, 实际{fs}, 期望{cfg.expected_sample_rate_hz}"
        )
    windows = _uniform_windows(
        x,
        fs,
        float(cfg.dictionary_window_seconds),
        int(cfg.dictionary_max_windows_per_file),
    )
    blocks: List[np.ndarray] = []
    freq_ref: Optional[np.ndarray] = None
    for window in windows:
        centered = np.asarray(window, dtype=np.float64) - float(np.mean(window))
        freq, _, z = core.stft_full(centered, fs, cfg)
        freq_band, power, _ = core.power_band_from_stft(freq, z, cfg)
        if freq_ref is None:
            freq_ref = freq_band
        elif len(freq_ref) != len(freq_band) or np.max(np.abs(freq_ref - freq_band)) > 1e-6:
            raise ValueError(f"同一文件不同窗口频率轴不一致: {path}")
        blocks.append(np.maximum(power, 0.0))

    if not blocks or freq_ref is None:
        raise RuntimeError(f"没有从T录音提取到功率帧: {path}")
    matrix = np.concatenate(blocks, axis=1)
    energy = np.sum(matrix, axis=0)
    positive = energy[np.isfinite(energy) & (energy > 0)]
    if positive.size == 0:
        raise RuntimeError(f"T录音主频带没有正能量: {path}")
    threshold = float(np.quantile(positive, float(cfg.dictionary_energy_quantile)))
    keep = np.isfinite(energy) & (energy >= threshold) & (energy > 0)
    matrix = matrix[:, keep]
    if matrix.shape[1] == 0:
        raise RuntimeError(f"T录音能量过滤后没有可用帧: {path}")

    rng = np.random.default_rng(seed)
    matrix = core.subsample_columns(
        matrix,
        int(cfg.dictionary_max_frames_per_file),
        rng,
    )
    row = {
        "file": str(path),
        "sample_rate_hz": fs,
        "duration_seconds": duration,
        "window_count": len(windows),
        "retained_frames": int(matrix.shape[1]),
        "energy_threshold": threshold,
        "dtype": dtype_name,
        "fingerprint_sha256": _file_fingerprint(path),
    }
    return np.asarray(freq_ref, dtype=np.float64), matrix, row


def _augment_positive_power(
    power: np.ndarray,
    rng: np.random.Generator,
    max_db: float,
    max_shift_bins: int,
) -> np.ndarray:
    """只改变T频响/轻微频移；不使用真实F，也不生成F标签。"""
    n_freq = power.shape[0]
    n_anchor = min(8, max(3, n_freq // 32))
    anchor_x = np.linspace(0, n_freq - 1, n_anchor)
    anchor_db = rng.uniform(-max_db, max_db, size=n_anchor)
    response_db = np.interp(np.arange(n_freq), anchor_x, anchor_db)
    augmented = power * np.power(10.0, response_db[:, None] / 10.0)

    shift = int(rng.integers(-max_shift_bins, max_shift_bins + 1)) if max_shift_bins > 0 else 0
    if shift > 0:
        shifted = np.full_like(augmented, EPS)
        shifted[shift:, :] = augmented[:-shift, :]
        augmented = shifted
    elif shift < 0:
        shifted = np.full_like(augmented, EPS)
        shifted[:shift, :] = augmented[-shift:, :]
        augmented = shifted
    return np.maximum(augmented, EPS)


def build_training_matrix(
    powers: Sequence[np.ndarray],
    cfg: core.AlgorithmConfig,
    seed: int,
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    blocks: List[np.ndarray] = []
    for power in powers:
        blocks.append(power)
        for _ in range(int(cfg.dictionary_augment_copies)):
            blocks.append(_augment_positive_power(
                power,
                rng,
                float(cfg.dictionary_augment_max_db),
                int(cfg.dictionary_augment_max_shift_bins),
            ))
    matrix = np.concatenate(blocks, axis=1)
    return core.subsample_columns(
        matrix,
        int(cfg.dictionary_max_total_frames),
        rng,
    )


def _fit_candidate(
    power: np.ndarray,
    n_components: int,
    beta_loss: str,
    activation_l1: float,
    seed: int,
    max_iter: int,
) -> Tuple[np.ndarray, Dict[str, Any]]:
    normalized, _ = core.normalize_columns(power)
    normalized = np.maximum(normalized.T, 1.0e-10)
    n_components = min(
        int(n_components),
        max(2, min(normalized.shape[0], normalized.shape[1]) - 1),
    )
    model = NMF(
        n_components=n_components,
        init="nndsvda",
        solver="mu",
        beta_loss=beta_loss,
        max_iter=int(max_iter),
        tol=1.0e-5,
        random_state=int(seed),
        alpha_W=float(activation_l1),
        # 同时约束两个因子，避免仅正则激活时出现D放大、H缩小的尺度退化。
        alpha_H=float(activation_l1),
        l1_ratio=1.0,
    )
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always", ConvergenceWarning)
        model.fit(normalized)
    dictionary = np.maximum(model.components_.T, EPS)
    dictionary /= np.maximum(np.sum(dictionary, axis=0, keepdims=True), EPS)
    info = {
        "n_components_actual": int(dictionary.shape[1]),
        "n_iter": int(model.n_iter_),
        "converged": not any(issubclass(item.category, ConvergenceWarning) for item in caught),
        "training_reconstruction_error": float(model.reconstruction_err_),
    }
    return dictionary, info


def infer_fixed_dictionary(
    power: np.ndarray,
    dictionary: np.ndarray,
    beta_loss: str,
    activation_l1: float,
    iterations: int,
    seed: int,
) -> Tuple[np.ndarray, np.ndarray, int]:
    """固定D估计H；与预训练使用同一beta损失和同一激活L1。"""
    normalized, scale = core.normalize_columns(np.maximum(power, 0.0))
    x = np.maximum(normalized.T, 1.0e-10)
    k = int(dictionary.shape[1])
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", ConvergenceWarning)
        codes, _, n_iter = non_negative_factorization(
            x,
            H=np.maximum(dictionary.T.copy(), 1.0e-10),
            n_components=k,
            init="custom",
            update_H=False,
            solver="mu",
            beta_loss=beta_loss,
            tol=1.0e-5,
            max_iter=int(iterations),
            alpha_W=float(activation_l1),
            alpha_H=0.0,
            l1_ratio=1.0,
            random_state=int(seed),
        )
    activation_normalized = np.maximum(codes.T, 0.0)
    activation = activation_normalized * scale
    reconstruction = np.maximum(dictionary @ activation, 0.0)
    return activation, reconstruction, int(n_iter)


def _atom_coherence(dictionary: np.ndarray) -> float:
    normalized = core.l2_normalize_columns(dictionary)
    gram = normalized.T @ normalized
    np.fill_diagonal(gram, 0.0)
    return float(np.max(gram)) if gram.size else 0.0


def _smoothed_log_envelope(spectrum: np.ndarray, sigma_bins: float) -> np.ndarray:
    """归一化后取平滑 log 频谱包络，保留稳定带宽/谱形，抑制随机细纹。"""
    p = core.normalize_vector(np.maximum(np.asarray(spectrum, dtype=np.float64), 0.0))
    logp = np.log(np.maximum(p, 1.0e-12))
    envelope = gaussian_filter1d(logp, sigma=max(float(sigma_bins), 0.5), mode="nearest")
    envelope -= float(np.median(envelope))
    return envelope


def _weighted_cosine(a: np.ndarray, b: np.ndarray, weights: np.ndarray, signed: bool) -> float:
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    w = np.maximum(np.asarray(weights, dtype=np.float64), 0.0)
    if a.shape != b.shape or a.shape != w.shape:
        raise ValueError("weighted cosine 维度不一致")
    sw = np.sqrt(w + EPS)
    aw = a * sw
    bw = b * sw
    denom = float(np.linalg.norm(aw) * np.linalg.norm(bw))
    if denom <= EPS:
        return 0.0
    value = float(np.dot(aw, bw) / denom)
    if signed:
        return float(np.clip(value, -1.0, 1.0))
    return float(np.clip(value, 0.0, 1.0))


def build_t_similarity_profile(
    training_powers: Sequence[np.ndarray],
    sigma_bins: float,
    saliency_floor: float,
    saliency_cap_quantile: float,
) -> Dict[str, np.ndarray | float]:
    """只由 T 训练文件学习稳定的平滑谱包络和频率显著性。"""
    if not training_powers:
        raise RuntimeError("没有 T 训练功率用于构建相似度画像")
    spectra = np.vstack([
        core.normalize_vector(core.representative_spectrum(power))
        for power in training_powers
    ])
    envelopes = np.vstack([
        _smoothed_log_envelope(spec, sigma_bins)
        for spec in spectra
    ])
    signature = np.median(envelopes, axis=0)
    mad = 1.4826 * np.median(np.abs(envelopes - signature[None, :]), axis=0)
    scale_floor = max(float(np.median(mad)), 0.05)
    # 只强调“在 T 中稳定且确实有谱形偏离”的频点，避免把随机细纹当成特征。
    stability = np.abs(signature) / (mad + 0.25 * scale_floor + 1.0e-6)
    positive = stability[np.isfinite(stability) & (stability > 0)]
    if positive.size:
        cap = float(np.quantile(positive, float(saliency_cap_quantile)))
        cap = max(cap, float(np.median(positive)), 1.0e-6)
        normalized = np.clip(stability / cap, 0.0, 1.0)
    else:
        normalized = np.ones_like(signature)
    floor = float(np.clip(saliency_floor, 0.0, 1.0))
    weights = floor + (1.0 - floor) * normalized
    weights /= max(float(np.mean(weights)), EPS)
    return {
        "signature": np.asarray(signature, dtype=np.float64),
        "saliency_weights": np.asarray(weights, dtype=np.float64),
        "training_spectra": spectra,
        "sigma_bins": float(sigma_bins),
    }


def _reference_spectrum_similarity(
    spectrum: np.ndarray,
    reference_specs: Sequence[Tuple[str, Path, np.ndarray]],
    top_fraction: float,
) -> float:
    """直接和真实 T 留出频谱比较；不经过当前样本的字典自重构。"""
    if not reference_specs:
        return 0.0
    scores = np.asarray([
        core.spectrum_metrics(spectrum, ref)["combined"]
        for _, _, ref in reference_specs
    ], dtype=np.float64)
    n_top = min(len(scores), max(1, int(np.ceil(len(scores) * float(top_fraction)))))
    return float(np.mean(np.sort(scores)[-n_top:]))


def _dictionary_atom_similarity(
    spectrum: np.ndarray,
    dictionary: np.ndarray,
    weights: np.ndarray,
    top_fraction: float,
) -> float:
    candidate = core.normalize_vector(np.maximum(np.asarray(spectrum, dtype=np.float64), 0.0))
    scores = np.asarray([
        _weighted_cosine(candidate, core.normalize_vector(dictionary[:, index]), weights, signed=False)
        for index in range(dictionary.shape[1])
    ], dtype=np.float64)
    n_top = min(len(scores), max(1, int(np.ceil(len(scores) * float(top_fraction)))))
    return float(np.mean(np.sort(scores)[-n_top:]))


def decision_similarity_for_power(
    power: np.ndarray,
    dictionary: np.ndarray,
    reference_specs: Sequence[Tuple[str, Path, np.ndarray]],
    profile: Mapping[str, Any],
    top_fraction: float,
    atom_weight: float,
    reference_weight: float,
    signature_weight: float,
) -> Dict[str, float]:
    """v3.2 固定 T 字典相似度：直接匹配 T 模型，不使用样本自重构 cosine。"""
    spectrum = core.representative_spectrum(power)
    weights = np.asarray(profile["saliency_weights"], dtype=np.float64)
    signature = np.asarray(profile["signature"], dtype=np.float64)
    sigma_bins = float(profile["sigma_bins"])

    atom_similarity = _dictionary_atom_similarity(
        spectrum, dictionary, weights, top_fraction
    )
    reference_similarity = _reference_spectrum_similarity(
        spectrum, reference_specs, top_fraction
    )
    candidate_envelope = _smoothed_log_envelope(spectrum, sigma_bins)
    signature_similarity = max(
        0.0,
        _weighted_cosine(candidate_envelope, signature, weights, signed=True),
    )

    raw_weights = np.asarray([atom_weight, reference_weight, signature_weight], dtype=np.float64)
    raw_weights = np.maximum(raw_weights, 0.0)
    raw_weights /= max(float(np.sum(raw_weights)), EPS)
    components = np.asarray([
        max(atom_similarity, 1.0e-6),
        max(reference_similarity, 1.0e-6),
        max(signature_similarity, 1.0e-6),
    ], dtype=np.float64)
    combined = float(np.exp(np.sum(raw_weights * np.log(components))))
    return {
        "combined": float(np.clip(combined, 0.0, 1.0)),
        "dictionary_atom_similarity": atom_similarity,
        "reference_spectrum_similarity": reference_similarity,
        "t_envelope_similarity": signature_similarity,
    }


def _evaluate_candidate(
    dictionary: np.ndarray,
    validation_powers: Sequence[Tuple[Path, np.ndarray]],
    reference_specs: Sequence[Tuple[str, Path, np.ndarray]],
    profile: Mapping[str, Any],
    similarity_top_fraction: float,
    atom_weight: float,
    reference_weight: float,
    signature_weight: float,
) -> Dict[str, float]:
    similarities: List[float] = []
    atom_scores: List[float] = []
    reference_scores: List[float] = []
    signature_scores: List[float] = []
    for _, power in validation_powers:
        parts = decision_similarity_for_power(
            power,
            dictionary,
            reference_specs,
            profile,
            similarity_top_fraction,
            atom_weight,
            reference_weight,
            signature_weight,
        )
        similarities.append(float(parts["combined"]))
        atom_scores.append(float(parts["dictionary_atom_similarity"]))
        reference_scores.append(float(parts["reference_spectrum_similarity"]))
        signature_scores.append(float(parts["t_envelope_similarity"]))

    return {
        "t_score_p10": float(np.quantile(similarities, 0.10)),
        "t_score_median": float(np.median(similarities)),
        "t_atom_similarity_median": float(np.median(atom_scores)),
        "t_reference_similarity_median": float(np.median(reference_scores)),
        "t_envelope_similarity_median": float(np.median(signature_scores)),
        "atom_coherence_max": _atom_coherence(dictionary),
    }


def _selection_key(row: Mapping[str, Any]) -> Tuple[float, float, float, float]:
    # 只优化 T 的留出一致性，同时惩罚高度重复的原子；完全不需要 F。
    return (
        float(row["t_score_p10"]),
        float(row["t_score_median"]),
        -float(row["atom_coherence_max"]),
        float(bool(row["converged"])),
    )


def run_pretraining(cfg: core.RunConfig, output_path: Optional[Path] = None) -> Path:
    """只用多孔径消声室 T 训练紧致字典和 T 稳定谱画像。"""
    a = cfg.algorithm
    bundle_path = Path(output_path or a.pretrained_dictionary_path).expanduser().resolve()
    core.ensure_dir(bundle_path.parent)

    positive_groups = list(a.dictionary_positive_groups) or sorted(cfg.lab_groups)
    files_by_group = {
        group: core.discover_wavs(cfg.lab_groups.get(group, []))
        for group in positive_groups
    }
    empty_groups = [group for group, files in files_by_group.items() if not files]
    if empty_groups:
        raise RuntimeError(f"以下消声室T孔径组没有发现WAV: {empty_groups}")
    all_group_files = [path for files in files_by_group.values() for path in files]
    if len(set(all_group_files)) != len(all_group_files):
        raise RuntimeError("同一个消声室WAV不能同时配置到多个孔径组")

    train_files, reference_files, validation_files = split_positive_files_by_group(
        files_by_group,
        float(a.dictionary_reference_fraction),
        float(a.dictionary_validation_fraction),
        int(a.random_state),
    )
    group_by_file: Dict[Path, str] = {}
    for group in positive_groups:
        for path in core.discover_wavs(cfg.lab_groups.get(group, [])):
            group_by_file.setdefault(path, group)

    scan_rows: List[Dict[str, Any]] = []
    power_by_file: Dict[Path, np.ndarray] = {}
    freq_ref: Optional[np.ndarray] = None
    roles = (
        [(path, "T_DICTIONARY_TRAIN") for path in train_files]
        + [(path, "T_SIMILARITY_REFERENCE") for path in reference_files]
        + [(path, "T_HELDOUT_VALIDATION") for path in validation_files]
    )
    for index, (path, role) in enumerate(roles):
        freq, power, row = extract_file_power(path, a, int(a.random_state) + index)
        if freq_ref is None:
            freq_ref = freq
        elif len(freq_ref) != len(freq) or np.max(np.abs(freq_ref - freq)) > 1e-6:
            raise RuntimeError(f"T预训练文件频率轴不一致: {path}")
        power_by_file[path] = power
        scan_rows.append({"group": group_by_file.get(path, ""), "role": role, **row})
    if freq_ref is None:
        raise RuntimeError("T预训练没有产生频率轴")

    reference_specs = [
        (group_by_file.get(path, ""), path, core.representative_spectrum(power_by_file[path]))
        for path in reference_files
    ]
    training_powers = [power_by_file[path] for path in train_files]
    similarity_profile = build_t_similarity_profile(
        training_powers,
        float(a.dictionary_signature_smooth_sigma_bins),
        float(a.dictionary_saliency_floor),
        float(a.dictionary_saliency_cap_quantile),
    )
    similarity_prototype = core.normalize_vector(np.median(
        np.vstack([spec for _, _, spec in reference_specs]), axis=0
    ))
    training_matrix = build_training_matrix(training_powers, a, int(a.random_state))
    validation_powers = [(path, power_by_file[path]) for path in validation_files]

    candidate_rows: List[Dict[str, Any]] = []
    candidates: List[Tuple[Dict[str, Any], np.ndarray]] = []
    candidate_index = 0
    for k in a.dictionary_candidate_components:
        for beta_loss in a.dictionary_candidate_beta_losses:
            for activation_l1 in a.dictionary_candidate_activation_l1:
                for seed in a.dictionary_candidate_seeds:
                    candidate_index += 1
                    base = {
                        "candidate_index": candidate_index,
                        "n_components": int(k),
                        "beta_loss": str(beta_loss),
                        "activation_l1": float(activation_l1),
                        "seed": int(seed),
                    }
                    try:
                        dictionary, fit_info = _fit_candidate(
                            training_matrix, int(k), str(beta_loss), float(activation_l1),
                            int(seed), int(a.nmf_max_iter),
                        )
                        metrics = _evaluate_candidate(
                            dictionary,
                            validation_powers,
                            reference_specs,
                            similarity_profile,
                            float(a.dictionary_similarity_top_fraction),
                            float(a.dictionary_score_atom_weight),
                            float(a.dictionary_score_reference_weight),
                            float(a.dictionary_score_signature_weight),
                        )
                        row = {**base, **fit_info, **metrics, "status": "OK", "error": ""}
                        candidate_rows.append(row)
                        candidates.append((row, dictionary))
                        print(
                            f"候选{candidate_index}: K={k}, beta={beta_loss}, l1={activation_l1:g}, "
                            f"seed={seed}, T-score-p10={metrics['t_score_p10']:.4f}, "
                            f"T-score-med={metrics['t_score_median']:.4f}, "
                            f"coherence={metrics['atom_coherence_max']:.4f}"
                        )
                    except Exception as exc:
                        candidate_rows.append({
                            **base, "status": "ERROR", "error": f"{type(exc).__name__}: {exc}"
                        })
    if not candidates:
        raise RuntimeError("全部 T-only 候选字典训练失败")

    best_row, final_dictionary = max(candidates, key=lambda item: _selection_key(item[0]))

    validation_rows: List[Dict[str, Any]] = []
    validation_scores: List[float] = []
    for path in validation_files:
        parts = decision_similarity_for_power(
            power_by_file[path], final_dictionary, reference_specs, similarity_profile,
            float(a.dictionary_similarity_top_fraction),
            float(a.dictionary_score_atom_weight),
            float(a.dictionary_score_reference_weight),
            float(a.dictionary_score_signature_weight),
        )
        validation_scores.append(float(parts["combined"]))
        validation_rows.append({
            "group": group_by_file.get(path, ""),
            "file": str(path),
            "t_dictionary_similarity": parts["combined"],
            "dictionary_atom_similarity": parts["dictionary_atom_similarity"],
            "reference_spectrum_similarity": parts["reference_spectrum_similarity"],
            "t_envelope_similarity": parts["t_envelope_similarity"],
            "role": "T_HELDOUT_VALIDATION",
        })

    metadata = {
        "model_version": "multi-diameter-t-only-relative-ranking-v3.2",
        "data_semantics": "MULTI_DIAMETER_T_ONLY_RELATIVE_RANKING_V3_2",
        "positive_groups": positive_groups,
        "training_files": [str(path) for path in train_files],
        "validation_files": [str(path) for path in validation_files],
        "reference_files": [str(path) for path in reference_files],
        "beta_loss": str(best_row["beta_loss"]),
        "activation_l1": float(best_row["activation_l1"]),
        "n_components": int(final_dictionary.shape[1]),
        "seed": int(best_row["seed"]),
        "decision": {
            "mode": "WITHIN_PAIR_KEY_RELATIVE_RANKING",
            "score_name": "T_dictionary_direct_similarity",
            "similarity_top_fraction": float(a.dictionary_similarity_top_fraction),
            "score_weights": {
                "dictionary_atom": float(a.dictionary_score_atom_weight),
                "reference_spectrum": float(a.dictionary_score_reference_weight),
                "t_envelope": float(a.dictionary_score_signature_weight),
            },
            "interpretation": (
                "No absolute threshold and no T probability. Within the same pair_key, "
                "the largest T-dictionary similarity is T and smaller similarities are F."
            ),
            "heldout_t_score_median": float(np.median(validation_scores)),
            "heldout_t_score_p10": float(np.quantile(validation_scores, 0.10)),
        },
        "selection_metrics": {
            key: best_row[key]
            for key in (
                "t_score_p10", "t_score_median", "t_atom_similarity_median",
                "t_reference_similarity_median", "t_envelope_similarity_median",
                "atom_coherence_max",
            )
        },
        "feature_config": {
            "freq_low_hz": float(a.freq_low_hz),
            "freq_high_hz": float(a.freq_high_hz),
            "expected_sample_rate_hz": int(a.expected_sample_rate_hz),
            "nperseg": int(a.nperseg),
            "hop_length": int(a.hop_length),
            "nfft": int(a.nfft),
        },
        "similarity_profile": {
            "signature_smooth_sigma_bins": float(a.dictionary_signature_smooth_sigma_bins),
            "saliency_floor": float(a.dictionary_saliency_floor),
            "saliency_cap_quantile": float(a.dictionary_saliency_cap_quantile),
        },
    }

    np.savez_compressed(
        bundle_path,
        dictionary=final_dictionary,
        freq_hz=np.asarray(freq_ref, dtype=np.float64),
        similarity_prototype=similarity_prototype,
        reference_spectra=np.vstack([spec for _, _, spec in reference_specs]),
        reference_groups=np.asarray([group for group, _, _ in reference_specs], dtype=str),
        reference_files=np.asarray([str(path) for _, path, _ in reference_specs], dtype=str),
        training_files=np.asarray([str(path) for path in train_files], dtype=str),
        validation_files=np.asarray([str(path) for path in validation_files], dtype=str),
        t_signature=np.asarray(similarity_profile["signature"], dtype=np.float64),
        saliency_weights=np.asarray(similarity_profile["saliency_weights"], dtype=np.float64),
        signature_smooth_sigma_bins=np.asarray(float(similarity_profile["sigma_bins"])),
        data_semantics=np.asarray("MULTI_DIAMETER_T_ONLY_RELATIVE_RANKING_V3_2"),
        metadata_json=np.asarray(json.dumps(metadata, ensure_ascii=False)),
    )
    pd.DataFrame(scan_rows).to_csv(
        bundle_path.with_name(bundle_path.stem + "_files.csv"), index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(candidate_rows).to_csv(
        bundle_path.with_name(bundle_path.stem + "_cv.csv"), index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(validation_rows).to_csv(
        bundle_path.with_name(bundle_path.stem + "_t_validation.csv"), index=False, encoding="utf-8-sig"
    )
    core.write_json(bundle_path.with_name(bundle_path.stem + "_manifest.json"), metadata)
    if bool(a.save_plots):
        core.plot_dictionary(
            np.asarray(freq_ref, dtype=np.float64), final_dictionary,
            "T-only compact dictionary v3.2", bundle_path.with_name(bundle_path.stem + "_atoms.png")
        )
    print("T-only v3.2 冻结字典已保存:", bundle_path)
    print("训练语义: MULTI_DIAMETER_T_ONLY_RELATIVE_RANKING_V3_2")
    print("判定语义: 同一 pair_key 内仅比较相似度大小；不使用绝对阈值，不输出概率。")
    return bundle_path


def _scalar_text(value: np.ndarray) -> str:
    return str(np.asarray(value).item())


def _validate_bundle_feature_config(metadata: Mapping[str, Any], cfg: core.AlgorithmConfig) -> None:
    expected = metadata.get("feature_config", {})
    actual = {
        "freq_low_hz": float(cfg.freq_low_hz),
        "freq_high_hz": float(cfg.freq_high_hz),
        "expected_sample_rate_hz": int(cfg.expected_sample_rate_hz),
        "nperseg": int(cfg.nperseg),
        "hop_length": int(cfg.hop_length),
        "nfft": int(cfg.nfft),
    }
    mismatch = {
        key: {"bundle": expected.get(key), "runtime": value}
        for key, value in actual.items()
        if expected.get(key) != value
    }
    if mismatch:
        raise RuntimeError(f"冻结字典与运行时STFT/频段配置不一致: {mismatch}")


def load_pretrained_reference(cfg: core.RunConfig, output_dir: Path) -> Dict[str, Any]:
    """加载 v3.2 冻结 T 字典、T 稳定谱签名和显著性权重。"""
    bundle_path = Path(cfg.algorithm.pretrained_dictionary_path).expanduser().resolve()
    if not bundle_path.is_file():
        raise FileNotFoundError(
            f"没有找到冻结T字典: {bundle_path}\n"
            "请先运行: python spatial_prior_fusion_v3_2.py --pretrain-dictionary "
            "--config spatial_prior_fusion_v3_2_config.json"
        )
    with np.load(bundle_path, allow_pickle=False) as bundle:
        dictionary = np.asarray(bundle["dictionary"], dtype=np.float64)
        freq_hz = np.asarray(bundle["freq_hz"], dtype=np.float64)
        reference_spectra = np.asarray(bundle["reference_spectra"], dtype=np.float64)
        reference_groups = np.asarray(bundle["reference_groups"], dtype=str)
        reference_files = np.asarray(bundle["reference_files"], dtype=str)
        similarity_prototype = np.asarray(bundle["similarity_prototype"], dtype=np.float64)
        t_signature = np.asarray(bundle["t_signature"], dtype=np.float64)
        saliency_weights = np.asarray(bundle["saliency_weights"], dtype=np.float64)
        sigma_bins = float(np.asarray(bundle["signature_smooth_sigma_bins"]).item())
        data_semantics = _scalar_text(bundle["data_semantics"])
        metadata = json.loads(_scalar_text(bundle["metadata_json"]))
        training_files = np.asarray(bundle["training_files"], dtype=str).tolist()
        validation_files = np.asarray(bundle["validation_files"], dtype=str).tolist()

    if data_semantics != "MULTI_DIAMETER_T_ONLY_RELATIVE_RANKING_V3_2":
        raise RuntimeError(f"冻结字典训练语义不符合 v3.2 T-only 相对排序约束: {data_semantics}")
    if dictionary.ndim != 2 or dictionary.shape[0] != len(freq_hz):
        raise RuntimeError("冻结字典维度与频率轴不一致")
    if reference_spectra.ndim != 2 or reference_spectra.shape[1] != len(freq_hz):
        raise RuntimeError("冻结T参照频谱维度错误")
    if t_signature.shape != freq_hz.shape or saliency_weights.shape != freq_hz.shape:
        raise RuntimeError("冻结 T 谱签名/显著性权重维度错误")
    _validate_bundle_feature_config(metadata, cfg.algorithm)

    setattr(cfg.algorithm, "dictionary_beta_loss", str(metadata["beta_loss"]))
    setattr(cfg.algorithm, "dictionary_activation_l1", float(metadata["activation_l1"]))
    setattr(
        cfg.algorithm, "dictionary_similarity_top_fraction",
        float(metadata["decision"]["similarity_top_fraction"]),
    )
    cfg.algorithm.leak_components = int(dictionary.shape[1])

    references = [
        (str(group), Path(str(path)), np.asarray(spec, dtype=np.float64))
        for group, path, spec in zip(reference_groups, reference_files, reference_spectra)
    ]
    provenance = {
        "bundle_path": str(bundle_path),
        "bundle_fingerprint_sha256": _file_fingerprint(bundle_path),
        "data_semantics": data_semantics,
        "metadata": metadata,
    }
    core.write_json(output_dir / "02_loaded_t_only_dictionary_v3_2.json", provenance)
    if bool(cfg.algorithm.save_plots):
        core.plot_dictionary(
            freq_hz, dictionary, "Loaded frozen T-only dictionary v3.2",
            output_dir / "02_loaded_t_only_dictionary_v3_2.png",
        )

    return {
        "freq_hz": freq_hz,
        "ws": dictionary,
        "lab_proto": similarity_prototype,
        "prior_proto": core.normalize_vector(np.median(dictionary, axis=1)),
        "prior_specs": [],
        "similarity_specs": references,
        "validation_specs": references,
        "validation_mode": "MULTI_DIAMETER_T_ONLY_RELATIVE_RANKING_V3_2",
        "split_summary": {
            "data_semantics": data_semantics,
            "training_files": training_files,
            "validation_files": validation_files,
            "reference_files": [str(path) for _, path, _ in references],
        },
        "bundle_path": str(bundle_path),
        "dictionary_metadata": metadata,
        "similarity_top_fraction": float(metadata["decision"]["similarity_top_fraction"]),
        "similarity_profile": {
            "signature": t_signature,
            "saliency_weights": saliency_weights,
            "sigma_bins": sigma_bins,
        },
        "score_weights": metadata["decision"]["score_weights"],
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="v3.2 多孔径消声室T紧致字典与相对排序相似度预训练")
    parser.add_argument("--config", default="spatial_prior_fusion_v3_2_config.json")
    parser.add_argument("--output", default=None)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    config_path = Path(args.config)
    import spatial_prior_fusion_v3_2 as app

    cfg = app.load_config(config_path)
    output = Path(args.output) if args.output else None
    run_pretraining(cfg, output)


if __name__ == "__main__":
    main()
