# -*- coding: utf-8 -*-
"""
build_anechoic_reference_models.py

第一阶段：处理消声室 0.1 mm、0.5 mm 泄漏数据，建立可冻结、可复用的
5维声学特征马氏距离参考模型，供后续工厂空间拟合残差调用。

核心特征（不使用绝对能量参与判别）：
    1. spectral_flatness       频谱平坦度
    2. spectral_spread_hz      频谱展宽
    3. adaptive_snr_db         文件内相对本底的自适应 SNR
    4. flatness_local_std      平坦度的局部时间波动
    5. spread_local_std_hz     展宽的局部时间波动

默认参数与原消声室程序保持一致：
    18-50 kHz，100 ms 窗，50 ms 步长，Welch NFFT=2048。

运行：
    python build_anechoic_reference_models.py --self-test
    python build_anechoic_reference_models.py --config anechoic_reference_config.json

依赖：
    pip install numpy scipy matplotlib
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
import tempfile
import traceback
from dataclasses import asdict, dataclass, field, fields
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
from scipy import signal
from scipy.io import wavfile
from scipy.stats import chi2

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
except Exception:
    plt = None

EPS = 1.0e-20
MODEL_FORMAT_VERSION = "anechoic_reference_v1"
FEATURE_NAMES = [
    "spectral_flatness",
    "spectral_spread_hz",
    "adaptive_snr_db",
    "flatness_local_std",
    "spread_local_std_hz",
]
ALL_FEATURE_COLUMNS = [
    "energy_db",
    "spectral_flatness",
    "spectral_centroid_hz",
    "spectral_spread_hz",
    "adaptive_snr_db",
    "flatness_local_std",
    "spread_local_std_hz",
]
DISCRIM_COLUMNS = FEATURE_NAMES.copy()


@dataclass(frozen=True)
class FeatureConfig:
    freq_low_hz: float = 18_000.0
    freq_high_hz: float = 50_000.0
    window_ms: float = 100.0
    hop_ms: float = 50.0
    welch_nfft: int = 2048
    snr_floor_percentile: float = 10.0
    consistency_window_frames: int = 10
    accept_probability: float = 0.99
    covariance_shrinkage: float = 0.05
    covariance_ridge: float = 1.0e-6
    max_windows_per_file_for_model: int = 500
    minimum_windows_per_file: int = 3


@dataclass(frozen=True)
class ValidationConfig:
    enabled: bool = True
    n_folds: int = 5
    random_seed: int = 42
    optimize_grid_size: int = 80


@dataclass(frozen=True)
class PlotConfig:
    enabled: bool = True
    dpi: int = 140


@dataclass(frozen=True)
class RunConfig:
    groups: Dict[str, List[str]] = field(default_factory=dict)
    noise_paths: List[str] = field(default_factory=list)
    output_dir: str = "anechoic_reference_results"
    features: FeatureConfig = field(default_factory=FeatureConfig)
    validation: ValidationConfig = field(default_factory=ValidationConfig)
    plots: PlotConfig = field(default_factory=PlotConfig)


@dataclass
class FileFeatureRecord:
    group: str
    file_path: str
    sample_rate_hz: int
    duration_seconds: float
    frames: np.ndarray  # shape: (T, 7), ALL_FEATURE_COLUMNS


class ReferenceModel:
    def __init__(
        self,
        model_name: str,
        feature_names: Sequence[str],
        accept_probability: float,
    ) -> None:
        self.model_name = str(model_name)
        self.feature_names = list(feature_names)
        self.accept_probability = float(accept_probability)

    def fit(
        self,
        feature_matrix: np.ndarray,
        shrinkage: float,
        ridge: float,
    ) -> "ReferenceModel":
        x = np.asarray(feature_matrix, dtype=np.float64)
        if x.ndim != 2 or x.shape[1] != len(self.feature_names):
            raise ValueError(
                f"模型 {self.model_name}: 特征矩阵形状应为 (N,{len(self.feature_names)})，"
                f"实际为 {x.shape}"
            )
        x = x[np.all(np.isfinite(x), axis=1)]
        if x.shape[0] < max(10, x.shape[1] + 3):
            raise ValueError(
                f"模型 {self.model_name}: 有效特征窗太少，仅 {x.shape[0]} 个"
            )

        self.n_training_windows = int(x.shape[0])
        self.raw_mean = np.mean(x, axis=0)
        self.raw_median = np.median(x, axis=0)
        self.raw_std = np.std(x, axis=0, ddof=0)
        self.raw_std = np.maximum(self.raw_std, 1.0e-12)

        z = (x - self.raw_mean) / self.raw_std
        self.center = np.mean(z, axis=0)

        empirical_cov = np.cov(z, rowvar=False, ddof=1)
        if empirical_cov.ndim == 0:
            empirical_cov = np.eye(x.shape[1], dtype=np.float64)
        diagonal_cov = np.diag(np.diag(empirical_cov))
        alpha = float(np.clip(shrinkage, 0.0, 1.0))
        self.covariance = (
            (1.0 - alpha) * empirical_cov
            + alpha * diagonal_cov
            + float(ridge) * np.eye(x.shape[1], dtype=np.float64)
        )
        self.inverse_covariance = np.linalg.pinv(self.covariance)
        self.window_distance_threshold = float(
            math.sqrt(chi2.ppf(self.accept_probability, df=x.shape[1]))
        )
        self.thresholds: Dict[str, Any] = {
            "available": False,
            "reason": "NO_NOISE_VALIDATION",
            "median_distance_threshold": None,
            "p90_distance_threshold": None,
        }
        return self

    def distances(self, feature_matrix: np.ndarray) -> np.ndarray:
        x = np.asarray(feature_matrix, dtype=np.float64)
        if x.ndim != 2 or x.shape[1] != len(self.feature_names):
            raise ValueError(
                f"模型 {self.model_name}: 待测特征形状错误 {x.shape}"
            )
        z = (x - self.raw_mean) / self.raw_std
        delta = z - self.center
        d2 = np.einsum(
            "ij,jk,ik->i",
            delta,
            self.inverse_covariance,
            delta,
            optimize=True,
        )
        return np.sqrt(np.maximum(d2, 0.0))

    def similarity_from_distance(self, distance: np.ndarray | float) -> np.ndarray:
        d = np.asarray(distance, dtype=np.float64)
        tau = max(float(self.window_distance_threshold), EPS)
        # 透明、单调的 0-1 映射：d=0 -> 1，d=tau -> exp(-0.5)=0.6065
        return np.exp(-0.5 * np.square(d / tau))

    def file_statistics(self, feature_matrix: np.ndarray) -> Dict[str, float]:
        distances = self.distances(feature_matrix)
        if distances.size == 0:
            return {
                "n_windows": 0,
                "median_distance": math.inf,
                "p90_distance": math.inf,
                "mean_distance": math.inf,
                "std_distance": math.inf,
                "window_inside_fraction": 0.0,
                "median_similarity": 0.0,
                "p90_guard_similarity": 0.0,
                "balanced_similarity": 0.0,
            }
        median_distance = float(np.median(distances))
        p90_distance = float(np.percentile(distances, 90.0))
        mean_distance = float(np.mean(distances))
        std_distance = float(np.std(distances))
        inside_fraction = float(
            np.mean(distances <= self.window_distance_threshold)
        )
        median_similarity = float(self.similarity_from_distance(median_distance))
        p90_similarity = float(self.similarity_from_distance(p90_distance))
        balanced_similarity = float(
            math.sqrt(max(median_similarity * p90_similarity, 0.0))
        )
        return {
            "n_windows": int(distances.size),
            "median_distance": median_distance,
            "p90_distance": p90_distance,
            "mean_distance": mean_distance,
            "std_distance": std_distance,
            "window_inside_fraction": inside_fraction,
            "median_similarity": median_similarity,
            "p90_guard_similarity": p90_similarity,
            "balanced_similarity": balanced_similarity,
        }

    def classify_file(self, feature_matrix: np.ndarray) -> Optional[bool]:
        if not bool(self.thresholds.get("available", False)):
            return None
        stats = self.file_statistics(feature_matrix)
        return bool(
            stats["median_distance"]
            <= float(self.thresholds["median_distance_threshold"])
            and stats["p90_distance"]
            <= float(self.thresholds["p90_distance_threshold"])
        )

    def to_json_dict(self, feature_cfg: FeatureConfig) -> Dict[str, Any]:
        return {
            "format_version": MODEL_FORMAT_VERSION,
            "model_name": self.model_name,
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "feature_names": self.feature_names,
            "feature_extraction": asdict(feature_cfg),
            "n_training_windows": self.n_training_windows,
            "raw_mean": self.raw_mean.tolist(),
            "raw_median": self.raw_median.tolist(),
            "raw_std": self.raw_std.tolist(),
            "standardized_center": self.center.tolist(),
            "covariance": self.covariance.tolist(),
            "inverse_covariance": self.inverse_covariance.tolist(),
            "accept_probability": self.accept_probability,
            "window_distance_threshold": self.window_distance_threshold,
            "file_thresholds": self.thresholds,
            "distance_definition": (
                "Mahalanobis distance in standardized 5D feature space; smaller means more similar"
            ),
            "similarity_definition": (
                "exp(-0.5 * (distance / window_distance_threshold)^2)"
            ),
            "file_similarity_definition": (
                "sqrt(median_similarity * p90_guard_similarity)"
            ),
        }


# -----------------------------------------------------------------------------
# 配置、文件发现和 WAV 读取
# -----------------------------------------------------------------------------

def dataclass_from_dict(cls, values: Optional[Mapping[str, Any]]) -> Any:
    values = dict(values or {})
    allowed = {f.name for f in fields(cls)}
    clean = {k: v for k, v in values.items() if k in allowed}
    return cls(**clean)


def load_config(path: Path) -> RunConfig:
    with path.open("r", encoding="utf-8-sig") as f:
        raw = json.load(f)
    feature_cfg = dataclass_from_dict(FeatureConfig, raw.get("features"))
    validation_cfg = dataclass_from_dict(ValidationConfig, raw.get("validation"))
    plot_cfg = dataclass_from_dict(PlotConfig, raw.get("plots"))

    groups_raw = raw.get("groups", {})
    groups: Dict[str, List[str]] = {}
    for key, value in groups_raw.items():
        if isinstance(value, str):
            groups[str(key)] = [value]
        else:
            groups[str(key)] = [str(v) for v in value]

    noise_raw = raw.get("noise_paths", [])
    if isinstance(noise_raw, str):
        noise_paths = [noise_raw]
    else:
        noise_paths = [str(v) for v in noise_raw]

    cfg = RunConfig(
        groups=groups,
        noise_paths=noise_paths,
        output_dir=str(raw.get("output_dir", "anechoic_reference_results")),
        features=feature_cfg,
        validation=validation_cfg,
        plots=plot_cfg,
    )
    validate_config(cfg)
    return cfg


def validate_config(cfg: RunConfig) -> None:
    if not cfg.groups:
        raise ValueError("配置中的 groups 不能为空，至少需要 0.1mm 和 0.5mm")
    if "0.1mm" not in cfg.groups or "0.5mm" not in cfg.groups:
        raise ValueError("groups 中必须同时包含 '0.1mm' 和 '0.5mm'")
    f = cfg.features
    if f.freq_low_hz < 0 or f.freq_high_hz <= f.freq_low_hz:
        raise ValueError("频率范围设置错误")
    if f.window_ms <= 0 or f.hop_ms <= 0:
        raise ValueError("window_ms 和 hop_ms 必须大于0")
    if f.welch_nfft < 64:
        raise ValueError("welch_nfft 不能小于64")
    if not (0.0 < f.accept_probability < 1.0):
        raise ValueError("accept_probability 必须在0和1之间")
    if f.consistency_window_frames < 1:
        raise ValueError("consistency_window_frames 必须至少为1")


def discover_wavs(paths: Sequence[str]) -> List[Path]:
    found: Dict[str, Path] = {}
    for raw in paths:
        p = Path(raw).expanduser()
        if p.is_file() and p.suffix.lower() == ".wav":
            found[str(p.resolve()).lower()] = p.resolve()
        elif p.is_dir():
            for wav in p.rglob("*"):
                if wav.is_file() and wav.suffix.lower() == ".wav":
                    found[str(wav.resolve()).lower()] = wav.resolve()
    return sorted(found.values(), key=lambda x: str(x).lower())


def pcm_to_float(data: np.ndarray) -> np.ndarray:
    """按数据类型统一满量程转换，不做逐文件峰值归一化。"""
    x = np.asarray(data)
    if np.issubdtype(x.dtype, np.floating):
        out = x.astype(np.float64, copy=False)
    elif x.dtype == np.uint8:
        out = (x.astype(np.float64) - 128.0) / 128.0
    elif np.issubdtype(x.dtype, np.signedinteger):
        info = np.iinfo(x.dtype)
        scale = float(max(abs(info.min), abs(info.max)))
        out = x.astype(np.float64) / scale
    else:
        raise TypeError(f"不支持的WAV数据类型: {x.dtype}")
    if out.ndim > 1:
        out = np.mean(out, axis=1)
    out = np.asarray(out, dtype=np.float64).reshape(-1)
    out[~np.isfinite(out)] = 0.0
    return out


def read_wav_mono(path: Path) -> Tuple[int, np.ndarray]:
    fs, data = wavfile.read(str(path), mmap=False)
    if int(fs) <= 0:
        raise ValueError("采样率无效")
    x = pcm_to_float(data)
    return int(fs), x


# -----------------------------------------------------------------------------
# 特征提取
# -----------------------------------------------------------------------------

def rolling_std(values: np.ndarray, width: int) -> np.ndarray:
    v = np.asarray(values, dtype=np.float64)
    out = np.zeros_like(v)
    half = max(int(width) // 2, 0)
    for i in range(v.size):
        start = max(0, i - half)
        end = min(v.size, i + half + 1)
        out[i] = float(np.std(v[start:end]))
    return out


def one_window_features(
    samples: np.ndarray,
    fs: int,
    cfg: FeatureConfig,
) -> np.ndarray:
    nperseg = min(int(cfg.welch_nfft), int(samples.size))
    if nperseg < 16:
        raise ValueError("单窗有效采样点少于16")
    freq, power = signal.welch(
        samples,
        fs=fs,
        window="hann",
        nperseg=nperseg,
        noverlap=nperseg // 2,
        nfft=int(cfg.welch_nfft),
        detrend=False,
        scaling="density",
    )
    mask = (freq >= cfg.freq_low_hz) & (freq <= cfg.freq_high_hz)
    if np.count_nonzero(mask) < 3:
        raise ValueError(
            f"{cfg.freq_low_hz:g}-{cfg.freq_high_hz:g} Hz内有效频点不足；"
            f"采样率={fs} Hz，Nyquist={fs/2:g} Hz"
        )
    f = freq[mask]
    p = np.maximum(power[mask], EPS)
    total = float(np.sum(p))
    energy_db = float(10.0 * np.log10(total + EPS))
    flatness = float(np.exp(np.mean(np.log(p))) / (np.mean(p) + EPS))
    centroid = float(np.sum(f * p) / (total + EPS))
    spread = float(
        np.sqrt(np.sum(np.square(f - centroid) * p) / (total + EPS))
    )
    return np.asarray([energy_db, flatness, centroid, spread], dtype=np.float64)


def extract_file_features(
    path: Path,
    group: str,
    cfg: FeatureConfig,
) -> FileFeatureRecord:
    fs, x = read_wav_mono(path)
    if fs / 2.0 < cfg.freq_high_hz:
        raise ValueError(
            f"采样率 {fs} Hz 的Nyquist频率仅 {fs/2:g} Hz，"
            f"低于配置上限 {cfg.freq_high_hz:g} Hz"
        )
    win = int(round(fs * cfg.window_ms / 1000.0))
    hop = int(round(fs * cfg.hop_ms / 1000.0))
    if win < 16 or hop < 1:
        raise ValueError("窗口或步长换算后的采样点数无效")
    if x.size < win:
        raise ValueError(
            f"WAV时长 {x.size/fs:.4f}s，小于窗口 {cfg.window_ms/1000:.4f}s"
        )

    base_rows: List[np.ndarray] = []
    starts: List[int] = []
    for start in range(0, x.size - win + 1, hop):
        base_rows.append(one_window_features(x[start : start + win], fs, cfg))
        starts.append(start)
    base = np.vstack(base_rows)
    energy = base[:, 0]
    flatness = base[:, 1]
    centroid = base[:, 2]
    spread = base[:, 3]

    floor = float(np.percentile(energy, cfg.snr_floor_percentile))
    adaptive_snr = energy - floor
    flatness_std = rolling_std(flatness, cfg.consistency_window_frames)
    spread_std = rolling_std(spread, cfg.consistency_window_frames)

    frames = np.column_stack(
        [
            energy,
            flatness,
            centroid,
            spread,
            adaptive_snr,
            flatness_std,
            spread_std,
        ]
    )
    if frames.shape[0] < cfg.minimum_windows_per_file:
        raise ValueError(
            f"有效时间窗仅 {frames.shape[0]}，少于 minimum_windows_per_file="
            f"{cfg.minimum_windows_per_file}"
        )
    return FileFeatureRecord(
        group=group,
        file_path=str(path),
        sample_rate_hz=fs,
        duration_seconds=float(x.size / fs),
        frames=np.asarray(frames, dtype=np.float64),
    )


def discrim_matrix(record: FileFeatureRecord) -> np.ndarray:
    indices = [ALL_FEATURE_COLUMNS.index(name) for name in DISCRIM_COLUMNS]
    return record.frames[:, indices]


def uniformly_select_rows(matrix: np.ndarray, maximum: int) -> np.ndarray:
    x = np.asarray(matrix)
    maximum = int(maximum)
    if maximum <= 0 or x.shape[0] <= maximum:
        return x.copy()
    idx = np.linspace(0, x.shape[0] - 1, maximum).round().astype(int)
    return x[idx]


def model_training_matrix(
    records: Sequence[FileFeatureRecord],
    cfg: FeatureConfig,
) -> np.ndarray:
    parts = [
        uniformly_select_rows(
            discrim_matrix(record), cfg.max_windows_per_file_for_model
        )
        for record in records
    ]
    if not parts:
        return np.zeros((0, len(DISCRIM_COLUMNS)), dtype=np.float64)
    return np.vstack(parts)


# -----------------------------------------------------------------------------
# 输出工具
# -----------------------------------------------------------------------------

def safe_scalar(value: Any) -> Any:
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        v = float(value)
        return v if math.isfinite(v) else None
    if isinstance(value, (np.bool_,)):
        return bool(value)
    return value


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]], columns: Sequence[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(columns), extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: safe_scalar(row.get(k)) for k in columns})


def write_json(path: Path, data: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, allow_nan=False)


def save_model_files(
    output_dir: Path,
    model: ReferenceModel,
    cfg: FeatureConfig,
) -> Tuple[Path, Path]:
    model_dir = output_dir / "models"
    model_dir.mkdir(parents=True, exist_ok=True)
    safe_name = model.model_name.replace("/", "_").replace("\\", "_")
    json_path = model_dir / f"reference_model_{safe_name}.json"
    npz_path = model_dir / f"reference_model_{safe_name}.npz"
    write_json(json_path, model.to_json_dict(cfg))
    np.savez_compressed(
        npz_path,
        format_version=np.asarray(MODEL_FORMAT_VERSION),
        model_name=np.asarray(model.model_name),
        feature_names=np.asarray(model.feature_names, dtype="U64"),
        raw_mean=model.raw_mean,
        raw_median=model.raw_median,
        raw_std=model.raw_std,
        standardized_center=model.center,
        covariance=model.covariance,
        inverse_covariance=model.inverse_covariance,
        window_distance_threshold=np.asarray(model.window_distance_threshold),
        accept_probability=np.asarray(model.accept_probability),
        median_distance_threshold=np.asarray(
            model.thresholds.get("median_distance_threshold")
            if model.thresholds.get("median_distance_threshold") is not None
            else np.nan
        ),
        p90_distance_threshold=np.asarray(
            model.thresholds.get("p90_distance_threshold")
            if model.thresholds.get("p90_distance_threshold") is not None
            else np.nan
        ),
    )
    return json_path, npz_path


# -----------------------------------------------------------------------------
# 阈值和文件级验证
# -----------------------------------------------------------------------------

def evaluate_records(
    model: ReferenceModel,
    records: Sequence[FileFeatureRecord],
    true_label: Optional[bool] = None,
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for record in records:
        stats = model.file_statistics(discrim_matrix(record))
        row: Dict[str, Any] = {
            "model_name": model.model_name,
            "source_group": record.group,
            "file_name": Path(record.file_path).name,
            "file_path": record.file_path,
            "sample_rate_hz": record.sample_rate_hz,
            "duration_seconds": record.duration_seconds,
            "true_label": (
                "LEAK" if true_label is True else "NOISE" if true_label is False else ""
            ),
            **stats,
        }
        predicted = model.classify_file(discrim_matrix(record))
        row["prediction"] = (
            "LEAK" if predicted is True else "NOISE" if predicted is False else "NO_THRESHOLD"
        )
        row["correct"] = (
            bool(predicted == true_label)
            if predicted is not None and true_label is not None
            else ""
        )
        rows.append(row)
    return rows


def candidate_thresholds(values: np.ndarray, grid_size: int) -> np.ndarray:
    v = np.asarray(values, dtype=np.float64)
    v = v[np.isfinite(v)]
    if v.size == 0:
        return np.asarray([], dtype=np.float64)
    quantiles = np.linspace(0.0, 1.0, max(3, int(grid_size)))
    candidates = np.unique(np.quantile(v, quantiles))
    pad = max(float(np.ptp(v)) * 1.0e-6, 1.0e-9)
    return np.unique(np.concatenate(([v.min() - pad], candidates, [v.max() + pad])))


def optimize_joint_thresholds(
    leak_rows: Sequence[Mapping[str, Any]],
    noise_rows: Sequence[Mapping[str, Any]],
    grid_size: int,
) -> Dict[str, Any]:
    leak_med = np.asarray([r["median_distance"] for r in leak_rows], dtype=float)
    leak_p90 = np.asarray([r["p90_distance"] for r in leak_rows], dtype=float)
    noise_med = np.asarray([r["median_distance"] for r in noise_rows], dtype=float)
    noise_p90 = np.asarray([r["p90_distance"] for r in noise_rows], dtype=float)

    med_candidates = candidate_thresholds(
        np.concatenate([leak_med, noise_med]), grid_size
    )
    p90_candidates = candidate_thresholds(
        np.concatenate([leak_p90, noise_p90]), grid_size
    )
    best: Optional[Tuple[Tuple[float, float, float, float], float, float, Dict[str, Any]]] = None
    for med_tau in med_candidates:
        leak_med_ok = leak_med <= med_tau
        noise_med_ok = noise_med <= med_tau
        for p90_tau in p90_candidates:
            leak_pred = leak_med_ok & (leak_p90 <= p90_tau)
            noise_pred = noise_med_ok & (noise_p90 <= p90_tau)
            recall = float(np.mean(leak_pred)) if leak_pred.size else 0.0
            specificity = float(np.mean(~noise_pred)) if noise_pred.size else 0.0
            balanced_accuracy = 0.5 * (recall + specificity)
            fp = int(np.sum(noise_pred))
            fn = int(np.sum(~leak_pred))
            # 优先：平衡准确率、召回率、特异性；再偏向较严格阈值。
            score = (balanced_accuracy, recall, specificity, -(med_tau + p90_tau))
            metrics = {
                "balanced_accuracy": balanced_accuracy,
                "recall": recall,
                "specificity": specificity,
                "false_positive_count": fp,
                "false_negative_count": fn,
                "n_leak_files": int(leak_pred.size),
                "n_noise_files": int(noise_pred.size),
            }
            if best is None or score > best[0]:
                best = (score, float(med_tau), float(p90_tau), metrics)
    if best is None:
        raise ValueError("无法优化文件级阈值")
    return {
        "available": True,
        "reason": "FILE_LEVEL_GROUPED_CROSS_VALIDATION",
        "median_distance_threshold": best[1],
        "p90_distance_threshold": best[2],
        **best[3],
    }


def grouped_cross_validation(
    model_name: str,
    leak_records: Sequence[FileFeatureRecord],
    noise_records: Sequence[FileFeatureRecord],
    feature_cfg: FeatureConfig,
    validation_cfg: ValidationConfig,
) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[Dict[str, Any]]]:
    n_folds = min(
        int(validation_cfg.n_folds), len(leak_records), len(noise_records)
    )
    if n_folds < 2:
        return (
            {
                "available": False,
                "reason": "至少需要2个泄漏WAV和2个噪声WAV才能做文件级交叉验证",
                "median_distance_threshold": None,
                "p90_distance_threshold": None,
            },
            [],
            [],
        )

    rng = np.random.default_rng(validation_cfg.random_seed)
    leak_order = rng.permutation(len(leak_records))
    noise_order = rng.permutation(len(noise_records))
    leak_folds = np.array_split(leak_order, n_folds)
    noise_folds = np.array_split(noise_order, n_folds)

    oof_leak: List[Dict[str, Any]] = []
    oof_noise: List[Dict[str, Any]] = []
    fold_rows: List[Dict[str, Any]] = []

    for fold_index in range(n_folds):
        val_leak_idx = set(int(v) for v in leak_folds[fold_index])
        val_noise_idx = set(int(v) for v in noise_folds[fold_index])
        train_leak = [
            record for i, record in enumerate(leak_records) if i not in val_leak_idx
        ]
        val_leak = [
            record for i, record in enumerate(leak_records) if i in val_leak_idx
        ]
        val_noise = [
            record for i, record in enumerate(noise_records) if i in val_noise_idx
        ]
        fold_model = ReferenceModel(
            model_name=model_name,
            feature_names=DISCRIM_COLUMNS,
            accept_probability=feature_cfg.accept_probability,
        ).fit(
            model_training_matrix(train_leak, feature_cfg),
            shrinkage=feature_cfg.covariance_shrinkage,
            ridge=feature_cfg.covariance_ridge,
        )
        leak_rows = evaluate_records(fold_model, val_leak, true_label=True)
        noise_rows = evaluate_records(fold_model, val_noise, true_label=False)
        for row in leak_rows:
            row["fold"] = fold_index + 1
        for row in noise_rows:
            row["fold"] = fold_index + 1
        oof_leak.extend(leak_rows)
        oof_noise.extend(noise_rows)
        fold_rows.append(
            {
                "model_name": model_name,
                "fold": fold_index + 1,
                "n_train_leak_files": len(train_leak),
                "n_validation_leak_files": len(val_leak),
                "n_validation_noise_files": len(val_noise),
                "window_distance_threshold": fold_model.window_distance_threshold,
            }
        )

    thresholds = optimize_joint_thresholds(
        oof_leak,
        oof_noise,
        grid_size=validation_cfg.optimize_grid_size,
    )
    thresholds["n_folds"] = n_folds

    med_tau = float(thresholds["median_distance_threshold"])
    p90_tau = float(thresholds["p90_distance_threshold"])
    for row in oof_leak + oof_noise:
        is_leak = bool(
            row["median_distance"] <= med_tau and row["p90_distance"] <= p90_tau
        )
        row["prediction"] = "LEAK" if is_leak else "NOISE"
        row["correct"] = bool(
            (row["true_label"] == "LEAK" and is_leak)
            or (row["true_label"] == "NOISE" and not is_leak)
        )
    return thresholds, oof_leak + oof_noise, fold_rows


# -----------------------------------------------------------------------------
# 特征汇总和共同范围
# -----------------------------------------------------------------------------

def feature_summary_rows(
    records_by_group: Mapping[str, Sequence[FileFeatureRecord]],
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for group, records in records_by_group.items():
        if not records:
            continue
        x = np.vstack([discrim_matrix(r) for r in records])
        for j, feature in enumerate(DISCRIM_COLUMNS):
            values = x[:, j]
            rows.append(
                {
                    "group": group,
                    "feature": feature,
                    "n_windows": int(values.size),
                    "mean": float(np.mean(values)),
                    "std": float(np.std(values)),
                    "median": float(np.median(values)),
                    "p10": float(np.percentile(values, 10)),
                    "p25": float(np.percentile(values, 25)),
                    "p75": float(np.percentile(values, 75)),
                    "p90": float(np.percentile(values, 90)),
                }
            )
    return rows


def common_feature_rows(
    summary_rows: Sequence[Mapping[str, Any]],
    group_a: str = "0.1mm",
    group_b: str = "0.5mm",
) -> List[Dict[str, Any]]:
    lookup = {(r["group"], r["feature"]): r for r in summary_rows}
    rows: List[Dict[str, Any]] = []
    for feature in DISCRIM_COLUMNS:
        a = lookup.get((group_a, feature))
        b = lookup.get((group_b, feature))
        if a is None or b is None:
            continue
        common_low = max(float(a["p10"]), float(b["p10"]))
        common_high = min(float(a["p90"]), float(b["p90"]))
        union_low = min(float(a["p10"]), float(b["p10"]))
        union_high = max(float(a["p90"]), float(b["p90"]))
        overlap_width = max(common_high - common_low, 0.0)
        union_width = max(union_high - union_low, EPS)
        pooled_std = math.sqrt(
            max((float(a["std"]) ** 2 + float(b["std"]) ** 2) / 2.0, EPS)
        )
        standardized_median_difference = abs(
            float(a["median"]) - float(b["median"])
        ) / pooled_std
        rows.append(
            {
                "feature": feature,
                "group_a": group_a,
                "group_b": group_b,
                "group_a_p10": a["p10"],
                "group_a_median": a["median"],
                "group_a_p90": a["p90"],
                "group_b_p10": b["p10"],
                "group_b_median": b["median"],
                "group_b_p90": b["p90"],
                "common_p10_p90_low": common_low if overlap_width > 0 else None,
                "common_p10_p90_high": common_high if overlap_width > 0 else None,
                "robust_interval_overlap_ratio": overlap_width / union_width,
                "standardized_median_difference": standardized_median_difference,
                "has_robust_common_range": bool(overlap_width > 0),
            }
        )
    return rows


# -----------------------------------------------------------------------------
# 绘图
# -----------------------------------------------------------------------------

def plot_feature_distributions(
    output_dir: Path,
    records_by_group: Mapping[str, Sequence[FileFeatureRecord]],
    cfg: PlotConfig,
) -> None:
    if not cfg.enabled or plt is None:
        return
    plot_dir = output_dir / "plots"
    plot_dir.mkdir(parents=True, exist_ok=True)
    groups = [g for g in ("0.1mm", "0.5mm", "NOISE") if records_by_group.get(g)]
    for feature_index, feature in enumerate(DISCRIM_COLUMNS):
        arrays = [
            np.concatenate([discrim_matrix(r)[:, feature_index] for r in records_by_group[g]])
            for g in groups
        ]
        fig, ax = plt.subplots(figsize=(8.2, 5.2), dpi=cfg.dpi)
        try:
            ax.boxplot(arrays, tick_labels=groups, showfliers=False)
        except TypeError:
            ax.boxplot(arrays, labels=groups, showfliers=False)
        ax.set_title(f"Anechoic feature distribution: {feature}")
        ax.set_ylabel(feature)
        ax.grid(True, axis="y", alpha=0.3)
        fig.tight_layout()
        fig.savefig(plot_dir / f"feature_{feature}.png", bbox_inches="tight")
        plt.close(fig)


def plot_oof_distances(
    output_dir: Path,
    model_name: str,
    rows: Sequence[Mapping[str, Any]],
    thresholds: Mapping[str, Any],
    cfg: PlotConfig,
) -> None:
    if not cfg.enabled or plt is None or not rows:
        return
    leak = [r for r in rows if r["true_label"] == "LEAK"]
    noise = [r for r in rows if r["true_label"] == "NOISE"]
    if not leak or not noise:
        return
    plot_dir = output_dir / "plots"
    plot_dir.mkdir(parents=True, exist_ok=True)
    safe_name = model_name.replace("/", "_").replace("\\", "_")

    for field_name, tau_name in [
        ("median_distance", "median_distance_threshold"),
        ("p90_distance", "p90_distance_threshold"),
    ]:
        fig, ax = plt.subplots(figsize=(8.2, 5.2), dpi=cfg.dpi)
        leak_values = [float(r[field_name]) for r in leak]
        noise_values = [float(r[field_name]) for r in noise]
        bins = max(8, min(30, len(rows)))
        ax.hist(leak_values, bins=bins, alpha=0.55, label="LEAK")
        ax.hist(noise_values, bins=bins, alpha=0.55, label="NOISE")
        if thresholds.get(tau_name) is not None:
            ax.axvline(float(thresholds[tau_name]), linestyle="--", label="threshold")
        ax.set_title(f"OOF {field_name}: model={model_name}")
        ax.set_xlabel(field_name)
        ax.set_ylabel("file count")
        ax.legend()
        ax.grid(True, alpha=0.25)
        fig.tight_layout()
        fig.savefig(
            plot_dir / f"oof_{safe_name}_{field_name}.png", bbox_inches="tight"
        )
        plt.close(fig)


# -----------------------------------------------------------------------------
# 主流程
# -----------------------------------------------------------------------------

def process_all(cfg: RunConfig) -> None:
    output_dir = Path(cfg.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    errors: List[Dict[str, Any]] = []
    discovered_rows: List[Dict[str, Any]] = []
    records_by_group: Dict[str, List[FileFeatureRecord]] = {}

    print("=" * 78)
    print("消声室泄漏参考模型构建")
    print("=" * 78)

    for group, paths in cfg.groups.items():
        wavs = discover_wavs(paths)
        print(f"[{group}] 发现 WAV: {len(wavs)}")
        records_by_group[group] = []
        for wav in wavs:
            try:
                record = extract_file_features(wav, group, cfg.features)
                records_by_group[group].append(record)
                discovered_rows.append(
                    {
                        "group": group,
                        "file_name": wav.name,
                        "file_path": str(wav),
                        "status": "OK",
                        "sample_rate_hz": record.sample_rate_hz,
                        "duration_seconds": record.duration_seconds,
                        "n_windows": int(record.frames.shape[0]),
                        "error": "",
                    }
                )
            except Exception as exc:
                errors.append(
                    {
                        "stage": "FEATURE_EXTRACTION",
                        "group": group,
                        "file_path": str(wav),
                        "error": f"{type(exc).__name__}: {exc}",
                    }
                )
                discovered_rows.append(
                    {
                        "group": group,
                        "file_name": wav.name,
                        "file_path": str(wav),
                        "status": "FAILED",
                        "sample_rate_hz": "",
                        "duration_seconds": "",
                        "n_windows": 0,
                        "error": f"{type(exc).__name__}: {exc}",
                    }
                )

    noise_records: List[FileFeatureRecord] = []
    noise_wavs = discover_wavs(cfg.noise_paths)
    print(f"[NOISE] 发现 WAV: {len(noise_wavs)}")
    for wav in noise_wavs:
        try:
            record = extract_file_features(wav, "NOISE", cfg.features)
            noise_records.append(record)
            discovered_rows.append(
                {
                    "group": "NOISE",
                    "file_name": wav.name,
                    "file_path": str(wav),
                    "status": "OK",
                    "sample_rate_hz": record.sample_rate_hz,
                    "duration_seconds": record.duration_seconds,
                    "n_windows": int(record.frames.shape[0]),
                    "error": "",
                }
            )
        except Exception as exc:
            errors.append(
                {
                    "stage": "FEATURE_EXTRACTION",
                    "group": "NOISE",
                    "file_path": str(wav),
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )

    if not records_by_group.get("0.1mm"):
        raise RuntimeError("0.1mm 没有成功提取任何WAV，请检查路径和采样率")
    if not records_by_group.get("0.5mm"):
        raise RuntimeError("0.5mm 没有成功提取任何WAV，请检查路径和采样率")

    all_leak_records: List[FileFeatureRecord] = []
    for group, records in records_by_group.items():
        if group != "NOISE":
            all_leak_records.extend(records)
    records_by_group["ALL_LEAKS"] = all_leak_records
    records_by_group["NOISE"] = noise_records

    scan_columns = [
        "group",
        "file_name",
        "file_path",
        "status",
        "sample_rate_hz",
        "duration_seconds",
        "n_windows",
        "error",
    ]
    write_csv(output_dir / "00_input_scan.csv", discovered_rows, scan_columns)

    # 保存逐窗特征和逐文件特征摘要。
    window_rows: List[Dict[str, Any]] = []
    file_feature_rows: List[Dict[str, Any]] = []
    for group in list(cfg.groups.keys()) + (["NOISE"] if noise_records else []):
        for record in records_by_group.get(group, []):
            for frame_index, values in enumerate(record.frames):
                row: Dict[str, Any] = {
                    "group": group,
                    "file_name": Path(record.file_path).name,
                    "file_path": record.file_path,
                    "frame_index": frame_index,
                    "start_second": frame_index * cfg.features.hop_ms / 1000.0,
                    "end_second": (
                        frame_index * cfg.features.hop_ms + cfg.features.window_ms
                    )
                    / 1000.0,
                }
                row.update(
                    {
                        name: float(values[i])
                        for i, name in enumerate(ALL_FEATURE_COLUMNS)
                    }
                )
                window_rows.append(row)

            dmat = discrim_matrix(record)
            summary_row: Dict[str, Any] = {
                "group": group,
                "file_name": Path(record.file_path).name,
                "file_path": record.file_path,
                "sample_rate_hz": record.sample_rate_hz,
                "duration_seconds": record.duration_seconds,
                "n_windows": int(dmat.shape[0]),
            }
            for j, feature in enumerate(DISCRIM_COLUMNS):
                values = dmat[:, j]
                summary_row[f"{feature}_median"] = float(np.median(values))
                summary_row[f"{feature}_p10"] = float(np.percentile(values, 10))
                summary_row[f"{feature}_p90"] = float(np.percentile(values, 90))
                summary_row[f"{feature}_std"] = float(np.std(values))
            file_feature_rows.append(summary_row)

    window_columns = [
        "group",
        "file_name",
        "file_path",
        "frame_index",
        "start_second",
        "end_second",
        *ALL_FEATURE_COLUMNS,
    ]
    write_csv(output_dir / "01_window_features.csv", window_rows, window_columns)
    file_feature_columns = [
        "group",
        "file_name",
        "file_path",
        "sample_rate_hz",
        "duration_seconds",
        "n_windows",
    ]
    for feature in DISCRIM_COLUMNS:
        file_feature_columns.extend(
            [
                f"{feature}_median",
                f"{feature}_p10",
                f"{feature}_p90",
                f"{feature}_std",
            ]
        )
    write_csv(
        output_dir / "02_file_feature_summary.csv",
        file_feature_rows,
        file_feature_columns,
    )

    # 建立三个模型。
    model_record_groups: Dict[str, List[FileFeatureRecord]] = {
        "0.1mm": records_by_group["0.1mm"],
        "0.5mm": records_by_group["0.5mm"],
        "ALL_LEAKS": all_leak_records,
    }
    models: Dict[str, ReferenceModel] = {}
    validation_rows: List[Dict[str, Any]] = []
    validation_fold_rows: List[Dict[str, Any]] = []
    model_summary_rows: List[Dict[str, Any]] = []

    for model_name, leak_records in model_record_groups.items():
        print(f"\n建立模型: {model_name}，泄漏WAV={len(leak_records)}")
        model = ReferenceModel(
            model_name=model_name,
            feature_names=DISCRIM_COLUMNS,
            accept_probability=cfg.features.accept_probability,
        ).fit(
            model_training_matrix(leak_records, cfg.features),
            shrinkage=cfg.features.covariance_shrinkage,
            ridge=cfg.features.covariance_ridge,
        )

        thresholds: Dict[str, Any] = {
            "available": False,
            "reason": "NO_NOISE_VALIDATION",
            "median_distance_threshold": None,
            "p90_distance_threshold": None,
        }
        oof_rows: List[Dict[str, Any]] = []
        fold_rows: List[Dict[str, Any]] = []
        if cfg.validation.enabled and noise_records:
            try:
                thresholds, oof_rows, fold_rows = grouped_cross_validation(
                    model_name,
                    leak_records,
                    noise_records,
                    cfg.features,
                    cfg.validation,
                )
            except Exception as exc:
                thresholds = {
                    "available": False,
                    "reason": f"CV_FAILED: {type(exc).__name__}: {exc}",
                    "median_distance_threshold": None,
                    "p90_distance_threshold": None,
                }
                errors.append(
                    {
                        "stage": "CROSS_VALIDATION",
                        "group": model_name,
                        "file_path": "",
                        "error": thresholds["reason"],
                    }
                )
        model.thresholds = thresholds
        models[model_name] = model
        validation_rows.extend(oof_rows)
        validation_fold_rows.extend(fold_rows)
        plot_oof_distances(
            output_dir,
            model_name,
            oof_rows,
            thresholds,
            cfg.plots,
        )
        json_path, npz_path = save_model_files(output_dir, model, cfg.features)
        model_summary_rows.append(
            {
                "model_name": model_name,
                "n_leak_files": len(leak_records),
                "n_training_windows": model.n_training_windows,
                "window_distance_threshold": model.window_distance_threshold,
                "file_threshold_available": bool(thresholds.get("available", False)),
                "median_distance_threshold": thresholds.get(
                    "median_distance_threshold"
                ),
                "p90_distance_threshold": thresholds.get("p90_distance_threshold"),
                "cv_balanced_accuracy": thresholds.get("balanced_accuracy"),
                "cv_recall": thresholds.get("recall"),
                "cv_specificity": thresholds.get("specificity"),
                "model_json": str(json_path),
                "model_npz": str(npz_path),
                "status": thresholds.get("reason", "OK"),
            }
        )

    model_summary_columns = [
        "model_name",
        "n_leak_files",
        "n_training_windows",
        "window_distance_threshold",
        "file_threshold_available",
        "median_distance_threshold",
        "p90_distance_threshold",
        "cv_balanced_accuracy",
        "cv_recall",
        "cv_specificity",
        "model_json",
        "model_npz",
        "status",
    ]
    write_csv(
        output_dir / "03_model_summary.csv",
        model_summary_rows,
        model_summary_columns,
    )

    # 所有消声室WAV分别与三个模型比较。
    reference_similarity_rows: List[Dict[str, Any]] = []
    source_records = records_by_group["0.1mm"] + records_by_group["0.5mm"]
    if noise_records:
        source_records += noise_records
    for model in models.values():
        reference_similarity_rows.extend(evaluate_records(model, source_records))
    similarity_columns = [
        "model_name",
        "source_group",
        "file_name",
        "file_path",
        "sample_rate_hz",
        "duration_seconds",
        "n_windows",
        "median_distance",
        "p90_distance",
        "mean_distance",
        "std_distance",
        "window_inside_fraction",
        "median_similarity",
        "p90_guard_similarity",
        "balanced_similarity",
        "prediction",
        "true_label",
        "correct",
    ]
    write_csv(
        output_dir / "04_reference_file_similarity.csv",
        reference_similarity_rows,
        similarity_columns,
    )

    validation_columns = [
        "model_name",
        "fold",
        "source_group",
        "true_label",
        "file_name",
        "file_path",
        "n_windows",
        "median_distance",
        "p90_distance",
        "mean_distance",
        "std_distance",
        "window_inside_fraction",
        "median_similarity",
        "p90_guard_similarity",
        "balanced_similarity",
        "prediction",
        "correct",
    ]
    write_csv(
        output_dir / "05_oof_validation_file_results.csv",
        validation_rows,
        validation_columns,
    )
    write_csv(
        output_dir / "06_oof_validation_folds.csv",
        validation_fold_rows,
        [
            "model_name",
            "fold",
            "n_train_leak_files",
            "n_validation_leak_files",
            "n_validation_noise_files",
            "window_distance_threshold",
        ],
    )

    summaries = feature_summary_rows(
        {
            "0.1mm": records_by_group["0.1mm"],
            "0.5mm": records_by_group["0.5mm"],
            "ALL_LEAKS": all_leak_records,
            **({"NOISE": noise_records} if noise_records else {}),
        }
    )
    summary_columns = [
        "group",
        "feature",
        "n_windows",
        "mean",
        "std",
        "median",
        "p10",
        "p25",
        "p75",
        "p90",
    ]
    write_csv(
        output_dir / "07_group_feature_statistics.csv", summaries, summary_columns
    )

    common_rows = common_feature_rows(summaries)
    common_columns = [
        "feature",
        "group_a",
        "group_b",
        "group_a_p10",
        "group_a_median",
        "group_a_p90",
        "group_b_p10",
        "group_b_median",
        "group_b_p90",
        "common_p10_p90_low",
        "common_p10_p90_high",
        "robust_interval_overlap_ratio",
        "standardized_median_difference",
        "has_robust_common_range",
    ]
    write_csv(
        output_dir / "08_common_feature_ranges_01mm_05mm.csv",
        common_rows,
        common_columns,
    )

    # 保存后续工厂程序直接读取的总清单。
    manifest = {
        "format_version": MODEL_FORMAT_VERSION,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "purpose": "Reference models for factory plane-residual acoustic feature comparison",
        "feature_names": DISCRIM_COLUMNS,
        "feature_extraction": asdict(cfg.features),
        "models": {
            name: {
                "json": str((output_dir / "models" / f"reference_model_{name}.json").resolve()),
                "npz": str((output_dir / "models" / f"reference_model_{name}.npz").resolve()),
                "file_threshold_available": bool(
                    model.thresholds.get("available", False)
                ),
            }
            for name, model in models.items()
        },
        "important_note": (
            "Factory residuals must use exactly the same frequency band, window, hop, Welch, "
            "SNR floor and consistency settings before distance comparison."
        ),
    }
    write_json(output_dir / "09_reference_manifest.json", manifest)

    run_info = {
        "format_version": MODEL_FORMAT_VERSION,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "config": {
            "groups": cfg.groups,
            "noise_paths": cfg.noise_paths,
            "output_dir": str(output_dir),
            "features": asdict(cfg.features),
            "validation": asdict(cfg.validation),
            "plots": asdict(cfg.plots),
        },
        "valid_file_counts": {
            "0.1mm": len(records_by_group["0.1mm"]),
            "0.5mm": len(records_by_group["0.5mm"]),
            "NOISE": len(noise_records),
        },
        "model_names": list(models.keys()),
        "noise_validation_available": bool(noise_records),
        "error_count": len(errors),
    }
    write_json(output_dir / "10_run_info.json", run_info)

    write_csv(
        output_dir / "99_errors.csv",
        errors,
        ["stage", "group", "file_path", "error"],
    )
    plot_feature_distributions(output_dir, records_by_group, cfg.plots)

    print("\n" + "=" * 78)
    print("处理完成")
    print(f"输出目录: {output_dir}")
    print("后续工厂程序最重要的输入:")
    print(f"  {output_dir / '09_reference_manifest.json'}")
    print(f"  {output_dir / 'models'}")
    if not noise_records:
        print("注意：未提供无泄漏噪声，因此已建立参考模型，但没有训练硬判定阈值。")
    print("=" * 78)


# -----------------------------------------------------------------------------
# 自检
# -----------------------------------------------------------------------------

def synth_signal(
    fs: int,
    seconds: float,
    rng: np.random.Generator,
    leak: bool,
    variant: float,
) -> np.ndarray:
    n = int(round(fs * seconds))
    t = np.arange(n, dtype=np.float64) / fs
    background = 0.02 * rng.standard_normal(n)
    if not leak:
        low = 0.04 * np.sin(2 * np.pi * (8_000 + 500 * variant) * t)
        return background + low
    carrier1 = np.sin(2 * np.pi * (28_000 + 600 * variant) * t + 0.3 * variant)
    carrier2 = np.sin(2 * np.pi * (39_000 - 400 * variant) * t)
    modulation = 0.75 + 0.25 * np.sin(2 * np.pi * 7.0 * t + variant)
    broadband = signal.sosfilt(
        signal.butter(4, [18_000, 50_000], btype="bandpass", fs=fs, output="sos"),
        rng.standard_normal(n),
    )
    return background + modulation * (0.08 * carrier1 + 0.05 * carrier2) + 0.025 * broadband


def run_self_test() -> None:
    cfg = FeatureConfig()
    rng = np.random.default_rng(1234)
    fs = 192_000
    leak_records: List[FileFeatureRecord] = []
    noise_records: List[FileFeatureRecord] = []
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        for i in range(6):
            x = synth_signal(fs, 1.2, rng, leak=True, variant=i / 5.0)
            path = root / f"leak_{i}.wav"
            wavfile.write(path, fs, np.int16(np.clip(x, -1, 1) * 32767))
            leak_records.append(extract_file_features(path, "LEAK", cfg))
        for i in range(6):
            x = synth_signal(fs, 1.2, rng, leak=False, variant=i / 5.0)
            path = root / f"noise_{i}.wav"
            wavfile.write(path, fs, np.int16(np.clip(x, -1, 1) * 32767))
            noise_records.append(extract_file_features(path, "NOISE", cfg))

        model = ReferenceModel("SELF_TEST", DISCRIM_COLUMNS, cfg.accept_probability).fit(
            model_training_matrix(leak_records, cfg),
            shrinkage=cfg.covariance_shrinkage,
            ridge=cfg.covariance_ridge,
        )
        leak_stats = [
            model.file_statistics(discrim_matrix(r))["balanced_similarity"]
            for r in leak_records
        ]
        noise_stats = [
            model.file_statistics(discrim_matrix(r))["balanced_similarity"]
            for r in noise_records
        ]
        if not float(np.median(leak_stats)) > float(np.median(noise_stats)):
            raise AssertionError(
                f"自检失败：泄漏中位相似度={np.median(leak_stats):.4f}，"
                f"噪声={np.median(noise_stats):.4f}"
            )
        thresholds, rows, _ = grouped_cross_validation(
            "SELF_TEST", leak_records, noise_records, cfg, ValidationConfig(n_folds=3)
        )
        if not thresholds.get("available", False):
            raise AssertionError(f"自检交叉验证失败: {thresholds}")
        print("自检通过")
        print(f"泄漏中位相似度: {np.median(leak_stats):.6f}")
        print(f"噪声中位相似度: {np.median(noise_stats):.6f}")
        print(f"OOF平衡准确率:  {thresholds['balanced_accuracy']:.6f}")
        print(f"OOF文件数:      {len(rows)}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="建立消声室0.1mm、0.5mm泄漏5维声学特征参考模型"
    )
    parser.add_argument("--config", type=str, help="JSON配置文件路径")
    parser.add_argument("--self-test", action="store_true", help="运行内置自检")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.self_test:
        run_self_test()
        return
    if not args.config:
        raise SystemExit("请使用 --config 指定配置文件，或使用 --self-test")
    cfg = load_config(Path(args.config))
    process_all(cfg)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("用户中止运行", file=sys.stderr)
        raise SystemExit(130)
    except Exception as exc:
        print(f"运行失败: {type(exc).__name__}: {exc}", file=sys.stderr)
        traceback.print_exc()
        raise SystemExit(1)
