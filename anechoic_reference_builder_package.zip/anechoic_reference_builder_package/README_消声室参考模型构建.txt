消声室0.1 mm、0.5 mm泄漏参考模型构建程序
============================================================

一、这一步做什么
------------------------------------------------------------
先处理消声室数据，建立三个冻结参考模型：

1. 0.1mm模型
2. 0.5mm模型
3. ALL_LEAKS模型（0.1mm和0.5mm合并）

后续工厂程序会先对00_00、00_01分别做plane空间拟合，
再提取完全相同的5维特征，并读取本程序保存的模型计算马氏距离和相似度。

这一步暂时只处理“5维声学特征”，不处理截图中的空间方向形态特征。
空间方向形态可以在第二阶段单独建立，避免两套特征混在一起。

二、数据目录
------------------------------------------------------------
建议：

消声室数据\
    0.1mm\
        任意层级子目录\
            *.wav
    0.5mm\
        任意层级子目录\
            *.wav
    无泄漏\
        任意层级子目录\
            *.wav

程序会递归读取所有WAV。

“无泄漏”目录是可选的：
- 有无泄漏WAV：可以做文件级交叉验证并保存判定阈值；
- 没有无泄漏WAV：仍会建立参考模型和相似度模型，但不会生成硬判定阈值。

三、提取的5维判别特征
------------------------------------------------------------
1. spectral_flatness：频谱平坦度
2. spectral_spread_hz：频谱展宽
3. adaptive_snr_db：相对本文件低分位本底的自适应SNR
4. flatness_local_std：平坦度局部波动
5. spread_local_std_hz：展宽局部波动

绝对energy只保存用于检查，不参与马氏距离模型。

默认参数：
- 18-50 kHz
- 100 ms窗口
- 50 ms步长
- Welch NFFT=2048

工厂数据后续必须使用完全相同的参数。

四、运行
------------------------------------------------------------
1. 安装依赖：

    pip install -r requirements.txt

2. 修改：

    anechoic_reference_config.json

只修改0.1mm、0.5mm、无泄漏和输出目录路径即可。

3. 先自检：

    python build_anechoic_reference_models.py --self-test

4. 正式运行：

    python build_anechoic_reference_models.py --config anechoic_reference_config.json

也可以双击：

    run_build_anechoic_reference.bat

五、最重要的输出
------------------------------------------------------------
00_input_scan.csv
    每个WAV是否成功读取、采样率、时长和时间窗数量。

01_window_features.csv
    每个100 ms时间窗的完整特征。文件可能较大。

02_file_feature_summary.csv
    每个WAV的5维特征中位数、p10、p90和标准差。

03_model_summary.csv
    三个模型的训练文件数、窗口数、窗口阈值、交叉验证阈值和验证指标。

04_reference_file_similarity.csv
    每个消声室WAV分别与0.1mm、0.5mm、ALL_LEAKS模型的距离和相似度。

05_oof_validation_file_results.csv
    有无泄漏数据时，文件级交叉验证的独立预测结果。

07_group_feature_statistics.csv
    0.1mm、0.5mm、ALL_LEAKS及可选NOISE的5维特征统计。

08_common_feature_ranges_01mm_05mm.csv
    0.1mm和0.5mm在每个特征上的稳健共同范围及重叠比例。

09_reference_manifest.json
    后续工厂程序应优先读取的模型总清单。

models\reference_model_0.1mm.json/.npz
models\reference_model_0.5mm.json/.npz
models\reference_model_ALL_LEAKS.json/.npz
    后续工厂程序真正使用的冻结模型参数。

99_errors.csv
    读取、采样率、WAV时长或交叉验证错误。

六、相似度的含义
------------------------------------------------------------
模型先计算工厂特征到消声室泄漏簇的马氏距离：

    距离越小，越像消声室泄漏。

再映射为0-1相似度：

    similarity = exp(-0.5 * (distance / window_threshold)^2)

balanced_similarity同时考虑：
- median_distance：整体是否接近；
- p90_distance：大部分时间是否都接近。

七、运行后先检查
------------------------------------------------------------
1. 00_input_scan.csv中0.1mm和0.5mm是否都有OK文件；
2. 03_model_summary.csv中三个模型是否建立成功；
3. 有无泄漏数据时，查看cv_recall、cv_specificity和cv_balanced_accuracy；
4. 检查99_errors.csv是否为空。

注意：如果没有无泄漏数据，不能仅凭一个固定相似度阈值宣称“确定泄漏”；
此时模型适合做相似程度比较和00_00/00_01排序。
