@echo off
chcp 65001 >nul
cd /d "%~dp0"
python build_anechoic_reference_models.py --config anechoic_reference_config.json
if errorlevel 1 (
    echo.
    echo 运行失败，请查看上面的错误信息。
) else (
    echo.
    echo 运行完成。
)
pause
