# -*- coding: utf-8 -*-
"""
AB_lab_raw_plane_group_correlation.py

用途
----
1. 按 methods/raw/residual_npz 与 methods/plane/residual_npz 分别读取 factory_A、factory_B；
2. 对 raw、plane 分别计算 A_TRUE-FALSE 与 B_TRUE-FALSE 的共同泄漏候选频谱；
3. 分别输出 A 与 B 的频谱相似度；
4. 对实验室目录中的每一个 WAV 文件，逐文件计算其频谱与 AB 共同部分的多种相似度；
5. 输出“一行一个WAV”的完整明细；
6. 对每种相似度分别统计各实验室组以及全部WAV文件的中位数、最大值，
   并记录取得最大值的具体WAV文件。

依赖
----
pip install numpy pandas scipy matplotlib

运行
----
python AB_lab_raw_plane_group_correlation.py --self-test
python AB_lab_raw_plane_group_correlation.py --config AB_lab_raw_plane_config.json
"""

from __future__ import annotations

import argparse
import json
import tempfile
import traceback
from dataclasses import asdict, dataclass, field, fields
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    from scipy.io import wavfile
except Exception as exc:
    raise RuntimeError("缺少 scipy，请运行: pip install scipy") from exc

try:
    import AB_lab_commonality_multiscale as core
except Exception as exc:
    raise RuntimeError(
        "无法导入 AB_lab_commonality_multiscale.py，请把两个程序放在同一目录。"
    ) from exc

EPS = 1.0e-20
VALID_LABELS = {"TRUE_LEAK", "FALSE_LEAK"}

SUPPORTED_METHODS = ("raw", "plane")


def lab_similarity_metric_columns(cfg: "RunConfig") -> List[str]:
    """返回所有需要逐WAV计算并汇总的相似度列。"""
    columns = [
        "pearson_correlation_to_AB_common",
        "cosine_similarity_to_AB_common",
        "overlap_similarity_to_AB_common",
        "js_similarity_to_AB_common",
    ]
    for width in cfg.coarse_bandwidths_hz:
        tag = f"{float(width) / 1000:g}kHz"
        columns.extend([
            f"pearson_correlation_{tag}_to_AB_common",
            f"cosine_similarity_{tag}_to_AB_common",
        ])
    return columns


def one_wav_similarity_metrics(
    ab_profile: np.ndarray,
    wav_spectrum: np.ndarray,
    freq_grid: np.ndarray,
    cfg: "RunConfig",
) -> Dict[str, float]:
    """
    只比较“AB共同部分”与“当前这一个WAV文件”的代表频谱。
    不会先把多个WAV合并成实验室组原型。
    """
    result: Dict[str, float] = {
        "pearson_correlation_to_AB_common": core.pearson_safe(ab_profile, wav_spectrum),
        "cosine_similarity_to_AB_common": core.cosine_similarity(ab_profile, wav_spectrum),
        "overlap_similarity_to_AB_common": core.overlap_coefficient(ab_profile, wav_spectrum),
        "js_similarity_to_AB_common": core.js_similarity(ab_profile, wav_spectrum),
    }
    for width in cfg.coarse_bandwidths_hz:
        tag = f"{float(width) / 1000:g}kHz"
        _, ab_coarse = core.coarse_profile(freq_grid, ab_profile, float(width))
        _, wav_coarse = core.coarse_profile(freq_grid, wav_spectrum, float(width))
        result[f"pearson_correlation_{tag}_to_AB_common"] = core.pearson_safe(
            ab_coarse, wav_coarse
        )
        result[f"cosine_similarity_{tag}_to_AB_common"] = core.cosine_similarity(
            ab_coarse, wav_coarse
        )
    return result


@dataclass
class SceneInput:
    name: str
    v9_dir: str


@dataclass
class RunConfig:
    scene_A: SceneInput
    scene_B: SceneInput
    lab_groups: Dict[str, List[str]]
    output_dir: str

    factory_methods: List[str] = field(default_factory=lambda: ["raw", "plane"])

    freq_low_hz: float = 20_000.0
    freq_high_hz: float = 80_000.0
    n_spectral_bins: int = 256
    n_temporal_quantiles: int = 64
    spectral_smooth_bins: int = 5

    bootstrap_iterations: int = 500
    bootstrap_positive_probability: float = 0.90
    min_robust_effect: float = 0.25
    random_state: int = 42

    coarse_bandwidths_hz: List[float] = field(default_factory=lambda: [5_000.0, 10_000.0])

    lab_segment_seconds: float = 1.0
    lab_segment_hop_seconds: float = 0.5
    lab_nperseg: int = 4096
    lab_hop_length: int = 2048
    lab_nfft: int = 4096
    min_segments_per_wav: int = 1

    save_figures: bool = True


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def load_config(path: Path) -> RunConfig:
    payload = json.loads(path.read_text(encoding="utf-8"))
    try:
        scene_a = SceneInput(**payload.pop("scene_A"))
        scene_b = SceneInput(**payload.pop("scene_B"))
        cfg = RunConfig(scene_A=scene_a, scene_B=scene_b, **payload)
    except TypeError as exc:
        raise ValueError(f"配置字段错误: {exc}") from exc

    methods = [str(x).strip().lower() for x in cfg.factory_methods]
    unknown = sorted(set(methods) - set(SUPPORTED_METHODS))
    if unknown:
        raise ValueError(f"factory_methods只支持raw、plane，当前未知值={unknown}")
    cfg.factory_methods = list(dict.fromkeys(methods))

    if not cfg.lab_groups:
        raise ValueError("lab_groups不能为空，例如 {'0.1mm': ['D:/.../0.1mm'], '0.5mm': [...]}")
    return cfg


def core_config(cfg: RunConfig, output_dir: Path) -> core.AnalysisConfig:
    """构造原多尺度算法需要的配置对象。"""
    return core.AnalysisConfig(
        scene_A=core.SceneInput(name=cfg.scene_A.name, v9_dir=cfg.scene_A.v9_dir),
        scene_B=core.SceneInput(name=cfg.scene_B.name, v9_dir=cfg.scene_B.v9_dir),
        lab_wav_paths=[],
        output_dir=str(output_dir),
        residual_variant="plane",
        factory_representation="excess_power",
        freq_low_hz=cfg.freq_low_hz,
        freq_high_hz=cfg.freq_high_hz,
        n_spectral_bins=cfg.n_spectral_bins,
        n_temporal_quantiles=cfg.n_temporal_quantiles,
        spectral_smooth_bins=cfg.spectral_smooth_bins,
        bootstrap_iterations=cfg.bootstrap_iterations,
        bootstrap_positive_probability=cfg.bootstrap_positive_probability,
        min_robust_effect=cfg.min_robust_effect,
        random_state=cfg.random_state,
        coarse_bandwidths_hz=tuple(float(x) for x in cfg.coarse_bandwidths_hz),
        lab_segment_seconds=cfg.lab_segment_seconds,
        lab_segment_hop_seconds=cfg.lab_segment_hop_seconds,
        lab_nperseg=cfg.lab_nperseg,
        lab_hop_length=cfg.lab_hop_length,
        lab_nfft=cfg.lab_nfft,
        min_lab_segments=max(1, cfg.min_segments_per_wav),
        save_figures=cfg.save_figures,
    )


def metadata_path(scene_root: Path, method: str) -> Path:
    candidates = [
        scene_root / "v9_all_features.csv",
        scene_root / "methods" / method / "v9_method_features.csv",
    ]
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(
        f"场景目录缺少标签元数据。至少需要以下文件之一：\n"
        f"  {candidates[0]}\n  {candidates[1]}"
    )


def method_npz_dir(scene_root: Path, method: str) -> Path:
    path = scene_root / "methods" / method / "residual_npz"
    if not path.exists():
        raise FileNotFoundError(f"找不到{method}方法NPZ目录: {path}")
    return path


def build_npz_index(npz_dir: Path) -> Dict[str, Path]:
    index: Dict[str, Path] = {}
    for path in sorted(npz_dir.glob("*.npz")):
        index[path.stem] = path
        index[core.safe_slug(path.stem)] = path
    if not index:
        raise FileNotFoundError(f"目录中没有NPZ: {npz_dir}")
    return index


def resolve_npz(sample_id: str, index: Mapping[str, Path]) -> Optional[Path]:
    sid = str(sample_id).strip()
    slug = core.safe_slug(sid)
    for key in (sid, slug):
        if key in index:
            return index[key]
    unique = sorted({p for stem, p in index.items() if slug and (slug in stem or stem in slug)})
    return unique[0] if len(unique) == 1 else None


def choose_component_key(data: Mapping[str, Any], method: str) -> str:
    if method == "raw":
        candidates = ("component_power", "raw_power")
    elif method == "plane":
        candidates = ("component_power", "excess_power_plane", "excess_power")
    else:
        raise ValueError(f"未知方法: {method}")
    for key in candidates:
        if key in data:
            return key
    raise KeyError(f"{method} NPZ缺少功率字段，尝试过{candidates}，现有字段={list(data.keys())}")


def orient_tf(matrix: np.ndarray, n_freq: int) -> np.ndarray:
    arr = np.asarray(matrix, dtype=float)
    if arr.ndim == 1:
        if arr.size != n_freq:
            raise ValueError(f"一维功率长度{arr.size}与频率长度{n_freq}不一致")
        return arr[:, None]
    if arr.ndim != 2:
        raise ValueError(f"功率矩阵应为二维，当前shape={arr.shape}")
    if arr.shape[0] == n_freq:
        return arr
    if arr.shape[1] == n_freq:
        return arr.T
    raise ValueError(f"无法判断频率轴: matrix={arr.shape}, n_freq={n_freq}")


def sample_fingerprint(
    npz_path: Path,
    method: str,
    freq_grid: np.ndarray,
    cfg: RunConfig,
) -> Tuple[np.ndarray, np.ndarray, str, str]:
    with np.load(npz_path, allow_pickle=False) as data:
        if "freq_hz" not in data:
            raise KeyError("NPZ缺少freq_hz")
        freq = np.asarray(data["freq_hz"], dtype=float).ravel()
        key = choose_component_key(data, method)
        matrix = orient_tf(np.asarray(data[key]), len(freq))
        matrix = np.maximum(np.nan_to_num(matrix, nan=0.0, posinf=0.0, neginf=0.0), 0.0)

        mask = (freq >= cfg.freq_low_hz) & (freq <= cfg.freq_high_hz)
        if int(np.sum(mask)) < 5:
            raise ValueError("NPZ在目标频带内频点不足")
        f = freq[mask]
        m = matrix[mask]

        spectrum_native = np.sqrt(np.maximum(np.mean(m, axis=1), 0.0))
        spectrum_native = core.smooth_1d(spectrum_native, cfg.spectral_smooth_bins)
        spectrum = core.normalize_nonnegative(core.interp_vector(f, spectrum_native, freq_grid))

        frame_signal = np.sum(m, axis=0)
        bg_key = ""
        if method == "plane":
            for candidate in ("background_power_db", "background_power_db_plane"):
                if candidate in data:
                    bg_key = candidate
                    break
        if bg_key:
            bg_db = orient_tf(np.asarray(data[bg_key]), len(freq))[mask]
            bg_power = np.power(10.0, np.clip(bg_db, -300.0, 300.0) / 10.0)
            frame_bg = np.sum(bg_power, axis=0)
            frame_measure = np.log1p(frame_signal / (frame_bg + EPS))
        else:
            positive = frame_signal[frame_signal > 0]
            scale = float(np.median(positive)) if positive.size else 1.0
            frame_measure = np.log1p(frame_signal / max(scale, EPS))

        frame_measure = np.nan_to_num(frame_measure, nan=0.0, posinf=0.0, neginf=0.0)
        temporal = np.quantile(frame_measure, np.linspace(0.0, 1.0, cfg.n_temporal_quantiles))
        q95 = float(np.quantile(temporal, 0.95)) if temporal.size else 0.0
        if q95 > EPS:
            temporal = np.clip(temporal / q95, 0.0, None)
    return spectrum, temporal, key, bg_key


def load_scene_method(
    scene: SceneInput,
    method: str,
    freq_grid: np.ndarray,
    cfg: RunConfig,
) -> Tuple[pd.DataFrame, np.ndarray, np.ndarray, pd.DataFrame]:
    root = Path(scene.v9_dir)
    csv_path = metadata_path(root, method)
    npz_dir = method_npz_dir(root, method)
    index = build_npz_index(npz_dir)

    df = pd.read_csv(csv_path, dtype={"sample_id": str, "center": str, "time": str})
    required = ["sample_id", "label"]
    missing = [x for x in required if x not in df.columns]
    if missing:
        raise ValueError(f"{csv_path}缺少列: {missing}")
    df["label"] = df["label"].astype(str).str.upper().str.strip()
    df = df[df["label"].isin(VALID_LABELS)].drop_duplicates("sample_id").reset_index(drop=True)
    if df.empty:
        raise ValueError(f"{csv_path}没有TRUE_LEAK/FALSE_LEAK样本")

    used_rows: List[Dict[str, Any]] = []
    spectra: List[np.ndarray] = []
    temporals: List[np.ndarray] = []
    log_rows: List[Dict[str, Any]] = []

    for _, row in df.iterrows():
        sample_id = str(row["sample_id"])
        npz_path = resolve_npz(sample_id, index)
        if npz_path is None:
            log_rows.append({
                "scene": scene.name, "method": method, "sample_id": sample_id,
                "label": row["label"], "status": "FAILED", "error": "找不到对应NPZ",
            })
            continue
        try:
            spec, temp, matrix_key, bg_key = sample_fingerprint(npz_path, method, freq_grid, cfg)
            spectra.append(spec)
            temporals.append(temp)
            used_rows.append({
                "sample_id": sample_id,
                "label": row["label"],
                "dataset": str(row.get("dataset", "")),
                "scene": scene.name,
                "time": str(row.get("time", "")),
                "center": str(row.get("center", "")),
                "npz_path": str(npz_path),
            })
            log_rows.append({
                "scene": scene.name, "method": method, "sample_id": sample_id,
                "label": row["label"], "status": "OK", "npz_path": str(npz_path),
                "matrix_key": matrix_key, "background_key": bg_key, "error": "",
            })
        except Exception as exc:
            log_rows.append({
                "scene": scene.name, "method": method, "sample_id": sample_id,
                "label": row["label"], "status": "FAILED", "npz_path": str(npz_path),
                "error": f"{type(exc).__name__}: {exc}", "traceback": traceback.format_exc(),
            })

    used = pd.DataFrame(used_rows)
    if used.empty:
        raise RuntimeError(f"{scene.name}的{method}没有成功读取任何样本")
    labels = set(used["label"])
    if labels != VALID_LABELS:
        raise ValueError(f"{scene.name}的{method}必须同时包含TRUE/FALSE，当前={sorted(labels)}")
    return used, np.vstack(spectra), np.vstack(temporals), pd.DataFrame(log_rows)


def lab_file_fingerprint(
    wav_path: Path,
    freq_grid: np.ndarray,
    cfg: RunConfig,
    algorithm_cfg: core.AnalysisConfig,
) -> Tuple[np.ndarray, np.ndarray, int]:
    fs, x = core.read_wav_preserve_scale(wav_path)
    segments = core.segment_signal(x, fs, cfg.lab_segment_seconds, cfg.lab_segment_hop_seconds)
    spectra: List[np.ndarray] = []
    temporals: List[np.ndarray] = []
    for segment in segments:
        try:
            fp = core.lab_segment_fingerprint(segment, fs, freq_grid, algorithm_cfg)
            spectra.append(np.asarray(fp["spectrum"], dtype=float))
            temporals.append(np.asarray(fp["temporal"], dtype=float))
        except Exception:
            continue
    if len(spectra) < max(1, int(cfg.min_segments_per_wav)):
        raise ValueError(
            f"有效切片只有{len(spectra)}个，少于min_segments_per_wav={cfg.min_segments_per_wav}"
        )
    spectrum = core.normalize_nonnegative(np.median(np.vstack(spectra), axis=0))
    temporal = np.median(np.vstack(temporals), axis=0)
    return spectrum, temporal, len(spectra)


def coarse_similarity_rows(
    freq_grid: np.ndarray,
    a_profile: np.ndarray,
    b_profile: np.ndarray,
    widths: Sequence[float],
) -> Dict[str, float]:
    out: Dict[str, float] = {}
    for width in widths:
        _, a = core.coarse_profile(freq_grid, a_profile, float(width))
        _, b = core.coarse_profile(freq_grid, b_profile, float(width))
        tag = f"{float(width)/1000:g}kHz"
        out[f"A_B_cosine_{tag}"] = core.cosine_similarity(a, b)
        out[f"A_B_pearson_{tag}"] = core.pearson_safe(a, b)
    return out


def analyze_lab_groups(
    method: str,
    ab_profile: np.ndarray,
    freq_grid: np.ndarray,
    cfg: RunConfig,
    algorithm_cfg: core.AnalysisConfig,
) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, np.ndarray]]:
    """
    对每个实验室WAV逐文件计算相似度。

    明细表：
        一行 = method × 一个真实WAV文件

    汇总表：
        对每一种相似度分别输出：
        - 各lab_group（例如0.1mm、0.5mm）的中位数和最大值；
        - ALL_FILES（所有实验室WAV合并）的中位数和最大值；
        - 每个最大值对应的WAV名称与完整路径。
    """
    rows: List[Dict[str, Any]] = []
    spectra_by_group: Dict[str, List[np.ndarray]] = {}
    discovered_counts: Dict[str, int] = {}
    metric_cols = lab_similarity_metric_columns(cfg)

    for group, paths in cfg.lab_groups.items():
        group_name = str(group)
        wavs = core.discover_wavs(paths)
        discovered_counts[group_name] = len(wavs)
        spectra_by_group[group_name] = []

        if not wavs:
            rows.append({
                "method": method,
                "lab_group": group_name,
                "wav_index_in_group": np.nan,
                "wav_name": "",
                "wav_stem": "",
                "wav_file": "",
                "comparison_unit": "ONE_WAV_FILE",
                "status": "NO_WAV_FOUND",
                "n_valid_segments": 0,
                "error": f"没有找到WAV，输入={paths}",
            })
            continue

        for wav_index, wav in enumerate(wavs, start=1):
            base_row: Dict[str, Any] = {
                "method": method,
                "lab_group": group_name,
                "wav_index_in_group": int(wav_index),
                "wav_name": wav.name,
                "wav_stem": wav.stem,
                "wav_file": str(wav),
                "comparison_unit": "ONE_WAV_FILE",
            }
            try:
                spectrum, temporal, n_segments = lab_file_fingerprint(
                    wav, freq_grid, cfg, algorithm_cfg
                )
                spectra_by_group[group_name].append(spectrum)

                row = {
                    **base_row,
                    "status": "OK",
                    "n_valid_segments": int(n_segments),
                    **one_wav_similarity_metrics(
                        ab_profile=ab_profile,
                        wav_spectrum=spectrum,
                        freq_grid=freq_grid,
                        cfg=cfg,
                    ),
                    "error": "",
                }
                rows.append(row)
            except Exception as exc:
                rows.append({
                    **base_row,
                    "status": "FAILED",
                    "n_valid_segments": 0,
                    "error": f"{type(exc).__name__}: {exc}",
                })

    detail = pd.DataFrame(rows)

    # 保证失败情况下也存在所有相似度列，方便输出固定格式。
    for column in metric_cols:
        if column not in detail.columns:
            detail[column] = np.nan

    summary_rows: List[Dict[str, Any]] = []
    summary_targets: List[Tuple[str, Optional[str]]] = [
        (str(group), str(group)) for group in cfg.lab_groups
    ]
    summary_targets.append(("ALL_FILES", None))

    successful_all = detail[detail["status"].astype(str).eq("OK")].copy()
    for output_group, group_filter in summary_targets:
        if group_filter is None:
            part = successful_all.copy()
            discovered = int(sum(discovered_counts.values()))
        else:
            part = successful_all[
                successful_all["lab_group"].astype(str).eq(group_filter)
            ].copy()
            discovered = int(discovered_counts.get(group_filter, 0))

        row: Dict[str, Any] = {
            "method": method,
            "summary_scope": (
                "ALL_LAB_WAV_FILES" if group_filter is None else "ONE_LAB_GROUP"
            ),
            "lab_group": output_group,
            "n_wavs_discovered": discovered,
            "n_wavs_success": int(len(part)),
            "n_wavs_failed": int(max(discovered - len(part), 0)),
        }

        for column in metric_cols:
            values = pd.to_numeric(part[column], errors="coerce")
            valid = values[np.isfinite(values)]

            row[f"{column}_median"] = (
                float(valid.median()) if len(valid) else np.nan
            )
            row[f"{column}_max"] = (
                float(valid.max()) if len(valid) else np.nan
            )

            max_name_key = f"{column}_max_wav_name"
            max_file_key = f"{column}_max_wav_file"
            if len(valid):
                best_idx = valid.idxmax()
                row[max_name_key] = str(part.loc[best_idx, "wav_name"])
                row[max_file_key] = str(part.loc[best_idx, "wav_file"])
            else:
                row[max_name_key] = ""
                row[max_file_key] = ""

        summary_rows.append(row)

    group_prototypes: Dict[str, np.ndarray] = {}
    for group, specs in spectra_by_group.items():
        if specs:
            # 仅用于画图，不用于逐WAV相似度计算。
            group_prototypes[group] = core.normalize_nonnegative(
                np.median(np.vstack(specs), axis=0)
            )

    return detail, pd.DataFrame(summary_rows), group_prototypes


def save_method_figure(
    output_dir: Path,
    method: str,
    freq_grid: np.ndarray,
    ab: Dict[str, np.ndarray],
    group_prototypes: Dict[str, np.ndarray],
) -> Optional[Path]:
    if not group_prototypes:
        return None
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig_dir = output_dir / "figures"
        ensure_dir(fig_dir)
        plt.figure(figsize=(11, 5.5))
        plt.plot(freq_grid / 1000.0, ab["a_profile"], label="A TRUE-FALSE")
        plt.plot(freq_grid / 1000.0, ab["b_profile"], label="B TRUE-FALSE")
        plt.plot(freq_grid / 1000.0, ab["common"], linewidth=2.3, label="AB common")
        for group, spectrum in group_prototypes.items():
            plt.plot(freq_grid / 1000.0, spectrum, label=f"Lab {group} median")
        plt.xlabel("Frequency (kHz)")
        plt.ylabel("Normalized spectrum")
        plt.title(f"{method}: AB common vs laboratory WAV groups")
        plt.grid(True, alpha=0.25)
        plt.legend()
        plt.tight_layout()
        path = fig_dir / f"{method}_AB_vs_lab_groups.png"
        plt.savefig(path, dpi=160)
        plt.close()
        return path
    except Exception as exc:
        print(f"  [图失败] {method}: {exc}")
        return None


def run_method(
    method: str,
    cfg: RunConfig,
    root_output: Path,
    freq_grid: np.ndarray,
) -> Dict[str, Path]:
    output_dir = root_output / method
    ensure_dir(output_dir)
    algorithm_cfg = core_config(cfg, output_dir)
    rng = np.random.default_rng(cfg.random_state)

    print("\n" + "=" * 100)
    print(f"方法: {method}")
    print("=" * 100)

    a_df, a_spec, a_temp, a_log = load_scene_method(cfg.scene_A, method, freq_grid, cfg)
    b_df, b_spec, b_temp, b_log = load_scene_method(cfg.scene_B, method, freq_grid, cfg)
    print(f"  A成功样本={len(a_df)}，TRUE={sum(a_df.label=='TRUE_LEAK')}，FALSE={sum(a_df.label=='FALSE_LEAK')}")
    print(f"  B成功样本={len(b_df)}，TRUE={sum(b_df.label=='TRUE_LEAK')}，FALSE={sum(b_df.label=='FALSE_LEAK')}")

    a_contrast = core.scene_contrast(a_spec, a_df["label"].to_numpy(), algorithm_cfg, rng)
    b_contrast = core.scene_contrast(b_spec, b_df["label"].to_numpy(), algorithm_cfg, rng)
    ab = core.build_ab_common(a_contrast, b_contrast)

    metrics: Dict[str, Any] = {
        "method": method,
        "A_B_pearson_fine": core.pearson_safe(ab["a_profile"], ab["b_profile"]),
        "A_B_cosine_fine": core.cosine_similarity(ab["a_profile"], ab["b_profile"]),
        "A_B_overlap_fine": core.overlap_coefficient(ab["a_profile"], ab["b_profile"]),
        "A_B_js_similarity_fine": core.js_similarity(ab["a_profile"], ab["b_profile"]),
        "A_stable_TRUE_bins": int(np.sum(a_contrast["stable_positive"])),
        "B_stable_TRUE_bins": int(np.sum(b_contrast["stable_positive"])),
        "AB_strict_common_bins": int(np.sum(ab["strict_mask"])),
    }
    metrics.update(coarse_similarity_rows(
        freq_grid, ab["a_profile"], ab["b_profile"], cfg.coarse_bandwidths_hz
    ))

    detail, group_summary, group_prototypes = analyze_lab_groups(
        method, ab["common"], freq_grid, cfg, algorithm_cfg
    )

    metrics_csv = output_dir / "AB_similarity_metrics.csv"
    spectrum_csv = output_dir / "AB_common_spectrum.csv"
    details_csv = output_dir / "lab_wav_similarity_each_file.csv"
    summary_csv = output_dir / "lab_wav_similarity_statistics.csv"
    legacy_details_csv = output_dir / "lab_wav_correlation_details.csv"
    legacy_summary_csv = output_dir / "lab_group_correlation_summary.csv"
    mapping_csv = output_dir / "factory_input_mapping_and_quality.csv"
    report_path = output_dir / "analysis_report.txt"

    pd.DataFrame([metrics]).to_csv(metrics_csv, index=False, encoding="utf-8-sig")
    pd.DataFrame({
        "frequency_hz": freq_grid,
        "frequency_khz": freq_grid / 1000.0,
        "A_positive_profile": ab["a_profile"],
        "B_positive_profile": ab["b_profile"],
        "AB_strict_supported": ab["strict_mask"].astype(int),
        "AB_soft_common": ab["soft_common"],
        "AB_common": ab["common"],
    }).to_csv(spectrum_csv, index=False, encoding="utf-8-sig")
    detail.to_csv(details_csv, index=False, encoding="utf-8-sig")
    group_summary.to_csv(summary_csv, index=False, encoding="utf-8-sig")
    # 同时保留旧文件名，避免用户旧流程失效。
    detail.to_csv(legacy_details_csv, index=False, encoding="utf-8-sig")
    group_summary.to_csv(legacy_summary_csv, index=False, encoding="utf-8-sig")
    pd.concat([a_log, b_log], ignore_index=True).to_csv(mapping_csv, index=False, encoding="utf-8-sig")

    lines = [
        f"AB与实验室WAV分析报告 | method={method}",
        "=" * 90,
        f"A目录: {cfg.scene_A.v9_dir}",
        f"B目录: {cfg.scene_B.v9_dir}",
        f"A/B Pearson: {metrics['A_B_pearson_fine']:.6f}",
        f"A/B Cosine: {metrics['A_B_cosine_fine']:.6f}",
        f"AB严格共同频点: {metrics['AB_strict_common_bins']}",
        "",
        "逐WAV比较：每个WAV先单独与AB共同部分计算相似度。",
        "以下为各组以及ALL_FILES的Pearson统计：",
    ]
    for _, row in group_summary.iterrows():
        lines.append(
            f"  {row['lab_group']}: 成功WAV={int(row['n_wavs_success'])}, "
            f"中位数={row['pearson_correlation_to_AB_common_median']:.6f}, "
            f"最大值={row['pearson_correlation_to_AB_common_max']:.6f}"
        )
    report_path.write_text("\n".join(lines), encoding="utf-8")

    if cfg.save_figures:
        save_method_figure(output_dir, method, freq_grid, ab, group_prototypes)

    print(f"  A/B Pearson={metrics['A_B_pearson_fine']:.4f}，Cosine={metrics['A_B_cosine_fine']:.4f}")
    for _, row in group_summary.iterrows():
        print(
            f"  {row['lab_group']}: Pearson中位数="
            f"{row['pearson_correlation_to_AB_common_median']:.4f}，最大值="
            f"{row['pearson_correlation_to_AB_common_max']:.4f}"
        )
    return {
        "metrics": metrics_csv,
        "spectrum": spectrum_csv,
        "details": details_csv,
        "summary": summary_csv,
        "report": report_path,
    }


def run_analysis(cfg: RunConfig) -> Dict[str, Path]:
    output_root = Path(cfg.output_dir)
    ensure_dir(output_root)
    freq_grid = np.linspace(cfg.freq_low_hz, cfg.freq_high_hz, cfg.n_spectral_bins)

    method_outputs: Dict[str, Dict[str, Path]] = {}
    for method in cfg.factory_methods:
        method_outputs[method] = run_method(method, cfg, output_root, freq_grid)

    metric_frames = [pd.read_csv(v["metrics"]) for v in method_outputs.values()]
    detail_frames = [pd.read_csv(v["details"]) for v in method_outputs.values()]
    summary_frames = [pd.read_csv(v["summary"]) for v in method_outputs.values()]

    combined_metrics = output_root / "raw_plane_AB_similarity_comparison.csv"
    combined_details = output_root / "all_methods_lab_wav_similarity_each_file.csv"
    combined_summary = output_root / "all_methods_lab_wav_similarity_statistics.csv"
    legacy_combined_summary = output_root / "raw_plane_lab_group_correlation_summary.csv"
    wide_details = output_root / "lab_wav_similarity_raw_plane_wide.csv"

    pd.concat(metric_frames, ignore_index=True).to_csv(
        combined_metrics, index=False, encoding="utf-8-sig"
    )

    all_details = pd.concat(detail_frames, ignore_index=True)
    all_details.to_csv(combined_details, index=False, encoding="utf-8-sig")

    all_summary = pd.concat(summary_frames, ignore_index=True)
    all_summary.to_csv(combined_summary, index=False, encoding="utf-8-sig")
    all_summary.to_csv(legacy_combined_summary, index=False, encoding="utf-8-sig")

    # 宽表：同一个WAV的raw、plane相似度并排，便于直接比较。
    ok_details = all_details[all_details["status"].astype(str).eq("OK")].copy()
    metric_cols = [
        column for column in lab_similarity_metric_columns(cfg)
        if column in ok_details.columns
    ]
    if not ok_details.empty and metric_cols:
        wide = ok_details.pivot_table(
            index=["lab_group", "wav_name", "wav_file", "n_valid_segments"],
            columns="method",
            values=metric_cols,
            aggfunc="first",
        )
        wide.columns = [
            f"{method}_{metric}"
            for metric, method in wide.columns.to_flat_index()
        ]
        wide.reset_index().to_csv(wide_details, index=False, encoding="utf-8-sig")
    else:
        pd.DataFrame().to_csv(wide_details, index=False, encoding="utf-8-sig")
    (output_root / "AB_lab_raw_plane_run_config.json").write_text(
        json.dumps(asdict(cfg), ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print("\n" + "=" * 100)
    print("raw/plane分析完成")
    print("A/B方法对比:", combined_metrics)
    print("每个实验室WAV的逐文件相似度:", combined_details)
    print("每种相似度的中位数/最大值:", combined_summary)
    print("raw/plane并排宽表:", wide_details)
    print("=" * 100)
    return {
        "combined_metrics": combined_metrics,
        "combined_details": combined_details,
        "combined_summary": combined_summary,
        "wide_details": wide_details,
    }


def synthetic_npz(path: Path, label: str, method: str, rng: np.random.Generator) -> None:
    freq = np.linspace(20_000.0, 80_000.0, 256)
    n_frames = 20
    base = 0.05 + 0.01 * rng.random((len(freq), n_frames))
    leak_shape = np.exp(-0.5 * ((freq - 57_000.0) / 3_000.0) ** 2)[:, None]
    boost = 0.30 if label == "TRUE_LEAK" else 0.02
    if method == "raw":
        matrix = base + boost * leak_shape
        bg_db = np.full_like(matrix, -300.0)
    else:
        matrix = 0.30 * base + boost * leak_shape
        bg_db = 10.0 * np.log10(base + EPS)
    ensure_dir(path.parent)
    payload = {
        "freq_hz": freq,
        "component_power": matrix,
        "background_power_db": bg_db,
        "method": np.asarray(method),
    }
    if method == "raw":
        payload["raw_power"] = matrix
    else:
        payload["excess_power_plane"] = matrix
    np.savez_compressed(path, **payload)


def synthetic_wav(path: Path, diameter: str, rng: np.random.Generator) -> None:
    fs = 192_000
    seconds = 2.5
    t = np.arange(int(fs * seconds)) / fs
    amp = 0.65 if diameter == "0.5mm" else 0.40
    x = (
        amp * np.sin(2 * np.pi * 57_000.0 * t)
        + 0.25 * np.sin(2 * np.pi * 61_000.0 * t)
        + 0.04 * rng.standard_normal(len(t))
    )
    x = np.clip(x / max(np.max(np.abs(x)), EPS), -1.0, 1.0)
    ensure_dir(path.parent)
    wavfile.write(str(path), fs, (x * 32767).astype(np.int16))


def run_self_test() -> None:
    rng = np.random.default_rng(123)
    with tempfile.TemporaryDirectory(prefix="ab_lab_raw_plane_") as tmp:
        root = Path(tmp)
        for scene in ("factory_A", "factory_B"):
            scene_root = root / scene
            metadata: List[Dict[str, Any]] = []
            for label in ("TRUE_LEAK", "FALSE_LEAK"):
                for i in range(4):
                    sid = f"{scene}_{label}_{i}"
                    metadata.append({
                        "sample_id": sid, "dataset": scene, "scene": scene,
                        "time": f"00_{i:02d}", "center": str(i), "label": label,
                    })
                    for method in SUPPORTED_METHODS:
                        synthetic_npz(
                            scene_root / "methods" / method / "residual_npz" / f"{core.safe_slug(sid)}.npz",
                            label, method, rng,
                        )
            pd.DataFrame(metadata).to_csv(
                scene_root / "v9_all_features.csv", index=False, encoding="utf-8-sig"
            )

        for group in ("0.1mm", "0.5mm"):
            for i in range(3):
                synthetic_wav(root / "lab" / group / f"{group}_{i}.wav", group, rng)

        cfg = RunConfig(
            scene_A=SceneInput("factory_A", str(root / "factory_A")),
            scene_B=SceneInput("factory_B", str(root / "factory_B")),
            lab_groups={
                "0.1mm": [str(root / "lab" / "0.1mm")],
                "0.5mm": [str(root / "lab" / "0.5mm")],
            },
            output_dir=str(root / "out"),
            bootstrap_iterations=20,
            save_figures=False,
        )
        paths = run_analysis(cfg)
        metrics = pd.read_csv(paths["combined_metrics"])
        details = pd.read_csv(paths["combined_details"])
        summary = pd.read_csv(paths["combined_summary"])

        if set(metrics["method"]) != {"raw", "plane"}:
            raise AssertionError("自检失败：缺少raw或plane结果")

        ok_details = details[details["status"].astype(str).eq("OK")]
        expected_detail_rows = 2 * 2 * 3  # 2 methods × 2 groups × 3 WAV
        if len(ok_details) != expected_detail_rows:
            raise AssertionError(
                f"自检失败：逐WAV明细应有{expected_detail_rows}行，实际={len(ok_details)}"
            )
        if ok_details.duplicated(["method", "wav_file"]).any():
            raise AssertionError("自检失败：同一method下某个WAV出现重复行")

        if set(summary["lab_group"]) != {"0.1mm", "0.5mm", "ALL_FILES"}:
            raise AssertionError("自检失败：汇总缺少0.1mm、0.5mm或ALL_FILES")
        if len(summary) != 6:
            raise AssertionError(f"自检失败：汇总应为6行，实际={len(summary)}")

        required = set()
        for metric in lab_similarity_metric_columns(cfg):
            required.update({
                f"{metric}_median",
                f"{metric}_max",
                f"{metric}_max_wav_name",
                f"{metric}_max_wav_file",
            })
        if not required.issubset(summary.columns):
            missing = sorted(required - set(summary.columns))
            raise AssertionError(f"自检失败：汇总缺少列={missing}")

        print("SELF-TEST PASSED")


def main() -> None:
    parser = argparse.ArgumentParser(description="raw/plane下逐WAV计算AB共同部分相似度，并汇总各指标中位数和最大值")
    parser.add_argument("--config", type=str, help="配置JSON")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        run_self_test()
        return
    if not args.config:
        parser.error("请提供--config，或使用--self-test")
    run_analysis(load_config(Path(args.config)))


if __name__ == "__main__":
    main()
