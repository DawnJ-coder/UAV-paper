AB共同部分与每个实验室WAV逐文件相似度程序
================================================

一、这次修改后的正确计算单位
----------------------------

每一个实验室WAV文件单独计算一次：

    AB共同部分  vs  当前这一个WAV文件

不会先把0.1mm目录或0.5mm目录中的多个WAV合并后再只计算一个结果。

一个WAV文件内部如果较长，程序会先切成多个时间片段；
这些片段只用于形成“该WAV文件自己的代表频谱”，不会被当成多个独立WAV。

因此最终明细表中：

    一行 = 一种方法(raw/plane) × 一个真实WAV文件


二、每个WAV输出的相似度
----------------------

每个WAV都会输出：

1. pearson_correlation_to_AB_common
2. cosine_similarity_to_AB_common
3. overlap_similarity_to_AB_common
4. js_similarity_to_AB_common
5. pearson_correlation_5kHz_to_AB_common
6. cosine_similarity_5kHz_to_AB_common
7. pearson_correlation_10kHz_to_AB_common
8. cosine_similarity_10kHz_to_AB_common


三、汇总统计
------------

程序对上面的每一种相似度分别输出：

1. 0.1mm目录下所有成功WAV的中位数、最大值
2. 0.5mm目录下所有成功WAV的中位数、最大值
3. ALL_FILES：0.1mm与0.5mm全部成功WAV合并后的中位数、最大值
4. 每一个最大值对应的WAV文件名和完整路径

raw和plane分别统计，不会混合。


四、配置路径
------------

修改 AB_lab_raw_plane_config.json：

{
  "scene_A": {
    "name": "factory_A",
    "v9_dir": "D:\\wurenji\\factory_A_v9_results"
  },
  "scene_B": {
    "name": "factory_B",
    "v9_dir": "D:\\wurenji\\factory_B_v9_results"
  },
  "lab_groups": {
    "0.1mm": [
      "D:\\wurenji\\0.1mm"
    ],
    "0.5mm": [
      "D:\\wurenji\\0.5mm"
    ]
  },
  "output_dir": "D:\\wurenji\\AB_lab_raw_plane_results"
}

程序会递归读取0.1mm和0.5mm目录及其子目录中的全部.wav文件。


五、运行
--------

先自检：

    python AB_lab_raw_plane_group_correlation.py --self-test

正式运行：

    python AB_lab_raw_plane_group_correlation.py --config AB_lab_raw_plane_config.json

也可以直接双击：

    run_AB_lab_raw_plane.bat


六、最重要的输出文件
--------------------

1. 每个WAV逐文件明细：

    all_methods_lab_wav_similarity_each_file.csv

一行对应一个 method × WAV。

主要列：

    method
    lab_group
    wav_name
    wav_file
    n_valid_segments
    pearson_correlation_to_AB_common
    cosine_similarity_to_AB_common
    overlap_similarity_to_AB_common
    js_similarity_to_AB_common
    pearson_correlation_5kHz_to_AB_common
    cosine_similarity_5kHz_to_AB_common
    pearson_correlation_10kHz_to_AB_common
    cosine_similarity_10kHz_to_AB_common


2. 每种相似度的中位数、最大值：

    all_methods_lab_wav_similarity_statistics.csv

正常包含六行：

    raw   0.1mm
    raw   0.5mm
    raw   ALL_FILES
    plane 0.1mm
    plane 0.5mm
    plane ALL_FILES

对于每一种相似度，都有：

    <相似度列>_median
    <相似度列>_max
    <相似度列>_max_wav_name
    <相似度列>_max_wav_file


3. raw与plane并排对比：

    lab_wav_similarity_raw_plane_wide.csv

同一个WAV的raw、plane相似度会放在同一行，方便直接比较。


七、各方法子目录
----------------

raw目录：

    raw\lab_wav_similarity_each_file.csv
    raw\lab_wav_similarity_statistics.csv

plane目录：

    plane\lab_wav_similarity_each_file.csv
    plane\lab_wav_similarity_statistics.csv


八、说明
--------

实验室组的中位频谱仍可能用于绘图展示，但绝不会用于替代逐WAV相似度计算。
逐WAV相似度始终由：

    AB共同部分  vs  当前单个WAV的代表频谱

直接计算。
