# -*- coding: utf-8 -*-
"""
消声室引导的半监督泄漏/背景分离
================================

目标：
    中心波束 X0 = S0 + N0
    周围波束 Xi = Si + Ni

程序不把任意周围点直接当背景，也不做中心减40/80 cm。
它先用消声室 0.1 mm / 0.5 mm WAV 建立冻结泄漏频谱字典，
再用当前中心附带的周围波束学习当前现场噪声字典，最后将中心
分解为泄漏功率和噪声功率，并通过软掩膜输出泄漏 WAV 与噪声 WAV。

安装：
    pip install numpy pandas scipy matplotlib scikit-learn

自检：
    python anechoic_semisupervised_leak_separation.py --self-test

正式运行：
    python anechoic_semisupervised_leak_separation.py --config anechoic_semisupervised_config.json
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import sys
import tempfile
import traceback
from dataclasses import asdict, dataclass, fields
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import signal
from scipy.io import wavfile
from scipy.spatial.distance import jensenshannon
from sklearn.decomposition import NMF

EPS = 1.0e-20

DIRECTIONS = [
    "up",
    "down",
    "left",
    "right",
    "up_left",
    "down_left",
    "up_right",
    "down_right",
]
DIRECTION_ANGLES = {
    "up": np.pi / 2,
    "down": -np.pi / 2,
    "left": np.pi,
    "right": 0.0,
    "up_left": 3 * np.pi / 4,
    "down_left": -3 * np.pi / 4,
    "up_right": np.pi / 4,
    "down_right": -np.pi / 4,
}
DIRECTION_RE = "|".join(re.escape(x) for x in sorted(DIRECTIONS, key=len, reverse=True))
CENTER_RE = re.compile(r"(?P<center>\d+(?:_\d+)?)_beamform_result\.wav$", re.I)
OFFSET_RE = re.compile(
    rf"(?P<center>\d+(?:_\d+)?)d(?P<distance>\d+)_(?P<direction>{DIRECTION_RE})(?P<suffix>.*?)\.wav$",
    re.I,
)


@dataclass
class AlgorithmConfig:
    freq_low_hz: float = 50_000.0
    freq_high_hz: float = 70_000.0
    diagnostic_low_hz: float = 20_000.0
    diagnostic_high_hz: float = 80_000.0
    expected_sample_rate_hz: int = 192_000
    time_slice_seconds: float = 1.0
    segment_mode: str = "indexed"  # indexed / first / auto
    strict_time_slice: bool = True
    nperseg: int = 4096
    hop_length: int = 2048
    nfft: int = 4096
    leak_components: int = 8
    noise_components: int = 12
    lab_train_fraction: float = 0.70
    random_state: int = 42
    max_lab_seconds_per_file: float = 30.0
    max_lab_training_frames: int = 20_000
    max_reference_training_frames: int = 30_000
    nmf_max_iter: int = 350
    joint_refine_iterations: int = 180
    inference_iterations: int = 220
    leak_activation_l1_ratio: float = 0.015
    noise_activation_l1_ratio: float = 0.002
    noise_candidate_fraction: float = 0.60
    noise_leak_repel_strength: float = 0.35
    min_neighbors: int = 64
    min_lab_files_per_group: int = 2
    minimum_frequency_bins: int = 50
    amplitude_peak_fullscale_threshold: float = 0.985
    amplitude_uniform_peak_cv_threshold: float = 0.015
    amplitude_uniform_rms_cv_threshold: float = 0.020
    save_plots: bool = True
    save_npz: bool = True
    save_wavs: bool = True
    plot_limit: int = 80


@dataclass
class FactoryDataset:
    name: str
    center_root_dir: str
    offset_root_dirs: List[str]
    time_folders: List[str]
    label_by_folder: Dict[str, str]


@dataclass
class RunConfig:
    lab_groups: Dict[str, List[str]]
    factory_datasets: List[FactoryDataset]
    output_dir: str
    algorithm: AlgorithmConfig


@dataclass
class WavSlice:
    path: Path
    fs: int
    x: np.ndarray
    original_dtype: str
    duration_seconds: float
    segment_start_seconds: float
    segment_end_seconds: float
    peak: float
    rms: float
    clipping_fraction: float


@dataclass
class SpatialFile:
    center_id: str
    distance_cm: int
    direction: str
    path: Path
    x_cm: float
    y_cm: float


def dataclass_from_dict(cls: Any, values: Optional[Mapping[str, Any]]) -> Any:
    raw = dict(values or {})
    allowed = {f.name for f in fields(cls)}
    return cls(**{k: v for k, v in raw.items() if k in allowed})


def load_config(path: Path) -> RunConfig:
    with path.open("r", encoding="utf-8-sig") as f:
        raw = json.load(f)
    algo = dataclass_from_dict(AlgorithmConfig, raw.get("algorithm"))
    datasets: List[FactoryDataset] = []
    for item in raw.get("factory_datasets", []):
        datasets.append(
            FactoryDataset(
                name=str(item["name"]),
                center_root_dir=str(item["center_root_dir"]),
                offset_root_dirs=[str(x) for x in item.get("offset_root_dirs", [])],
                time_folders=[str(x) for x in item.get("time_folders", [])],
                label_by_folder={str(k): str(v) for k, v in item.get("label_by_folder", {}).items()},
            )
        )
    lab_groups: Dict[str, List[str]] = {}
    for key, value in raw.get("lab_groups", {}).items():
        if isinstance(value, str):
            lab_groups[str(key)] = [value]
        else:
            lab_groups[str(key)] = [str(v) for v in value]
    cfg = RunConfig(
        lab_groups=lab_groups,
        factory_datasets=datasets,
        output_dir=str(raw.get("output_dir", "anechoic_semisupervised_results")),
        algorithm=algo,
    )
    validate_config(cfg)
    return cfg


def validate_config(cfg: RunConfig) -> None:
    a = cfg.algorithm
    if "0.1mm" not in cfg.lab_groups or "0.5mm" not in cfg.lab_groups:
        raise ValueError("lab_groups 必须包含 0.1mm 和 0.5mm")
    if not cfg.factory_datasets:
        raise ValueError("factory_datasets 不能为空")
    if a.freq_low_hz < 0 or a.freq_high_hz <= a.freq_low_hz:
        raise ValueError("主分析频段设置错误")
    if a.nperseg < 256 or a.hop_length < 1 or a.nfft < a.nperseg:
        raise ValueError("STFT 参数错误")
    if a.segment_mode not in {"indexed", "first", "auto"}:
        raise ValueError("segment_mode 只能是 indexed / first / auto")
    if not 0.0 < a.lab_train_fraction < 1.0:
        raise ValueError("lab_train_fraction 必须位于 (0,1)")
    if a.leak_components < 1 or a.noise_components < 1:
        raise ValueError("字典成分数量必须大于0")


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_json(path: Path, obj: Any) -> None:
    ensure_dir(path.parent)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]], columns: Optional[Sequence[str]] = None) -> None:
    ensure_dir(path.parent)
    if columns is None:
        keys: List[str] = []
        seen = set()
        for row in rows:
            for key in row.keys():
                if key not in seen:
                    keys.append(key)
                    seen.add(key)
        columns = keys
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(columns))
        writer.writeheader()
        for row in rows:
            writer.writerow({k: row.get(k, "") for k in columns})


def discover_wavs(paths: Sequence[str]) -> List[Path]:
    found: Dict[str, Path] = {}
    for raw in paths:
        p = Path(raw).expanduser()
        if p.is_file() and p.suffix.lower() == ".wav":
            found[str(p.resolve()).lower()] = p.resolve()
        elif p.is_dir():
            for wav in p.rglob("*.wav"):
                if wav.is_file():
                    found[str(wav.resolve()).lower()] = wav.resolve()
    return sorted(found.values(), key=lambda x: str(x).lower())


def list_wavs(folder: Path) -> List[Path]:
    return sorted([p for p in folder.glob("*.wav") if p.is_file()], key=lambda x: x.name.lower())


def resolve_time_dir(root: Path, time_folder: str) -> Path:
    nested = root / time_folder
    if nested.is_dir():
        return nested
    if root.is_dir() and list_wavs(root):
        return root
    return nested


def available_time_folders(dataset: FactoryDataset) -> List[str]:
    if dataset.time_folders:
        return list(dataset.time_folders)
    root = Path(dataset.center_root_dir)
    if not root.exists():
        return []
    subdirs = sorted([p.name for p in root.iterdir() if p.is_dir()])
    if subdirs:
        return subdirs
    if list_wavs(root):
        return [""]
    return []


def build_center_index(folder: Path) -> Dict[str, List[Path]]:
    out: Dict[str, List[Path]] = {}
    for path in list_wavs(folder):
        m = CENTER_RE.search(path.name)
        if m:
            out.setdefault(m.group("center"), []).append(path)
    for key in out:
        out[key] = sorted(out[key], key=lambda p: p.name.lower())
    return out


def build_offset_index(folders: Sequence[Path]) -> Dict[Tuple[str, int, str], List[Path]]:
    out: Dict[Tuple[str, int, str], List[Path]] = {}
    for folder in folders:
        for path in list_wavs(folder):
            m = OFFSET_RE.search(path.name)
            if not m:
                continue
            key = (m.group("center"), int(m.group("distance")), m.group("direction").lower())
            out.setdefault(key, []).append(path)
    for key in out:
        out[key] = sorted(set(out[key]), key=lambda p: str(p).lower())
    return out


def center_sort_key(center_id: str) -> Tuple[int, ...]:
    try:
        return tuple(int(x) for x in center_id.split("_"))
    except Exception:
        return (10**9,)


def segment_bounds(center_id: str, wav_duration: float, cfg: AlgorithmConfig) -> Tuple[float, float, str]:
    duration = float(cfg.time_slice_seconds)
    if cfg.segment_mode == "first":
        return 0.0, duration, "first"
    parts = center_id.split("_")
    if not parts[-1].isdigit():
        if cfg.segment_mode == "auto":
            return 0.0, duration, "auto_first"
        raise ValueError(f"center_id={center_id} 无法解析秒编号")
    index = int(parts[-1])
    indexed_start = index * duration
    indexed_end = indexed_start + duration
    if cfg.segment_mode == "indexed":
        return indexed_start, indexed_end, "indexed"
    if wav_duration + 1e-9 >= indexed_end:
        return indexed_start, indexed_end, "auto_indexed"
    return 0.0, duration, "auto_first"


def pcm_to_float(raw: np.ndarray) -> Tuple[np.ndarray, str, float]:
    dtype_name = str(raw.dtype)
    if np.issubdtype(raw.dtype, np.integer):
        info = np.iinfo(raw.dtype)
        full_scale = float(max(abs(info.min), abs(info.max)))
        x = raw.astype(np.float64) / max(full_scale, 1.0)
        return x, dtype_name, 1.0
    if np.issubdtype(raw.dtype, np.floating):
        return raw.astype(np.float64), dtype_name, 1.0
    raise TypeError(f"不支持的WAV类型: {raw.dtype}")


def read_wav_slice(path: Path, center_id: str, cfg: AlgorithmConfig) -> WavSlice:
    fs, raw = wavfile.read(str(path))
    if raw.ndim > 1:
        raw = np.mean(raw.astype(np.float64), axis=1)
    total_duration = len(raw) / float(fs)
    start_s, end_s, _ = segment_bounds(center_id, total_duration, cfg)
    start = int(round(start_s * fs))
    end = int(round(end_s * fs))
    if start >= len(raw):
        raise ValueError(f"目标片段起点超出WAV: {path.name}, duration={total_duration:.6f}s")
    if end > len(raw):
        if cfg.strict_time_slice:
            raise ValueError(
                f"目标片段不完整: {path.name}, 需要[{start_s:.3f},{end_s:.3f})s, 实际{total_duration:.6f}s"
            )
        end = len(raw)
    piece_raw = raw[start:end]
    x, dtype_name, full_scale = pcm_to_float(np.asarray(piece_raw))
    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    if x.size < 256:
        raise ValueError(f"片段过短: {path}")
    x = x - float(np.mean(x))
    peak = float(np.max(np.abs(x))) if x.size else 0.0
    rms = float(np.sqrt(np.mean(x * x) + EPS))
    clipping_fraction = float(np.mean(np.abs(x) >= 0.999 * full_scale)) if x.size else 0.0
    return WavSlice(
        path=path,
        fs=int(fs),
        x=np.asarray(x, dtype=np.float64),
        original_dtype=dtype_name,
        duration_seconds=total_duration,
        segment_start_seconds=start_s,
        segment_end_seconds=end_s,
        peak=peak,
        rms=rms,
        clipping_fraction=clipping_fraction,
    )


def read_lab_wav(path: Path, max_seconds: float) -> Tuple[int, np.ndarray, str, float]:
    fs, raw = wavfile.read(str(path))
    dtype_name = str(raw.dtype)
    if raw.ndim > 1:
        raw = np.mean(raw.astype(np.float64), axis=1)
    x, _, _ = pcm_to_float(np.asarray(raw))
    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    if max_seconds > 0:
        x = x[: int(round(max_seconds * fs))]
    x = x - float(np.mean(x))
    return int(fs), np.asarray(x, dtype=np.float64), dtype_name, len(raw) / float(fs)


def stft_full(x: np.ndarray, fs: int, cfg: AlgorithmConfig) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    nperseg = min(cfg.nperseg, len(x))
    if nperseg < 256:
        raise ValueError("STFT片段过短")
    hop = min(cfg.hop_length, nperseg)
    noverlap = nperseg - hop
    nfft = max(cfg.nfft, nperseg)
    f, t, z = signal.stft(
        x,
        fs=fs,
        window="hann",
        nperseg=nperseg,
        noverlap=noverlap,
        nfft=nfft,
        detrend=False,
        return_onesided=True,
        boundary="zeros",
        padded=True,
    )
    return f, t, z


def frequency_mask(freq: np.ndarray, low: float, high: float) -> np.ndarray:
    return (freq >= low) & (freq <= high)


def power_band_from_stft(freq: np.ndarray, z: np.ndarray, cfg: AlgorithmConfig) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    mask = frequency_mask(freq, cfg.freq_low_hz, cfg.freq_high_hz)
    if int(np.sum(mask)) < cfg.minimum_frequency_bins:
        raise ValueError(
            f"{cfg.freq_low_hz:g}-{cfg.freq_high_hz:g}Hz内频点不足: {int(np.sum(mask))}"
        )
    return freq[mask], np.abs(z[mask]) ** 2, mask


def representative_spectrum(power: np.ndarray) -> np.ndarray:
    if power.ndim != 2 or power.shape[1] == 0:
        raise ValueError("功率矩阵为空")
    spec = np.median(np.maximum(power, 0.0), axis=1)
    return normalize_vector(spec)


def normalize_vector(x: np.ndarray) -> np.ndarray:
    x = np.maximum(np.nan_to_num(np.asarray(x, dtype=np.float64), nan=0.0, posinf=0.0, neginf=0.0), 0.0)
    s = float(np.sum(x))
    if s <= EPS:
        return np.full_like(x, 1.0 / max(len(x), 1))
    return x / s


def normalize_columns(v: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    v = np.maximum(np.nan_to_num(np.asarray(v, dtype=np.float64), nan=0.0, posinf=0.0, neginf=0.0), 0.0)
    scale = np.sum(v, axis=0, keepdims=True)
    scale = np.maximum(scale, EPS)
    return v / scale, scale


def l2_normalize_columns(v: np.ndarray) -> np.ndarray:
    denom = np.sqrt(np.sum(v * v, axis=0, keepdims=True))
    return v / np.maximum(denom, EPS)


def deterministic_split(files: Sequence[Path], train_fraction: float, seed: int) -> Tuple[List[Path], List[Path]]:
    scored: List[Tuple[int, Path]] = []
    for p in files:
        token = f"{seed}|{str(p.resolve()).lower()}".encode("utf-8")
        score = int(hashlib.sha256(token).hexdigest()[:16], 16)
        scored.append((score, p))
    ordered = [p for _, p in sorted(scored, key=lambda x: x[0])]
    if len(ordered) <= 1:
        return ordered, []
    n_train = int(round(len(ordered) * train_fraction))
    n_train = min(max(n_train, 1), len(ordered) - 1)
    return ordered[:n_train], ordered[n_train:]


def subsample_columns(v: np.ndarray, max_columns: int, rng: np.random.Generator) -> np.ndarray:
    if v.shape[1] <= max_columns:
        return v
    idx = np.sort(rng.choice(v.shape[1], size=max_columns, replace=False))
    return v[:, idx]


def fit_dictionary(v: np.ndarray, n_components: int, max_iter: int, seed: int) -> np.ndarray:
    vn, _ = normalize_columns(v)
    n_components = min(n_components, max(1, min(vn.shape[0], vn.shape[1]) - 1))
    model = NMF(
        n_components=n_components,
        init="nndsvda",
        solver="mu",
        beta_loss="kullback-leibler",
        max_iter=max_iter,
        random_state=seed,
        tol=1e-5,
    )
    model.fit(vn.T)
    w = np.maximum(model.components_.T, EPS)
    w /= np.maximum(np.sum(w, axis=0, keepdims=True), EPS)
    return w


def dynamic_penalty(base_ratio: float, projection: np.ndarray) -> float:
    positive = projection[np.isfinite(projection) & (projection > 0)]
    typical = float(np.median(positive)) if positive.size else 1.0
    return max(base_ratio, 0.0) * max(typical, EPS)


def infer_activations(
    v: np.ndarray,
    ws: np.ndarray,
    wn: np.ndarray,
    iterations: int,
    leak_l1_ratio: float,
    noise_l1_ratio: float,
    seed: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    ks, kn = ws.shape[1], wn.shape[1]
    hs = rng.random((ks, v.shape[1])) + 0.1
    hn = rng.random((kn, v.shape[1])) + 0.1
    lambda_s = dynamic_penalty(leak_l1_ratio, ws.T @ v)
    lambda_n = dynamic_penalty(noise_l1_ratio, wn.T @ v)
    for _ in range(iterations):
        recon = ws @ hs + wn @ hn + EPS
        hs *= (ws.T @ v) / (ws.T @ recon + lambda_s + EPS)
        recon = ws @ hs + wn @ hn + EPS
        hn *= (wn.T @ v) / (wn.T @ recon + lambda_n + EPS)
        hs = np.maximum(hs, EPS)
        hn = np.maximum(hn, EPS)
    recon = ws @ hs + wn @ hn
    return hs, hn, recon


def repel_noise_dictionary(wn: np.ndarray, ws: np.ndarray, strength: float) -> np.ndarray:
    if strength <= 0:
        return wn
    q, _ = np.linalg.qr(ws)
    projection = q @ (q.T @ wn)
    out = np.maximum(wn - strength * np.maximum(projection, 0.0), EPS)
    out /= np.maximum(np.sum(out, axis=0, keepdims=True), EPS)
    return out


def learn_noise_dictionary(
    v_reference: np.ndarray,
    ws: np.ndarray,
    cfg: AlgorithmConfig,
    seed: int,
) -> Tuple[np.ndarray, Dict[str, Any]]:
    rng = np.random.default_rng(seed)
    vn, _ = normalize_columns(v_reference)
    ws_l2 = l2_normalize_columns(ws)
    vn_l2 = l2_normalize_columns(vn)
    leak_similarity = np.max(ws_l2.T @ vn_l2, axis=0)
    n_candidates = max(cfg.noise_components * 8, int(round(cfg.noise_candidate_fraction * vn.shape[1])))
    n_candidates = min(max(n_candidates, cfg.noise_components + 2), vn.shape[1])
    candidate_idx = np.argsort(leak_similarity)[:n_candidates]
    candidate_v = vn[:, candidate_idx]
    candidate_v = subsample_columns(candidate_v, cfg.max_reference_training_frames, rng)
    wn = fit_dictionary(candidate_v, cfg.noise_components, cfg.nmf_max_iter, seed)
    wn = repel_noise_dictionary(wn, ws, cfg.noise_leak_repel_strength)

    train_v = subsample_columns(vn, cfg.max_reference_training_frames, rng)
    ks, kn = ws.shape[1], wn.shape[1]
    hs = rng.random((ks, train_v.shape[1])) + 0.05
    hn = rng.random((kn, train_v.shape[1])) + 0.10
    lambda_s = dynamic_penalty(cfg.leak_activation_l1_ratio, ws.T @ train_v)
    lambda_n = dynamic_penalty(cfg.noise_activation_l1_ratio, wn.T @ train_v)

    for it in range(cfg.joint_refine_iterations):
        recon = ws @ hs + wn @ hn + EPS
        hs *= (ws.T @ train_v) / (ws.T @ recon + lambda_s + EPS)
        recon = ws @ hs + wn @ hn + EPS
        hn *= (wn.T @ train_v) / (wn.T @ recon + lambda_n + EPS)
        recon = ws @ hs + wn @ hn + EPS
        wn *= (train_v @ hn.T) / (recon @ hn.T + EPS)
        wn = np.maximum(wn, EPS)
        col_scale = np.sum(wn, axis=0, keepdims=True)
        wn /= np.maximum(col_scale, EPS)
        hn *= col_scale.T
        if (it + 1) % 5 == 0:
            wn = repel_noise_dictionary(wn, ws, cfg.noise_leak_repel_strength)

    max_cross_similarity = float(np.max(l2_normalize_columns(ws).T @ l2_normalize_columns(wn)))
    diagnostics = {
        "reference_frames_total": int(vn.shape[1]),
        "noise_candidate_frames": int(len(candidate_idx)),
        "candidate_leak_similarity_median": float(np.median(leak_similarity[candidate_idx])),
        "all_reference_leak_similarity_median": float(np.median(leak_similarity)),
        "max_leak_noise_atom_cosine": max_cross_similarity,
    }
    return wn, diagnostics


def spectrum_metrics(a: np.ndarray, b: np.ndarray) -> Dict[str, float]:
    p = normalize_vector(a)
    q = normalize_vector(b)
    cosine = float(np.dot(p, q) / (np.linalg.norm(p) * np.linalg.norm(q) + EPS))
    if np.std(p) <= EPS or np.std(q) <= EPS:
        pearson = 0.0
    else:
        pearson = float(np.corrcoef(p, q)[0, 1])
    overlap = float(np.sum(np.minimum(p, q)))
    js_distance = float(jensenshannon(p + EPS, q + EPS, base=2.0))
    js_similarity = float(np.clip(1.0 - js_distance, 0.0, 1.0))
    combined = float(np.mean([np.clip(cosine, 0.0, 1.0), np.clip((pearson + 1.0) / 2.0, 0.0, 1.0), overlap, js_similarity]))
    return {
        "cosine": cosine,
        "pearson": pearson,
        "overlap": overlap,
        "js_similarity": js_similarity,
        "combined": combined,
    }


def evaluate_against_lab(spec: np.ndarray, lab_specs: Sequence[Tuple[str, Path, np.ndarray]]) -> Dict[str, Any]:
    if not lab_specs:
        return {
            "lab_similarity_combined_median": float("nan"),
            "lab_similarity_combined_max": float("nan"),
            "lab_similarity_best_file": "",
            "lab_cosine_median": float("nan"),
            "lab_pearson_median": float("nan"),
            "lab_overlap_median": float("nan"),
            "lab_js_similarity_median": float("nan"),
        }
    rows = []
    for group, path, lab_spec in lab_specs:
        m = spectrum_metrics(spec, lab_spec)
        rows.append((group, path, m))
    combined = np.array([r[2]["combined"] for r in rows], dtype=float)
    best = int(np.nanargmax(combined))
    return {
        "lab_similarity_combined_median": float(np.nanmedian(combined)),
        "lab_similarity_combined_max": float(combined[best]),
        "lab_similarity_best_file": str(rows[best][1]),
        "lab_cosine_median": float(np.nanmedian([r[2]["cosine"] for r in rows])),
        "lab_pearson_median": float(np.nanmedian([r[2]["pearson"] for r in rows])),
        "lab_overlap_median": float(np.nanmedian([r[2]["overlap"] for r in rows])),
        "lab_js_similarity_median": float(np.nanmedian([r[2]["js_similarity"] for r in rows])),
    }


def sample_label(dataset: FactoryDataset, folder: str) -> str:
    return str(dataset.label_by_folder.get(folder, "UNLABELED")).upper().strip() or "UNLABELED"


def safe_slug(text: str) -> str:
    out = re.sub(r"[^0-9A-Za-z._-]+", "_", str(text)).strip("_")
    return out[:180] or "sample"


def amplitude_diagnostics(slices: Sequence[WavSlice], cfg: AlgorithmConfig) -> Dict[str, Any]:
    peaks = np.array([s.peak for s in slices], dtype=float)
    rms = np.array([s.rms for s in slices], dtype=float)
    clip = np.array([s.clipping_fraction for s in slices], dtype=float)
    peak_mean = float(np.mean(peaks)) if peaks.size else float("nan")
    rms_mean = float(np.mean(rms)) if rms.size else float("nan")
    peak_cv = float(np.std(peaks) / (peak_mean + EPS)) if peaks.size else float("nan")
    rms_cv = float(np.std(rms) / (rms_mean + EPS)) if rms.size else float("nan")
    near_full = float(np.mean(peaks >= cfg.amplitude_peak_fullscale_threshold)) if peaks.size else 0.0
    suspicious = bool(
        peaks.size >= 20
        and (
            (near_full >= 0.90 and peak_cv <= cfg.amplitude_uniform_peak_cv_threshold)
            or (peak_cv <= cfg.amplitude_uniform_peak_cv_threshold and rms_cv <= cfg.amplitude_uniform_rms_cv_threshold)
        )
    )
    clipping = bool(float(np.max(clip)) > 1e-3) if clip.size else False
    return {
        "amplitude_status": "POSSIBLE_PER_FILE_NORMALIZATION" if suspicious else "AMPLITUDE_SCALE_OK",
        "clipping_status": "POSSIBLE_CLIPPING" if clipping else "NO_OBVIOUS_CLIPPING",
        "n_files": int(len(slices)),
        "peak_min": float(np.min(peaks)) if peaks.size else float("nan"),
        "peak_median": float(np.median(peaks)) if peaks.size else float("nan"),
        "peak_max": float(np.max(peaks)) if peaks.size else float("nan"),
        "peak_cv": peak_cv,
        "rms_min": float(np.min(rms)) if rms.size else float("nan"),
        "rms_median": float(np.median(rms)) if rms.size else float("nan"),
        "rms_max": float(np.max(rms)) if rms.size else float("nan"),
        "rms_cv": rms_cv,
        "near_fullscale_fraction": near_full,
        "max_clipping_fraction": float(np.max(clip)) if clip.size else 0.0,
    }


def plot_dictionary(freq: np.ndarray, w: np.ndarray, title: str, path: Path) -> None:
    fig, ax = plt.subplots(figsize=(11, 6))
    for i in range(w.shape[1]):
        ax.plot(freq / 1000.0, normalize_vector(w[:, i]), linewidth=1.1, label=f"atom {i+1}")
    ax.set_xlabel("Frequency (kHz)")
    ax.set_ylabel("Normalized spectral weight")
    ax.set_title(title)
    ax.grid(alpha=0.25)
    if w.shape[1] <= 12:
        ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def plot_sample_spectra(
    freq: np.ndarray,
    raw_spec: np.ndarray,
    leak_spec: np.ndarray,
    noise_spec: np.ndarray,
    lab_proto: np.ndarray,
    title: str,
    path: Path,
) -> None:
    fig, ax = plt.subplots(figsize=(11, 6))
    ax.plot(freq / 1000.0, normalize_vector(raw_spec), label="raw center", linewidth=1.4)
    ax.plot(freq / 1000.0, normalize_vector(leak_spec), label="estimated leak", linewidth=1.8)
    ax.plot(freq / 1000.0, normalize_vector(noise_spec), label="estimated noise", linewidth=1.3)
    ax.plot(freq / 1000.0, normalize_vector(lab_proto), label="held-out lab prototype", linewidth=2.0, linestyle="--")
    ax.set_xlabel("Frequency (kHz)")
    ax.set_ylabel("Normalized spectrum")
    ax.set_title(title)
    ax.grid(alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def plot_spectrogram_triplet(
    freq: np.ndarray,
    time_s: np.ndarray,
    raw_power: np.ndarray,
    leak_power: np.ndarray,
    noise_power: np.ndarray,
    title: str,
    path: Path,
) -> None:
    arrays = [raw_power, leak_power, noise_power]
    names = ["Raw center", "Estimated leak", "Estimated noise"]
    stacked = np.concatenate([10 * np.log10(np.maximum(x, EPS)).ravel() for x in arrays])
    vmin, vmax = np.percentile(stacked[np.isfinite(stacked)], [5, 99])
    fig, axes = plt.subplots(3, 1, figsize=(11, 10), sharex=True, sharey=True)
    for ax, arr, name in zip(axes, arrays, names):
        im = ax.pcolormesh(time_s, freq / 1000.0, 10 * np.log10(np.maximum(arr, EPS)), shading="auto", vmin=vmin, vmax=vmax)
        ax.set_ylabel("kHz")
        ax.set_title(name)
        fig.colorbar(im, ax=ax, label="Power (dB)")
    axes[-1].set_xlabel("Time (s)")
    fig.suptitle(title)
    fig.tight_layout(rect=(0, 0, 1, 0.97))
    fig.savefig(path, dpi=140, bbox_inches="tight")
    plt.close(fig)


def plot_neighbor_contamination(rows: Sequence[Mapping[str, Any]], title: str, path: Path) -> None:
    if not rows:
        return
    x = np.array([float(r["x_cm"]) for r in rows])
    y = np.array([float(r["y_cm"]) for r in rows])
    q = np.array([float(r["estimated_leak_power_fraction"]) for r in rows])
    fig, ax = plt.subplots(figsize=(8, 7))
    sc = ax.scatter(x, y, c=q, s=55, edgecolors="black", linewidths=0.4)
    ax.scatter([0], [0], marker="*", s=220, label="center", edgecolors="black")
    ax.set_aspect("equal")
    ax.set_xlabel("X (cm)")
    ax.set_ylabel("Y (cm)")
    ax.set_title(title)
    ax.grid(alpha=0.25)
    ax.legend()
    fig.colorbar(sc, ax=ax, label="Estimated leak fraction")
    fig.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def prepare_lab_reference(cfg: RunConfig, output_dir: Path) -> Dict[str, Any]:
    a = cfg.algorithm
    rng = np.random.default_rng(a.random_state)
    scan_rows: List[Dict[str, Any]] = []
    split_rows: List[Dict[str, Any]] = []
    train_blocks: List[np.ndarray] = []
    validation_specs: List[Tuple[str, Path, np.ndarray]] = []
    train_specs: List[Tuple[str, Path, np.ndarray]] = []
    freq_ref: Optional[np.ndarray] = None
    errors: List[Dict[str, Any]] = []

    for group in ("0.1mm", "0.5mm"):
        files = discover_wavs(cfg.lab_groups.get(group, []))
        train_files, validation_files = deterministic_split(files, a.lab_train_fraction, a.random_state + (1 if group == "0.1mm" else 2))
        independent = len(validation_files) > 0
        for path in files:
            role = "train" if path in train_files else "validation"
            split_rows.append({"group": group, "file": str(path), "role": role, "independent_validation": independent})
            try:
                fs, x, dtype_name, duration = read_lab_wav(path, a.max_lab_seconds_per_file)
                f, _, z = stft_full(x, fs, a)
                freq_band, power, _ = power_band_from_stft(f, z, a)
                if freq_ref is None:
                    freq_ref = freq_band
                elif len(freq_ref) != len(freq_band) or np.max(np.abs(freq_ref - freq_band)) > 1e-6:
                    raise ValueError("实验室WAV频率轴不一致，请检查采样率/STFT参数")
                spec = representative_spectrum(power)
                if role == "train":
                    train_blocks.append(power)
                    train_specs.append((group, path, spec))
                else:
                    validation_specs.append((group, path, spec))
                scan_rows.append({
                    "group": group,
                    "file": str(path),
                    "role": role,
                    "status": "OK",
                    "sample_rate_hz": fs,
                    "duration_seconds": duration,
                    "used_seconds": len(x) / fs,
                    "n_frames": power.shape[1],
                    "dtype": dtype_name,
                    "error": "",
                })
            except Exception as exc:
                scan_rows.append({
                    "group": group,
                    "file": str(path),
                    "role": role,
                    "status": "ERROR",
                    "sample_rate_hz": "",
                    "duration_seconds": "",
                    "used_seconds": "",
                    "n_frames": "",
                    "dtype": "",
                    "error": f"{type(exc).__name__}: {exc}",
                })
                errors.append({"stage": "lab", "file": str(path), "error": f"{type(exc).__name__}: {exc}"})

    write_csv(output_dir / "00_lab_input_scan.csv", scan_rows)
    write_csv(output_dir / "01_lab_train_validation_split.csv", split_rows)
    if not train_blocks or freq_ref is None:
        raise RuntimeError("没有可用的消声室训练WAV")
    v_train = np.concatenate(train_blocks, axis=1)
    v_train = subsample_columns(v_train, a.max_lab_training_frames, rng)
    ws = fit_dictionary(v_train, a.leak_components, a.nmf_max_iter, a.random_state)

    if not validation_specs:
        validation_specs = train_specs
        validation_mode = "TRAIN_REFERENCE_FALLBACK_NOT_INDEPENDENT"
    else:
        validation_mode = "HELD_OUT_WAV_FILES"
    lab_proto = normalize_vector(np.median(np.vstack([s for _, _, s in validation_specs]), axis=0))

    np.savez_compressed(
        output_dir / "02_frozen_leak_dictionary.npz",
        freq_hz=freq_ref,
        leak_dictionary=ws,
        validation_prototype=lab_proto,
    )
    if a.save_plots:
        plot_dictionary(freq_ref, ws, "Frozen anechoic leak dictionary", output_dir / "02_frozen_leak_dictionary.png")

    validation_rows: List[Dict[str, Any]] = []
    for group, path, spec in validation_specs:
        metrics = spectrum_metrics(spec, lab_proto)
        validation_rows.append({"group": group, "file": str(path), "validation_mode": validation_mode, **metrics})
    write_csv(output_dir / "03_lab_validation_similarity.csv", validation_rows)
    write_csv(output_dir / "99_errors_lab.csv", errors)
    return {
        "freq_hz": freq_ref,
        "ws": ws,
        "lab_proto": lab_proto,
        "validation_specs": validation_specs,
        "validation_mode": validation_mode,
        "scan_rows": scan_rows,
    }


def collect_sample_files(
    center_id: str,
    center_index: Dict[str, List[Path]],
    offset_index: Dict[Tuple[str, int, str], List[Path]],
) -> Tuple[Path, List[SpatialFile]]:
    center_files = center_index.get(center_id, [])
    if not center_files:
        raise FileNotFoundError(f"中心文件缺失: {center_id}")
    center_path = center_files[0]
    points: List[SpatialFile] = []
    for (cid, distance, direction), paths in offset_index.items():
        if cid != center_id or not paths or direction not in DIRECTION_ANGLES:
            continue
        angle = DIRECTION_ANGLES[direction]
        x = float(distance * np.cos(angle))
        y = float(distance * np.sin(angle))
        if abs(x) < 1e-10:
            x = 0.0
        if abs(y) < 1e-10:
            y = 0.0
        points.append(
            SpatialFile(
                center_id=center_id,
                distance_cm=int(distance),
                direction=direction,
                path=paths[0],
                x_cm=x,
                y_cm=y,
            )
        )
    points.sort(key=lambda p: (p.distance_cm, DIRECTIONS.index(p.direction)))
    return center_path, points


def reconstruct_wav(z_full: np.ndarray, fs: int, cfg: AlgorithmConfig, target_len: int) -> np.ndarray:
    nperseg = min(cfg.nperseg, target_len)
    hop = min(cfg.hop_length, nperseg)
    noverlap = nperseg - hop
    _, x = signal.istft(
        z_full,
        fs=fs,
        window="hann",
        nperseg=nperseg,
        noverlap=noverlap,
        nfft=max(cfg.nfft, nperseg),
        input_onesided=True,
        boundary=True,
    )
    if len(x) < target_len:
        x = np.pad(x, (0, target_len - len(x)))
    return np.asarray(x[:target_len], dtype=np.float64)


def process_factory_sample(
    dataset: FactoryDataset,
    time_folder: str,
    center_id: str,
    center_path: Path,
    spatial_files: Sequence[SpatialFile],
    lab: Dict[str, Any],
    cfg: RunConfig,
    sample_dir: Path,
    seed: int,
) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[Dict[str, Any]]]:
    a = cfg.algorithm
    ensure_dir(sample_dir)
    center_slice = read_wav_slice(center_path, center_id, a)
    neighbor_slices: List[Tuple[SpatialFile, WavSlice]] = []
    errors: List[Dict[str, Any]] = []
    for point in spatial_files:
        try:
            s = read_wav_slice(point.path, center_id, a)
            if s.fs != center_slice.fs:
                raise ValueError(f"采样率不一致: center={center_slice.fs}, point={s.fs}")
            if len(s.x) != len(center_slice.x):
                raise ValueError(f"片段长度不一致: center={len(center_slice.x)}, point={len(s.x)}")
            neighbor_slices.append((point, s))
        except Exception as exc:
            errors.append({
                "dataset": dataset.name,
                "time_folder": time_folder,
                "center_id": center_id,
                "file": str(point.path),
                "stage": "read_neighbor",
                "error": f"{type(exc).__name__}: {exc}",
            })
    if len(neighbor_slices) < a.min_neighbors:
        raise RuntimeError(f"有效周围点不足: {len(neighbor_slices)} < {a.min_neighbors}")

    amp = amplitude_diagnostics([center_slice] + [s for _, s in neighbor_slices], a)
    freq_full, time_stft, z_center = stft_full(center_slice.x, center_slice.fs, a)
    freq_band, v_center, band_mask = power_band_from_stft(freq_full, z_center, a)
    if len(freq_band) != len(lab["freq_hz"]) or np.max(np.abs(freq_band - lab["freq_hz"])) > 1e-6:
        raise ValueError("工厂与消声室频率轴不一致")

    reference_blocks: List[np.ndarray] = []
    point_cache: List[Tuple[SpatialFile, np.ndarray]] = []
    for point, wav_slice in neighbor_slices:
        f, _, z = stft_full(wav_slice.x, wav_slice.fs, a)
        fb, power, _ = power_band_from_stft(f, z, a)
        if len(fb) != len(freq_band) or np.max(np.abs(fb - freq_band)) > 1e-6:
            raise ValueError(f"周围点频率轴不一致: {point.path.name}")
        reference_blocks.append(power)
        point_cache.append((point, power))
    v_ref = np.concatenate(reference_blocks, axis=1)
    wn, noise_diag = learn_noise_dictionary(v_ref, lab["ws"], a, seed)

    hs0, hn0, recon0 = infer_activations(
        v_center,
        lab["ws"],
        wn,
        a.inference_iterations,
        a.leak_activation_l1_ratio,
        a.noise_activation_l1_ratio,
        seed + 10,
    )
    p_leak = np.maximum(lab["ws"] @ hs0, 0.0)
    p_noise_model = np.maximum(wn @ hn0, 0.0)
    residual = np.maximum(v_center - p_leak - p_noise_model, 0.0)
    p_noise = p_noise_model + residual
    soft_mask = p_leak / np.maximum(p_leak + p_noise, EPS)
    soft_mask = np.clip(soft_mask, 0.0, 1.0)

    z_leak = np.zeros_like(z_center)
    z_leak[band_mask] = soft_mask * z_center[band_mask]
    z_noise = z_center - z_leak
    leak_wav = reconstruct_wav(z_leak, center_slice.fs, a, len(center_slice.x))
    noise_wav = reconstruct_wav(z_noise, center_slice.fs, a, len(center_slice.x))

    if a.save_wavs:
        wavfile.write(str(sample_dir / "estimated_leak.wav"), center_slice.fs, leak_wav.astype(np.float32))
        wavfile.write(str(sample_dir / "estimated_noise.wav"), center_slice.fs, noise_wav.astype(np.float32))
        wavfile.write(str(sample_dir / "raw_center_slice.wav"), center_slice.fs, center_slice.x.astype(np.float32))

    raw_spec = representative_spectrum(v_center)
    leak_spec = representative_spectrum(p_leak)
    noise_spec = representative_spectrum(p_noise)
    raw_sim = evaluate_against_lab(raw_spec, lab["validation_specs"])
    leak_sim = evaluate_against_lab(leak_spec, lab["validation_specs"])
    noise_sim = evaluate_against_lab(noise_spec, lab["validation_specs"])

    point_rows: List[Dict[str, Any]] = []
    for idx, (point, power) in enumerate(point_cache):
        hs, hn, _ = infer_activations(
            power,
            lab["ws"],
            wn,
            max(80, a.inference_iterations // 2),
            a.leak_activation_l1_ratio,
            a.noise_activation_l1_ratio,
            seed + 1000 + idx,
        )
        ps = np.maximum(lab["ws"] @ hs, 0.0)
        pn = np.maximum(wn @ hn, 0.0)
        leak_fraction = float(np.sum(ps) / (np.sum(ps) + np.sum(pn) + EPS))
        point_rows.append({
            "dataset": dataset.name,
            "time_folder": time_folder,
            "center_id": center_id,
            "label": sample_label(dataset, time_folder),
            "distance_cm": point.distance_cm,
            "direction": point.direction,
            "x_cm": point.x_cm,
            "y_cm": point.y_cm,
            "wav_file": str(point.path),
            "estimated_leak_power_fraction": leak_fraction,
            "raw_power_sum": float(np.sum(power)),
            "estimated_leak_power_sum": float(np.sum(ps)),
            "estimated_noise_power_sum": float(np.sum(pn)),
        })

    summary: Dict[str, Any] = {
        "dataset": dataset.name,
        "time_folder": time_folder,
        "center_id": center_id,
        "label": sample_label(dataset, time_folder),
        "center_file": str(center_path),
        "segment_start_seconds": center_slice.segment_start_seconds,
        "segment_end_seconds": center_slice.segment_end_seconds,
        "sample_rate_hz": center_slice.fs,
        "n_neighbors_used": len(neighbor_slices),
        "main_freq_low_hz": a.freq_low_hz,
        "main_freq_high_hz": a.freq_high_hz,
        "leak_dictionary_components": lab["ws"].shape[1],
        "noise_dictionary_components": wn.shape[1],
        "center_estimated_leak_power_fraction": float(np.sum(p_leak) / (np.sum(p_leak) + np.sum(p_noise) + EPS)),
        "center_reconstruction_relative_error": float(np.linalg.norm(v_center - recon0) / (np.linalg.norm(v_center) + EPS)),
        "lab_validation_mode": lab["validation_mode"],
        **amp,
        **{f"noise_model_{k}": v for k, v in noise_diag.items()},
        **{f"raw_{k}": v for k, v in raw_sim.items()},
        **{f"leak_{k}": v for k, v in leak_sim.items()},
        **{f"noise_{k}": v for k, v in noise_sim.items()},
    }
    summary["leak_similarity_gain_over_raw"] = float(
        summary["leak_lab_similarity_combined_median"] - summary["raw_lab_similarity_combined_median"]
    )
    summary["leak_vs_noise_similarity_gap"] = float(
        summary["leak_lab_similarity_combined_median"] - summary["noise_lab_similarity_combined_median"]
    )
    summary["separation_quality_flag"] = (
        "PROMISING"
        if summary["leak_similarity_gain_over_raw"] > 0
        and summary["leak_vs_noise_similarity_gap"] > 0
        else "NOT_VALIDATED"
    )

    np.savez_compressed(
        sample_dir / "separation_result.npz",
        freq_hz=freq_band,
        time_s=time_stft,
        raw_center_power=v_center,
        estimated_leak_power=p_leak,
        estimated_noise_power=p_noise,
        soft_mask=soft_mask,
        leak_dictionary=lab["ws"],
        noise_dictionary=wn,
        leak_activation=hs0,
        noise_activation=hn0,
    )
    write_json(sample_dir / "summary.json", summary)
    write_csv(sample_dir / "neighbor_leak_contamination.csv", point_rows)

    if a.save_plots:
        plot_dictionary(freq_band, wn, "Learned factory noise dictionary", sample_dir / "noise_dictionary.png")
        plot_sample_spectra(
            freq_band,
            raw_spec,
            leak_spec,
            noise_spec,
            lab["lab_proto"],
            f"{dataset.name} | {time_folder} | {center_id}",
            sample_dir / "spectrum_comparison.png",
        )
        plot_spectrogram_triplet(
            freq_band,
            time_stft,
            v_center,
            p_leak,
            p_noise,
            f"{dataset.name} | {time_folder} | {center_id}",
            sample_dir / "spectrogram_comparison.png",
        )
        plot_neighbor_contamination(
            point_rows,
            f"Estimated leak contamination | {time_folder} | {center_id}",
            sample_dir / "neighbor_leak_contamination_map.png",
        )

    return summary, point_rows, errors


def label_evaluation(summary_df: pd.DataFrame) -> pd.DataFrame:
    if summary_df.empty or "label" not in summary_df.columns:
        return pd.DataFrame()
    valid = summary_df[~summary_df["label"].astype(str).str.upper().isin(["", "UNLABELED", "UNKNOWN", "NONE"])].copy()
    if valid.empty:
        return pd.DataFrame()
    metrics = [
        "raw_lab_similarity_combined_median",
        "leak_lab_similarity_combined_median",
        "noise_lab_similarity_combined_median",
        "leak_similarity_gain_over_raw",
        "leak_vs_noise_similarity_gap",
        "center_estimated_leak_power_fraction",
    ]
    rows = []
    for (dataset, label), sub in valid.groupby(["dataset", "label"]):
        row: Dict[str, Any] = {"dataset": dataset, "label": label, "n_samples": len(sub)}
        for metric in metrics:
            row[f"{metric}_median"] = float(pd.to_numeric(sub[metric], errors="coerce").median())
            row[f"{metric}_mean"] = float(pd.to_numeric(sub[metric], errors="coerce").mean())
        rows.append(row)
    return pd.DataFrame(rows)


def write_read_me_first(output_dir: Path, cfg: RunConfig, lab: Dict[str, Any]) -> None:
    text = f"""消声室引导半监督源分离：结果阅读顺序
============================================================

主分析频带：{cfg.algorithm.freq_low_hz/1000:g}-{cfg.algorithm.freq_high_hz/1000:g} kHz
消声室验证模式：{lab['validation_mode']}

本程序做什么：
1. 消声室 0.1mm / 0.5mm 建立冻结泄漏字典；
2. 每个工厂中心使用自己的周围波束学习现场噪声字典；
3. 中心分解为 estimated_leak.wav 和 estimated_noise.wav；
4. 用留出的消声室 WAV 比较原始中心、分离泄漏和分离噪声。

先看：
- 00_lab_input_scan.csv：消声室文件是否全部成功；
- 01_lab_train_validation_split.csv：按整条WAV划分训练/验证；
- 10_factory_sample_summary.csv：每个中心的总结果；
- 11_factory_neighbor_contamination.csv：128点中各点估计的泄漏污染比例；
- 99_errors_factory.csv：读取或处理错误。

10_factory_sample_summary.csv 重点列：
- amplitude_status：AMPLITUDE_SCALE_OK较好；POSSIBLE_PER_FILE_NORMALIZATION需谨慎；
- center_estimated_leak_power_fraction：中心50-70kHz功率中模型分给泄漏的比例；
- leak_lab_similarity_combined_median：分离泄漏与留出消声室WAV的中位相似度；
- raw_lab_similarity_combined_median：原始中心与消声室的中位相似度；
- noise_lab_similarity_combined_median：分离噪声与消声室的中位相似度；
- leak_similarity_gain_over_raw：应大于0；
- leak_vs_noise_similarity_gap：应大于0；
- separation_quality_flag：PROMISING只表示两项相对验证同时成立，不是最终泄漏判定。

重要边界：
- 没有消声室无泄漏录音，因此不能由固定相似度阈值宣布“确定泄漏”；
- 消声室泄漏字典参与分离，所以最终验证必须使用未参与训练的整条消声室WAV；
- 如果验证WAV不足，程序会标记 TRAIN_REFERENCE_FALLBACK_NOT_INDEPENDENT，此时相似度不能作为独立验证；
- 软掩膜能平滑输出WAV，但方法是否正确主要取决于噪声字典是否没有吸收泄漏。
"""
    (output_dir / "00_READ_ME_FIRST.txt").write_text(text, encoding="utf-8")


def run_analysis(cfg: RunConfig) -> Dict[str, Path]:
    output_dir = ensure_dir(Path(cfg.output_dir))
    print("=" * 88)
    print("消声室引导的半监督泄漏/背景分离")
    print("输出目录:", output_dir)
    print("主分析频带:", f"{cfg.algorithm.freq_low_hz:g}-{cfg.algorithm.freq_high_hz:g} Hz")
    print("=" * 88)

    lab = prepare_lab_reference(cfg, output_dir)
    write_read_me_first(output_dir, cfg, lab)
    summaries: List[Dict[str, Any]] = []
    all_points: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []
    plot_count = 0
    sample_counter = 0

    for dataset in cfg.factory_datasets:
        print("\n" + "#" * 88)
        print("数据集:", dataset.name)
        folders = available_time_folders(dataset)
        if not folders:
            errors.append({"dataset": dataset.name, "stage": "scan", "error": "没有找到time_folder"})
            continue
        for time_folder in folders:
            center_dir = resolve_time_dir(Path(dataset.center_root_dir), time_folder)
            offset_dirs = [resolve_time_dir(Path(root), time_folder) for root in dataset.offset_root_dirs]
            if not center_dir.is_dir():
                errors.append({"dataset": dataset.name, "time_folder": time_folder, "stage": "scan", "error": f"中心目录不存在: {center_dir}"})
                continue
            existing_offset_dirs = [p for p in offset_dirs if p.is_dir()]
            if not existing_offset_dirs:
                errors.append({"dataset": dataset.name, "time_folder": time_folder, "stage": "scan", "error": "偏移目录全部不存在"})
                continue
            center_index = build_center_index(center_dir)
            offset_index = build_offset_index(existing_offset_dirs)
            center_ids = sorted(center_index.keys(), key=center_sort_key)
            print(f"\n{time_folder or '[root]'}: 中心={center_ids}, offset组合={len(offset_index)}")
            for center_id in center_ids:
                sample_counter += 1
                try:
                    center_path, spatial_files = collect_sample_files(center_id, center_index, offset_index)
                    sample_dir = output_dir / "samples" / safe_slug(dataset.name) / safe_slug(time_folder or "root") / f"center_{safe_slug(center_id)}"
                    summary, point_rows, sample_errors = process_factory_sample(
                        dataset,
                        time_folder,
                        center_id,
                        center_path,
                        spatial_files,
                        lab,
                        cfg,
                        sample_dir,
                        cfg.algorithm.random_state + sample_counter * 17,
                    )
                    summaries.append(summary)
                    all_points.extend(point_rows)
                    errors.extend(sample_errors)
                    print(
                        f"  {center_id}: neighbors={summary['n_neighbors_used']}, "
                        f"leak_sim={summary['leak_lab_similarity_combined_median']:.3f}, "
                        f"gain={summary['leak_similarity_gain_over_raw']:.3f}, "
                        f"gap={summary['leak_vs_noise_similarity_gap']:.3f}, "
                        f"flag={summary['separation_quality_flag']}"
                    )
                    if cfg.algorithm.save_plots:
                        plot_count += 1
                        if plot_count >= cfg.algorithm.plot_limit:
                            cfg.algorithm.save_plots = False
                            print("  已达到plot_limit，后续样本不再绘图。")
                except Exception as exc:
                    errors.append({
                        "dataset": dataset.name,
                        "time_folder": time_folder,
                        "center_id": center_id,
                        "stage": "sample",
                        "error": f"{type(exc).__name__}: {exc}",
                    })
                    print(f"  {center_id}: ERROR {type(exc).__name__}: {exc}")

    summary_path = output_dir / "10_factory_sample_summary.csv"
    points_path = output_dir / "11_factory_neighbor_contamination.csv"
    errors_path = output_dir / "99_errors_factory.csv"
    write_csv(summary_path, summaries)
    write_csv(points_path, all_points)
    write_csv(errors_path, errors)
    summary_df = pd.DataFrame(summaries)
    eval_df = label_evaluation(summary_df)
    eval_path = output_dir / "12_label_group_summary.csv"
    eval_df.to_csv(eval_path, index=False, encoding="utf-8-sig")

    run_info = {
        "config": {
            "lab_groups": cfg.lab_groups,
            "factory_datasets": [asdict(x) for x in cfg.factory_datasets],
            "output_dir": cfg.output_dir,
            "algorithm": asdict(cfg.algorithm),
        },
        "lab_validation_mode": lab["validation_mode"],
        "successful_factory_samples": len(summaries),
        "factory_error_count": len(errors),
    }
    write_json(output_dir / "00_run_info.json", run_info)
    print("\n" + "=" * 88)
    print("处理完成")
    print("先看:", output_dir / "00_READ_ME_FIRST.txt")
    print("总表:", summary_path)
    print("错误表:", errors_path)
    print("=" * 88)
    return {
        "output_dir": output_dir,
        "summary": summary_path,
        "points": points_path,
        "errors": errors_path,
        "label_summary": eval_path,
    }


def synth_leak(fs: int, seconds: float, rng: np.random.Generator, variant: float) -> np.ndarray:
    n = int(round(fs * seconds))
    white = rng.standard_normal(n)
    sos = signal.butter(5, [50_000, 70_000], btype="bandpass", fs=fs, output="sos")
    band = signal.sosfilt(sos, white)
    t = np.arange(n) / fs
    mod = 0.65 + 0.35 * np.sin(2 * np.pi * (8 + variant) * t + variant)
    return 0.05 * mod * band


def synth_noise(fs: int, seconds: float, rng: np.random.Generator, variant: float) -> np.ndarray:
    n = int(round(fs * seconds))
    t = np.arange(n) / fs
    base = 0.025 * rng.standard_normal(n)
    tones = 0.04 * np.sin(2 * np.pi * (53_000 + 1200 * variant) * t) + 0.03 * np.sin(2 * np.pi * 62_000 * t)
    return base + tones


def run_self_test() -> None:
    print("开始SELF-TEST...")
    rng = np.random.default_rng(1234)
    fs = 192_000
    seconds = 0.25
    with tempfile.TemporaryDirectory(prefix="semisup_leak_test_") as td:
        root = Path(td)
        lab01 = ensure_dir(root / "lab" / "0.1mm")
        lab05 = ensure_dir(root / "lab" / "0.5mm")
        for group_dir, shift in ((lab01, 0.0), (lab05, 1.5)):
            for i in range(4):
                x = synth_leak(fs, seconds, rng, shift + i * 0.1)
                wavfile.write(str(group_dir / f"lab_{i}.wav"), fs, x.astype(np.float32))

        center_root = ensure_dir(root / "center" / "condition")
        near_root = ensure_dir(root / "near" / "condition")
        far_root = ensure_dir(root / "far" / "condition")
        leak = synth_leak(fs, seconds, rng, 0.2)
        center = synth_noise(fs, seconds, rng, 0.0) + leak
        wavfile.write(str(center_root / "test_00_00_beamform_result.wav"), fs, center.astype(np.float32))
        distances = list(range(5, 85, 5))
        for direction in DIRECTIONS:
            for distance in distances:
                alpha = max(0.05, 0.8 * math.exp(-distance / 35.0))
                x = synth_noise(fs, seconds, rng, DIRECTIONS.index(direction) * 0.1) + alpha * leak
                target = near_root if distance <= 40 else far_root
                wavfile.write(
                    str(target / f"test_00_00d{distance}_{direction}_beamform_result.wav"),
                    fs,
                    x.astype(np.float32),
                )

        cfg = RunConfig(
            lab_groups={"0.1mm": [str(lab01)], "0.5mm": [str(lab05)]},
            factory_datasets=[
                FactoryDataset(
                    name="synthetic",
                    center_root_dir=str(root / "center"),
                    offset_root_dirs=[str(root / "near"), str(root / "far")],
                    time_folders=["condition"],
                    label_by_folder={"condition": "TRUE"},
                )
            ],
            output_dir=str(root / "out"),
            algorithm=AlgorithmConfig(
                time_slice_seconds=seconds,
                segment_mode="first",
                nperseg=1024,
                hop_length=512,
                nfft=2048,
                leak_components=4,
                noise_components=5,
                max_lab_training_frames=2000,
                max_reference_training_frames=3000,
                nmf_max_iter=120,
                joint_refine_iterations=60,
                inference_iterations=80,
                min_neighbors=100,
                minimum_frequency_bins=20,
                save_plots=False,
                plot_limit=0,
            ),
        )
        paths = run_analysis(cfg)
        summary = pd.read_csv(paths["summary"])
        points = pd.read_csv(paths["points"])
        if len(summary) != 1:
            raise AssertionError(f"SELF-TEST summary行数错误: {len(summary)}")
        if len(points) != 128:
            raise AssertionError(f"SELF-TEST周围点行数错误: {len(points)}")
        required = {
            "leak_lab_similarity_combined_median",
            "noise_lab_similarity_combined_median",
            "leak_similarity_gain_over_raw",
            "center_estimated_leak_power_fraction",
        }
        if not required.issubset(summary.columns):
            raise AssertionError(f"SELF-TEST缺少列: {required - set(summary.columns)}")
        sample_dir = root / "out" / "samples" / "synthetic" / "condition" / "center_00_00"
        for name in ("estimated_leak.wav", "estimated_noise.wav", "separation_result.npz"):
            if not (sample_dir / name).exists():
                raise AssertionError(f"SELF-TEST缺少输出: {name}")
    print("SELF-TEST PASSED")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="消声室引导的半监督泄漏/背景分离")
    parser.add_argument("--config", type=str, default="anechoic_semisupervised_config.json")
    parser.add_argument("--self-test", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if args.self_test:
        run_self_test()
        return
    cfg = load_config(Path(args.config))
    run_analysis(cfg)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n用户中止。")
        sys.exit(130)
    except Exception as exc:
        print(f"\n程序失败: {type(exc).__name__}: {exc}")
        traceback.print_exc()
        sys.exit(1)
