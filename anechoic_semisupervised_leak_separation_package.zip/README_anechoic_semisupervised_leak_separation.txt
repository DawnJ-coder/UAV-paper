消声室引导的半监督泄漏/背景分离
============================================

一、程序解决什么问题
--------------------
中心波束：X0 = S0 + N0
周围波束：Xi = Si + Ni

周围点也含泄漏，因此程序不把40cm、80cm或任意周围点直接当背景。
程序采用：
1. 消声室0.1mm和0.5mm建立冻结泄漏字典；
2. 当前中心附带的周围点学习当前现场噪声字典；
3. 用泄漏字典+噪声字典分解中心；
4. 输出estimated_leak.wav和estimated_noise.wav；
5. 用未参与训练的整条消声室WAV进行相似度验证。

二、必须修改的路径
------------------
打开：
    anechoic_semisupervised_config.json

只需要先修改：
1. lab_groups.0.1mm
2. lab_groups.0.5mm
3. output_dir（如有需要）

工厂路径已按当前数据填写：
    D:\gas\beamform_results_gc_cs
    D:\gas\beamform_results_offset_multiple_gc_cs_0001
    D:\gas\beamform_results_offset_multiple_gc_gy_cs_0001

三、文件名支持
--------------
中心：
    任意前缀_00_00_beamform_result.wav
    任意前缀_00_01_beamform_result.wav

周围：
    任意前缀_00_00d5_down_beamform_result.wav
    ...
    任意前缀_00_00d80_up_right_beamform_result.wav

00_00读取第1秒[0,1)；00_01读取第2秒[1,2)。

四、安装与运行
--------------
安装：
    pip install numpy pandas scipy matplotlib scikit-learn

先自检：
    python anechoic_semisupervised_leak_separation.py --self-test

正式运行：
    python anechoic_semisupervised_leak_separation.py --config anechoic_semisupervised_config.json

五、主要输出
------------
00_READ_ME_FIRST.txt
    结果阅读说明。

00_lab_input_scan.csv
    消声室WAV数量、采样率、时长、状态。

01_lab_train_validation_split.csv
    每条消声室WAV属于训练还是独立验证。按整条WAV划分。

02_frozen_leak_dictionary.npz / .png
    冻结泄漏字典。

10_factory_sample_summary.csv
    每个中心一行的总结果。

11_factory_neighbor_contamination.csv
    每个中心的每个周围点一行，查看估计泄漏污染比例。

samples\数据集\工况\center_编号\
    raw_center_slice.wav
    estimated_leak.wav
    estimated_noise.wav
    separation_result.npz
    neighbor_leak_contamination.csv
    spectrum_comparison.png
    spectrogram_comparison.png
    noise_dictionary.png
    neighbor_leak_contamination_map.png

六、总表重点列
--------------
amplitude_status
    AMPLITUDE_SCALE_OK：未发现明显逐文件归一化迹象。
    POSSIBLE_PER_FILE_NORMALIZATION：幅值关系需谨慎。

center_estimated_leak_power_fraction
    中心50-70kHz功率中，模型分给泄漏成分的比例。

raw_lab_similarity_combined_median
    原始中心与留出消声室WAV的中位相似度。

leak_lab_similarity_combined_median
    分离泄漏与留出消声室WAV的中位相似度。

noise_lab_similarity_combined_median
    分离噪声与留出消声室WAV的中位相似度。

leak_similarity_gain_over_raw
    leak相似度 - raw相似度。应大于0。

leak_vs_noise_similarity_gap
    leak相似度 - noise相似度。应大于0。

separation_quality_flag
    PROMISING：上述两项均大于0。
    NOT_VALIDATED：当前样本未同时满足。
    这不是最终真假泄漏判定。

七、TRUE/FALSE标签
-----------------
null没有任何含义，程序不会根据null猜标签。

当前label_by_folder为空，程序照常分离，但label显示UNLABELED。
如果后续需要自动汇总TRUE/FALSE，可在配置中填写：

"label_by_folder": {
  "完整文件夹名称1": "TRUE",
  "完整文件夹名称2": "FALSE"
}

八、重要限制
------------
1. 没有消声室无泄漏WAV，因此不能设置一个固定相似度阈值宣布“确定泄漏”。
2. 消声室泄漏字典参与分离，所以必须用留出的整条消声室WAV验证。
3. 如果消声室每组只有1条WAV，程序只能退回训练参考验证，不是独立验证。
4. 周围128点来自同一阵列的不同波束输出，不等于128个独立传感器；结果必须结合TRUE/FALSE和后续受控实验验证。
