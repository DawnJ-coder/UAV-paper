@echo off
chcp 65001 >nul
cd /d "%~dp0"
python v16_1_two_points_plane_compare_01_05mm.py --config v16_1_two_points_config_00_00_00_01.json
echo.
pause
