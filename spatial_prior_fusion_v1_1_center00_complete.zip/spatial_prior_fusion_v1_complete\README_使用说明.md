# 空间拟合降噪 + 实验室先验补偿 v1

## 1. 数据口径

本程序没有机器学习意义上的训练集/测试集划分。

- `0.5mm`：构建固定的实验室泄露先验字典。
- `0.1mm`：作为相似度计算依据。
- 工厂中心点和空间偏移点：全部直接逐样本处理。
- T/F 标签（如果配置）：只用于处理完成后的分组、AUC和成对统计，不参与参数估计。

中心点采用严格白名单：只处理 `00_00` 和 `00_01`。其他中心编号及其对应偏移点在建立文件索引时即被过滤，不参与读取、空间拟合、先验补偿、相似度或汇总。

配置文件里不需要设置训练场景或测试场景。

## 2. 新方法

对每个工厂样本，中心功率为 `P0(f,t)`：

1. 排除最近 24 个空间点，只用最外圈 40 点。
2. 在对数功率域学习该样本自己的鲁棒点权重和空间平面系数，得到中心环境噪声预测 `B(f,t)`。
3. 空间拟合保留的泄露为：

   `R_space = max(P0 - B, 0)`

4. 0.5 mm 先验字典在中心样本上逐帧估计激活，只允许从 `min(P0, B)`（被空间背景吸收的部分）中产生补偿候选 `C_prior`，不会重复叠加已保留的空间残差。
5. 对每个样本独立搜索混合系数 `alpha`：

   `P_fused = min(P0, R_space + alpha * C_prior)`

   `alpha` 的选择依据是与 0.1 mm 参照的中位综合相似度。候选中包含 `alpha=0`，因此按该相似度指标，融合输出不会低于空间拟合基线。

空间点权重、平面系数、先验激活和 `alpha` 全部逐样本计算，没有跨工厂样本学习。

## 3. 安装与运行

建议 Python 3.10 或更高版本：

```powershell
python -m pip install -r requirements.txt
python spatial_prior_fusion_v1.py --self-test
python spatial_prior_fusion_v1.py --config spatial_prior_fusion_config.json
```

运行前修改 `spatial_prior_fusion_config.json` 中：

- `lab_groups.0.5mm`
- `lab_groups.0.1mm`
- 每个 `factory_datasets` 的中心目录和偏移目录
- `output_dir`

`time_folders` 留空时会递归自动发现工况目录。中心 WAV 与同一 `center_id` 的全部偏移 WAV 使用完全相同的 1 秒片段。

每个工况最多输出两个样本：`00_00` 和 `00_01`。若其中某个编号不存在，则只处理实际存在的白名单编号；不会用其他编号补足。

## 4. 主要输出

- `00_READ_ME_FIRST.txt`：本次方法和数据口径。
- `00_run_info.json`：完整配置和融合参数。
- `00_lab_prior_similarity_scan.csv`：0.5/0.1 mm 文件角色与读取状态。
- `02_frozen_0p5mm_prior_and_0p1mm_similarity_reference.npz`：实验室先验与相似度参照。
- `10_factory_sample_summary.csv`：每个样本的主结果。
- `11_outer40_plane_point_diagnostics.csv`：所有样本的空间点角色、鲁棒权重和平面影响系数。
- `13_TF_metric_auc.csv`：有 T/F 标签时的事后 AUC。
- `samples/.../spatial_prior_fusion_result.npz`：中心、背景、空间残差、先验补偿和最终结果的完整时频矩阵。
- `samples/.../prior_mix_similarity_grid.csv`：该样本每个 `alpha` 的 0.1 mm 相似度。
- `samples/.../estimated_fused_leak.wav`：融合估计的泄露声音。

重点查看 `10_factory_sample_summary.csv` 中：

- `center_spatial_filtered_power_fraction`
- `center_prior_supplement_power_fraction`
- `center_final_leak_power_fraction`
- `prior_mix_alpha_per_sample`
- `prior_similarity_gain_over_spatial`
- `leak_lab_similarity_combined_median`
- `source_center_score`

## 5. 结果解释

该结构解决的是空间拟合可能把部分扩散泄露吸收到背景中的问题。程序保证融合输出不低于空间正残差，并保证在本程序用于选择 `alpha` 的 0.1 mm 综合相似度上不劣于 `alpha=0` 基线。

这不等于对真实现场性能的无条件保证。最终是否优于旧方法，应结合 T/F 的 AUC、成对差异、现场定位结果和人工复核判断。
