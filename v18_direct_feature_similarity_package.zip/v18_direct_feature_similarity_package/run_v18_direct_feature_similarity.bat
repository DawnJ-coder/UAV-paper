@echo off
chcp 65001 >nul
cd /d "%~dp0"
python v18_direct_feature_similarity.py --config v18_direct_feature_similarity_config.json
if errorlevel 1 (
  echo.
  echo 程序运行失败，请查看上面的错误信息。
) else (
  echo.
  echo 程序运行完成。
)
pause
