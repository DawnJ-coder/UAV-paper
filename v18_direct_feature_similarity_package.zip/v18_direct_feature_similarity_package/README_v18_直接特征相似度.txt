v18：工厂空间拟合残差与消声室三个模型的直接特征相似度
================================================================

一、为什么重新做v18
------------------
v17的主要结果偏向马氏距离判别。
v18改为“特征对特征”的透明比较：

1. 读取v16_1已经生成的filtered_leak.wav；
2. 用消声室建模时完全相同的参数提取5维特征；
3. 分别与0.1mm、0.5mm、ALL_LEAKS三个模型逐项比较；
4. 输出每个具体特征的0~1相似度；
5. 输出工厂样本与0.1mm、0.5mm共同拥有的特征；
6. 比较同一文件夹中00_00和00_01哪个更接近各模型。

二、五个特征
------------
- spectral_flatness
- spectral_spread_hz
- adaptive_snr_db
- flatness_local_std
- spread_local_std_hz

三、直接特征相似度
----------------
对每个特征：

z = (工厂样本中位数 - 消声室模型中位数) / 消声室模型标准差
similarity = exp(-0.5*z^2)

含义：
- similarity=1：该特征与模型中心一致；
- 差1个模型标准差：约0.607；
- 差2个模型标准差：约0.135。

03表中的mean_feature_similarity，是五个特征相似度的简单算术平均，
没有隐藏权重。

四、配置
--------
reference_root_dir默认已经写为：
D:\gas\xssck

请确认v16_output_dir是你实际运行v16_1后得到结果的目录。
该目录中必须能找到：
- 02_all_points_summary.csv
- 各个00_00、00_01对应的filtered_leak.wav

五、运行
--------
自检：
python v18_direct_feature_similarity.py --self-test

正式运行：
python v18_direct_feature_similarity.py --config v18_direct_feature_similarity_config.json

或者双击：
run_v18_direct_feature_similarity.bat

六、最重要的输出
----------------
00_input_check.csv
    确认每个00_00、00_01是否成功读取。

01_factory_sample_feature_values.csv
    工厂空间降噪后，每个样本五个特征的实际数值和P10/P90范围。

02_feature_similarity_detail.csv
    主明细。一行=一个工厂样本×一个模型×一个特征。
    重点看：
    - feature_center_similarity
    - range_overlap_similarity
    - feature_match

03_sample_model_similarity_summary.csv
    一行=一个工厂样本×一个模型。
    重点看：
    - mean_feature_similarity：五个特征的平均直接相似度，主结果；
    - feature_match_count / feature_match_ratio；
    - mean_range_overlap_similarity。
    马氏距离和window_distribution_similarity只作为辅助结果。

04_factory_anechoic_common_features.csv
    判断某项特征是否同时：
    - 接近0.1mm模型；
    - 接近0.5mm模型；
    - 接近ALL_LEAKS模型；
    - 落入0.1mm与0.5mm的稳健共同范围。
    is_factory_anechoic_common_feature=true才属于严格共同特征。

05_two_point_feature_similarity_comparison.csv
    同一个文件夹中00_00与00_01分别对三个模型的比较。
    higher_similarity_point表示哪个点的五维直接特征平均相似度更高；
    SIMILAR表示两个点过于接近，不强行选择。

七、注意
--------
1. v18不重新执行空间拟合，也不需要重新运行消声室建模程序。
2. v18仍使用v16_1的filtered_leak.wav，因为消声室模型也是从WAV按相同方法提取特征。
3. 0.60只是“单项特征较匹配”的显示阈值，不是最终泄漏分类阈值。
4. 先看直接特征相似度和共同特征，再看马氏距离辅助结果。
