# -*- coding: utf-8 -*-
"""
v18_direct_feature_similarity.py

用途
----
把两类已经完成的结果直接接起来：
1. 消声室三个冻结模型：0.1mm、0.5mm、ALL_LEAKS；
2. v16_1 空间拟合降噪后保存的 filtered_leak.wav。

本程序重点不是“分类”，而是透明地计算：
- 每个工厂样本的5维声学特征值；
- 每个特征与每个消声室模型的直接相似度；
- 工厂样本与三个模型的整体特征相似度；
- 工厂样本与0.1mm、0.5mm共同拥有的特征；
- 同一文件夹中00_00和00_01哪个在特征层面更接近消声室模型。

运行
----
python v18_direct_feature_similarity.py --self-test
python v18_direct_feature_similarity.py --config v18_direct_feature_similarity_config.json
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
import traceback
from dataclasses import asdict, dataclass, fields
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    import matplotlib.pyplot as plt
except Exception:
    plt = None

try:
    import anechoic_feature_core as core
except Exception as exc:
    raise RuntimeError(
        "无法导入 anechoic_feature_core.py，请把它与v18主程序放在同一文件夹。"
    ) from exc

EPS = 1.0e-20
FEATURES = list(core.EXPECTED_DISCRIM_COLUMNS)


@dataclass(frozen=True)
class AppConfig:
    reference_root_dir: str = r"D:\gas\xssck"
    v16_output_dir: str = r"D:\gas\v16_two_points_plane_compare_results"
    output_dir: str = r"D:\gas\v18_direct_feature_similarity_results"

    selected_center_ids: Tuple[str, ...] = ("00_00", "00_01")
    models_to_use: Tuple[str, ...] = ("0.1mm", "0.5mm", "ALL_LEAKS")

    # 单项特征中心相似度达到该值，认为该项“较匹配”。
    feature_similarity_threshold: float = 0.60

    # 样本P10-P90与模型P10-P90的区间重叠度达到该值，认为分布范围有重合。
    range_overlap_threshold: float = 0.25

    # 同一文件夹两个点的整体相似度差低于该值，只报告接近，不强行选点。
    minimum_point_similarity_gap: float = 0.03

    require_plane_valid: bool = True
    require_plane_geometry_ok: bool = True
    require_plane_reason_ok: bool = False

    save_window_features: bool = False
    save_plots: bool = True


def dataclass_from_dict(cls: Any, raw: Mapping[str, Any]) -> Any:
    allowed = {f.name for f in fields(cls)}
    clean: Dict[str, Any] = {}
    for key, value in dict(raw).items():
        if key not in allowed:
            continue
        if key in {"selected_center_ids", "models_to_use"} and isinstance(value, list):
            value = tuple(str(v) for v in value)
        clean[key] = value
    return cls(**clean)


def safe_value(value: Any) -> Any:
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        v = float(value)
        return v if math.isfinite(v) else ""
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    if value is None:
        return ""
    return value


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]], columns: Sequence[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(columns), extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: safe_value(row.get(k)) for k in columns})


def write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2, allow_nan=False)


def locate_unique(root: Path, filename: str, required: bool = True) -> Optional[Path]:
    direct = root / filename
    if direct.exists():
        return direct
    matches = list(root.rglob(filename))
    if len(matches) == 1:
        return matches[0]
    if not matches:
        if required:
            raise FileNotFoundError(f"在{root}中没有找到{filename}")
        return None
    raise RuntimeError(
        f"在{root}中找到多个{filename}，请把reference_root_dir指向具体结果目录："
        + "; ".join(str(p) for p in matches[:10])
    )


def load_reference_group_statistics(
    reference_root: Path,
    models: Mapping[str, core.FrozenReferenceModel],
) -> Tuple[pd.DataFrame, str]:
    """读取构建参考模型时保存的P10/P90统计；缺失时使用均值和标准差近似。"""
    path = locate_unique(reference_root, "07_group_feature_statistics.csv", required=False)
    if path is not None:
        df = pd.read_csv(path)
        required = {"group", "feature", "mean", "std", "median", "p10", "p90"}
        missing = required.difference(df.columns)
        if missing:
            raise ValueError(f"{path}缺少列: {sorted(missing)}")
        df = df[df["group"].astype(str).isin(models.keys())].copy()
        return df, str(path)

    # 后备：正态近似P10/P90，只为避免旧结果无法使用；输出中会标明来源。
    rows: List[Dict[str, Any]] = []
    z90 = 1.2815515655446004
    for model_name, model in models.items():
        for i, feature in enumerate(model.feature_names):
            mean = float(model.raw_mean[i])
            std = float(max(model.raw_std[i], 1e-12))
            rows.append({
                "group": model_name,
                "feature": feature,
                "mean": mean,
                "std": std,
                "median": float(model.raw_median[i]),
                "p10": mean - z90 * std,
                "p90": mean + z90 * std,
            })
    return pd.DataFrame(rows), "APPROX_FROM_MODEL_MEAN_STD"


def load_common_ranges(reference_root: Path) -> Tuple[pd.DataFrame, str]:
    path = locate_unique(
        reference_root,
        "08_common_feature_ranges_01mm_05mm.csv",
        required=False,
    )
    if path is None:
        return pd.DataFrame(), "NOT_AVAILABLE"
    df = pd.read_csv(path)
    return df, str(path)


def interval_overlap_coefficient(a_low: float, a_high: float, b_low: float, b_high: float) -> float:
    """交集长度 / 较短区间长度。0表示不重叠，1表示较短区间完全被覆盖。"""
    values = np.asarray([a_low, a_high, b_low, b_high], dtype=np.float64)
    if not np.all(np.isfinite(values)):
        return 0.0
    if a_high < a_low:
        a_low, a_high = a_high, a_low
    if b_high < b_low:
        b_low, b_high = b_high, b_low
    overlap = max(0.0, min(a_high, b_high) - max(a_low, b_low))
    width_a = max(a_high - a_low, EPS)
    width_b = max(b_high - b_low, EPS)
    return float(np.clip(overlap / min(width_a, width_b), 0.0, 1.0))


def feature_center_similarity(sample_median: float, model_median: float, model_std: float) -> Tuple[float, float]:
    """
    先用模型标准差把差异标准化，再映射到0~1：
        z = (sample_median - model_median) / model_std
        similarity = exp(-0.5*z^2)
    """
    scale = max(abs(float(model_std)), 1e-12)
    z = (float(sample_median) - float(model_median)) / scale
    similarity = math.exp(-0.5 * z * z)
    return float(z), float(similarity)


def sample_feature_statistics(matrix: np.ndarray, feature_names: Sequence[str]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for i, feature in enumerate(feature_names):
        values = np.asarray(matrix[:, i], dtype=np.float64)
        rows.append({
            "feature": feature,
            "n_windows": int(values.size),
            "sample_mean": float(np.mean(values)),
            "sample_std": float(np.std(values)),
            "sample_median": float(np.median(values)),
            "sample_p10": float(np.percentile(values, 10.0)),
            "sample_p25": float(np.percentile(values, 25.0)),
            "sample_p75": float(np.percentile(values, 75.0)),
            "sample_p90": float(np.percentile(values, 90.0)),
        })
    return rows


def reference_stat_lookup(group_stats: pd.DataFrame) -> Dict[Tuple[str, str], Dict[str, float]]:
    lookup: Dict[Tuple[str, str], Dict[str, float]] = {}
    for _, row in group_stats.iterrows():
        key = (str(row["group"]), str(row["feature"]))
        lookup[key] = {
            "mean": float(row["mean"]),
            "std": float(max(abs(float(row["std"])), 1e-12)),
            "median": float(row["median"]),
            "p10": float(row["p10"]),
            "p90": float(row["p90"]),
        }
    return lookup


def common_range_lookup(common_df: pd.DataFrame) -> Dict[str, Dict[str, Any]]:
    lookup: Dict[str, Dict[str, Any]] = {}
    if common_df.empty or "feature" not in common_df.columns:
        return lookup
    for _, row in common_df.iterrows():
        feature = str(row["feature"])
        def get_float(name: str) -> float:
            value = row.get(name, np.nan)
            try:
                return float(value)
            except Exception:
                return float("nan")
        raw_bool = row.get("has_robust_common_range", False)
        if isinstance(raw_bool, str):
            has_common = raw_bool.strip().lower() in {"true", "1", "yes", "y"}
        else:
            has_common = bool(raw_bool) if not pd.isna(raw_bool) else False
        lookup[feature] = {
            "has_common": has_common,
            "low": get_float("common_p10_p90_low"),
            "high": get_float("common_p10_p90_high"),
            "overlap_ratio_01_05": get_float("robust_interval_overlap_ratio"),
        }
    return lookup


def direct_feature_rows_for_model(
    meta: Mapping[str, Any],
    sample_stats: Sequence[Mapping[str, Any]],
    model_name: str,
    lookup: Mapping[Tuple[str, str], Mapping[str, float]],
    threshold: float,
    overlap_threshold: float,
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for sample in sample_stats:
        feature = str(sample["feature"])
        ref = lookup.get((model_name, feature))
        if ref is None:
            raise KeyError(f"参考统计中缺少 model={model_name}, feature={feature}")
        z, center_sim = feature_center_similarity(
            float(sample["sample_median"]), ref["median"], ref["std"]
        )
        overlap = interval_overlap_coefficient(
            float(sample["sample_p10"]), float(sample["sample_p90"]),
            ref["p10"], ref["p90"],
        )
        median_inside = bool(ref["p10"] <= float(sample["sample_median"]) <= ref["p90"])
        rows.append({
            **meta,
            "model_name": model_name,
            "feature": feature,
            **sample,
            "model_mean": ref["mean"],
            "model_std": ref["std"],
            "model_median": ref["median"],
            "model_p10": ref["p10"],
            "model_p90": ref["p90"],
            "signed_z_difference": z,
            "absolute_z_difference": abs(z),
            "feature_center_similarity": center_sim,
            "range_overlap_similarity": overlap,
            "sample_median_inside_model_p10_p90": median_inside,
            "center_similarity_pass": bool(center_sim >= threshold),
            "range_overlap_pass": bool(overlap >= overlap_threshold),
            "feature_match": bool(center_sim >= threshold and (median_inside or overlap >= overlap_threshold)),
        })
    return rows


def model_summary_row(
    meta: Mapping[str, Any],
    model: core.FrozenReferenceModel,
    matrix: np.ndarray,
    detail_rows: Sequence[Mapping[str, Any]],
    threshold: float,
) -> Dict[str, Any]:
    center_sims = np.asarray([float(r["feature_center_similarity"]) for r in detail_rows])
    overlaps = np.asarray([float(r["range_overlap_similarity"]) for r in detail_rows])
    matches = np.asarray([bool(r["feature_match"]) for r in detail_rows], dtype=bool)

    # “直接特征相似度”：五个特征各自相似度的算术平均，完全透明。
    mean_feature_similarity = float(np.mean(center_sims))
    median_feature_similarity = float(np.median(center_sims))
    minimum_feature_similarity = float(np.min(center_sims))
    feature_match_ratio = float(np.mean(matches))
    mean_range_overlap = float(np.mean(overlaps))

    # 辅助1：样本中位特征向量到模型的联合马氏距离。
    median_vector = np.asarray(
        [float(r["sample_median"]) for r in detail_rows], dtype=np.float64
    ).reshape(1, -1)
    joint_distance = float(model.distances(median_vector)[0])
    joint_similarity = float(model.similarity(joint_distance))

    # 辅助2：逐时间窗分布与模型的接近程度。
    window_stats, _ = model.file_statistics(matrix)

    return {
        **meta,
        "model_name": model.model_name,
        "n_features": int(center_sims.size),
        "mean_feature_similarity": mean_feature_similarity,
        "median_feature_similarity": median_feature_similarity,
        "minimum_feature_similarity": minimum_feature_similarity,
        "feature_match_count": int(np.sum(matches)),
        "feature_match_ratio": feature_match_ratio,
        "mean_range_overlap_similarity": mean_range_overlap,
        "all_features_above_threshold": bool(np.all(center_sims >= threshold)),
        "joint_mahalanobis_distance_of_medians": joint_distance,
        "joint_mahalanobis_similarity_of_medians": joint_similarity,
        "window_median_distance": window_stats["median_distance"],
        "window_p90_distance": window_stats["p90_distance"],
        "window_inside_fraction": window_stats["window_inside_fraction"],
        "window_distribution_similarity": window_stats["balanced_similarity"],
    }


def build_cross_aperture_common_rows(
    sample_meta_rows: Sequence[Mapping[str, Any]],
    all_detail_rows: Sequence[Mapping[str, Any]],
    common_lookup: Mapping[str, Mapping[str, Any]],
    similarity_threshold: float,
) -> List[Dict[str, Any]]:
    detail = pd.DataFrame(all_detail_rows)
    if detail.empty:
        return []
    wanted = {"0.1mm", "0.5mm", "ALL_LEAKS"}
    rows: List[Dict[str, Any]] = []
    for meta in sample_meta_rows:
        mask = detail["sample_id"].astype(str) == str(meta["sample_id"])
        part = detail.loc[mask]
        for feature in FEATURES:
            fp = part[part["feature"].astype(str) == feature]
            by_model = {str(r["model_name"]): r for _, r in fp.iterrows()}
            cr = dict(common_lookup.get(feature, {}))
            has_common = bool(cr.get("has_common", False))
            common_low = float(cr.get("low", np.nan))
            common_high = float(cr.get("high", np.nan))

            sample_row = next((r for r in sample_meta_rows if str(r["sample_id"]) == str(meta["sample_id"])), meta)
            # 任一模型行都包含相同的sample_median。
            sample_median = float(fp.iloc[0]["sample_median"]) if not fp.empty else np.nan
            in_common = bool(
                has_common and np.isfinite(common_low) and np.isfinite(common_high)
                and common_low <= sample_median <= common_high
            )

            sims = {
                name: float(by_model[name]["feature_center_similarity"])
                if name in by_model else np.nan
                for name in wanted
            }
            sim01 = sims["0.1mm"]
            sim05 = sims["0.5mm"]
            simall = sims["ALL_LEAKS"]
            finite = [v for v in [sim01, sim05, simall] if np.isfinite(v)]
            min_sim = float(min(finite)) if finite else np.nan

            reasons: List[str] = []
            if not has_common:
                reasons.append("消声室0.1mm与0.5mm本身无稳健共同范围")
            if has_common and not in_common:
                reasons.append("工厂样本中位特征不在消声室共同范围内")
            if any(not np.isfinite(v) or v < similarity_threshold for v in [sim01, sim05, simall]):
                reasons.append("至少一个模型的单项特征相似度不足")
            is_common = bool(
                has_common and in_common
                and np.isfinite(sim01) and sim01 >= similarity_threshold
                and np.isfinite(sim05) and sim05 >= similarity_threshold
                and np.isfinite(simall) and simall >= similarity_threshold
            )
            if is_common:
                reasons = ["通过：同时接近0.1mm、0.5mm及ALL_LEAKS，且落入跨孔径共同范围"]

            rows.append({
                **meta,
                "feature": feature,
                "sample_median": sample_median,
                "similarity_to_0.1mm": sim01,
                "similarity_to_0.5mm": sim05,
                "similarity_to_ALL_LEAKS": simall,
                "minimum_similarity_across_three_models": min_sim,
                "anechoic_01_05_has_common_range": has_common,
                "anechoic_common_range_low": common_low,
                "anechoic_common_range_high": common_high,
                "sample_inside_anechoic_common_range": in_common,
                "is_factory_anechoic_common_feature": is_common,
                "reason": "; ".join(reasons),
            })
    return rows


def build_two_point_rows(summary_rows: Sequence[Mapping[str, Any]], cfg: AppConfig) -> List[Dict[str, Any]]:
    df = pd.DataFrame(summary_rows)
    if df.empty:
        return []
    output: List[Dict[str, Any]] = []
    group_cols = ["dataset", "folder", "model_name"]
    for keys, part in df.groupby(group_cols, dropna=False):
        dataset, folder, model_name = keys
        by_center = {
            str(row["center_id"]): row
            for _, row in part.iterrows()
            if str(row["center_id"]) in cfg.selected_center_ids
        }
        row: Dict[str, Any] = {
            "dataset": dataset,
            "folder": folder,
            "model_name": model_name,
        }
        scores: List[Tuple[str, float]] = []
        for center_id in cfg.selected_center_ids:
            item = by_center.get(center_id)
            score = float(item["mean_feature_similarity"]) if item is not None else np.nan
            row[f"mean_feature_similarity__{center_id}"] = score
            row[f"feature_match_ratio__{center_id}"] = (
                float(item["feature_match_ratio"]) if item is not None else np.nan
            )
            row[f"mean_range_overlap__{center_id}"] = (
                float(item["mean_range_overlap_similarity"]) if item is not None else np.nan
            )
            if np.isfinite(score):
                scores.append((center_id, score))
        scores.sort(key=lambda x: x[1], reverse=True)
        if not scores:
            decision = "NO_VALID_POINT"
            gap = np.nan
            reason = "没有有效点"
        elif len(scores) == 1:
            decision = scores[0][0]
            gap = np.nan
            reason = "只有一个有效点"
        else:
            gap = scores[0][1] - scores[1][1]
            if gap < cfg.minimum_point_similarity_gap:
                decision = "SIMILAR"
                reason = "两个点的直接特征相似度接近，不强行选点"
            else:
                decision = scores[0][0]
                reason = "该点的五维直接特征平均相似度更高"
        row.update({
            "higher_similarity_point": decision,
            "similarity_gap": gap,
            "decision_reason": reason,
        })
        output.append(row)
    return output


def save_sample_plot(
    out_dir: Path,
    sample_meta: Mapping[str, Any],
    detail_rows: Sequence[Mapping[str, Any]],
) -> None:
    if plt is None:
        return
    part = pd.DataFrame(detail_rows)
    if part.empty:
        return
    models = [m for m in ["0.1mm", "0.5mm", "ALL_LEAKS"] if m in set(part["model_name"])]
    x = np.arange(len(FEATURES), dtype=float)
    width = 0.8 / max(len(models), 1)
    fig, ax = plt.subplots(figsize=(11, 5.8), dpi=140)
    for i, model_name in enumerate(models):
        mp = part[part["model_name"] == model_name].set_index("feature")
        values = [float(mp.loc[f, "feature_center_similarity"]) if f in mp.index else np.nan for f in FEATURES]
        ax.bar(x + (i - (len(models)-1)/2) * width, values, width=width, label=model_name)
    ax.set_xticks(x)
    ax.set_xticklabels(FEATURES, rotation=20, ha="right")
    ax.set_ylim(0.0, 1.05)
    ax.set_ylabel("Direct feature similarity (0-1)")
    ax.set_title(
        f"{sample_meta['dataset']} | {sample_meta['folder']} | {sample_meta['center_id']}\n"
        "Each bar compares one factory feature with one anechoic model"
    )
    ax.grid(axis="y", alpha=0.3)
    ax.legend()
    fig.tight_layout()
    safe_id = re.sub(r"[^0-9A-Za-z_.-]+", "_", str(sample_meta["sample_id"]))
    fig.savefig(out_dir / "plots" / f"feature_similarity_{safe_id}.png", bbox_inches="tight")
    plt.close(fig)


def process(cfg: AppConfig) -> None:
    reference_root = Path(cfg.reference_root_dir)
    v16_root = Path(cfg.v16_output_dir)
    output_dir = Path(cfg.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "plots").mkdir(parents=True, exist_ok=True)

    manifest_path, feature_cfg, models = core.load_models(reference_root, cfg.models_to_use)
    group_stats, group_stats_source = load_reference_group_statistics(reference_root, models)
    common_df, common_source = load_common_ranges(reference_root)
    ref_lookup = reference_stat_lookup(group_stats)
    common_lookup = common_range_lookup(common_df)

    summary_path = core.locate_v16_summary(v16_root)
    v16_df = pd.read_csv(summary_path)

    selected = {str(v) for v in cfg.selected_center_ids}
    sample_stats_rows: List[Dict[str, Any]] = []
    detail_rows: List[Dict[str, Any]] = []
    model_summary_rows: List[Dict[str, Any]] = []
    input_rows: List[Dict[str, Any]] = []
    error_rows: List[Dict[str, Any]] = []
    window_rows: List[Dict[str, Any]] = []
    sample_meta_rows: List[Dict[str, Any]] = []

    for _, series in v16_df.iterrows():
        row = series.to_dict()
        center_id = core.normalize_center_id(core.row_text(row, "center_id"))
        if center_id not in selected:
            continue
        sample_id = core.row_text(row, "sample_id") or (
            f"{core.row_text(row, 'dataset')}__{core.row_text(row, 'folder')}__{center_id}"
        )
        meta = {
            "sample_id": sample_id,
            "dataset": core.row_text(row, "dataset"),
            "folder": core.row_text(row, "folder"),
            "center_id": center_id,
        }
        try:
            plane_ok, plane_reason = core.validate_plane_row(row, core.AppConfig(
                require_plane_valid=cfg.require_plane_valid,
                require_plane_geometry_ok=cfg.require_plane_geometry_ok,
                require_plane_reason_ok=cfg.require_plane_reason_ok,
            ))
            if not plane_ok:
                raise ValueError(f"空间拟合质量检查未通过: {plane_reason}")

            wav_path = core.locate_filtered_wav(row, v16_root)
            record = core.extract_file_features(wav_path, feature_cfg)
            matrix = core.discrimination_matrix(record, FEATURES)
            stats = sample_feature_statistics(matrix, FEATURES)

            sample_meta = {
                **meta,
                "filtered_leak_wav": str(wav_path),
                "sample_rate_hz": record.sample_rate_hz,
                "duration_seconds": record.duration_seconds,
                "n_windows": int(matrix.shape[0]),
                "plane_component_fraction_of_center": row.get("plane_component_fraction_of_center", np.nan),
                "plane_integrated_snr_db": row.get("plane_integrated_snr_db", np.nan),
            }
            sample_meta_rows.append(sample_meta)

            for stat in stats:
                sample_stats_rows.append({**sample_meta, **stat})

            current_detail: List[Dict[str, Any]] = []
            for model_name, model in models.items():
                model_detail = direct_feature_rows_for_model(
                    sample_meta,
                    stats,
                    model_name,
                    ref_lookup,
                    cfg.feature_similarity_threshold,
                    cfg.range_overlap_threshold,
                )
                detail_rows.extend(model_detail)
                current_detail.extend(model_detail)
                model_summary_rows.append(model_summary_row(
                    sample_meta,
                    model,
                    matrix,
                    model_detail,
                    cfg.feature_similarity_threshold,
                ))

            if cfg.save_window_features:
                for wi, values in enumerate(matrix):
                    wrow = {**sample_meta, "window_index": wi}
                    for feature, value in zip(FEATURES, values):
                        wrow[feature] = float(value)
                    window_rows.append(wrow)

            if cfg.save_plots:
                save_sample_plot(output_dir, sample_meta, current_detail)

            input_rows.append({
                **sample_meta,
                "status": "OK",
                "error": "",
            })
        except Exception as exc:
            message = f"{type(exc).__name__}: {exc}"
            input_rows.append({**meta, "status": "FAILED", "error": message})
            error_rows.append({**meta, "error": message, "traceback": traceback.format_exc()})

    common_rows = build_cross_aperture_common_rows(
        sample_meta_rows,
        detail_rows,
        common_lookup,
        cfg.feature_similarity_threshold,
    )
    two_point_rows = build_two_point_rows(model_summary_rows, cfg)

    input_cols = [
        "sample_id", "dataset", "folder", "center_id", "filtered_leak_wav",
        "sample_rate_hz", "duration_seconds", "n_windows", "status", "error",
    ]
    sample_cols = [
        "sample_id", "dataset", "folder", "center_id", "filtered_leak_wav",
        "sample_rate_hz", "duration_seconds", "n_windows",
        "plane_component_fraction_of_center", "plane_integrated_snr_db",
        "feature", "sample_mean", "sample_std", "sample_median",
        "sample_p10", "sample_p25", "sample_p75", "sample_p90",
    ]
    detail_cols = [
        "sample_id", "dataset", "folder", "center_id", "model_name", "feature",
        "sample_median", "sample_p10", "sample_p90",
        "model_median", "model_std", "model_p10", "model_p90",
        "signed_z_difference", "absolute_z_difference",
        "feature_center_similarity", "range_overlap_similarity",
        "sample_median_inside_model_p10_p90", "center_similarity_pass",
        "range_overlap_pass", "feature_match",
    ]
    summary_cols = [
        "sample_id", "dataset", "folder", "center_id", "model_name",
        "n_features", "mean_feature_similarity", "median_feature_similarity",
        "minimum_feature_similarity", "feature_match_count", "feature_match_ratio",
        "mean_range_overlap_similarity", "all_features_above_threshold",
        "joint_mahalanobis_distance_of_medians", "joint_mahalanobis_similarity_of_medians",
        "window_median_distance", "window_p90_distance", "window_inside_fraction",
        "window_distribution_similarity",
    ]
    common_cols = [
        "sample_id", "dataset", "folder", "center_id", "feature", "sample_median",
        "similarity_to_0.1mm", "similarity_to_0.5mm", "similarity_to_ALL_LEAKS",
        "minimum_similarity_across_three_models",
        "anechoic_01_05_has_common_range", "anechoic_common_range_low",
        "anechoic_common_range_high", "sample_inside_anechoic_common_range",
        "is_factory_anechoic_common_feature", "reason",
    ]
    two_cols = [
        "dataset", "folder", "model_name",
        "mean_feature_similarity__00_00", "mean_feature_similarity__00_01",
        "feature_match_ratio__00_00", "feature_match_ratio__00_01",
        "mean_range_overlap__00_00", "mean_range_overlap__00_01",
        "higher_similarity_point", "similarity_gap", "decision_reason",
    ]

    write_csv(output_dir / "00_input_check.csv", input_rows, input_cols)
    write_csv(output_dir / "01_factory_sample_feature_values.csv", sample_stats_rows, sample_cols)
    write_csv(output_dir / "02_feature_similarity_detail.csv", detail_rows, detail_cols)
    write_csv(output_dir / "03_sample_model_similarity_summary.csv", model_summary_rows, summary_cols)
    write_csv(output_dir / "04_factory_anechoic_common_features.csv", common_rows, common_cols)
    write_csv(output_dir / "05_two_point_feature_similarity_comparison.csv", two_point_rows, two_cols)
    if cfg.save_window_features:
        write_csv(
            output_dir / "06_factory_window_features.csv",
            window_rows,
            ["sample_id", "dataset", "folder", "center_id", "window_index"] + FEATURES,
        )
    write_csv(
        output_dir / "99_errors.csv",
        error_rows,
        ["sample_id", "dataset", "folder", "center_id", "error", "traceback"],
    )

    run_info = {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "method": "DIRECT_PER_FEATURE_SIMILARITY",
        "reference_manifest": str(manifest_path),
        "reference_group_statistics_source": group_stats_source,
        "reference_common_ranges_source": common_source,
        "v16_summary": str(summary_path),
        "feature_names": FEATURES,
        "feature_similarity_formula": "exp(-0.5*((sample_median-model_median)/model_std)^2)",
        "overall_direct_similarity": "arithmetic mean of the five per-feature center similarities",
        "range_overlap_formula": "intersection length / shorter P10-P90 interval length",
        "important_note": "Mahalanobis and window-distribution scores are auxiliary; 02 and 03 direct feature similarity columns are the main results.",
        "config": asdict(cfg),
        "n_valid_samples": len(sample_meta_rows),
        "n_failed_samples": len(error_rows),
    }
    write_json(output_dir / "00_run_info.json", run_info)

    print("\n处理完成")
    print(f"有效工厂样本: {len(sample_meta_rows)}")
    print(f"失败样本: {len(error_rows)}")
    print(f"结果目录: {output_dir}")
    print("主结果:")
    print("  02_feature_similarity_detail.csv       每个具体特征的相似度")
    print("  03_sample_model_similarity_summary.csv 每个样本与三个模型的整体特征相似度")
    print("  04_factory_anechoic_common_features.csv 工厂与0.1/0.5mm共同特征")
    print("  05_two_point_feature_similarity_comparison.csv 00_00与00_01比较")


def load_config(path: Path) -> AppConfig:
    with path.open("r", encoding="utf-8-sig") as f:
        raw = json.load(f)
    cfg = dataclass_from_dict(AppConfig, raw)
    if not (0.0 < cfg.feature_similarity_threshold <= 1.0):
        raise ValueError("feature_similarity_threshold必须在(0,1]内")
    if not (0.0 <= cfg.range_overlap_threshold <= 1.0):
        raise ValueError("range_overlap_threshold必须在[0,1]内")
    return cfg


def run_self_test() -> None:
    z0, s0 = feature_center_similarity(10.0, 10.0, 2.0)
    z1, s1 = feature_center_similarity(12.0, 10.0, 2.0)
    z2, s2 = feature_center_similarity(14.0, 10.0, 2.0)
    overlap_full = interval_overlap_coefficient(2.0, 4.0, 1.0, 5.0)
    overlap_none = interval_overlap_coefficient(1.0, 2.0, 3.0, 4.0)
    if not (abs(z0) < 1e-12 and abs(s0 - 1.0) < 1e-12):
        raise AssertionError("完全相同特征的相似度自检失败")
    if not (s0 > s1 > s2):
        raise AssertionError("特征差异增大时相似度应下降")
    if abs(overlap_full - 1.0) > 1e-12 or abs(overlap_none) > 1e-12:
        raise AssertionError("区间重叠度自检失败")
    print("自检通过")
    print(f"差0个标准差: similarity={s0:.6f}")
    print(f"差1个标准差: similarity={s1:.6f}")
    print(f"差2个标准差: similarity={s2:.6f}")
    print(f"完全覆盖区间重叠度: {overlap_full:.6f}")
    print(f"无交集区间重叠度: {overlap_none:.6f}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="工厂空间残差与消声室三个模型的直接特征相似度")
    parser.add_argument("--config", type=str, help="JSON配置文件路径")
    parser.add_argument("--self-test", action="store_true", help="运行内置自检")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.self_test:
        run_self_test()
        return
    if not args.config:
        raise SystemExit("请使用 --config 指定配置文件，或使用 --self-test")
    process(load_config(Path(args.config)))


if __name__ == "__main__":
    main()
