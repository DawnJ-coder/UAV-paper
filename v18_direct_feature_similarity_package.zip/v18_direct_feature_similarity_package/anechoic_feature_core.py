# -*- coding: utf-8 -*-
"""
v17_factory_vs_anechoic_models.py

用途
----
读取：
1. 消声室参考模型目录（由 build_anechoic_reference_models.py 生成）；
2. v16_1 的输出目录（包含 02_all_points_summary.csv 和 filtered_leak.wav）；

对每个工厂文件夹中的 00_00、00_01：
- 读取 v16_1 空间拟合后重建的 filtered_leak.wav；
- 使用消声室模型完全相同的参数提取5维特征；
- 计算到 0.1mm、0.5mm、ALL_LEAKS 模型的马氏距离和0~1相似度；
- 输出逐点结果、特征差异和每个文件夹的两点比较结论。

说明
----
本程序不会重新执行空间拟合。它直接复用 v16_1 已经保存的 filtered_leak.wav。
如 filtered_leak.wav 不存在，请确认 v16_1 配置中的 save_filtered_wav=true 后重跑 v16_1。

依赖
----
pip install numpy pandas scipy matplotlib

运行
----
python v17_factory_vs_anechoic_models.py --self-test
python v17_factory_vs_anechoic_models.py --config v17_factory_vs_anechoic_config.json
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
import sys
import traceback
from dataclasses import dataclass, fields
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    from scipy import signal
    from scipy.io import wavfile
except Exception as exc:
    raise RuntimeError("缺少 scipy，请运行: pip install scipy") from exc

try:
    import matplotlib.pyplot as plt
except Exception:
    plt = None

EPS = 1.0e-20
ALL_FEATURE_COLUMNS = [
    "energy_db",
    "spectral_flatness",
    "spectral_centroid_hz",
    "spectral_spread_hz",
    "adaptive_snr_db",
    "flatness_local_std",
    "spread_local_std_hz",
]
EXPECTED_DISCRIM_COLUMNS = [
    "spectral_flatness",
    "spectral_spread_hz",
    "adaptive_snr_db",
    "flatness_local_std",
    "spread_local_std_hz",
]


@dataclass(frozen=True)
class FeatureConfig:
    freq_low_hz: float = 18_000.0
    freq_high_hz: float = 50_000.0
    window_ms: float = 100.0
    hop_ms: float = 50.0
    welch_nfft: int = 2048
    snr_floor_percentile: float = 10.0
    consistency_window_frames: int = 10
    minimum_windows_per_file: int = 3


@dataclass(frozen=True)
class AppConfig:
    reference_root_dir: str = r"D:\gas\xssck"
    v16_output_dir: str = r"D:\gas\v16_two_points_plane_compare_results"
    output_dir: str = r"D:\gas\v17_factory_vs_xssck_results"
    selected_center_ids: Tuple[str, ...] = ("00_00", "00_01")
    models_to_use: Tuple[str, ...] = ("0.1mm", "0.5mm", "ALL_LEAKS")
    preferred_decision_model: str = "ALL_LEAKS"
    minimum_similarity_gap: float = 0.03
    require_plane_valid: bool = True
    require_plane_geometry_ok: bool = True
    require_plane_reason_ok: bool = False
    save_window_details: bool = False
    save_plots: bool = True


@dataclass
class FeatureRecord:
    file_path: str
    sample_rate_hz: int
    duration_seconds: float
    frames: np.ndarray


class FrozenReferenceModel:
    def __init__(self, payload: Mapping[str, Any], source_path: Path) -> None:
        self.source_path = str(source_path)
        self.model_name = str(payload["model_name"])
        self.feature_names = [str(v) for v in payload["feature_names"]]
        self.feature_extraction = dict(payload["feature_extraction"])
        self.raw_mean = np.asarray(payload["raw_mean"], dtype=np.float64)
        self.raw_median = np.asarray(payload.get("raw_median", payload["raw_mean"]), dtype=np.float64)
        self.raw_std = np.asarray(payload["raw_std"], dtype=np.float64)
        self.center = np.asarray(payload["standardized_center"], dtype=np.float64)
        self.inverse_covariance = np.asarray(payload["inverse_covariance"], dtype=np.float64)
        self.window_distance_threshold = float(payload["window_distance_threshold"])
        self.file_thresholds = dict(payload.get("file_thresholds", {}))
        self._validate()

    def _validate(self) -> None:
        n = len(self.feature_names)
        if n != len(EXPECTED_DISCRIM_COLUMNS):
            raise ValueError(
                f"模型 {self.model_name} 特征维数={n}，预期={len(EXPECTED_DISCRIM_COLUMNS)}"
            )
        for name, array in [
            ("raw_mean", self.raw_mean),
            ("raw_median", self.raw_median),
            ("raw_std", self.raw_std),
            ("center", self.center),
        ]:
            if array.shape != (n,):
                raise ValueError(f"模型 {self.model_name} 的 {name} 形状错误: {array.shape}")
        if self.inverse_covariance.shape != (n, n):
            raise ValueError(
                f"模型 {self.model_name} inverse_covariance形状错误: "
                f"{self.inverse_covariance.shape}"
            )
        self.raw_std = np.maximum(self.raw_std, 1.0e-12)

    def distances(self, matrix: np.ndarray) -> np.ndarray:
        x = np.asarray(matrix, dtype=np.float64)
        if x.ndim != 2 or x.shape[1] != len(self.feature_names):
            raise ValueError(
                f"模型 {self.model_name}: 待测矩阵应为(N,{len(self.feature_names)})，实际{x.shape}"
            )
        z = (x - self.raw_mean) / self.raw_std
        delta = z - self.center
        d2 = np.einsum("ij,jk,ik->i", delta, self.inverse_covariance, delta, optimize=True)
        return np.sqrt(np.maximum(d2, 0.0))

    def similarity(self, distance: np.ndarray | float) -> np.ndarray:
        d = np.asarray(distance, dtype=np.float64)
        tau = max(self.window_distance_threshold, EPS)
        return np.exp(-0.5 * np.square(d / tau))

    def file_statistics(self, matrix: np.ndarray) -> Tuple[Dict[str, Any], np.ndarray]:
        distances = self.distances(matrix)
        if distances.size == 0:
            return ({
                "n_windows": 0,
                "median_distance": np.nan,
                "p90_distance": np.nan,
                "mean_distance": np.nan,
                "std_distance": np.nan,
                "window_inside_fraction": 0.0,
                "median_similarity": 0.0,
                "p90_guard_similarity": 0.0,
                "balanced_similarity": 0.0,
                "threshold_available": False,
                "classified_as_leak": None,
            }, distances)
        median_d = float(np.median(distances))
        p90_d = float(np.percentile(distances, 90.0))
        mean_d = float(np.mean(distances))
        std_d = float(np.std(distances))
        inside = float(np.mean(distances <= self.window_distance_threshold))
        med_sim = float(self.similarity(median_d))
        p90_sim = float(self.similarity(p90_d))
        balanced = float(math.sqrt(max(med_sim * p90_sim, 0.0)))

        available = bool(self.file_thresholds.get("available", False))
        classified: Optional[bool] = None
        med_tau = self.file_thresholds.get("median_distance_threshold")
        p90_tau = self.file_thresholds.get("p90_distance_threshold")
        if available and med_tau is not None and p90_tau is not None:
            classified = bool(median_d <= float(med_tau) and p90_d <= float(p90_tau))

        return ({
            "n_windows": int(distances.size),
            "median_distance": median_d,
            "p90_distance": p90_d,
            "mean_distance": mean_d,
            "std_distance": std_d,
            "window_inside_fraction": inside,
            "median_similarity": med_sim,
            "p90_guard_similarity": p90_sim,
            "balanced_similarity": balanced,
            "threshold_available": available,
            "classified_as_leak": classified,
            "median_distance_threshold": med_tau,
            "p90_distance_threshold": p90_tau,
        }, distances)


def dataclass_from_dict(cls: Any, raw: Mapping[str, Any]) -> Any:
    allowed = {f.name for f in fields(cls)}
    clean: Dict[str, Any] = {}
    for key, value in dict(raw).items():
        if key not in allowed:
            continue
        if key in {"selected_center_ids", "models_to_use"} and isinstance(value, list):
            value = tuple(str(v) for v in value)
        clean[key] = value
    return cls(**clean)


def load_json(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as f:
        return json.load(f)


def write_json(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2, allow_nan=False)


def safe_value(value: Any) -> Any:
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        v = float(value)
        return v if math.isfinite(v) else ""
    if isinstance(value, (np.bool_, bool)):
        return bool(value)
    if value is None:
        return ""
    return value


def write_csv(path: Path, rows: Sequence[Mapping[str, Any]], columns: Sequence[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(columns), extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: safe_value(row.get(k)) for k in columns})


def pcm_to_float(data: np.ndarray) -> np.ndarray:
    x = np.asarray(data)
    if np.issubdtype(x.dtype, np.floating):
        out = x.astype(np.float64, copy=False)
    elif x.dtype == np.uint8:
        out = (x.astype(np.float64) - 128.0) / 128.0
    elif np.issubdtype(x.dtype, np.signedinteger):
        info = np.iinfo(x.dtype)
        scale = float(max(abs(info.min), abs(info.max)))
        out = x.astype(np.float64) / scale
    else:
        raise TypeError(f"不支持的WAV数据类型: {x.dtype}")
    if out.ndim > 1:
        out = np.mean(out, axis=1)
    out = np.asarray(out, dtype=np.float64).reshape(-1)
    out[~np.isfinite(out)] = 0.0
    return out


def read_wav_mono(path: Path) -> Tuple[int, np.ndarray]:
    fs, data = wavfile.read(str(path), mmap=False)
    if int(fs) <= 0:
        raise ValueError("采样率无效")
    return int(fs), pcm_to_float(data)


def rolling_std(values: np.ndarray, width: int) -> np.ndarray:
    v = np.asarray(values, dtype=np.float64)
    out = np.zeros_like(v)
    half = max(int(width) // 2, 0)
    for i in range(v.size):
        start = max(0, i - half)
        end = min(v.size, i + half + 1)
        out[i] = float(np.std(v[start:end]))
    return out


def one_window_features(samples: np.ndarray, fs: int, cfg: FeatureConfig) -> np.ndarray:
    nperseg = min(int(cfg.welch_nfft), int(samples.size))
    if nperseg < 16:
        raise ValueError("单窗有效采样点少于16")
    freq, power = signal.welch(
        samples,
        fs=fs,
        window="hann",
        nperseg=nperseg,
        noverlap=nperseg // 2,
        nfft=int(cfg.welch_nfft),
        detrend=False,
        scaling="density",
    )
    mask = (freq >= cfg.freq_low_hz) & (freq <= cfg.freq_high_hz)
    if np.count_nonzero(mask) < 3:
        raise ValueError(
            f"{cfg.freq_low_hz:g}-{cfg.freq_high_hz:g}Hz内有效频点不足；"
            f"采样率={fs}Hz，Nyquist={fs/2:g}Hz"
        )
    f = freq[mask]
    p = np.maximum(power[mask], EPS)
    total = float(np.sum(p))
    energy_db = float(10.0 * np.log10(total + EPS))
    flatness = float(np.exp(np.mean(np.log(p))) / (np.mean(p) + EPS))
    centroid = float(np.sum(f * p) / (total + EPS))
    spread = float(np.sqrt(np.sum(np.square(f - centroid) * p) / (total + EPS)))
    return np.asarray([energy_db, flatness, centroid, spread], dtype=np.float64)


def extract_file_features(path: Path, cfg: FeatureConfig) -> FeatureRecord:
    fs, x = read_wav_mono(path)
    if fs / 2.0 < cfg.freq_high_hz:
        raise ValueError(
            f"采样率{fs}Hz的Nyquist频率仅{fs/2:g}Hz，"
            f"低于模型频率上限{cfg.freq_high_hz:g}Hz"
        )
    win = int(round(fs * cfg.window_ms / 1000.0))
    hop = int(round(fs * cfg.hop_ms / 1000.0))
    if win < 16 or hop < 1:
        raise ValueError("窗口或步长换算后的采样点数无效")
    if x.size < win:
        raise ValueError(
            f"WAV时长{x.size/fs:.4f}s，小于窗口{cfg.window_ms/1000:.4f}s"
        )

    base_rows: List[np.ndarray] = []
    for start in range(0, x.size - win + 1, hop):
        base_rows.append(one_window_features(x[start:start + win], fs, cfg))
    base = np.vstack(base_rows)
    energy = base[:, 0]
    flatness = base[:, 1]
    centroid = base[:, 2]
    spread = base[:, 3]
    floor = float(np.percentile(energy, cfg.snr_floor_percentile))
    adaptive_snr = energy - floor
    flatness_std = rolling_std(flatness, cfg.consistency_window_frames)
    spread_std = rolling_std(spread, cfg.consistency_window_frames)
    frames = np.column_stack([
        energy,
        flatness,
        centroid,
        spread,
        adaptive_snr,
        flatness_std,
        spread_std,
    ])
    if frames.shape[0] < cfg.minimum_windows_per_file:
        raise ValueError(
            f"有效时间窗仅{frames.shape[0]}，少于minimum_windows_per_file="
            f"{cfg.minimum_windows_per_file}"
        )
    return FeatureRecord(
        file_path=str(path),
        sample_rate_hz=fs,
        duration_seconds=float(x.size / fs),
        frames=np.asarray(frames, dtype=np.float64),
    )


def discrimination_matrix(record: FeatureRecord, feature_names: Sequence[str]) -> np.ndarray:
    indices: List[int] = []
    for name in feature_names:
        if name not in ALL_FEATURE_COLUMNS:
            raise ValueError(f"模型使用了未知特征: {name}")
        indices.append(ALL_FEATURE_COLUMNS.index(name))
    return record.frames[:, indices]


def resolve_manifest(reference_root: Path) -> Path:
    direct = reference_root / "09_reference_manifest.json"
    if direct.exists():
        return direct
    matches = list(reference_root.rglob("09_reference_manifest.json"))
    if len(matches) == 1:
        return matches[0]
    if not matches:
        raise FileNotFoundError(
            f"在{reference_root}中没有找到09_reference_manifest.json"
        )
    raise RuntimeError(
        f"在{reference_root}中找到多个09_reference_manifest.json，请只保留或明确一个目录: "
        + "; ".join(str(p) for p in matches[:10])
    )


def resolve_model_json(
    reference_root: Path,
    manifest_path: Path,
    model_name: str,
    entry: Mapping[str, Any],
) -> Path:
    declared = entry.get("json")
    candidates: List[Path] = []
    if declared:
        candidates.append(Path(str(declared)))
    safe_name = model_name.replace("/", "_").replace("\\", "_")
    candidates.extend([
        reference_root / "models" / f"reference_model_{safe_name}.json",
        manifest_path.parent / "models" / f"reference_model_{safe_name}.json",
    ])
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(
        f"找不到模型{model_name}的JSON文件，尝试过: "
        + "; ".join(str(p) for p in candidates)
    )


def load_models(reference_root: Path, wanted: Sequence[str]) -> Tuple[Path, FeatureConfig, Dict[str, FrozenReferenceModel]]:
    manifest_path = resolve_manifest(reference_root)
    manifest = load_json(manifest_path)
    feature_payload = dict(manifest.get("feature_extraction", {}))
    feature_cfg = dataclass_from_dict(FeatureConfig, feature_payload)
    manifest_models = dict(manifest.get("models", {}))
    models: Dict[str, FrozenReferenceModel] = {}
    for name in wanted:
        if name not in manifest_models:
            raise KeyError(
                f"参考清单中没有模型{name}；已有模型={list(manifest_models.keys())}"
            )
        model_json = resolve_model_json(
            reference_root, manifest_path, name, manifest_models[name]
        )
        model = FrozenReferenceModel(load_json(model_json), model_json)
        if model.feature_names != list(manifest.get("feature_names", model.feature_names)):
            raise ValueError(f"模型{name}与manifest中的feature_names不一致")
        models[name] = model
    return manifest_path, feature_cfg, models


def locate_v16_summary(v16_root: Path) -> Path:
    direct = v16_root / "02_all_points_summary.csv"
    if direct.exists():
        return direct
    matches = list(v16_root.rglob("02_all_points_summary.csv"))
    if len(matches) == 1:
        return matches[0]
    if not matches:
        raise FileNotFoundError(
            f"在{v16_root}中没有找到02_all_points_summary.csv"
        )
    raise RuntimeError(
        f"在{v16_root}中找到多个02_all_points_summary.csv，请配置到具体结果目录: "
        + "; ".join(str(p) for p in matches[:10])
    )


def normalize_center_id(value: Any) -> str:
    text = str(value).strip()
    match = re.search(r"(\d{2}_\d{2})", text)
    return match.group(1) if match else text


def row_text(row: Mapping[str, Any], key: str, default: str = "") -> str:
    value = row.get(key, default)
    if pd.isna(value):
        return default
    return str(value)


def row_int(row: Mapping[str, Any], key: str, default: int = 0) -> int:
    value = row.get(key, default)
    try:
        if pd.isna(value):
            return default
        return int(float(value))
    except Exception:
        return default


def locate_filtered_wav(row: Mapping[str, Any], v16_root: Path) -> Path:
    declared = row_text(row, "filtered_leak_wav", "").strip()
    if declared:
        p = Path(declared)
        if p.exists():
            return p
        # v16结果整体搬动后，按文件名在新根目录中重新查找。
        basename = p.name
        matches = list(v16_root.rglob(basename))
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            dataset = row_text(row, "dataset")
            folder = row_text(row, "folder")
            center_id = normalize_center_id(row_text(row, "center_id"))
            narrowed = [
                m for m in matches
                if dataset.lower() in str(m).lower()
                and folder.lower() in str(m).lower()
                and center_id.lower() in str(m).lower()
            ]
            if len(narrowed) == 1:
                return narrowed[0]

    dataset = row_text(row, "dataset")
    folder = row_text(row, "folder")
    center_id = normalize_center_id(row_text(row, "center_id"))
    patterns = [
        f"*point_{center_id}*_filtered_leak.wav",
        f"*{center_id}*_filtered_leak.wav",
    ]
    found: List[Path] = []
    for pattern in patterns:
        found.extend(v16_root.rglob(pattern))
    unique = list({str(p.resolve()).lower(): p.resolve() for p in found}.values())
    narrowed = [
        p for p in unique
        if (not dataset or dataset.lower() in str(p).lower())
        and (not folder or folder.lower() in str(p).lower())
    ]
    if len(narrowed) == 1:
        return narrowed[0]
    if len(unique) == 1:
        return unique[0]
    if not unique:
        raise FileNotFoundError(
            f"找不到filtered_leak.wav: dataset={dataset}, folder={folder}, center_id={center_id}"
        )
    raise RuntimeError(
        f"filtered_leak.wav匹配到多个文件: dataset={dataset}, folder={folder}, "
        f"center_id={center_id}; 候选={'; '.join(str(p) for p in unique[:10])}"
    )


def validate_plane_row(row: Mapping[str, Any], cfg: AppConfig) -> Tuple[bool, str]:
    reasons: List[str] = []
    if cfg.require_plane_valid and row_int(row, "plane_valid", 0) != 1:
        reasons.append("plane_valid不是1")
    if cfg.require_plane_geometry_ok and row_int(row, "plane_geometry_ok", 0) != 1:
        reasons.append("plane_geometry_ok不是1")
    reason = row_text(row, "plane_reject_reason", "").strip()
    if cfg.require_plane_reason_ok and reason.upper() not in {"", "OK", "NONE"}:
        reasons.append(f"plane_reject_reason={reason}")
    return (len(reasons) == 0, "; ".join(reasons) if reasons else "OK")


def summarize_features(
    sample_id: str,
    dataset: str,
    folder: str,
    center_id: str,
    matrix: np.ndarray,
    model: FrozenReferenceModel,
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for index, name in enumerate(model.feature_names):
        values = matrix[:, index]
        sample_median = float(np.median(values))
        sample_mean = float(np.mean(values))
        sample_p10 = float(np.percentile(values, 10.0))
        sample_p90 = float(np.percentile(values, 90.0))
        model_mean = float(model.raw_mean[index])
        model_median = float(model.raw_median[index])
        model_std = float(model.raw_std[index])
        z_to_model_mean = float((sample_median - model_mean) / max(model_std, 1e-12))
        rows.append({
            "sample_id": sample_id,
            "dataset": dataset,
            "folder": folder,
            "center_id": center_id,
            "model_name": model.model_name,
            "feature": name,
            "sample_mean": sample_mean,
            "sample_median": sample_median,
            "sample_p10": sample_p10,
            "sample_p90": sample_p90,
            "model_mean": model_mean,
            "model_median": model_median,
            "model_std": model_std,
            "sample_median_z_to_model_mean": z_to_model_mean,
            "absolute_z_difference": abs(z_to_model_mean),
        })
    return rows


def build_wide_summary(long_df: pd.DataFrame, point_meta: pd.DataFrame) -> pd.DataFrame:
    if long_df.empty:
        return point_meta.copy()
    value_columns = [
        "median_distance",
        "p90_distance",
        "window_inside_fraction",
        "median_similarity",
        "p90_guard_similarity",
        "balanced_similarity",
        "threshold_available",
        "classified_as_leak",
    ]
    wide_parts: List[pd.DataFrame] = []
    for value in value_columns:
        pivot = long_df.pivot_table(
            index=["sample_id", "dataset", "folder", "center_id"],
            columns="model_name",
            values=value,
            aggfunc="first",
            dropna=False,
        )
        pivot.columns = [f"{value}__{str(col).replace('.', '_')}" for col in pivot.columns]
        wide_parts.append(pivot)
    wide = pd.concat(wide_parts, axis=1).reset_index()
    return point_meta.merge(
        wide,
        on=["sample_id", "dataset", "folder", "center_id"],
        how="left",
    )


def make_decisions(
    point_wide: pd.DataFrame,
    long_df: pd.DataFrame,
    cfg: AppConfig,
) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    preferred = cfg.preferred_decision_model
    preferred_long = long_df[long_df["model_name"] == preferred].copy()

    for (dataset, folder), group in point_wide.groupby(["dataset", "folder"], sort=False):
        selected = group[group["center_id"].isin(cfg.selected_center_ids)].copy()
        base: Dict[str, Any] = {
            "dataset": dataset,
            "folder": folder,
            "decision_model": preferred,
            "n_valid_points": int(len(selected)),
        }
        if len(selected) == 0:
            rows.append({**base, "decision": "NO_VALID_POINT", "decision_reason": "没有有效点"})
            continue

        pstats = preferred_long[
            (preferred_long["dataset"] == dataset)
            & (preferred_long["folder"] == folder)
            & (preferred_long["center_id"].isin(cfg.selected_center_ids))
        ].copy()
        if pstats.empty:
            rows.append({
                **base,
                "decision": "NO_MODEL_RESULT",
                "decision_reason": f"没有{preferred}模型结果",
            })
            continue

        pstats = pstats.sort_values("balanced_similarity", ascending=False)
        for center_id in cfg.selected_center_ids:
            one = pstats[pstats["center_id"] == center_id]
            if one.empty:
                base[f"similarity__{center_id}"] = np.nan
                base[f"classified_as_leak__{center_id}"] = None
            else:
                rec = one.iloc[0]
                base[f"similarity__{center_id}"] = float(rec["balanced_similarity"])
                base[f"median_distance__{center_id}"] = float(rec["median_distance"])
                base[f"p90_distance__{center_id}"] = float(rec["p90_distance"])
                base[f"inside_fraction__{center_id}"] = float(rec["window_inside_fraction"])
                val = rec["classified_as_leak"]
                base[f"classified_as_leak__{center_id}"] = (
                    None if pd.isna(val) else bool(val)
                )

        threshold_available = bool(pstats["threshold_available"].fillna(False).any())
        base["threshold_available"] = threshold_available
        ordered = pstats.dropna(subset=["balanced_similarity"])
        if ordered.empty:
            rows.append({
                **base,
                "decision": "NO_VALID_SCORE",
                "decision_reason": "没有有效相似度",
            })
            continue

        winner = ordered.iloc[0]
        winner_id = str(winner["center_id"])
        winner_score = float(winner["balanced_similarity"])
        if len(ordered) >= 2:
            runner = ordered.iloc[1]
            runner_id = str(runner["center_id"])
            runner_score = float(runner["balanced_similarity"])
            gap = winner_score - runner_score
        else:
            runner_id = ""
            runner_score = np.nan
            gap = np.nan

        base.update({
            "winner_center_id": winner_id,
            "winner_similarity": winner_score,
            "runner_up_center_id": runner_id,
            "runner_up_similarity": runner_score,
            "similarity_gap": gap,
        })

        if threshold_available:
            leak_rows = ordered[ordered["classified_as_leak"] == True]  # noqa: E712
            if len(leak_rows) == 1:
                chosen = leak_rows.iloc[0]
                decision = str(chosen["center_id"])
                reason = "只有该点通过消声室冻结阈值"
            elif len(leak_rows) >= 2:
                if len(ordered) >= 2 and gap >= cfg.minimum_similarity_gap:
                    decision = winner_id
                    reason = "两个点都通过阈值，选择相似度更高且差值足够的点"
                else:
                    decision = "BOTH_LIKE_LEAK"
                    reason = "两个点都通过阈值且相似度接近"
            else:
                if len(ordered) >= 2 and gap >= cfg.minimum_similarity_gap:
                    decision = winner_id
                    reason = "两个点均未通过硬阈值，仅作为相对排序选出更接近的点"
                else:
                    decision = "NEITHER_LIKE_LEAK"
                    reason = "两个点都未通过阈值且无明显差异"
        else:
            if len(ordered) == 1:
                decision = winner_id
                reason = "没有噪声阈值，只能给出单点相似度排序"
            elif gap >= cfg.minimum_similarity_gap:
                decision = winner_id
                reason = "没有噪声阈值，仅按相似度差进行相对排序"
            else:
                decision = "UNCERTAIN"
                reason = "没有噪声阈值，且两个点相似度差过小"

        rows.append({**base, "decision": decision, "decision_reason": reason})

    return pd.DataFrame(rows)


def save_point_plot(
    output_dir: Path,
    dataset: str,
    folder: str,
    center_id: str,
    results: Sequence[Mapping[str, Any]],
) -> str:
    if plt is None or not results:
        return ""
    names = [str(r["model_name"]) for r in results]
    sims = [float(r["balanced_similarity"]) for r in results]
    distances = [float(r["median_distance"]) for r in results]

    plot_dir = output_dir / "plots" / re.sub(r"[^\w.-]+", "_", dataset) / re.sub(r"[^\w.-]+", "_", folder)
    plot_dir.mkdir(parents=True, exist_ok=True)
    path = plot_dir / f"{center_id}_anechoic_model_comparison.png"

    fig, ax = plt.subplots(figsize=(8.0, 4.8), dpi=140)
    x = np.arange(len(names))
    bars = ax.bar(x, sims)
    ax.set_xticks(x)
    ax.set_xticklabels(names)
    ax.set_ylim(0.0, 1.0)
    ax.set_ylabel("Balanced similarity (0-1)")
    ax.set_title(f"{dataset} / {folder} / {center_id}\nFactory plane residual vs anechoic models")
    ax.grid(axis="y", alpha=0.3)
    for bar, sim, dist in zip(bars, sims, distances):
        ax.text(
            bar.get_x() + bar.get_width() / 2,
            min(sim + 0.025, 0.98),
            f"S={sim:.3f}\nmed d={dist:.2f}",
            ha="center",
            va="bottom",
            fontsize=8,
        )
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight")
    plt.close(fig)
    return str(path)


def process(cfg: AppConfig) -> None:
    reference_root = Path(cfg.reference_root_dir)
    v16_root = Path(cfg.v16_output_dir)
    output_dir = Path(cfg.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    manifest_path, feature_cfg, models = load_models(reference_root, cfg.models_to_use)
    if cfg.preferred_decision_model not in models:
        raise ValueError(
            f"preferred_decision_model={cfg.preferred_decision_model}不在models_to_use中"
        )

    summary_path = locate_v16_summary(v16_root)
    source_df = pd.read_csv(summary_path, encoding="utf-8-sig")
    required = {"dataset", "folder", "center_id"}
    missing = required - set(source_df.columns)
    if missing:
        raise ValueError(f"v16汇总表缺少列: {sorted(missing)}")
    source_df["center_id"] = source_df["center_id"].map(normalize_center_id)
    source_df = source_df[source_df["center_id"].isin(cfg.selected_center_ids)].copy()

    input_rows: List[Dict[str, Any]] = []
    long_rows: List[Dict[str, Any]] = []
    feature_rows: List[Dict[str, Any]] = []
    window_rows: List[Dict[str, Any]] = []
    point_meta_rows: List[Dict[str, Any]] = []
    error_rows: List[Dict[str, Any]] = []

    for _, series in source_df.iterrows():
        row = series.to_dict()
        dataset = row_text(row, "dataset")
        folder = row_text(row, "folder")
        center_id = normalize_center_id(row_text(row, "center_id"))
        sample_id = row_text(
            row,
            "sample_id",
            f"{dataset}__{folder}__point_{center_id}",
        )
        plane_ok, plane_check = validate_plane_row(row, cfg)
        input_base = {
            "sample_id": sample_id,
            "dataset": dataset,
            "folder": folder,
            "center_id": center_id,
            "plane_valid": row_int(row, "plane_valid", 0),
            "plane_geometry_ok": row_int(row, "plane_geometry_ok", 0),
            "plane_reject_reason": row_text(row, "plane_reject_reason"),
            "plane_check_passed": plane_ok,
            "plane_check_message": plane_check,
        }
        if not plane_ok:
            input_rows.append({
                **input_base,
                "status": "SKIPPED_PLANE_CHECK",
                "filtered_leak_wav": row_text(row, "filtered_leak_wav"),
                "error": plane_check,
            })
            error_rows.append({
                **input_base,
                "stage": "plane_check",
                "error": plane_check,
            })
            continue

        try:
            wav_path = locate_filtered_wav(row, v16_root)
            record = extract_file_features(wav_path, feature_cfg)
            input_rows.append({
                **input_base,
                "status": "OK",
                "filtered_leak_wav": str(wav_path),
                "sample_rate_hz": record.sample_rate_hz,
                "duration_seconds": record.duration_seconds,
                "n_windows": int(record.frames.shape[0]),
                "error": "",
            })

            model_results_for_plot: List[Dict[str, Any]] = []
            for model_name, model in models.items():
                matrix = discrimination_matrix(record, model.feature_names)
                stats, distances = model.file_statistics(matrix)
                result_row: Dict[str, Any] = {
                    "sample_id": sample_id,
                    "dataset": dataset,
                    "folder": folder,
                    "center_id": center_id,
                    "filtered_leak_wav": str(wav_path),
                    "model_name": model_name,
                    "model_json": model.source_path,
                    **stats,
                }
                long_rows.append(result_row)
                model_results_for_plot.append(result_row)
                feature_rows.extend(
                    summarize_features(
                        sample_id,
                        dataset,
                        folder,
                        center_id,
                        matrix,
                        model,
                    )
                )
                if cfg.save_window_details:
                    similarities = model.similarity(distances)
                    for index, (distance, similarity) in enumerate(zip(distances, similarities)):
                        window_rows.append({
                            "sample_id": sample_id,
                            "dataset": dataset,
                            "folder": folder,
                            "center_id": center_id,
                            "model_name": model_name,
                            "window_index": int(index),
                            "distance": float(distance),
                            "similarity": float(similarity),
                            "inside_model_window": bool(distance <= model.window_distance_threshold),
                        })

            plot_path = ""
            if cfg.save_plots:
                plot_path = save_point_plot(
                    output_dir, dataset, folder, center_id, model_results_for_plot
                )
            point_meta_rows.append({
                "sample_id": sample_id,
                "dataset": dataset,
                "folder": folder,
                "center_id": center_id,
                "filtered_leak_wav": str(wav_path),
                "sample_rate_hz": record.sample_rate_hz,
                "duration_seconds": record.duration_seconds,
                "n_windows": int(record.frames.shape[0]),
                "plane_valid": row_int(row, "plane_valid", 0),
                "plane_geometry_ok": row_int(row, "plane_geometry_ok", 0),
                "plane_reject_reason": row_text(row, "plane_reject_reason"),
                "plane_component_fraction_of_center": row.get("plane_component_fraction_of_center", np.nan),
                "plane_integrated_snr_db": row.get("plane_integrated_snr_db", np.nan),
                "comparison_plot": plot_path,
            })
        except Exception as exc:
            message = f"{type(exc).__name__}: {exc}"
            input_rows.append({
                **input_base,
                "status": "FAILED",
                "filtered_leak_wav": row_text(row, "filtered_leak_wav"),
                "error": message,
            })
            error_rows.append({
                **input_base,
                "stage": "feature_or_model_comparison",
                "error": message,
                "traceback": traceback.format_exc(),
            })

    input_columns = [
        "sample_id", "dataset", "folder", "center_id",
        "plane_valid", "plane_geometry_ok", "plane_reject_reason",
        "plane_check_passed", "plane_check_message", "status",
        "filtered_leak_wav", "sample_rate_hz", "duration_seconds",
        "n_windows", "error",
    ]
    write_csv(output_dir / "00_input_check.csv", input_rows, input_columns)

    long_columns = [
        "sample_id", "dataset", "folder", "center_id", "filtered_leak_wav",
        "model_name", "model_json", "n_windows", "median_distance",
        "p90_distance", "mean_distance", "std_distance",
        "window_inside_fraction", "median_similarity",
        "p90_guard_similarity", "balanced_similarity",
        "threshold_available", "classified_as_leak",
        "median_distance_threshold", "p90_distance_threshold",
    ]
    write_csv(output_dir / "01_point_model_similarity_long.csv", long_rows, long_columns)

    point_meta_df = pd.DataFrame(point_meta_rows)
    long_df = pd.DataFrame(long_rows)
    if point_meta_df.empty:
        point_wide = pd.DataFrame(columns=["sample_id", "dataset", "folder", "center_id"])
    else:
        point_wide = build_wide_summary(long_df, point_meta_df)
    point_wide.to_csv(
        output_dir / "02_point_summary_wide.csv",
        index=False,
        encoding="utf-8-sig",
    )

    decisions = make_decisions(point_wide, long_df, cfg) if not point_wide.empty else pd.DataFrame()
    decisions.to_csv(
        output_dir / "03_folder_two_point_decision.csv",
        index=False,
        encoding="utf-8-sig",
    )

    feature_columns = [
        "sample_id", "dataset", "folder", "center_id", "model_name", "feature",
        "sample_mean", "sample_median", "sample_p10", "sample_p90",
        "model_mean", "model_median", "model_std",
        "sample_median_z_to_model_mean", "absolute_z_difference",
    ]
    write_csv(output_dir / "04_feature_comparison.csv", feature_rows, feature_columns)

    if cfg.save_window_details:
        window_columns = [
            "sample_id", "dataset", "folder", "center_id", "model_name",
            "window_index", "distance", "similarity", "inside_model_window",
        ]
        write_csv(output_dir / "05_window_details.csv", window_rows, window_columns)

    error_columns = [
        "sample_id", "dataset", "folder", "center_id", "stage", "error", "traceback"
    ]
    write_csv(output_dir / "99_errors.csv", error_rows, error_columns)

    run_info = {
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "reference_root_dir": str(reference_root),
        "reference_manifest": str(manifest_path),
        "v16_output_dir": str(v16_root),
        "v16_summary": str(summary_path),
        "output_dir": str(output_dir),
        "selected_center_ids": list(cfg.selected_center_ids),
        "models_to_use": list(cfg.models_to_use),
        "preferred_decision_model": cfg.preferred_decision_model,
        "feature_extraction": {
            name: getattr(feature_cfg, name) for name in FeatureConfig.__dataclass_fields__
        },
        "n_v16_rows_selected": int(len(source_df)),
        "n_points_successful": int(len(point_meta_rows)),
        "n_model_comparisons": int(len(long_rows)),
        "n_errors": int(len(error_rows)),
        "decision_note": (
            "When frozen file thresholds are available, classification uses median and p90 distance. "
            "Without noise thresholds, decisions are rankings only."
        ),
    }
    write_json(output_dir / "00_run_info.json", run_info)

    print("\n处理完成")
    print(f"参考模型清单: {manifest_path}")
    print(f"v16汇总表:    {summary_path}")
    print(f"成功点数:      {len(point_meta_rows)}")
    print(f"模型比较数:    {len(long_rows)}")
    print(f"错误数:        {len(error_rows)}")
    print(f"输出目录:      {output_dir}")
    print("最先查看:")
    print(f"  {output_dir / '00_input_check.csv'}")
    print(f"  {output_dir / '02_point_summary_wide.csv'}")
    print(f"  {output_dir / '03_folder_two_point_decision.csv'}")
    print(f"  {output_dir / '04_feature_comparison.csv'}")


def load_config(path: Path) -> AppConfig:
    raw = load_json(path)
    cfg = dataclass_from_dict(AppConfig, raw)
    if tuple(cfg.selected_center_ids) != ("00_00", "00_01"):
        raise ValueError("selected_center_ids必须是['00_00','00_01']")
    if cfg.minimum_similarity_gap < 0:
        raise ValueError("minimum_similarity_gap不能小于0")
    return cfg


def run_self_test() -> None:
    feature_names = list(EXPECTED_DISCRIM_COLUMNS)
    payload = {
        "model_name": "TEST",
        "feature_names": feature_names,
        "feature_extraction": {
            "freq_low_hz": 18000.0,
            "freq_high_hz": 50000.0,
            "window_ms": 100.0,
            "hop_ms": 50.0,
            "welch_nfft": 2048,
            "snr_floor_percentile": 10.0,
            "consistency_window_frames": 10,
            "minimum_windows_per_file": 3,
        },
        "raw_mean": [0.3, 5000.0, 4.0, 0.02, 300.0],
        "raw_median": [0.3, 5000.0, 4.0, 0.02, 300.0],
        "raw_std": [0.05, 500.0, 1.0, 0.01, 80.0],
        "standardized_center": [0, 0, 0, 0, 0],
        "inverse_covariance": np.eye(5).tolist(),
        "window_distance_threshold": 3.88,
        "file_thresholds": {
            "available": True,
            "median_distance_threshold": 3.0,
            "p90_distance_threshold": 4.0,
        },
    }
    tmp = Path("self_test_model.json")
    model = FrozenReferenceModel(payload, tmp)
    near = np.tile(np.asarray(payload["raw_mean"], dtype=float), (20, 1))
    far = near.copy()
    far[:, 0] += 0.5
    near_stats, _ = model.file_statistics(near)
    far_stats, _ = model.file_statistics(far)
    if not near_stats["balanced_similarity"] > far_stats["balanced_similarity"]:
        raise AssertionError("自检失败：相近特征的相似度没有更高")
    if near_stats["classified_as_leak"] is not True:
        raise AssertionError("自检失败：相近特征未通过阈值")
    if far_stats["classified_as_leak"] is not False:
        raise AssertionError("自检失败：远离特征错误通过阈值")
    print("自检通过")
    print(f"相近特征相似度: {near_stats['balanced_similarity']:.6f}")
    print(f"远离特征相似度: {far_stats['balanced_similarity']:.6f}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="比较v16_1工厂空间残差与消声室冻结参考模型"
    )
    parser.add_argument("--config", type=str, help="JSON配置文件")
    parser.add_argument("--self-test", action="store_true", help="运行内置自检")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.self_test:
        run_self_test()
        return
    if not args.config:
        raise SystemExit("请使用--config指定配置文件，或使用--self-test")
    cfg = load_config(Path(args.config))
    process(cfg)


if __name__ == "__main__":
    main()
