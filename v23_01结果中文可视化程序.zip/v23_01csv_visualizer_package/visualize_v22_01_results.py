# -*- coding: utf-8 -*-
"""
v23：v22 的 01_每个样本_距离与相似度_long.csv 中文可视化工具

功能：
1. 自动读取 v22 输出的 01 CSV；
2. 将同一样本 RAW / PLANE 配对；
3. 输出中文汇总表、异常样本表；
4. 绘制距离、相似度、场景分布和样本变化图；
5. 生成“00_打开这个.html”，用浏览器直接查看。

运行：
    python visualize_v22_01_results.py --config v23_visualizer_config.json
    python visualize_v22_01_results.py --input "...\\01_每个样本_距离与相似度_long.csv"
    python visualize_v22_01_results.py --self-test
"""
from __future__ import annotations

import argparse
import html
import json
import math
import os
import sys
import tempfile
import traceback
from dataclasses import dataclass, fields
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
except Exception as exc:  # pragma: no cover
    raise RuntimeError("缺少 matplotlib，请先运行 install_requirements.bat") from exc


REQUIRED_COLUMNS = {
    "sample_id",
    "scene",
    "label",
    "method",
    "reference_group",
    "median_distance",
    "p90_distance",
    "median_distance_ratio",
    "p90_distance_ratio",
    "window_inside_fraction",
    "balanced_similarity",
    "combined_similarity",
}

OPTIONAL_NUMERIC_COLUMNS = [
    "n_windows",
    "mean_distance",
    "std_distance",
    "median_similarity",
    "p90_guard_similarity",
    "cosine_similarity",
    "spectral_overlap",
    "pearson_similarity",
    "individual_lab_similarity_median",
    "individual_lab_similarity_p90",
    "individual_lab_similarity_max",
]

PAIR_METRICS = [
    "median_distance",
    "p90_distance",
    "median_distance_ratio",
    "p90_distance_ratio",
    "window_inside_fraction",
    "balanced_similarity",
    "combined_similarity",
    "cosine_similarity",
    "spectral_overlap",
    "pearson_similarity",
]

LABEL_CN = {
    "TRUE_LEAK": "真泄漏",
    "FALSE_LEAK": "假泄漏",
}
METHOD_CN = {"raw": "原始RAW", "plane": "空间拟合PLANE"}
REFERENCE_CN = {
    "ALL_LEAKS": "0.1mm+0.5mm联合泄漏参考",
    "0.1mm": "0.1mm泄漏参考",
    "0.5mm": "0.5mm泄漏参考",
}


def reference_display(value: Any) -> str:
    return REFERENCE_CN.get(str(value), str(value))


@dataclass(frozen=True)
class Config:
    input_csv: str = ""
    output_dir: str = ""
    main_reference: str = "ALL_LEAKS"
    reference_groups: Tuple[str, ...] = ("ALL_LEAKS", "0.1mm", "0.5mm")
    top_n_samples: int = 25
    distance_change_tolerance: float = 0.05
    similarity_change_tolerance: float = 0.01
    figure_dpi: int = 150
    open_report_after_run: bool = True


def dataclass_from_dict(cls: Any, raw: Mapping[str, Any]) -> Any:
    allowed = {f.name for f in fields(cls)}
    unknown = sorted(set(raw) - allowed)
    if unknown:
        raise ValueError(f"配置中存在未知字段: {unknown}")
    values = dict(raw)
    if "reference_groups" in values:
        values["reference_groups"] = tuple(values["reference_groups"])
    return cls(**values)


def read_json(path: Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def read_csv_flexible(path: Path) -> pd.DataFrame:
    errors: List[str] = []
    for encoding in ("utf-8-sig", "utf-8", "gb18030"):
        try:
            return pd.read_csv(path, encoding=encoding, low_memory=False)
        except Exception as exc:
            errors.append(f"{encoding}: {type(exc).__name__}: {exc}")
    raise RuntimeError("CSV读取失败：\n" + "\n".join(errors))


def choose_csv_with_dialog() -> Optional[Path]:
    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        selected = filedialog.askopenfilename(
            title="选择 01_每个样本_距离与相似度_long.csv",
            filetypes=[("CSV 文件", "*.csv"), ("所有文件", "*.*")],
        )
        root.destroy()
        return Path(selected) if selected else None
    except Exception:
        return None


def resolve_input_path(cli_input: Optional[str], cfg: Config, base_dir: Path) -> Path:
    candidates: List[Path] = []
    if cli_input:
        candidates.append(Path(cli_input))
    if cfg.input_csv:
        p = Path(cfg.input_csv)
        candidates.append(p if p.is_absolute() else base_dir / p)
    candidates.extend([
        base_dir / "01_每个样本_距离与相似度_long.csv",
        Path.cwd() / "01_每个样本_距离与相似度_long.csv",
    ])
    for candidate in candidates:
        if candidate.is_file():
            return candidate.resolve()

    matches: List[Path] = []
    for root in {base_dir.resolve(), Path.cwd().resolve()}:
        try:
            matches.extend(root.rglob("01_每个样本_距离与相似度_long.csv"))
        except Exception:
            pass
    unique = sorted({p.resolve() for p in matches if p.is_file()})
    if len(unique) == 1:
        return unique[0]
    if len(unique) > 1:
        print("发现多个01结果文件，请在弹出的窗口中选择正确文件：")
        for p in unique[:10]:
            print("  ", p)

    selected = choose_csv_with_dialog()
    if selected and selected.is_file():
        return selected.resolve()
    raise FileNotFoundError(
        "没有找到 01_每个样本_距离与相似度_long.csv。\n"
        "请把本程序放进 RAW_PLANE_vs_anechoic 结果文件夹后双击，\n"
        "或者修改 v23_visualizer_config.json 中的 input_csv。"
    )


def resolve_output_dir(input_path: Path, cfg: Config, base_dir: Path) -> Path:
    if cfg.output_dir:
        p = Path(cfg.output_dir)
        return (p if p.is_absolute() else base_dir / p).resolve()
    return (input_path.parent / "01结果可视化").resolve()


def setup_chinese_font() -> str:
    preferred = [
        "Microsoft YaHei",
        "Microsoft YaHei UI",
        "SimHei",
        "Noto Sans CJK SC",
        "Noto Sans CJK JP",
        "Source Han Sans SC",
        "WenQuanYi Micro Hei",
        "Arial Unicode MS",
    ]
    available = {f.name for f in font_manager.fontManager.ttflist}
    for name in preferred:
        if name in available:
            plt.rcParams["font.sans-serif"] = [name]
            plt.rcParams["axes.unicode_minus"] = False
            return name
    plt.rcParams["axes.unicode_minus"] = False
    return "matplotlib默认字体（中文可能显示方框）"


def normalize_label(value: Any) -> str:
    text = str(value).strip().upper()
    aliases = {
        "TRUE": "TRUE_LEAK",
        "T": "TRUE_LEAK",
        "1": "TRUE_LEAK",
        "真泄漏": "TRUE_LEAK",
        "FALSE": "FALSE_LEAK",
        "F": "FALSE_LEAK",
        "0": "FALSE_LEAK",
        "假泄漏": "FALSE_LEAK",
    }
    return aliases.get(text, text)


def normalize_method(value: Any) -> str:
    text = str(value).strip().lower()
    aliases = {"raw": "raw", "原始": "raw", "plane": "plane", "pl": "plane"}
    return aliases.get(text, text)


def clean_input(df: pd.DataFrame) -> Tuple[pd.DataFrame, List[Dict[str, Any]]]:
    notes: List[Dict[str, Any]] = []
    original_columns = list(df.columns)
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    missing = sorted(REQUIRED_COLUMNS - set(df.columns))
    if missing:
        raise ValueError(
            "输入CSV缺少必要列：" + ", ".join(missing) + "\n"
            "请确认选择的是 01_每个样本_距离与相似度_long.csv。"
        )

    df["sample_id"] = df["sample_id"].astype(str).str.strip()
    df["scene"] = df["scene"].astype(str).str.strip()
    df["reference_group"] = df["reference_group"].astype(str).str.strip()
    df["label"] = df["label"].map(normalize_label)
    df["method"] = df["method"].map(normalize_method)

    invalid_label = sorted(set(df["label"]) - {"TRUE_LEAK", "FALSE_LEAK"})
    invalid_method = sorted(set(df["method"]) - {"raw", "plane"})
    if invalid_label:
        notes.append({"检查项": "未知标签", "结果": "警告", "详情": str(invalid_label)})
    if invalid_method:
        notes.append({"检查项": "未知方法", "结果": "警告", "详情": str(invalid_method)})
    df = df[df["label"].isin(["TRUE_LEAK", "FALSE_LEAK"])].copy()
    df = df[df["method"].isin(["raw", "plane"])].copy()

    numeric_cols = sorted((REQUIRED_COLUMNS & set(df.columns)) - {
        "sample_id", "scene", "label", "method", "reference_group"
    }) + [c for c in OPTIONAL_NUMERIC_COLUMNS if c in df.columns]
    numeric_cols = sorted(set(numeric_cols))
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    before = len(df)
    df = df.dropna(subset=["sample_id", "scene", "reference_group", "median_distance", "combined_similarity"])
    dropped = before - len(df)
    notes.append({"检查项": "读取行数", "结果": "正常", "详情": f"有效行 {len(df)}，删除关键数值为空的行 {dropped}"})

    keys = ["sample_id", "scene", "label", "reference_group", "method"]
    dup_count = int(df.duplicated(keys, keep=False).sum())
    if dup_count:
        notes.append({
            "检查项": "重复记录",
            "结果": "警告",
            "详情": f"发现 {dup_count} 行重复键，程序对数值列取中位数",
        })
        agg: Dict[str, Any] = {}
        for c in df.columns:
            if c in keys:
                continue
            agg[c] = "median" if pd.api.types.is_numeric_dtype(df[c]) else "first"
        df = df.groupby(keys, as_index=False).agg(agg)
    else:
        notes.append({"检查项": "重复记录", "结果": "正常", "详情": "未发现重复键"})

    notes.append({"检查项": "场景", "结果": "正常", "详情": ", ".join(sorted(df["scene"].unique()))})
    notes.append({"检查项": "参考组", "结果": "正常", "详情": ", ".join(sorted(df["reference_group"].unique()))})
    notes.append({"检查项": "原始列数", "结果": "正常", "详情": str(len(original_columns))})
    return df, notes


def pair_raw_plane(df: pd.DataFrame, cfg: Config) -> Tuple[pd.DataFrame, List[Dict[str, Any]]]:
    keys = ["sample_id", "scene", "label", "reference_group"]
    raw = df[df["method"] == "raw"].copy()
    plane = df[df["method"] == "plane"].copy()
    merged = raw.merge(plane, on=keys, how="inner", suffixes=("_raw", "_plane"))

    all_keys = df[keys].drop_duplicates()
    paired_keys = merged[keys].drop_duplicates()
    missing = all_keys.merge(paired_keys, on=keys, how="left", indicator=True)
    missing = missing[missing["_merge"] == "left_only"].drop(columns="_merge")
    notes = [{
        "检查项": "RAW/PLANE配对",
        "结果": "正常" if missing.empty else "警告",
        "详情": f"成功配对 {len(merged)} 组，未配对 {len(missing)} 组",
    }]

    for metric in PAIR_METRICS:
        raw_col = f"{metric}_raw"
        plane_col = f"{metric}_plane"
        if raw_col in merged.columns and plane_col in merged.columns:
            merged[f"{metric}_change_plane_minus_raw"] = merged[plane_col] - merged[raw_col]

    merged["标签中文"] = merged["label"].map(LABEL_CN)
    merged["距离有利变化"] = np.where(
        merged["label"] == "TRUE_LEAK",
        merged["median_distance_raw"] - merged["median_distance_plane"],
        merged["median_distance_plane"] - merged["median_distance_raw"],
    )
    merged["距离比例有利变化"] = np.where(
        merged["label"] == "TRUE_LEAK",
        merged["median_distance_ratio_raw"] - merged["median_distance_ratio_plane"],
        merged["median_distance_ratio_plane"] - merged["median_distance_ratio_raw"],
    )
    merged["频谱相似度有利变化"] = np.where(
        merged["label"] == "TRUE_LEAK",
        merged["combined_similarity_plane"] - merged["combined_similarity_raw"],
        merged["combined_similarity_raw"] - merged["combined_similarity_plane"],
    )
    merged["距离型相似度有利变化"] = np.where(
        merged["label"] == "TRUE_LEAK",
        merged["balanced_similarity_plane"] - merged["balanced_similarity_raw"],
        merged["balanced_similarity_raw"] - merged["balanced_similarity_plane"],
    )
    merged["参考范围内比例有利变化"] = np.where(
        merged["label"] == "TRUE_LEAK",
        merged["window_inside_fraction_plane"] - merged["window_inside_fraction_raw"],
        merged["window_inside_fraction_raw"] - merged["window_inside_fraction_plane"],
    )

    d_tol = float(cfg.distance_change_tolerance)
    s_tol = float(cfg.similarity_change_tolerance)

    def classify(row: pd.Series) -> str:
        d = float(row["距离比例有利变化"])
        s = float(row["频谱相似度有利变化"])
        d_good = d > d_tol
        d_bad = d < -d_tol
        s_good = s > s_tol
        s_bad = s < -s_tol
        if d_good and s_good:
            return "明显改善"
        if d_bad and s_bad:
            return "明显变差"
        if (d_good and not s_bad) or (s_good and not d_bad):
            return "部分改善"
        if (d_bad and not s_good) or (s_bad and not d_good):
            return "部分变差"
        return "变化很小或指标矛盾"

    merged["样本结论"] = merged.apply(classify, axis=1)
    return merged, notes


def make_chinese_pair_table(paired: pd.DataFrame) -> pd.DataFrame:
    mapping = {
        "sample_id": "样本名称",
        "scene": "场景",
        "标签中文": "真假标签",
        "reference_group": "消声室参考组代码",
        "median_distance_raw": "RAW典型马氏距离",
        "median_distance_plane": "PLANE典型马氏距离",
        "p90_distance_raw": "RAW较差时段马氏距离P90",
        "p90_distance_plane": "PLANE较差时段马氏距离P90",
        "median_distance_ratio_raw": "RAW典型距离比例",
        "median_distance_ratio_plane": "PLANE典型距离比例",
        "window_inside_fraction_raw": "RAW落入参考范围比例",
        "window_inside_fraction_plane": "PLANE落入参考范围比例",
        "balanced_similarity_raw": "RAW距离型相似度",
        "balanced_similarity_plane": "PLANE距离型相似度",
        "combined_similarity_raw": "RAW频谱综合相似度",
        "combined_similarity_plane": "PLANE频谱综合相似度",
        "距离有利变化": "马氏距离有利变化_正数好",
        "距离比例有利变化": "距离比例有利变化_正数好",
        "距离型相似度有利变化": "距离型相似度有利变化_正数好",
        "频谱相似度有利变化": "频谱相似度有利变化_正数好",
        "参考范围内比例有利变化": "参考范围比例有利变化_正数好",
        "样本结论": "空间拟合对该样本的作用",
    }
    cols = [c for c in mapping if c in paired.columns]
    out = paired[cols].rename(columns=mapping).copy()
    out.insert(4, "消声室参考组中文", out["消声室参考组代码"].map(reference_display))
    return out.sort_values(["消声室参考组代码", "场景", "真假标签", "样本名称"])


def make_scene_summary(paired: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for (ref, scene, label), g in paired.groupby(["reference_group", "scene", "label"], dropna=False):
        rows.append({
            "消声室参考组代码": ref,
            "消声室参考组中文": reference_display(ref),
            "场景": scene,
            "真假标签": LABEL_CN.get(label, label),
            "样本数": len(g),
            "RAW典型马氏距离中位数": float(g["median_distance_raw"].median()),
            "PLANE典型马氏距离中位数": float(g["median_distance_plane"].median()),
            "RAW频谱相似度中位数": float(g["combined_similarity_raw"].median()),
            "PLANE频谱相似度中位数": float(g["combined_similarity_plane"].median()),
            "马氏距离有利变化中位数_正数好": float(g["距离有利变化"].median()),
            "频谱相似度有利变化中位数_正数好": float(g["频谱相似度有利变化"].median()),
            "明显改善数量": int((g["样本结论"] == "明显改善").sum()),
            "明显变差数量": int((g["样本结论"] == "明显变差").sum()),
        })
    return pd.DataFrame(rows).sort_values(["消声室参考组代码", "场景", "真假标签"])


def overall_reference_summary(paired: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for ref, g in paired.groupby("reference_group"):
        true = g[g["label"] == "TRUE_LEAK"]
        false = g[g["label"] == "FALSE_LEAK"]
        if true.empty or false.empty:
            continue
        raw_d_sep = float(false["median_distance_raw"].median() - true["median_distance_raw"].median())
        plane_d_sep = float(false["median_distance_plane"].median() - true["median_distance_plane"].median())
        raw_s_sep = float(true["combined_similarity_raw"].median() - false["combined_similarity_raw"].median())
        plane_s_sep = float(true["combined_similarity_plane"].median() - false["combined_similarity_plane"].median())
        rows.append({
            "消声室参考组代码": ref,
            "消声室参考组中文": reference_display(ref),
            "场景数": int(g["scene"].nunique()),
            "样本配对数": len(g),
            "RAW真泄漏马氏距离": float(true["median_distance_raw"].median()),
            "PLANE真泄漏马氏距离": float(true["median_distance_plane"].median()),
            "RAW假泄漏马氏距离": float(false["median_distance_raw"].median()),
            "PLANE假泄漏马氏距离": float(false["median_distance_plane"].median()),
            "RAW真泄漏频谱相似度": float(true["combined_similarity_raw"].median()),
            "PLANE真泄漏频谱相似度": float(true["combined_similarity_plane"].median()),
            "RAW假泄漏频谱相似度": float(false["combined_similarity_raw"].median()),
            "PLANE假泄漏频谱相似度": float(false["combined_similarity_plane"].median()),
            "RAW马氏距离真假分离_FALSE减TRUE": raw_d_sep,
            "PLANE马氏距离真假分离_FALSE减TRUE": plane_d_sep,
            "马氏距离分离改善_PLANE减RAW": plane_d_sep - raw_d_sep,
            "RAW频谱相似度真假分离_TRUE减FALSE": raw_s_sep,
            "PLANE频谱相似度真假分离_TRUE减FALSE": plane_s_sep,
            "频谱相似度分离改善_PLANE减RAW": plane_s_sep - raw_s_sep,
            "明显改善样本数": int((g["样本结论"] == "明显改善").sum()),
            "部分改善样本数": int((g["样本结论"] == "部分改善").sum()),
            "明显变差样本数": int((g["样本结论"] == "明显变差").sum()),
            "部分变差样本数": int((g["样本结论"] == "部分变差").sum()),
            "变化很小或矛盾样本数": int((g["样本结论"] == "变化很小或指标矛盾").sum()),
        })
    return pd.DataFrame(rows)


def short_text(value: Any, max_len: int = 28) -> str:
    text = str(value)
    return text if len(text) <= max_len else text[: max_len - 1] + "…"


def safe_filename(text: str) -> str:
    import re
    out = re.sub(r"[\\/:*?\"<>|]+", "_", str(text))
    return out.strip(" .") or "result"


def save_fig(fig: Any, path: Path, dpi: int) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, dpi=dpi, bbox_inches="tight")
    plt.close(fig)
    return path


def plot_scene_metric(paired: pd.DataFrame, ref: str, metric: str, ylabel: str, title: str, path: Path, dpi: int) -> Optional[Path]:
    sub = paired[paired["reference_group"] == ref]
    if sub.empty:
        return None
    rows = []
    for (scene, label), g in sub.groupby(["scene", "label"]):
        rows.append({
            "分组": f"{scene}\n{LABEL_CN.get(label, label)}",
            "RAW": float(g[f"{metric}_raw"].median()),
            "PLANE": float(g[f"{metric}_plane"].median()),
        })
    d = pd.DataFrame(rows)
    x = np.arange(len(d))
    width = 0.36
    fig, ax = plt.subplots(figsize=(max(9.0, len(d) * 1.35), 5.8))
    bars1 = ax.bar(x - width / 2, d["RAW"], width, label="原始RAW")
    bars2 = ax.bar(x + width / 2, d["PLANE"], width, label="空间拟合PLANE")
    ax.set_xticks(x)
    ax.set_xticklabels(d["分组"])
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(axis="y", alpha=0.25)
    ax.legend()
    for bars in (bars1, bars2):
        for b in bars:
            value = b.get_height()
            ax.text(b.get_x() + b.get_width() / 2, value, f"{value:.3f}", ha="center", va="bottom", fontsize=8)
    return save_fig(fig, path, dpi)


def plot_benefit_top(paired: pd.DataFrame, ref: str, benefit_col: str, title: str, xlabel: str, path: Path, dpi: int, top_n: int) -> Optional[Path]:
    sub = paired[paired["reference_group"] == ref].copy()
    if sub.empty:
        return None
    sub["显示名"] = sub.apply(
        lambda r: f"{r['scene']} | {LABEL_CN.get(r['label'], r['label'])} | {short_text(r['sample_id'])}", axis=1
    )
    sub = sub.reindex(sub[benefit_col].abs().sort_values(ascending=False).index).head(top_n)
    sub = sub.sort_values(benefit_col)
    fig, ax = plt.subplots(figsize=(10.5, max(5.5, len(sub) * 0.36)))
    bars = ax.barh(np.arange(len(sub)), sub[benefit_col])
    ax.set_yticks(np.arange(len(sub)))
    ax.set_yticklabels(sub["显示名"], fontsize=8)
    ax.axvline(0.0, linewidth=1.0)
    ax.set_xlabel(xlabel)
    ax.set_title(title + "\n正数=PLANE有帮助，负数=PLANE使样本变差")
    ax.grid(axis="x", alpha=0.25)
    for b, value in zip(bars, sub[benefit_col]):
        ax.text(value, b.get_y() + b.get_height() / 2, f" {value:+.3f}", va="center", fontsize=8)
    return save_fig(fig, path, dpi)


def plot_benefit_scatter(paired: pd.DataFrame, ref: str, path: Path, dpi: int) -> Optional[Path]:
    sub = paired[paired["reference_group"] == ref].copy()
    if sub.empty:
        return None
    fig, ax = plt.subplots(figsize=(8.0, 6.5))
    markers = {"TRUE_LEAK": "o", "FALSE_LEAK": "^"}
    for (scene, label), g in sub.groupby(["scene", "label"]):
        ax.scatter(
            g["距离比例有利变化"],
            g["频谱相似度有利变化"],
            marker=markers.get(label, "o"),
            alpha=0.75,
            label=f"{scene}-{LABEL_CN.get(label, label)}",
        )
    ax.axvline(0.0, linewidth=1.0)
    ax.axhline(0.0, linewidth=1.0)
    ax.set_xlabel("距离比例有利变化（正数好）")
    ax.set_ylabel("频谱相似度有利变化（正数好）")
    ax.set_title(f"{reference_display(ref)}：每个样本的PLANE作用\n右上角最好，左下角最差")
    ax.grid(alpha=0.25)
    ax.legend(fontsize=8, ncol=2)
    return save_fig(fig, path, dpi)


def plot_category_counts(paired: pd.DataFrame, ref: str, path: Path, dpi: int) -> Optional[Path]:
    sub = paired[paired["reference_group"] == ref]
    if sub.empty:
        return None
    order = ["明显改善", "部分改善", "变化很小或指标矛盾", "部分变差", "明显变差"]
    counts = sub["样本结论"].value_counts().reindex(order, fill_value=0)
    fig, ax = plt.subplots(figsize=(9.0, 5.2))
    bars = ax.bar(np.arange(len(order)), counts.values)
    ax.set_xticks(np.arange(len(order)))
    ax.set_xticklabels(order, rotation=15, ha="right")
    ax.set_ylabel("样本数")
    ax.set_title(f"{reference_display(ref)}：空间拟合对样本的作用分类")
    ax.grid(axis="y", alpha=0.25)
    for b, v in zip(bars, counts.values):
        ax.text(b.get_x() + b.get_width() / 2, v, str(int(v)), ha="center", va="bottom")
    return save_fig(fig, path, dpi)


def plot_raw_plane_scatter(paired: pd.DataFrame, ref: str, method: str, path: Path, dpi: int) -> Optional[Path]:
    sub = paired[paired["reference_group"] == ref]
    if sub.empty:
        return None
    fig, ax = plt.subplots(figsize=(8.0, 6.5))
    markers = {"TRUE_LEAK": "o", "FALSE_LEAK": "^"}
    for (scene, label), g in sub.groupby(["scene", "label"]):
        ax.scatter(
            g[f"median_distance_ratio_{method}"],
            g[f"combined_similarity_{method}"],
            marker=markers.get(label, "o"),
            alpha=0.75,
            label=f"{scene}-{LABEL_CN.get(label, label)}",
        )
    ax.axvline(1.0, linewidth=1.0, linestyle="--")
    ax.set_xlabel("典型马氏距离比例（越小越接近消声室）")
    ax.set_ylabel("频谱综合相似度（越大越像消声室）")
    ax.set_title(f"{reference_display(ref)}：{METHOD_CN[method]}二维分布\n理想真泄漏在左上，假泄漏在右下")
    ax.grid(alpha=0.25)
    ax.legend(fontsize=8, ncol=2)
    return save_fig(fig, path, dpi)


def generate_plots(paired: pd.DataFrame, refs: Sequence[str], main_ref: str, output_dir: Path, cfg: Config) -> Dict[str, List[Path]]:
    figures_dir = output_dir / "figures"
    figures_dir.mkdir(parents=True, exist_ok=True)
    result: Dict[str, List[Path]] = {}
    available = list(paired["reference_group"].dropna().astype(str).unique())
    ordered = [r for r in refs if r in available] + [r for r in available if r not in refs]
    for ref in ordered:
        prefix = safe_filename(ref)
        paths: List[Optional[Path]] = []
        paths.append(plot_scene_metric(
            paired, ref, "median_distance", "典型马氏距离（越小越像消声室）",
            f"{reference_display(ref)}：各场景真/假泄漏的RAW与PLANE马氏距离",
            figures_dir / f"{prefix}_01_各场景马氏距离.png", cfg.figure_dpi,
        ))
        paths.append(plot_scene_metric(
            paired, ref, "combined_similarity", "频谱综合相似度（越大越像消声室）",
            f"{reference_display(ref)}：各场景真/假泄漏的RAW与PLANE频谱相似度",
            figures_dir / f"{prefix}_02_各场景频谱相似度.png", cfg.figure_dpi,
        ))
        paths.append(plot_benefit_top(
            paired, ref, "距离比例有利变化",
            f"{reference_display(ref)}：马氏距离变化最明显的样本",
            "距离比例有利变化", figures_dir / f"{prefix}_03_距离变化最大的样本.png",
            cfg.figure_dpi, cfg.top_n_samples,
        ))
        paths.append(plot_benefit_top(
            paired, ref, "频谱相似度有利变化",
            f"{reference_display(ref)}：频谱相似度变化最明显的样本",
            "频谱相似度有利变化", figures_dir / f"{prefix}_04_相似度变化最大的样本.png",
            cfg.figure_dpi, cfg.top_n_samples,
        ))
        paths.append(plot_benefit_scatter(
            paired, ref, figures_dir / f"{prefix}_05_距离与相似度有利变化散点图.png", cfg.figure_dpi
        ))
        paths.append(plot_category_counts(
            paired, ref, figures_dir / f"{prefix}_06_样本结论计数.png", cfg.figure_dpi
        ))
        paths.append(plot_raw_plane_scatter(
            paired, ref, "raw", figures_dir / f"{prefix}_07_RAW二维分布.png", cfg.figure_dpi
        ))
        paths.append(plot_raw_plane_scatter(
            paired, ref, "plane", figures_dir / f"{prefix}_08_PLANE二维分布.png", cfg.figure_dpi
        ))
        result[ref] = [p for p in paths if p is not None]
    return result


def format_num(value: Any, digits: int = 3) -> str:
    try:
        x = float(value)
        if not math.isfinite(x):
            return ""
        return f"{x:.{digits}f}"
    except Exception:
        return html.escape(str(value))


def derive_main_conclusion(overall: pd.DataFrame, main_ref: str) -> str:
    if overall.empty:
        return "没有足够数据形成结论。"
    match = overall[overall["消声室参考组代码"] == main_ref]
    if match.empty:
        match = overall.iloc[[0]]
    row = match.iloc[0]
    d = float(row["马氏距离分离改善_PLANE减RAW"])
    s = float(row["频谱相似度分离改善_PLANE减RAW"])
    improved = int(row["明显改善样本数"]) + int(row["部分改善样本数"])
    worsened = int(row["明显变差样本数"]) + int(row["部分变差样本数"])
    if d > 0 and s > 0 and improved > worsened:
        return "PLANE总体有辅助作用：真假距离和频谱相似度的分离都扩大，且改善样本多于变差样本。它仍不能自动等同于“纯泄漏”。"
    if d < 0 and s < 0 and worsened >= improved:
        return "PLANE总体偏负面：真假距离和频谱相似度的分离都缩小，且变差样本不少。"
    return "PLANE作用不一致：部分指标或样本改善，另一些变差。需要重点查看场景图和异常样本清单。"


def dataframe_html(df: pd.DataFrame, max_rows: int = 20) -> str:
    if df.empty:
        return "<p>无数据</p>"
    view = df.head(max_rows).copy()
    for col in view.columns:
        if pd.api.types.is_numeric_dtype(view[col]):
            view[col] = view[col].map(lambda x: "" if pd.isna(x) else f"{float(x):.4f}")
    return view.to_html(index=False, escape=True, border=0, classes="data-table")


def write_html_report(
    output_dir: Path,
    input_path: Path,
    overall: pd.DataFrame,
    scene_summary: pd.DataFrame,
    paired_cn: pd.DataFrame,
    figures: Dict[str, List[Path]],
    main_ref: str,
    font_name: str,
) -> Path:
    report_path = output_dir / "00_打开这个.html"
    conclusion = derive_main_conclusion(overall, main_ref)
    main_figs = figures.get(main_ref, [])
    if not main_figs and figures:
        main_ref = next(iter(figures))
        main_figs = figures[main_ref]

    img_html = "\n".join(
        f'<div class="figure"><img src="{html.escape(str(p.relative_to(output_dir)).replace(os.sep, "/"))}" alt="{html.escape(p.name)}"><p>{html.escape(p.stem)}</p></div>'
        for p in main_figs
    )
    worst = paired_cn[paired_cn["空间拟合对该样本的作用"].isin(["明显变差", "部分变差"])].copy()
    best = paired_cn[paired_cn["空间拟合对该样本的作用"].isin(["明显改善", "部分改善"])].copy()

    content = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>RAW与PLANE结果中文可视化</title>
<style>
body {{ font-family: "Microsoft YaHei", "Noto Sans CJK SC", Arial, sans-serif; margin: 28px; line-height: 1.65; color: #222; }}
h1, h2 {{ margin-top: 1.4em; }}
.notice {{ padding: 14px 18px; background: #f4f4f4; border-left: 5px solid #555; }}
.key {{ font-size: 1.08em; font-weight: 600; }}
.data-table {{ border-collapse: collapse; width: 100%; font-size: 13px; display: block; overflow-x: auto; }}
.data-table th, .data-table td {{ border: 1px solid #ddd; padding: 6px 8px; white-space: nowrap; }}
.data-table th {{ background: #f1f1f1; position: sticky; top: 0; }}
.figure {{ margin: 26px 0; }}
.figure img {{ max-width: 100%; border: 1px solid #ddd; }}
.figure p {{ margin-top: 5px; color: #555; }}
code {{ background: #f5f5f5; padding: 2px 5px; }}
.small {{ color: #666; font-size: 0.92em; }}
</style>
</head>
<body>
<h1>RAW与PLANE结果中文可视化</h1>
<p class="small">输入文件：{html.escape(str(input_path))}<br>绘图字体：{html.escape(font_name)}</p>
<div class="notice"><span class="key">最先看这一句：</span>{html.escape(conclusion)}</div>

<h2>怎么看图</h2>
<p><strong>马氏距离：</strong>真泄漏希望PLANE后变小；假泄漏希望PLANE后变大。</p>
<p><strong>频谱相似度：</strong>真泄漏希望PLANE后变大；假泄漏希望PLANE后变小。</p>
<p><strong>有利变化：</strong>本报告已把TRUE和FALSE方向统一，所有“有利变化”都是<strong>正数代表好，负数代表坏</strong>。</p>

<h2>总体汇总</h2>
{dataframe_html(overall, 20)}

<h2>{html.escape(reference_display(main_ref))} 主要图片</h2>
{img_html}

<h2>各场景汇总（前20行）</h2>
{dataframe_html(scene_summary[scene_summary['消声室参考组代码'] == main_ref], 20)}

<h2>PLANE改善较明显的样本（前20行）</h2>
{dataframe_html(best, 20)}

<h2>PLANE使结果变差的样本（前20行）</h2>
{dataframe_html(worst, 20)}

<h2>输出文件说明</h2>
<ul>
<li><code>00_最先看这个_中文总览.csv</code>：每个消声室参考组的总体结论。</li>
<li><code>01_样本RAW_PLANE配对中文表.csv</code>：同一样本RAW和PLANE放在一行。</li>
<li><code>02_各场景中文汇总.csv</code>：E/F/G分开查看。</li>
<li><code>03_PLANE使结果变差的样本.csv</code>：优先检查这些样本。</li>
<li><code>04_PLANE改善的样本.csv</code>：查看空间拟合在哪些样本上有效。</li>
<li><code>figures</code>：全部图片，包括0.1mm、0.5mm和ALL_LEAKS。</li>
</ul>
</body>
</html>"""
    report_path.write_text(content, encoding="utf-8")
    return report_path


def save_outputs(
    output_dir: Path,
    overall: pd.DataFrame,
    paired_cn: pd.DataFrame,
    scene_summary: pd.DataFrame,
    notes: List[Dict[str, Any]],
) -> Dict[str, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    paths = {
        "overall": output_dir / "00_最先看这个_中文总览.csv",
        "paired": output_dir / "01_样本RAW_PLANE配对中文表.csv",
        "scene": output_dir / "02_各场景中文汇总.csv",
        "worse": output_dir / "03_PLANE使结果变差的样本.csv",
        "better": output_dir / "04_PLANE改善的样本.csv",
        "check": output_dir / "99_读取与配对检查.csv",
    }
    overall.to_csv(paths["overall"], index=False, encoding="utf-8-sig")
    paired_cn.to_csv(paths["paired"], index=False, encoding="utf-8-sig")
    scene_summary.to_csv(paths["scene"], index=False, encoding="utf-8-sig")
    paired_cn[paired_cn["空间拟合对该样本的作用"].isin(["明显变差", "部分变差"])].to_csv(
        paths["worse"], index=False, encoding="utf-8-sig"
    )
    paired_cn[paired_cn["空间拟合对该样本的作用"].isin(["明显改善", "部分改善"])].to_csv(
        paths["better"], index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(notes).to_csv(paths["check"], index=False, encoding="utf-8-sig")
    return paths


def run(input_path: Path, output_dir: Path, cfg: Config) -> Path:
    print(f"读取: {input_path}")
    df_raw = read_csv_flexible(input_path)
    df, notes1 = clean_input(df_raw)
    paired, notes2 = pair_raw_plane(df, cfg)
    if paired.empty:
        raise RuntimeError("没有任何同一样本的RAW/PLANE成功配对，请查看method和sample_id列。")

    available_refs = list(paired["reference_group"].dropna().astype(str).unique())
    main_ref = cfg.main_reference if cfg.main_reference in available_refs else available_refs[0]
    refs = [r for r in cfg.reference_groups if r in available_refs] + [r for r in available_refs if r not in cfg.reference_groups]

    paired_cn = make_chinese_pair_table(paired)
    scene_summary = make_scene_summary(paired)
    overall = overall_reference_summary(paired)
    paths = save_outputs(output_dir, overall, paired_cn, scene_summary, notes1 + notes2)

    print("绘制图片...")
    font_name = setup_chinese_font()
    figures = generate_plots(paired, refs, main_ref, output_dir, cfg)
    report = write_html_report(output_dir, input_path, overall, scene_summary, paired_cn, figures, main_ref, font_name)

    print("\n处理完成")
    print(f"最先打开: {report}")
    print(f"中文总览: {paths['overall']}")
    print(f"样本配对表: {paths['paired']}")
    print(f"图片目录: {output_dir / 'figures'}")

    if cfg.open_report_after_run and sys.platform.startswith("win"):
        try:
            os.startfile(report)  # type: ignore[attr-defined]
        except Exception:
            pass
    return report


def make_self_test_csv(path: Path) -> None:
    rng = np.random.default_rng(42)
    rows: List[Dict[str, Any]] = []
    refs = ["0.1mm", "0.5mm", "ALL_LEAKS"]
    for scene_i, scene in enumerate(["factory_E", "factory_F", "factory_G"]):
        for label in ["TRUE_LEAK", "FALSE_LEAK"]:
            for idx in range(8):
                sample = f"{scene}_{label}_{idx:02d}"
                for ref_i, ref in enumerate(refs):
                    threshold = 4.5 + ref_i * 0.2
                    if label == "TRUE_LEAK":
                        raw_d = 5.8 + scene_i * 0.2 + rng.normal(0, 0.45)
                        plane_d = raw_d - 0.35 + rng.normal(0, 0.25)
                        raw_s = 0.83 + rng.normal(0, 0.025)
                        plane_s = raw_s + 0.025 + rng.normal(0, 0.015)
                    else:
                        raw_d = 6.3 + scene_i * 0.2 + rng.normal(0, 0.55)
                        plane_d = raw_d + 0.65 + rng.normal(0, 0.3)
                        raw_s = 0.76 + rng.normal(0, 0.035)
                        plane_s = raw_s - 0.045 + rng.normal(0, 0.02)
                    for method, d, s in [("raw", raw_d, raw_s), ("plane", plane_d, plane_s)]:
                        p90 = d + 1.1 + abs(rng.normal(0, 0.3))
                        ratio = d / threshold
                        inside = float(np.clip(1.15 - ratio * 0.45, 0, 1))
                        bal = float(np.exp(-0.5 * (ratio ** 2)))
                        rows.append({
                            "sample_id": sample,
                            "dataset": scene,
                            "scene": scene,
                            "label": label,
                            "y_true": int(label == "TRUE_LEAK"),
                            "time_folder": f"folder_{idx}",
                            "center": "00_00",
                            "method": method,
                            "reference_group": ref,
                            "npz_path": "test.npz",
                            "plane_valid": 1,
                            "plane_geometry_ok": 1,
                            "window_distance_threshold": threshold,
                            "n_windows": 19,
                            "median_distance": d,
                            "p90_distance": p90,
                            "mean_distance": (d + p90) / 2,
                            "std_distance": 0.5,
                            "window_inside_fraction": inside,
                            "median_similarity": bal,
                            "p90_guard_similarity": bal * 0.9,
                            "balanced_similarity": bal * 0.95,
                            "median_distance_ratio": ratio,
                            "p90_distance_ratio": p90 / threshold,
                            "cosine_similarity": min(1.0, s + 0.03),
                            "spectral_overlap": max(0.0, s - 0.03),
                            "pearson_similarity": np.clip(2 * s - 1, -1, 1),
                            "combined_similarity": s,
                            "individual_lab_similarity_median": s - 0.02,
                            "individual_lab_similarity_p90": s + 0.01,
                            "individual_lab_similarity_max": min(1.0, s + 0.06),
                        })
    pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")


def self_test() -> None:
    with tempfile.TemporaryDirectory(prefix="v23_visualizer_test_") as td:
        root = Path(td)
        csv_path = root / "01_每个样本_距离与相似度_long.csv"
        out = root / "output"
        make_self_test_csv(csv_path)
        cfg = Config(output_dir=str(out), open_report_after_run=False, top_n_samples=15)
        report = run(csv_path, out, cfg)
        required = [
            report,
            out / "00_最先看这个_中文总览.csv",
            out / "01_样本RAW_PLANE配对中文表.csv",
            out / "02_各场景中文汇总.csv",
            out / "figures" / "ALL_LEAKS_01_各场景马氏距离.png",
        ]
        missing = [str(p) for p in required if not p.exists() or p.stat().st_size == 0]
        if missing:
            raise AssertionError(f"自检输出缺失: {missing}")
        print("\nSELF-TEST PASSED：中文表、HTML和图片均成功生成。")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="把v22的01结果CSV转换成中文表和图片")
    parser.add_argument("--config", type=str, default="v23_visualizer_config.json", help="配置文件")
    parser.add_argument("--input", type=str, default=None, help="直接指定01 CSV路径")
    parser.add_argument("--output", type=str, default=None, help="直接指定输出目录")
    parser.add_argument("--self-test", action="store_true", help="运行自检")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.self_test:
        self_test()
        return

    config_path = Path(args.config).resolve()
    if config_path.exists():
        cfg = dataclass_from_dict(Config, read_json(config_path))
        base_dir = config_path.parent
    else:
        cfg = Config()
        base_dir = Path.cwd()

    input_path = resolve_input_path(args.input, cfg, base_dir)
    output_dir = Path(args.output).resolve() if args.output else resolve_output_dir(input_path, cfg, base_dir)
    run(input_path, output_dir, cfg)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n用户中止。")
        sys.exit(130)
    except Exception as exc:
        print("\n程序失败：", f"{type(exc).__name__}: {exc}")
        traceback.print_exc()
        sys.exit(1)
