@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 安装可视化程序依赖...
python -m pip install --upgrade pip
python -m pip install numpy pandas matplotlib
if errorlevel 1 (
  echo.
  echo 安装失败，请检查Python和网络。
  pause
  exit /b 1
)
echo.
echo 安装完成。
pause
