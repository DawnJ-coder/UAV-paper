@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not "%~1"=="" (
  python visualize_v22_01_results.py --input "%~1"
) else (
  python visualize_v22_01_results.py --config v23_visualizer_config.json
)
pause
