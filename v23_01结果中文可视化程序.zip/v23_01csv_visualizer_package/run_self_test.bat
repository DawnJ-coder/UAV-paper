@echo off
chcp 65001 >nul
cd /d "%~dp0"
python visualize_v22_01_results.py --self-test
pause
