# -*- coding: utf-8 -*-
"""只使用真实泄漏 T 的离线字典预训练与冻结字典加载。

本模块严格不读取工厂 T/F 标签，也不使用工厂 F 进行训练、选参或阈值调整。
工厂程序只加载本模块生成的冻结字典，并在每个样本内部使用周围测点估计环境。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import warnings
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from sklearn.decomposition import NMF, non_negative_factorization
from sklearn.exceptions import ConvergenceWarning

import _spatial_v3_engine as core


EPS = core.EPS


DICTIONARY_DEFAULTS: Dict[str, Any] = {
    "pretrained_dictionary_path": "pretrained_t_dictionary.npz",
    "dictionary_validation_fraction": 0.25,
    "dictionary_candidate_components": [6, 8, 12],
    "dictionary_candidate_beta_losses": ["kullback-leibler"],
    "dictionary_candidate_activation_l1": [0.0, 1.0e-5],
    "dictionary_candidate_seeds": [23, 42],
    "dictionary_energy_quantile": 0.25,
    "dictionary_window_seconds": 5.0,
    "dictionary_max_windows_per_file": 12,
    "dictionary_max_frames_per_file": 2000,
    "dictionary_max_total_frames": 30000,
    "dictionary_augment_copies": 1,
    "dictionary_augment_max_db": 3.0,
    "dictionary_augment_max_shift_bins": 2,
}


def _resolve_bundle_path(value: str, config_path: Optional[Path]) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute() and config_path is not None:
        path = config_path.resolve().parent / path
    return path.resolve()


def attach_dictionary_config(
    cfg: core.RunConfig,
    raw_algorithm: Optional[Mapping[str, Any]] = None,
    config_path: Optional[Path] = None,
) -> None:
    """向兼容引擎的 AlgorithmConfig 附加 T-only 预训练参数。"""
    raw = dict(raw_algorithm or {})
    a = cfg.algorithm

    path_value = str(raw.get(
        "pretrained_dictionary_path",
        DICTIONARY_DEFAULTS["pretrained_dictionary_path"],
    ))
    setattr(a, "pretrained_dictionary_path", str(_resolve_bundle_path(path_value, config_path)))

    list_types = {
        "dictionary_candidate_components": int,
        "dictionary_candidate_beta_losses": str,
        "dictionary_candidate_activation_l1": float,
        "dictionary_candidate_seeds": int,
    }
    for key, default in DICTIONARY_DEFAULTS.items():
        if key == "pretrained_dictionary_path":
            continue
        value = raw.get(key, default)
        if key in list_types:
            value = [list_types[key](item) for item in value]
        setattr(a, key, value)

    _validate_dictionary_config(cfg)


def _validate_dictionary_config(cfg: core.RunConfig) -> None:
    a = cfg.algorithm
    if not 0.0 < float(a.dictionary_validation_fraction) < 1.0:
        raise ValueError("dictionary_validation_fraction 必须位于(0,1)")
    if not a.dictionary_candidate_components or min(a.dictionary_candidate_components) < 2:
        raise ValueError("dictionary_candidate_components 至少包含一个>=2的整数")
    allowed_beta = {"frobenius", "kullback-leibler", "itakura-saito"}
    unknown = set(a.dictionary_candidate_beta_losses) - allowed_beta
    if unknown:
        raise ValueError(f"不支持的 dictionary_candidate_beta_losses: {sorted(unknown)}")
    if not a.dictionary_candidate_activation_l1 or min(a.dictionary_candidate_activation_l1) < 0:
        raise ValueError("dictionary_candidate_activation_l1 必须为非负列表")
    if not a.dictionary_candidate_seeds:
        raise ValueError("dictionary_candidate_seeds 不能为空")
    if not 0.0 <= float(a.dictionary_energy_quantile) < 1.0:
        raise ValueError("dictionary_energy_quantile 必须位于[0,1)")
    for key in (
        "dictionary_window_seconds",
        "dictionary_max_windows_per_file",
        "dictionary_max_frames_per_file",
        "dictionary_max_total_frames",
    ):
        if float(getattr(a, key)) <= 0:
            raise ValueError(f"{key} 必须>0")
    if int(a.dictionary_augment_copies) < 0:
        raise ValueError("dictionary_augment_copies 必须>=0")


def _stable_file_score(path: Path, seed: int) -> int:
    token = f"{seed}|{str(path.resolve()).casefold()}".encode("utf-8")
    return int(hashlib.sha256(token).hexdigest()[:16], 16)


def _file_fingerprint(path: Path) -> str:
    stat = path.stat()
    token = f"{path.resolve()}|{stat.st_size}|{stat.st_mtime_ns}".encode("utf-8")
    return hashlib.sha256(token).hexdigest()


def split_positive_files(
    files: Sequence[Path], validation_fraction: float, seed: int,
) -> Tuple[List[Path], List[Path]]:
    ordered = sorted(files, key=lambda path: _stable_file_score(path, seed))
    if len(ordered) < 2:
        raise RuntimeError("T-only 预训练至少需要2个先验泄漏WAV，才能按文件划分训练/验证")
    n_validation = int(round(len(ordered) * validation_fraction))
    n_validation = min(max(n_validation, 1), len(ordered) - 1)
    return ordered[n_validation:], ordered[:n_validation]


def _uniform_windows(x: np.ndarray, fs: int, seconds: float, count: int) -> List[np.ndarray]:
    window_samples = min(len(x), max(256, int(round(seconds * fs))))
    if len(x) <= window_samples or count <= 1:
        starts = np.asarray([0], dtype=int)
    else:
        starts = np.linspace(0, len(x) - window_samples, count, dtype=int)
        starts = np.unique(starts)
    return [x[start : start + window_samples] for start in starts]


def extract_file_power(
    path: Path,
    cfg: core.AlgorithmConfig,
    seed: int,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, Any]]:
    """从整段T录音均匀取窗，先过滤低能量帧，再按文件平衡抽样。"""
    fs, x, dtype_name, duration = core.read_lab_wav(path, 0.0)
    if fs != int(cfg.expected_sample_rate_hz):
        raise ValueError(
            f"实验室WAV采样率不匹配: {path}, 实际{fs}, 期望{cfg.expected_sample_rate_hz}"
        )
    windows = _uniform_windows(
        x,
        fs,
        float(cfg.dictionary_window_seconds),
        int(cfg.dictionary_max_windows_per_file),
    )
    blocks: List[np.ndarray] = []
    freq_ref: Optional[np.ndarray] = None
    for window in windows:
        centered = np.asarray(window, dtype=np.float64) - float(np.mean(window))
        freq, _, z = core.stft_full(centered, fs, cfg)
        freq_band, power, _ = core.power_band_from_stft(freq, z, cfg)
        if freq_ref is None:
            freq_ref = freq_band
        elif len(freq_ref) != len(freq_band) or np.max(np.abs(freq_ref - freq_band)) > 1e-6:
            raise ValueError(f"同一文件不同窗口频率轴不一致: {path}")
        blocks.append(np.maximum(power, 0.0))

    if not blocks or freq_ref is None:
        raise RuntimeError(f"没有从T录音提取到功率帧: {path}")
    matrix = np.concatenate(blocks, axis=1)
    energy = np.sum(matrix, axis=0)
    positive = energy[np.isfinite(energy) & (energy > 0)]
    if positive.size == 0:
        raise RuntimeError(f"T录音主频带没有正能量: {path}")
    threshold = float(np.quantile(positive, float(cfg.dictionary_energy_quantile)))
    keep = np.isfinite(energy) & (energy >= threshold) & (energy > 0)
    matrix = matrix[:, keep]
    if matrix.shape[1] == 0:
        raise RuntimeError(f"T录音能量过滤后没有可用帧: {path}")

    rng = np.random.default_rng(seed)
    matrix = core.subsample_columns(
        matrix,
        int(cfg.dictionary_max_frames_per_file),
        rng,
    )
    row = {
        "file": str(path),
        "sample_rate_hz": fs,
        "duration_seconds": duration,
        "window_count": len(windows),
        "retained_frames": int(matrix.shape[1]),
        "energy_threshold": threshold,
        "dtype": dtype_name,
        "fingerprint_sha256": _file_fingerprint(path),
    }
    return np.asarray(freq_ref, dtype=np.float64), matrix, row


def _augment_positive_power(
    power: np.ndarray,
    rng: np.random.Generator,
    max_db: float,
    max_shift_bins: int,
) -> np.ndarray:
    """只改变T频响/轻微频移；不使用真实F，也不生成F标签。"""
    n_freq = power.shape[0]
    n_anchor = min(8, max(3, n_freq // 32))
    anchor_x = np.linspace(0, n_freq - 1, n_anchor)
    anchor_db = rng.uniform(-max_db, max_db, size=n_anchor)
    response_db = np.interp(np.arange(n_freq), anchor_x, anchor_db)
    augmented = power * np.power(10.0, response_db[:, None] / 10.0)

    shift = int(rng.integers(-max_shift_bins, max_shift_bins + 1)) if max_shift_bins > 0 else 0
    if shift > 0:
        shifted = np.full_like(augmented, EPS)
        shifted[shift:, :] = augmented[:-shift, :]
        augmented = shifted
    elif shift < 0:
        shifted = np.full_like(augmented, EPS)
        shifted[:shift, :] = augmented[-shift:, :]
        augmented = shifted
    return np.maximum(augmented, EPS)


def build_training_matrix(
    powers: Sequence[np.ndarray],
    cfg: core.AlgorithmConfig,
    seed: int,
) -> np.ndarray:
    rng = np.random.default_rng(seed)
    blocks: List[np.ndarray] = []
    for power in powers:
        blocks.append(power)
        for _ in range(int(cfg.dictionary_augment_copies)):
            blocks.append(_augment_positive_power(
                power,
                rng,
                float(cfg.dictionary_augment_max_db),
                int(cfg.dictionary_augment_max_shift_bins),
            ))
    matrix = np.concatenate(blocks, axis=1)
    return core.subsample_columns(
        matrix,
        int(cfg.dictionary_max_total_frames),
        rng,
    )


def _fit_candidate(
    power: np.ndarray,
    n_components: int,
    beta_loss: str,
    activation_l1: float,
    seed: int,
    max_iter: int,
) -> Tuple[np.ndarray, Dict[str, Any]]:
    normalized, _ = core.normalize_columns(power)
    normalized = np.maximum(normalized.T, 1.0e-10)
    n_components = min(
        int(n_components),
        max(2, min(normalized.shape[0], normalized.shape[1]) - 1),
    )
    model = NMF(
        n_components=n_components,
        init="nndsvda",
        solver="mu",
        beta_loss=beta_loss,
        max_iter=int(max_iter),
        tol=1.0e-5,
        random_state=int(seed),
        alpha_W=float(activation_l1),
        # 同时约束两个因子，避免仅正则激活时出现D放大、H缩小的尺度退化。
        alpha_H=float(activation_l1),
        l1_ratio=1.0,
    )
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always", ConvergenceWarning)
        model.fit(normalized)
    dictionary = np.maximum(model.components_.T, EPS)
    dictionary /= np.maximum(np.sum(dictionary, axis=0, keepdims=True), EPS)
    info = {
        "n_components_actual": int(dictionary.shape[1]),
        "n_iter": int(model.n_iter_),
        "converged": not any(issubclass(item.category, ConvergenceWarning) for item in caught),
        "training_reconstruction_error": float(model.reconstruction_err_),
    }
    return dictionary, info


def infer_fixed_dictionary(
    power: np.ndarray,
    dictionary: np.ndarray,
    beta_loss: str,
    activation_l1: float,
    iterations: int,
    seed: int,
) -> Tuple[np.ndarray, np.ndarray, int]:
    """固定D估计H；与预训练使用同一beta损失和同一激活L1。"""
    normalized, scale = core.normalize_columns(np.maximum(power, 0.0))
    x = np.maximum(normalized.T, 1.0e-10)
    k = int(dictionary.shape[1])
    codes, _, n_iter = non_negative_factorization(
        x,
        H=np.maximum(dictionary.T.copy(), 1.0e-10),
        n_components=k,
        init="custom",
        update_H=False,
        solver="mu",
        beta_loss=beta_loss,
        tol=1.0e-5,
        max_iter=int(iterations),
        alpha_W=float(activation_l1),
        alpha_H=0.0,
        l1_ratio=1.0,
        random_state=int(seed),
    )
    activation_normalized = np.maximum(codes.T, 0.0)
    activation = activation_normalized * scale
    reconstruction = np.maximum(dictionary @ activation, 0.0)
    return activation, reconstruction, int(n_iter)


def _atom_coherence(dictionary: np.ndarray) -> float:
    normalized = core.l2_normalize_columns(dictionary)
    gram = normalized.T @ normalized
    np.fill_diagonal(gram, 0.0)
    return float(np.max(gram)) if gram.size else 0.0


def _evaluate_candidate(
    dictionary: np.ndarray,
    validation_powers: Sequence[Tuple[Path, np.ndarray]],
    reference_specs: Sequence[Tuple[str, Path, np.ndarray]],
    beta_loss: str,
    activation_l1: float,
    iterations: int,
    seed: int,
) -> Dict[str, float]:
    similarities: List[float] = []
    errors: List[float] = []
    frame_cosines: List[float] = []
    usage = np.zeros(dictionary.shape[1], dtype=np.float64)
    for index, (_, power) in enumerate(validation_powers):
        activation, reconstruction, _ = infer_fixed_dictionary(
            power,
            dictionary,
            beta_loss,
            activation_l1,
            iterations,
            seed + 1000 + index,
        )
        metrics = core.evaluate_against_lab(
            core.representative_spectrum(reconstruction),
            reference_specs,
        )
        similarities.append(float(metrics["lab_similarity_combined_median"]))
        x_norm, _ = core.normalize_columns(power)
        r_norm, _ = core.normalize_columns(reconstruction)
        errors.append(float(np.sum(np.abs(x_norm - r_norm)) / (np.sum(x_norm) + EPS)))
        frame_cosine = np.sum(
            core.l2_normalize_columns(power) * core.l2_normalize_columns(reconstruction),
            axis=0,
        )
        frame_cosines.append(float(np.median(np.clip(frame_cosine, 0.0, 1.0))))
        usage += np.sum(activation, axis=1)

    return {
        "t_similarity_p10": float(np.quantile(similarities, 0.10)),
        "t_similarity_median": float(np.median(similarities)),
        "t_relative_l1_error_median": float(np.median(errors)),
        "t_frame_cosine_median": float(np.median(frame_cosines)),
        "atom_coherence_max": _atom_coherence(dictionary),
        "atom_usage_fraction": float(np.mean(usage > EPS)),
    }


def _selection_key(row: Mapping[str, Any]) -> Tuple[float, float, float, float, float]:
    return (
        float(row["t_similarity_p10"]),
        float(row["t_similarity_median"]),
        -float(row["t_relative_l1_error_median"]),
        -float(row["atom_coherence_max"]),
        float(bool(row["converged"])),
    )


def _collect_group_files(cfg: core.RunConfig, groups: Sequence[str]) -> List[Path]:
    return sorted({
        path
        for group in groups
        for path in core.discover_wavs(cfg.lab_groups.get(group, []))
    }, key=lambda path: str(path).casefold())


def run_pretraining(cfg: core.RunConfig, output_path: Optional[Path] = None) -> Path:
    """只使用实验室泄漏T训练、验证并保存冻结整体字典。"""
    a = cfg.algorithm
    bundle_path = Path(output_path or a.pretrained_dictionary_path).expanduser().resolve()
    core.ensure_dir(bundle_path.parent)

    prior_groups = list(a.lab_prior_groups)
    reference_groups = list(a.lab_similarity_groups)
    prior_files = _collect_group_files(cfg, prior_groups)
    reference_files = _collect_group_files(cfg, reference_groups)
    overlap = set(prior_files) & set(reference_files)
    if overlap:
        raise RuntimeError("T训练文件与T相似度参照文件不能重叠")
    if not prior_files:
        raise RuntimeError(f"没有发现T训练WAV，组={prior_groups}")
    if not reference_files:
        raise RuntimeError(f"没有发现T相似度参照WAV，组={reference_groups}")

    train_files, validation_files = split_positive_files(
        prior_files,
        float(a.dictionary_validation_fraction),
        int(a.random_state),
    )
    group_by_file: Dict[Path, str] = {}
    for group in prior_groups + reference_groups:
        for path in core.discover_wavs(cfg.lab_groups.get(group, [])):
            group_by_file.setdefault(path, group)

    scan_rows: List[Dict[str, Any]] = []
    power_by_file: Dict[Path, np.ndarray] = {}
    freq_ref: Optional[np.ndarray] = None
    roles = (
        [(path, "T_DICTIONARY_TRAIN") for path in train_files]
        + [(path, "T_DICTIONARY_VALIDATION") for path in validation_files]
        + [(path, "T_SIMILARITY_REFERENCE") for path in reference_files]
    )
    for index, (path, role) in enumerate(roles):
        freq, power, row = extract_file_power(path, a, int(a.random_state) + index)
        if freq_ref is None:
            freq_ref = freq
        elif len(freq_ref) != len(freq) or np.max(np.abs(freq_ref - freq)) > 1e-6:
            raise RuntimeError(f"T预训练文件频率轴不一致: {path}")
        power_by_file[path] = power
        scan_rows.append({"group": group_by_file.get(path, ""), "role": role, **row})
    if freq_ref is None:
        raise RuntimeError("T预训练没有产生频率轴")

    reference_specs = [
        (group_by_file.get(path, ""), path, core.representative_spectrum(power_by_file[path]))
        for path in reference_files
    ]
    similarity_prototype = core.normalize_vector(np.median(
        np.vstack([spec for _, _, spec in reference_specs]),
        axis=0,
    ))

    training_matrix = build_training_matrix(
        [power_by_file[path] for path in train_files],
        a,
        int(a.random_state),
    )
    validation_powers = [(path, power_by_file[path]) for path in validation_files]

    candidate_rows: List[Dict[str, Any]] = []
    candidates: List[Tuple[Dict[str, Any], np.ndarray]] = []
    candidate_index = 0
    for k in a.dictionary_candidate_components:
        for beta_loss in a.dictionary_candidate_beta_losses:
            for activation_l1 in a.dictionary_candidate_activation_l1:
                for seed in a.dictionary_candidate_seeds:
                    candidate_index += 1
                    base = {
                        "candidate_index": candidate_index,
                        "n_components": int(k),
                        "beta_loss": str(beta_loss),
                        "activation_l1": float(activation_l1),
                        "seed": int(seed),
                    }
                    try:
                        dictionary, fit_info = _fit_candidate(
                            training_matrix,
                            int(k),
                            str(beta_loss),
                            float(activation_l1),
                            int(seed),
                            int(a.nmf_max_iter),
                        )
                        metrics = _evaluate_candidate(
                            dictionary,
                            validation_powers,
                            reference_specs,
                            str(beta_loss),
                            float(activation_l1),
                            int(a.lab_projection_iterations),
                            int(seed),
                        )
                        row = {**base, **fit_info, **metrics, "status": "OK", "error": ""}
                        candidate_rows.append(row)
                        candidates.append((row, dictionary))
                        print(
                            f"候选{candidate_index}: K={k}, beta={beta_loss}, l1={activation_l1:g}, "
                            f"seed={seed}, T-p10={metrics['t_similarity_p10']:.4f}, "
                            f"error={metrics['t_relative_l1_error_median']:.4f}"
                        )
                    except Exception as exc:
                        candidate_rows.append({
                            **base,
                            "status": "ERROR",
                            "error": f"{type(exc).__name__}: {exc}",
                        })
    if not candidates:
        raise RuntimeError("全部T-only候选字典训练失败")

    best_row, _ = max(candidates, key=lambda item: _selection_key(item[0]))
    final_matrix = build_training_matrix(
        [power_by_file[path] for path in train_files + validation_files],
        a,
        int(best_row["seed"]),
    )
    final_dictionary, final_fit = _fit_candidate(
        final_matrix,
        int(best_row["n_components"]),
        str(best_row["beta_loss"]),
        float(best_row["activation_l1"]),
        int(best_row["seed"]),
        int(a.nmf_max_iter),
    )

    metadata = {
        "model_version": "t-only-leak-dictionary-v3.0",
        "data_semantics": "T_ONLY_NO_F_TRAINING_OR_SELECTION",
        "training_groups": prior_groups,
        "reference_groups": reference_groups,
        "training_files": [str(path) for path in train_files],
        "validation_files": [str(path) for path in validation_files],
        "reference_files": [str(path) for path in reference_files],
        "beta_loss": str(best_row["beta_loss"]),
        "activation_l1": float(best_row["activation_l1"]),
        "n_components": int(final_dictionary.shape[1]),
        "seed": int(best_row["seed"]),
        "selection_metrics": {
            key: best_row[key]
            for key in (
                "t_similarity_p10",
                "t_similarity_median",
                "t_relative_l1_error_median",
                "t_frame_cosine_median",
                "atom_coherence_max",
                "atom_usage_fraction",
            )
        },
        "final_fit": final_fit,
        "feature_config": {
            "freq_low_hz": float(a.freq_low_hz),
            "freq_high_hz": float(a.freq_high_hz),
            "expected_sample_rate_hz": int(a.expected_sample_rate_hz),
            "nperseg": int(a.nperseg),
            "hop_length": int(a.hop_length),
            "nfft": int(a.nfft),
        },
    }

    np.savez_compressed(
        bundle_path,
        dictionary=final_dictionary,
        freq_hz=np.asarray(freq_ref, dtype=np.float64),
        similarity_prototype=similarity_prototype,
        reference_spectra=np.vstack([spec for _, _, spec in reference_specs]),
        reference_groups=np.asarray([group for group, _, _ in reference_specs], dtype=str),
        reference_files=np.asarray([str(path) for _, path, _ in reference_specs], dtype=str),
        training_files=np.asarray([str(path) for path in train_files], dtype=str),
        validation_files=np.asarray([str(path) for path in validation_files], dtype=str),
        data_semantics=np.asarray("T_ONLY_NO_F_TRAINING_OR_SELECTION"),
        metadata_json=np.asarray(json.dumps(metadata, ensure_ascii=False)),
    )
    pd.DataFrame(scan_rows).to_csv(
        bundle_path.with_name(bundle_path.stem + "_files.csv"),
        index=False,
        encoding="utf-8-sig",
    )
    pd.DataFrame(candidate_rows).to_csv(
        bundle_path.with_name(bundle_path.stem + "_cv.csv"),
        index=False,
        encoding="utf-8-sig",
    )
    core.write_json(bundle_path.with_name(bundle_path.stem + "_manifest.json"), metadata)
    if bool(a.save_plots):
        core.plot_dictionary(
            np.asarray(freq_ref, dtype=np.float64),
            final_dictionary,
            "T-only pretrained leak dictionary",
            bundle_path.with_name(bundle_path.stem + "_atoms.png"),
        )
    print("T-only冻结字典已保存:", bundle_path)
    print("训练语义: T_ONLY_NO_F_TRAINING_OR_SELECTION")
    return bundle_path


def _scalar_text(value: np.ndarray) -> str:
    return str(np.asarray(value).item())


def _validate_bundle_feature_config(metadata: Mapping[str, Any], cfg: core.AlgorithmConfig) -> None:
    expected = metadata.get("feature_config", {})
    actual = {
        "freq_low_hz": float(cfg.freq_low_hz),
        "freq_high_hz": float(cfg.freq_high_hz),
        "expected_sample_rate_hz": int(cfg.expected_sample_rate_hz),
        "nperseg": int(cfg.nperseg),
        "hop_length": int(cfg.hop_length),
        "nfft": int(cfg.nfft),
    }
    mismatch = {
        key: {"bundle": expected.get(key), "runtime": value}
        for key, value in actual.items()
        if expected.get(key) != value
    }
    if mismatch:
        raise RuntimeError(f"冻结字典与运行时STFT/频段配置不一致: {mismatch}")


def load_pretrained_reference(cfg: core.RunConfig, output_dir: Path) -> Dict[str, Any]:
    """加载冻结T字典并构造旧引擎所需的兼容返回结构。"""
    bundle_path = Path(cfg.algorithm.pretrained_dictionary_path).expanduser().resolve()
    if not bundle_path.is_file():
        raise FileNotFoundError(
            f"没有找到冻结T字典: {bundle_path}\n"
            "请先运行: python spatial_prior_fusion_v2.py --pretrain-dictionary "
            "--config spatial_prior_fusion_v2_config.json"
        )
    with np.load(bundle_path, allow_pickle=False) as bundle:
        dictionary = np.asarray(bundle["dictionary"], dtype=np.float64)
        freq_hz = np.asarray(bundle["freq_hz"], dtype=np.float64)
        reference_spectra = np.asarray(bundle["reference_spectra"], dtype=np.float64)
        reference_groups = np.asarray(bundle["reference_groups"], dtype=str)
        reference_files = np.asarray(bundle["reference_files"], dtype=str)
        similarity_prototype = np.asarray(bundle["similarity_prototype"], dtype=np.float64)
        data_semantics = _scalar_text(bundle["data_semantics"])
        metadata = json.loads(_scalar_text(bundle["metadata_json"]))
        training_files = np.asarray(bundle["training_files"], dtype=str).tolist()
        validation_files = np.asarray(bundle["validation_files"], dtype=str).tolist()

    if data_semantics != "T_ONLY_NO_F_TRAINING_OR_SELECTION":
        raise RuntimeError(f"冻结字典训练语义不符合T-only约束: {data_semantics}")
    if dictionary.ndim != 2 or dictionary.shape[0] != len(freq_hz):
        raise RuntimeError("冻结字典维度与频率轴不一致")
    if reference_spectra.ndim != 2 or reference_spectra.shape[1] != len(freq_hz):
        raise RuntimeError("冻结T参照频谱维度错误")
    _validate_bundle_feature_config(metadata, cfg.algorithm)

    setattr(cfg.algorithm, "dictionary_beta_loss", str(metadata["beta_loss"]))
    setattr(cfg.algorithm, "dictionary_activation_l1", float(metadata["activation_l1"]))
    cfg.algorithm.leak_components = int(dictionary.shape[1])

    references = [
        (str(group), Path(str(path)), np.asarray(spec, dtype=np.float64))
        for group, path, spec in zip(reference_groups, reference_files, reference_spectra)
    ]
    provenance = {
        "bundle_path": str(bundle_path),
        "bundle_fingerprint_sha256": _file_fingerprint(bundle_path),
        "data_semantics": data_semantics,
        "metadata": metadata,
    }
    core.write_json(output_dir / "02_loaded_t_only_dictionary.json", provenance)
    if bool(cfg.algorithm.save_plots):
        core.plot_dictionary(
            freq_hz,
            dictionary,
            "Loaded frozen T-only leak dictionary",
            output_dir / "02_loaded_t_only_dictionary.png",
        )

    return {
        "freq_hz": freq_hz,
        "ws": dictionary,
        "lab_proto": similarity_prototype,
        "prior_proto": core.normalize_vector(np.median(dictionary, axis=1)),
        "prior_specs": [],
        "similarity_specs": references,
        "validation_specs": references,
        "validation_mode": "FROZEN_T_ONLY_DICTIONARY",
        "split_summary": {
            "data_semantics": data_semantics,
            "training_files": training_files,
            "validation_files": validation_files,
            "reference_files": [str(path) for _, path, _ in references],
        },
        "bundle_path": str(bundle_path),
        "dictionary_metadata": metadata,
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="只使用泄漏T的离线字典预训练")
    parser.add_argument("--config", default="spatial_prior_fusion_v2_config.json")
    parser.add_argument("--output", default=None)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    config_path = Path(args.config)
    import spatial_prior_fusion_v2 as app

    cfg = app.load_config(config_path)
    output = Path(args.output) if args.output else None
    run_pretraining(cfg, output)


if __name__ == "__main__":
    main()
