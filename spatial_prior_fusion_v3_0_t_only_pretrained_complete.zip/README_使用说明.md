# 双空间融合 + T-only冻结整体字典 v3.0

## 核心约束

- 字典训练、验证和选参只使用真实泄漏 `T`。
- 工厂 `F` 不进入字典训练、损失函数、候选模型选择或阈值调整。
- 工厂标签只在全部输出冻结后计算AUC和T/F成对统计。
- 周围测点只在当前工厂样本内部估计公共环境，不作为F训练数据。
- 工厂分析不再现场重训字典，只加载离线生成的冻结模型包。

## 数据角色

- `lab_prior_groups`（默认0.5 mm）：T-only字典数据。程序按完整WAV划分训练集和验证集，绝不按相邻时频帧随机拆分。
- `lab_similarity_groups`（默认0.1 mm）：T相似度参照，保存在冻结模型包中，不参与F训练。
- 工厂T/F：只进入正式样本处理和最终冻结评估。

## 第一次运行

1. 修改 `spatial_prior_fusion_v2_config.json` 中实验室T路径、工厂路径和输出路径。
2. 安装依赖：

```powershell
python -m pip install -r requirements.txt
```

3. 只使用实验室T预训练冻结字典：

```powershell
python spatial_prior_fusion_v2.py --pretrain-dictionary --config spatial_prior_fusion_v2_config.json
```

也可以双击 `预训练T字典.bat`。

4. 运行自检：

```powershell
python spatial_prior_fusion_v2.py --self-test
```

5. 运行工厂分析：

```powershell
python spatial_prior_fusion_v2.py --config spatial_prior_fusion_v2_config.json
```

也可以双击 `运行正式程序.bat`。

如果没有先生成 `pretrained_t_dictionary.npz`，正式分析会直接停止并给出预训练命令，不会悄悄退回旧的现场重训流程。

## T-only预训练流程

1. 从每个T录音的全时长均匀取窗，不再只使用前30秒。
2. 在列归一化之前按文件内能量分位数剔除低能量帧。
3. 每个文件最多贡献相同数量的时频帧，避免长录音主导字典。
4. 对训练T加入轻微平滑频响和频移增强，不使用任何真实F。
5. 搜索字典原子数、激活L1和随机种子。
6. 每个候选只在留出的T验证WAV上评价；优先提高弱T的相似度第10分位数，再比较重构误差和原子重复度。
7. 选定超参数后，用T训练+验证文件重新拟合最终整体字典并冻结。
8. 训练和工厂投影使用相同的beta损失、相同的激活L1和相同的列归一化规则。

默认只搜索 `kullback-leibler`，避免第一次预训练候选过多。需要比较IS-NMF时，可将配置改为：

```json
"dictionary_candidate_beta_losses": [
  "kullback-leibler",
  "itakura-saito"
]
```

## 冻结字典输出

默认在配置文件旁生成：

- `pretrained_t_dictionary.npz`：整体字典、频率轴、T参照、训练语义和最优参数。
- `pretrained_t_dictionary_cv.csv`：所有T-only候选结果。
- `pretrained_t_dictionary_files.csv`：训练/验证/参照文件及能量过滤记录。
- `pretrained_t_dictionary_manifest.json`：模型版本、特征配置和文件角色。
- `pretrained_t_dictionary_atoms.png`：字典原子图。

模型包中的 `data_semantics` 必须为：

```text
T_ONLY_NO_F_TRAINING_OR_SELECTION
```

正式运行会校验该字段以及频段、采样率、STFT参数；不一致时拒绝加载。

## 工厂样本方法

每个样本计算四条链：

1. `fixed_ring`：20/25/30/35/40 cm五圈、每圈8方向的鲁棒平面背景预测。
2. `opposite_pair`：同半径相反方向、多半径、多轴支持背景预测。
3. `dual_spatial`：按单样本不确定度融合两个空间模型。
4. `final`：中心点和周围点投影到冻结T字典，在激活域计算中心超过环境上界的额外T激活，并受时频点上限和总能量上限约束。

只有中心点相对周围环境额外出现的T字典激活才能产生补偿。

## 工厂分析主要输出

- `02_loaded_t_only_dictionary.json`：实际加载模型及指纹。
- `10_factory_sample_summary.csv`：四条方法链结果。
- `11_v2_spatial_diagnostics.csv`：空间模型诊断。
- `13_TF_metric_auc.csv`：冻结后的事后AUC。
- `14_TF_paired_comparison.csv`、`15_TF_paired_summary.csv`：冻结后的T/F成对统计。
- `samples/.../spatial_prior_fusion_v2_result.npz`：完整时频矩阵。

F评估结果不能用于回头调整本次字典；如果根据F结果改了参数，需要另采一批未见工厂数据作为最终测试。
