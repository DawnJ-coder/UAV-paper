@echo off
chcp 65001 >nul
python spatial_prior_fusion_v2.py --config spatial_prior_fusion_v2_config.json
pause
