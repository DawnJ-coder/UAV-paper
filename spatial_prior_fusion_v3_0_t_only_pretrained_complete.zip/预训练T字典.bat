@echo off
chcp 65001 >nul
python spatial_prior_fusion_v2.py --pretrain-dictionary --config spatial_prior_fusion_v2_config.json
pause
