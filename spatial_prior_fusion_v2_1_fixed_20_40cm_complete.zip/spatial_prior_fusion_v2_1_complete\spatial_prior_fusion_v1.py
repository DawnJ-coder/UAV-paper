# -*- coding: utf-8 -*-
"""v2 内部公共函数模块，请勿作为正式入口直接运行。

空间拟合降噪 + 实验室先验补偿（无训练集版本）。

方法：
1. 每个工厂样本独立使用最外圈 40 点，在对数功率域鲁棒拟合空间平面，
   预测中心点环境噪声；
2. 对中心功率减去预测背景，得到空间正残差；
3. 仅用 0.5 mm 消声室数据提取非负泄露先验字典，并从被空间背景吸收的
   功率中生成先验补偿候选；
4. 仅用 0.1 mm 数据作为相似度参照，在每个样本内选择补偿混合系数。

没有任何工厂训练集。标签只用于运行结束后的汇总/AUC（如果用户提供）。
"""
from __future__ import annotations

import argparse
import json
import math
import shutil
import sys
import tempfile
import traceback
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.io import wavfile
from scipy.spatial import Delaunay, QhullError

import _spatial_v3_engine as core


EPS = core.EPS
DB_PER_NATURAL_LOG = core.DB_PER_NATURAL_LOG

# 严格中心点白名单。其他中心编号及其偏移点在索引阶段即被丢弃。
ALLOWED_CENTER_IDS: Tuple[str, ...] = ("00_00", "00_01")
_ORIGINAL_BUILD_CENTER_INDEX = core.build_center_index
_ORIGINAL_BUILD_OFFSET_INDEX = core.build_offset_index


def build_allowed_center_index(folder: Path) -> Dict[str, List[Path]]:
    index = _ORIGINAL_BUILD_CENTER_INDEX(folder)
    return {center_id: files for center_id, files in index.items() if center_id in ALLOWED_CENTER_IDS}


def build_allowed_offset_index(
    folders: Sequence[Path],
) -> Dict[Tuple[str, int, str], List[Path]]:
    index = _ORIGINAL_BUILD_OFFSET_INDEX(folders)
    return {key: files for key, files in index.items() if key[0] in ALLOWED_CENTER_IDS}


def directory_has_allowed_center_wav(folder: Path) -> bool:
    return bool(build_allowed_center_index(folder))

# 新参数由本文件读取并附加到兼容引擎的 AlgorithmConfig 实例上。
FUSION_DEFAULTS: Dict[str, Any] = {
    "lab_prior_groups": ["0.5mm"],
    "lab_similarity_groups": ["0.1mm"],
    "max_lab_prior_frames": 20000,
    "plane_fit_distances_cm": [20, 25, 30, 35, 40],
    "point_huber_delta": 1.5,
    "plane_clip_margin_db": 3.0,
    "max_geometry_condition": 1.0e6,
    "plane_ridge_ratio": 1.0e-10,
    "prior_share_exponent": 1.0,
    "prior_frame_cosine_midpoint": 0.76,
    "prior_frame_cosine_softness": 0.06,
    "prior_contrast_midpoint": 0.0,
    "prior_contrast_softness": 0.04,
    "prior_supplement_bin_cap": 0.50,
    "prior_mix_max": 1.0,
    "prior_mix_steps": 21,
}


def _attach_fusion_config(cfg: core.RunConfig, raw_algorithm: Optional[Mapping[str, Any]] = None) -> None:
    raw = dict(raw_algorithm or {})
    for key, default in FUSION_DEFAULTS.items():
        value = raw.get(key, default)
        if isinstance(default, list):
            value = [str(x) for x in value]
        setattr(cfg.algorithm, key, value)
    # 底层兼容引擎保留了旧字段名；新程序对外统一称为“先验帧”。
    cfg.algorithm.max_lab_training_frames = int(cfg.algorithm.max_lab_prior_frames)
    _validate_fusion_config(cfg)


def _validate_fusion_config(cfg: core.RunConfig) -> None:
    a = cfg.algorithm
    if not a.lab_prior_groups or not a.lab_similarity_groups:
        raise ValueError("lab_prior_groups 和 lab_similarity_groups 均不能为空")
    overlap = set(a.lab_prior_groups) & set(a.lab_similarity_groups)
    if overlap:
        raise ValueError(f"先验组和相似度参照组不能重叠: {sorted(overlap)}")
    missing = [
        group
        for group in list(a.lab_prior_groups) + list(a.lab_similarity_groups)
        if group not in cfg.lab_groups
    ]
    if missing:
        raise ValueError(f"lab_groups 中缺少配置组: {missing}")
    distances = [int(value) for value in a.plane_fit_distances_cm]
    if distances != [20, 25, 30, 35, 40]:
        raise ValueError("plane_fit_distances_cm 必须严格为 [20,25,30,35,40]")
    if float(a.point_huber_delta) <= 0:
        raise ValueError("point_huber_delta 必须>0")
    if not 0.0 <= float(a.prior_supplement_bin_cap) <= 1.0:
        raise ValueError("prior_supplement_bin_cap 必须位于[0,1]")
    if float(a.prior_mix_max) < 0 or int(a.prior_mix_steps) < 2:
        raise ValueError("prior_mix_max 必须>=0，prior_mix_steps 必须>=2")


def load_config(path: Path) -> core.RunConfig:
    cfg = core.load_config(path)
    with path.open("r", encoding="utf-8-sig") as handle:
        raw = json.load(handle)
    _attach_fusion_config(cfg, raw.get("algorithm", {}))
    return cfg


def _frame_cosine(power: np.ndarray, reconstruction: np.ndarray) -> np.ndarray:
    p = core.l2_normalize_columns(np.maximum(np.asarray(power, dtype=float), 0.0))
    q = core.l2_normalize_columns(np.maximum(np.asarray(reconstruction, dtype=float), 0.0))
    return np.clip(np.sum(p * q, axis=0), 0.0, 1.0)


def _dictionary_projection(
    power: np.ndarray,
    dictionary: np.ndarray,
    cfg: core.AlgorithmConfig,
    seed: int,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    activation, reconstruction = core.infer_single_dictionary(
        np.maximum(power, 0.0),
        dictionary,
        cfg.lab_projection_iterations,
        cfg.lab_projection_l1_ratio,
        seed,
    )
    reconstruction = np.maximum(reconstruction, 0.0)
    return activation, reconstruction, _frame_cosine(power, reconstruction)


def prepare_lab_reference(cfg: core.RunConfig, output_dir: Path) -> Dict[str, Any]:
    """0.5 mm 只构建先验；0.1 mm 只保存为相似度参照。"""
    a = cfg.algorithm
    rng = np.random.default_rng(a.random_state)
    prior_groups = list(a.lab_prior_groups)
    similarity_groups = list(a.lab_similarity_groups)
    prior_files = sorted({
        path
        for group in prior_groups
        for path in core.discover_wavs(cfg.lab_groups.get(group, []))
    }, key=lambda path: str(path).casefold())
    similarity_files = sorted({
        path
        for group in similarity_groups
        for path in core.discover_wavs(cfg.lab_groups.get(group, []))
    }, key=lambda path: str(path).casefold())

    overlap = set(prior_files) & set(similarity_files)
    if overlap:
        examples = "; ".join(str(path) for path in sorted(overlap)[:3])
        raise RuntimeError(f"0.5 mm 先验文件与 0.1 mm 相似度文件发生重叠: {examples}")
    if not prior_files:
        raise RuntimeError("没有发现可用的 0.5 mm 先验 WAV")
    if not similarity_files:
        raise RuntimeError("没有发现可用的 0.1 mm 相似度参照 WAV")

    group_by_file: Dict[Path, str] = {}
    for group in prior_groups + similarity_groups:
        for path in core.discover_wavs(cfg.lab_groups.get(group, [])):
            group_by_file.setdefault(path, group)

    scan_rows: List[Dict[str, Any]] = []
    error_rows: List[Dict[str, Any]] = []
    prior_blocks: List[np.ndarray] = []
    prior_specs: List[Tuple[str, Path, np.ndarray]] = []
    similarity_specs: List[Tuple[str, Path, np.ndarray]] = []
    similarity_powers: List[Tuple[str, Path, np.ndarray]] = []
    freq_ref: Optional[np.ndarray] = None

    records = [(path, "PRIOR_0.5MM") for path in prior_files]
    records += [(path, "SIMILARITY_REFERENCE_0.1MM") for path in similarity_files]
    for path, role in records:
        group = group_by_file.get(path, "")
        try:
            fs, x, dtype_name, duration = core.read_lab_wav(path, a.max_lab_seconds_per_file)
            freq, _, z = core.stft_full(x, fs, a)
            freq_band, power, _ = core.power_band_from_stft(freq, z, a)
            if freq_ref is None:
                freq_ref = freq_band
            elif len(freq_ref) != len(freq_band) or np.max(np.abs(freq_ref - freq_band)) > 1e-6:
                raise ValueError("实验室 WAV 的采样率/STFT 频率轴不一致")
            spec = core.representative_spectrum(power)
            if role == "PRIOR_0.5MM":
                prior_blocks.append(power)
                prior_specs.append((group, path, spec))
            else:
                similarity_specs.append((group, path, spec))
                similarity_powers.append((group, path, power))
            scan_rows.append({
                "group": group,
                "role": role,
                "file": str(path),
                "status": "OK",
                "sample_rate_hz": fs,
                "duration_seconds": duration,
                "used_seconds": len(x) / fs,
                "n_frames": power.shape[1],
                "dtype": dtype_name,
                "error": "",
            })
        except Exception as exc:
            row = {
                "group": group,
                "role": role,
                "file": str(path),
                "status": "ERROR",
                "error": f"{type(exc).__name__}: {exc}",
            }
            scan_rows.append(row)
            error_rows.append(row)

    core.write_csv(output_dir / "00_lab_prior_similarity_scan.csv", scan_rows)
    core.write_csv(output_dir / "99_errors_lab.csv", error_rows)
    if not prior_blocks or freq_ref is None:
        raise RuntimeError("0.5 mm 先验 WAV 全部读取失败，请查看 00_lab_prior_similarity_scan.csv")
    if not similarity_specs:
        raise RuntimeError("0.1 mm 相似度参照 WAV 全部读取失败，请查看 00_lab_prior_similarity_scan.csv")

    prior_matrix = core.subsample_columns(
        np.concatenate(prior_blocks, axis=1),
        a.max_lab_prior_frames,
        rng,
    )
    dictionary = core.fit_dictionary(
        prior_matrix,
        a.leak_components,
        a.nmf_max_iter,
        a.random_state,
    )
    prior_prototype = core.normalize_vector(
        np.median(np.vstack([spec for _, _, spec in prior_specs]), axis=0)
    )
    similarity_prototype = core.normalize_vector(
        np.median(np.vstack([spec for _, _, spec in similarity_specs]), axis=0)
    )

    np.savez_compressed(
        output_dir / "02_frozen_0p5mm_prior_and_0p1mm_similarity_reference.npz",
        freq_hz=freq_ref,
        leak_dictionary=dictionary,
        prior_prototype_0p5mm=prior_prototype,
        similarity_prototype_0p1mm=similarity_prototype,
        prior_groups=np.asarray(prior_groups, dtype=str),
        similarity_groups=np.asarray(similarity_groups, dtype=str),
        data_semantics=np.asarray("NO_TRAIN_TEST_SPLIT"),
    )
    if a.save_plots:
        core.plot_dictionary(
            freq_ref,
            dictionary,
            "0.5 mm laboratory prior dictionary",
            output_dir / "02_frozen_0p5mm_prior_dictionary.png",
        )

    similarity_rows: List[Dict[str, Any]] = []
    for index, (group, path, power) in enumerate(similarity_powers):
        _, reconstruction, cosine = _dictionary_projection(
            power, dictionary, a, a.random_state + 1000 + index,
        )
        spec = core.representative_spectrum(power)
        row = {
            "group": group,
            "file": str(path),
            "role": "SIMILARITY_REFERENCE_0.1MM",
            "dictionary_frame_cosine_median": float(np.median(cosine)),
            "dictionary_relative_l1_error": float(
                np.sum(np.abs(power - reconstruction)) / (np.sum(power) + EPS)
            ),
            **core.spectrum_metrics(spec, similarity_prototype),
        }
        similarity_rows.append(row)
    core.write_csv(output_dir / "03_0p1mm_similarity_reference_report.csv", similarity_rows)

    role_summary = {
        "data_semantics": "NO_TRAIN_TEST_SPLIT",
        "prior_groups": prior_groups,
        "similarity_reference_groups": similarity_groups,
        "n_prior_files_ok": len(prior_specs),
        "n_similarity_reference_files_ok": len(similarity_specs),
        "important": "0.5mm构建先验；0.1mm只作为相似度计算依据；没有工厂训练集。",
    }
    core.write_json(output_dir / "04_lab_role_summary.json", role_summary)
    return {
        "freq_hz": freq_ref,
        "ws": dictionary,
        "lab_proto": similarity_prototype,
        "prior_proto": prior_prototype,
        "prior_specs": prior_specs,
        "similarity_specs": similarity_specs,
        # 兼容底层汇总字段，但内容明确是 0.1 mm 相似度参照，不是验证集。
        "validation_specs": similarity_specs,
        "validation_mode": "NO_SPLIT_0.5MM_PRIOR_0.1MM_SIMILARITY_REFERENCE",
        "split_summary": role_summary,
    }


def _robust_point_weights(y_db: np.ndarray, delta: float) -> np.ndarray:
    median_bin = np.median(y_db, axis=0, keepdims=True)
    point_bias = np.median(y_db - median_bin, axis=1)
    point_deviation = np.median(np.abs(y_db - median_bin), axis=1)
    score = np.maximum(point_bias, 0.0) + 0.5 * point_deviation
    center = float(np.median(score))
    mad = float(np.median(np.abs(score - center)))
    scale = max(1.4826 * mad, 0.25)
    u = np.abs(score - center) / max(delta * scale, 1e-12)
    weights = np.ones_like(u)
    mask = u > 1.0
    weights[mask] = 1.0 / u[mask]
    return np.clip(weights, 0.05, 1.0)


def _center_inside_hull(xy: np.ndarray) -> bool:
    if len(xy) < 3:
        return False
    try:
        return bool(Delaunay(xy).find_simplex(np.asarray([[0.0, 0.0]]))[0] >= 0)
    except QhullError:
        return False


def build_fixed_ring_plane_prediction(
    center_power: np.ndarray,
    point_cache: Sequence[Tuple[core.SpatialFile, np.ndarray]],
    cfg: core.AlgorithmConfig,
) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    """使用20/25/30/35/40 cm五圈共40点拟合中心环境噪声。"""
    selected_distances = {int(value) for value in cfg.plane_fit_distances_cm}
    candidates = [
        (point, power)
        for point, power in point_cache
        if cfg.spatial_min_distance_cm <= point.distance_cm <= cfg.spatial_max_distance_cm
    ]
    selected = [
        (point, power) for point, power in candidates
        if int(point.distance_cm) in selected_distances
    ]
    expected_count = len(selected_distances) * len(core.DIRECTIONS)
    selected_keys = {(int(point.distance_cm), point.direction) for point, _ in selected}
    expected_keys = {
        (distance, direction)
        for distance in selected_distances
        for direction in core.DIRECTIONS
    }
    missing_keys = sorted(expected_keys - selected_keys)
    if len(selected) != expected_count or missing_keys:
        missing_text = ";".join(f"{distance}cm_{direction}" for distance, direction in missing_keys[:8])
        raise RuntimeError(
            "20-40cm固定环带拟合必须具备5圈×8方向=40点；"
            f"当前匹配{len(selected)}点，缺失示例: {missing_text or '存在重复点'}"
        )
    candidates.sort(key=lambda item: (item[0].distance_cm, core.DIRECTIONS.index(item[0].direction)))
    selected.sort(key=lambda item: (item[0].distance_cm, core.DIRECTIONS.index(item[0].direction)))

    selected_power = np.stack([power for _, power in selected], axis=0)
    selected_db = 10.0 * np.log10(np.maximum(selected_power, EPS))
    n_points, n_freq, n_frames = selected_db.shape
    y = selected_db.reshape(n_points, -1)
    median_flat = np.median(y, axis=0)
    median_mae = float(np.median(np.abs(y - median_flat[None, :])))

    xy = np.asarray([[point.x_cm, point.y_cm] for point, _ in selected], dtype=float)
    max_radius = max(float(np.max(np.linalg.norm(xy, axis=1))), 1.0)
    xy_scaled = xy / max_radius
    design = np.column_stack([np.ones(n_points), xy_scaled[:, 0], xy_scaled[:, 1]])
    weights = _robust_point_weights(y, float(cfg.point_huber_delta))
    lhs = design.T @ (weights[:, None] * design)
    condition = float(np.linalg.cond(lhs))
    rank_ok = bool(np.linalg.matrix_rank(design) >= 3)
    inside_hull = _center_inside_hull(xy)
    geometry_ok = bool(
        rank_ok
        and inside_hull
        and np.isfinite(condition)
        and condition <= float(cfg.max_geometry_condition)
    )

    ridge = max(float(np.trace(lhs)) / 3.0, 1.0) * float(cfg.plane_ridge_ratio)
    solver = "ridge_solve"
    try:
        beta = np.linalg.solve(lhs + ridge * np.eye(3), design.T @ (weights[:, None] * y))
    except np.linalg.LinAlgError:
        solver = "ridge_pinv"
        beta = np.linalg.pinv(lhs + ridge * np.eye(3), rcond=1e-12) @ (
            design.T @ (weights[:, None] * y)
        )
    plane_flat = beta[0]
    fitted_flat = design @ beta
    plane_mae = float(np.median(np.abs(y - fitted_flat)))
    plane_flat = np.clip(
        plane_flat,
        median_flat - float(cfg.plane_clip_margin_db),
        median_flat + float(cfg.plane_clip_margin_db),
    )
    plane_valid = bool(np.all(np.isfinite(plane_flat)))
    use_plane = bool(plane_valid and geometry_ok)
    background_db = (plane_flat if use_plane else median_flat).reshape(n_freq, n_frames)
    background_power = np.power(10.0, np.clip(background_db, -300.0, 300.0) / 10.0)

    center_db = 10.0 * np.log10(np.maximum(center_power, EPS))
    center_excess_db = center_db - background_db
    spatial_residual = np.maximum(center_power - background_power, 0.0)
    fitted_residual = (y - fitted_flat).reshape(n_points, n_freq, n_frames)
    uncertainty_db = 1.4826 * np.median(np.abs(fitted_residual), axis=0)

    selector = np.asarray([1.0, 0.0, 0.0])
    influence = selector @ np.linalg.pinv(lhs + ridge * np.eye(3), rcond=1e-12) @ design.T @ np.diag(weights)
    influence_abs = np.abs(influence)
    influence_abs /= max(float(np.sum(influence_abs)), EPS)
    normalized_weights = weights / max(float(np.sum(weights)), EPS)

    point_rows: List[Dict[str, Any]] = []
    selected_lookup = {
        (point.distance_cm, point.direction, str(point.path)): index
        for index, (point, _) in enumerate(selected)
    }
    for point, _ in candidates:
        key = (point.distance_cm, point.direction, str(point.path))
        index = selected_lookup.get(key)
        if index is not None:
            role = "USED_FIXED_RING_20_TO_40_CM"
        elif point.distance_cm < min(selected_distances):
            role = "NOT_USED_NEARER_THAN_20_CM"
        elif point.distance_cm > max(selected_distances):
            role = "NOT_USED_FARTHER_THAN_40_CM"
        else:
            role = "NOT_USED_NON_CONFIGURED_DISTANCE"
        point_rows.append({
            "distance_cm": point.distance_cm,
            "direction": point.direction,
            "x_cm": point.x_cm,
            "y_cm": point.y_cm,
            "file": str(point.path),
            "point_role": role,
            "robust_weight": float(weights[index]) if index is not None else 0.0,
            "robust_weight_normalized": float(normalized_weights[index]) if index is not None else 0.0,
            "plane_influence_signed": float(influence[index]) if index is not None else 0.0,
            "plane_influence_absolute_normalized": float(influence_abs[index]) if index is not None else 0.0,
        })

    return {
        "background_power": background_power,
        "background_db": background_db,
        "local_excess_power": spatial_residual,
        "spatial_local_power": spatial_residual,
        "center_excess_db": center_excess_db,
        "prediction_uncertainty_db": uncertainty_db,
        "plane_valid": int(plane_valid),
        "plane_used": int(use_plane),
        "geometry_ok": int(geometry_ok),
        "center_inside_hull": int(inside_hull),
        "fit_condition_number": condition,
        "fit_median_mae_db": median_mae,
        "fit_plane_mae_db": plane_mae,
        "fit_plane_improvement_db": median_mae - plane_mae,
        "plane_solver": solver,
        "n_ring_points": len(selected),
        "ring_distances_cm": np.asarray(sorted(selected_distances), dtype=int),
        "selected_points": selected,
        "point_weights": weights,
        "plane_influence": influence,
    }, point_rows


# 旧名称仅供v1内部兼容；v2.1正式调用固定20-40cm环带函数。
build_outer40_plane_prediction = build_fixed_ring_plane_prediction


def build_prior_supplement_candidate(
    center_power: np.ndarray,
    background_power: np.ndarray,
    dictionary: np.ndarray,
    cfg: core.AlgorithmConfig,
    seed: int,
) -> Dict[str, np.ndarray]:
    activation, prior_power, center_cosine = _dictionary_projection(
        center_power, dictionary, cfg, seed,
    )
    _, background_prior, background_cosine = _dictionary_projection(
        background_power, dictionary, cfg, seed + 1,
    )
    frame_gate = core.sigmoid(
        (center_cosine - float(cfg.prior_frame_cosine_midpoint))
        / max(float(cfg.prior_frame_cosine_softness), 1e-6)
    )
    contrast_gate = core.sigmoid(
        (center_cosine - background_cosine - float(cfg.prior_contrast_midpoint))
        / max(float(cfg.prior_contrast_softness), 1e-6)
    )
    prior_share = np.clip(prior_power / np.maximum(center_power, EPS), 0.0, 1.0)
    prior_share = np.power(prior_share, max(float(cfg.prior_share_exponent), 1e-6))
    # 只有被空间背景吸收的部分才允许补回，避免重复叠加已保留的空间正残差。
    spatially_absorbed = np.minimum(center_power, background_power)
    candidate = spatially_absorbed * prior_share * frame_gate[None, :] * contrast_gate[None, :]
    candidate = np.minimum(
        candidate,
        float(cfg.prior_supplement_bin_cap) * np.maximum(center_power, 0.0),
    )
    return {
        "candidate_power": np.maximum(candidate, 0.0),
        "prior_power": prior_power,
        "background_prior_power": background_prior,
        "activation": activation,
        "center_frame_cosine": center_cosine,
        "background_frame_cosine": background_cosine,
        "frame_gate": frame_gate,
        "contrast_gate": contrast_gate,
        "prior_share": prior_share,
    }


def _finalize_power(
    center_power: np.ndarray,
    spatial_residual: np.ndarray,
    supplement: np.ndarray,
    cfg: core.AlgorithmConfig,
) -> Tuple[np.ndarray, np.ndarray]:
    preliminary = np.minimum(spatial_residual + supplement, center_power)
    mask = np.sqrt(preliminary / np.maximum(center_power, EPS))
    mask = core.smooth_amplitude_mask(mask, cfg)
    smoothed = np.minimum(mask * mask * center_power, center_power)
    # 平滑不得再次剪掉空间拟合已经保留的泄露残差。
    final_power = np.minimum(np.maximum(smoothed, spatial_residual), center_power)
    final_mask = np.sqrt(final_power / np.maximum(center_power, EPS))
    return final_power, final_mask


def select_sample_mix_by_similarity(
    center_power: np.ndarray,
    spatial_residual: np.ndarray,
    supplement_candidate: np.ndarray,
    similarity_specs: Sequence[Tuple[str, Path, np.ndarray]],
    cfg: core.AlgorithmConfig,
) -> Dict[str, Any]:
    """逐样本用 0.1 mm 相似度选择补偿系数；alpha=0 保证不会劣于空间基线。"""
    alphas = np.linspace(0.0, float(cfg.prior_mix_max), int(cfg.prior_mix_steps))
    rows: List[Dict[str, float]] = []
    best: Optional[Tuple[float, float, np.ndarray, np.ndarray]] = None
    for alpha in alphas:
        power, mask = _finalize_power(
            center_power,
            spatial_residual,
            float(alpha) * supplement_candidate,
            cfg,
        )
        metrics = core.evaluate_against_lab(core.representative_spectrum(power), similarity_specs)
        similarity = float(metrics["lab_similarity_combined_median"])
        if not np.isfinite(similarity):
            similarity = -np.inf
        rows.append({"prior_mix_alpha": float(alpha), "similarity_0p1mm": similarity})
        if best is None or similarity > best[0] + 1e-12:
            best = (similarity, float(alpha), power, mask)
    if best is None:
        raise RuntimeError("无法计算 0.1 mm 相似度，不能选择先验补偿系数")
    baseline = rows[0]["similarity_0p1mm"]
    return {
        "similarity": best[0],
        "alpha": best[1],
        "final_power": best[2],
        "amplitude_mask": best[3],
        "baseline_similarity": baseline,
        "similarity_gain": best[0] - baseline,
        "grid_rows": rows,
    }


def _plot_fusion_diagnostics(
    freq: np.ndarray,
    time_s: np.ndarray,
    spatial_residual: np.ndarray,
    supplement: np.ndarray,
    final_power: np.ndarray,
    uncertainty_db: np.ndarray,
    title: str,
    path: Path,
) -> None:
    fig, axes = plt.subplots(4, 1, figsize=(12, 12), sharex=True)
    matrices = [spatial_residual, supplement, final_power, uncertainty_db]
    labels = [
        "Spatial-only residual power (dB)",
        "Selected prior supplement power (dB)",
        "Fused leak power (dB)",
        "Plane prediction uncertainty (dB)",
    ]
    for index, (axis, matrix, label) in enumerate(zip(axes, matrices, labels)):
        shown = 10.0 * np.log10(np.maximum(matrix, EPS)) if index < 3 else matrix
        image = axis.pcolormesh(time_s, freq / 1000.0, shown, shading="auto")
        axis.set_ylabel("kHz")
        axis.set_title(label)
        fig.colorbar(image, ax=axis)
    axes[-1].set_xlabel("Time (s)")
    fig.suptitle(title)
    fig.tight_layout()
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)


def process_factory_sample(
    dataset: core.FactoryDataset,
    time_folder: str,
    center_id: str,
    center_path: Path,
    spatial_files: Sequence[core.SpatialFile],
    lab: Dict[str, Any],
    cfg: core.RunConfig,
    sample_dir: Path,
    seed: int,
) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[Dict[str, Any]]]:
    a = cfg.algorithm
    core.ensure_dir(sample_dir)
    center_slice = core.read_wav_slice(center_path, center_id, a)
    neighbor_slices: List[Tuple[core.SpatialFile, core.WavSlice]] = []
    errors: List[Dict[str, Any]] = []
    for point in spatial_files:
        try:
            item = core.read_wav_slice(point.path, center_id, a)
            if item.fs != center_slice.fs or len(item.x) != len(center_slice.x):
                raise ValueError("邻点与中心点的采样率或片段长度不一致")
            neighbor_slices.append((point, item))
        except Exception as exc:
            errors.append({
                "dataset": dataset.name,
                "time_folder": time_folder,
                "center_id": center_id,
                "file": str(point.path),
                "stage": "read_neighbor",
                "error": f"{type(exc).__name__}: {exc}",
            })
    if len(neighbor_slices) < a.min_neighbors:
        raise RuntimeError(f"有效邻点不足: {len(neighbor_slices)} < {a.min_neighbors}")

    amplitude_info = core.amplitude_diagnostics(
        [center_slice] + [item for _, item in neighbor_slices], a
    )
    freq_full, time_stft, z_center = core.stft_full(center_slice.x, center_slice.fs, a)
    freq_band, center_power, band_mask = core.power_band_from_stft(freq_full, z_center, a)
    if len(freq_band) != len(lab["freq_hz"]) or np.max(np.abs(freq_band - lab["freq_hz"])) > 1e-6:
        raise ValueError("工厂样本与实验室参照的频率轴不一致")

    point_cache: List[Tuple[core.SpatialFile, np.ndarray]] = []
    for point, item in neighbor_slices:
        freq, _, z = core.stft_full(item.x, item.fs, a)
        neighbor_freq, power, _ = core.power_band_from_stft(freq, z, a)
        if len(neighbor_freq) != len(freq_band) or np.max(np.abs(neighbor_freq - freq_band)) > 1e-6:
            raise ValueError(f"邻点频率轴不一致: {point.path.name}")
        point_cache.append((point, power))

    spatial, point_rows = build_outer40_plane_prediction(center_power, point_cache, a)
    prior = build_prior_supplement_candidate(
        center_power, spatial["background_power"], lab["ws"], a, seed + 100,
    )
    selection = select_sample_mix_by_similarity(
        center_power,
        spatial["local_excess_power"],
        prior["candidate_power"],
        lab["similarity_specs"],
        a,
    )
    final_power = selection["final_power"]
    amplitude_mask = selection["amplitude_mask"]
    selected_supplement = np.maximum(final_power - spatial["local_excess_power"], 0.0)
    remaining_power = np.maximum(center_power - final_power, 0.0)

    z_leak = np.zeros_like(z_center)
    z_leak[band_mask] = amplitude_mask * z_center[band_mask]
    z_remaining = z_center - z_leak
    leak_wav = core.reconstruct_wav(z_leak, center_slice.fs, a, len(center_slice.x))
    remaining_wav = core.reconstruct_wav(z_remaining, center_slice.fs, a, len(center_slice.x))
    if a.save_wavs:
        wavfile.write(str(sample_dir / "estimated_fused_leak.wav"), center_slice.fs, leak_wav.astype(np.float32))
        wavfile.write(str(sample_dir / "estimated_environment_remaining.wav"), center_slice.fs, remaining_wav.astype(np.float32))
        wavfile.write(str(sample_dir / "raw_center_slice.wav"), center_slice.fs, center_slice.x.astype(np.float32))

    raw_spec = core.representative_spectrum(center_power)
    background_spec = core.representative_spectrum(spatial["background_power"])
    spatial_spec = core.representative_spectrum(spatial["local_excess_power"])
    supplement_spec = core.representative_spectrum(selected_supplement)
    final_spec = core.representative_spectrum(final_power)
    remaining_spec = core.representative_spectrum(remaining_power)
    reference_specs = lab["similarity_specs"]
    raw_similarity = core.evaluate_against_lab(raw_spec, reference_specs)
    spatial_similarity = core.evaluate_against_lab(spatial_spec, reference_specs)
    supplement_similarity = core.evaluate_against_lab(supplement_spec, reference_specs)
    final_similarity = core.evaluate_against_lab(final_spec, reference_specs)
    remaining_similarity = core.evaluate_against_lab(remaining_spec, reference_specs)

    total = float(np.sum(center_power)) + EPS
    spatial_fraction = float(np.sum(spatial["local_excess_power"]) / total)
    supplement_fraction = float(np.sum(selected_supplement) / total)
    final_fraction = float(np.sum(final_power) / total)
    uncertainty_weighted = core.weighted_mean(spatial["prediction_uncertainty_db"], center_power)
    plane_confidence = float(
        (0.25 + 0.75 * spatial["plane_used"])
        * math.exp(-uncertainty_weighted / max(a.prediction_uncertainty_ref_db, 1e-6))
    )
    frame_gate_weighted = core.weighted_mean(prior["frame_gate"][None, :], center_power)
    similarity_for_score = float(final_similarity["lab_similarity_combined_median"])
    source_score = float(
        math.sqrt(max(final_fraction, 0.0) * max(frame_gate_weighted, 0.0))
        * max(similarity_for_score, 0.0)
        * max(plane_confidence, 0.0)
    )
    evidence_flag = (
        "STRONG_LOCAL_SOURCE_EVIDENCE"
        if source_score >= a.evidence_score_threshold
        and similarity_for_score >= a.evidence_lab_similarity_threshold
        else "WEAK_LOCAL_SOURCE_EVIDENCE"
    )

    excess_median, excess_weighted = core.robust_positive_summary(
        spatial["center_excess_db"], spatial["local_excess_power"]
    )
    label = core.sample_label(dataset, time_folder)
    leak_type, condition_name = core.infer_leak_type_and_condition(time_folder)
    normalized_folder = core.normalize_relative_folder(time_folder)
    canonical = core.canonical_condition(normalized_folder, cfg.pairing_remove_tokens)
    pair_key = f"{canonical}::{center_id}"
    summary: Dict[str, Any] = {
        "method": "OUTER40_ROBUST_PLANE_PLUS_0P5MM_PRIOR_0P1MM_SIMILARITY",
        "data_semantics": "NO_TRAIN_TEST_SPLIT",
        "dataset": dataset.name,
        "leak_type": leak_type,
        "condition_name": condition_name,
        "time_folder": normalized_folder,
        "condition_relative_path": normalized_folder,
        "canonical_condition": canonical,
        "pair_key": pair_key,
        "center_id": center_id,
        "label": label,
        "center_file": str(center_path),
        "segment_start_seconds": center_slice.segment_start_seconds,
        "segment_end_seconds": center_slice.segment_end_seconds,
        "sample_rate_hz": center_slice.fs,
        "n_neighbors_used": len(neighbor_slices),
        "n_outer40_points": spatial["n_outer_points"],
        "n_inner_points_excluded": spatial["n_inner_excluded"],
        "n_complete_opposite_pairs": 0,
        "n_complete_axes": 0,
        "main_freq_low_hz": a.freq_low_hz,
        "main_freq_high_hz": a.freq_high_hz,
        "plane_valid": spatial["plane_valid"],
        "plane_used": spatial["plane_used"],
        "plane_geometry_ok": spatial["geometry_ok"],
        "plane_center_inside_hull": spatial["center_inside_hull"],
        "plane_solver": spatial["plane_solver"],
        "plane_condition_number": spatial["fit_condition_number"],
        "plane_median_mae_db": spatial["fit_median_mae_db"],
        "plane_fit_mae_db": spatial["fit_plane_mae_db"],
        "plane_fit_improvement_db": spatial["fit_plane_improvement_db"],
        "center_local_excess_power_fraction": spatial_fraction,
        "center_spatial_filtered_power_fraction": spatial_fraction,
        "center_prior_supplement_power_fraction": supplement_fraction,
        "center_final_leak_power_fraction": final_fraction,
        "prior_mix_alpha_per_sample": selection["alpha"],
        "prior_similarity_gain_over_spatial": selection["similarity_gain"],
        "center_excess_db_positive_median": excess_median,
        "center_excess_db_power_weighted_mean": excess_weighted,
        "background_prediction_uncertainty_db_power_weighted": uncertainty_weighted,
        "background_prediction_confidence_power_weighted": plane_confidence,
        # 兼容原汇总列；本方法中含义是平面置信度，不是相反方向支持率。
        "opposite_pair_support_ratio_power_weighted": plane_confidence,
        "opposite_axis_support_ratio_power_weighted": plane_confidence,
        "lab_atom_cosine_frame_median": float(np.median(prior["center_frame_cosine"])),
        "lab_frame_gate_power_weighted": frame_gate_weighted,
        "source_center_score": source_score,
        "spatial_evidence_flag": evidence_flag,
        "lab_validation_mode": lab["validation_mode"],
        **amplitude_info,
        **{f"raw_{key}": value for key, value in raw_similarity.items()},
        **{f"local_excess_{key}": value for key, value in spatial_similarity.items()},
        **{f"spatial_local_{key}": value for key, value in spatial_similarity.items()},
        **{f"prior_supplement_{key}": value for key, value in supplement_similarity.items()},
        **{f"leak_{key}": value for key, value in final_similarity.items()},
        **{f"remaining_{key}": value for key, value in remaining_similarity.items()},
    }
    summary["leak_similarity_gain_over_raw"] = float(
        summary["leak_lab_similarity_combined_median"]
        - summary["raw_lab_similarity_combined_median"]
    )
    summary["leak_vs_remaining_similarity_gap"] = float(
        summary["leak_lab_similarity_combined_median"]
        - summary["remaining_lab_similarity_combined_median"]
    )

    enriched_rows = [{
        "dataset": dataset.name,
        "leak_type": leak_type,
        "condition_name": condition_name,
        "time_folder": normalized_folder,
        "condition_relative_path": normalized_folder,
        "canonical_condition": canonical,
        "pair_key": pair_key,
        "center_id": center_id,
        "label": label,
        **row,
    } for row in point_rows]

    core.write_json(sample_dir / "summary.json", summary)
    core.write_csv(sample_dir / "outer40_plane_point_diagnostics.csv", enriched_rows)
    core.write_csv(sample_dir / "prior_mix_similarity_grid.csv", selection["grid_rows"])
    if a.save_npz:
        payload = dict(
            freq_hz=freq_band,
            time_s=time_stft,
            raw_center_power=center_power,
            spatial_predicted_background_power=spatial["background_power"],
            spatial_only_residual_power=spatial["local_excess_power"],
            prior_supplement_candidate_power=prior["candidate_power"],
            selected_prior_supplement_power=selected_supplement,
            final_fused_leak_power=final_power,
            remaining_power=remaining_power,
            amplitude_mask=amplitude_mask,
            center_excess_db=spatial["center_excess_db"],
            prediction_uncertainty_db=spatial["prediction_uncertainty_db"],
            leak_dictionary_0p5mm=lab["ws"],
            prior_activation=prior["activation"],
            prior_mix_alpha=np.asarray(selection["alpha"]),
            similarity_gain_0p1mm=np.asarray(selection["similarity_gain"]),
        )
        np.savez_compressed(sample_dir / "spatial_prior_fusion_result.npz", **payload)
        # 兼容旧流程寻找的文件名。
        np.savez_compressed(sample_dir / "spatial_local_excess_result.npz", **payload)

    if a.save_plots:
        title = f"{dataset.name} | {time_folder} | {center_id}"
        core.plot_sample_spectra(
            freq_band,
            raw_spec,
            background_spec,
            final_spec,
            remaining_spec,
            lab["lab_proto"],
            title,
            sample_dir / "spectrum_comparison.png",
        )
        _plot_fusion_diagnostics(
            freq_band,
            time_stft,
            spatial["local_excess_power"],
            selected_supplement,
            final_power,
            spatial["prediction_uncertainty_db"],
            title,
            sample_dir / "fusion_diagnostics.png",
        )
        core.plot_power_triplet(
            freq_band,
            time_stft,
            center_power,
            spatial["background_power"],
            final_power,
            title,
            sample_dir / "power_spectrograms.png",
        )
    return summary, enriched_rows, errors


def write_read_me_first(output_dir: Path, cfg: core.RunConfig, lab: Dict[str, Any]) -> None:
    text = f"""空间拟合降噪 + 实验室先验补偿 v1
====================================

数据口径：没有训练集/测试集划分。
- 0.5 mm：构建固定泄露先验字典。
- 0.1 mm：相似度计算依据。
- 工厂数据：全部直接逐样本处理；标签（若有）只用于事后汇总。
- 中心点严格只处理 00_00、00_01；其他中心编号及对应偏移点不建立索引。

逐样本流程：
1. 排除最近 {cfg.algorithm.inner_excluded_points} 点，使用最外圈 {cfg.algorithm.outer_background_points} 点。
2. 在对数功率域由该样本独立学习鲁棒点权重与平面系数，预测中心环境噪声。
3. 空间正残差 = max(中心功率 - 预测背景, 0)。
4. 用 0.5 mm 先验从被背景吸收的功率中产生补偿候选。
5. 在该样本内搜索补偿系数，使输出对 0.1 mm 参照的中位综合相似度最大。
   搜索包含 alpha=0，因此该相似度指标理论上不会低于空间拟合基线。

主结果：10_factory_sample_summary.csv
单样本完整矩阵：samples/.../spatial_prior_fusion_result.npz
单样本补偿搜索：samples/.../prior_mix_similarity_grid.csv
空间点权重：samples/.../outer40_plane_point_diagnostics.csv

注意：相似度不等于真实泄露率；是否优于旧方法仍应结合真实标注、AUC和现场复核判断。
"""
    (output_dir / "00_READ_ME_FIRST.txt").write_text(text, encoding="utf-8")


def run_analysis(cfg: core.RunConfig) -> Dict[str, Path]:
    # 复用原程序成熟的目录扫描、WAV 切片、汇总与评估框架，只替换核心方法。
    core.prepare_lab_reference = prepare_lab_reference
    core.process_factory_sample = process_factory_sample
    core.write_read_me_first = write_read_me_first
    core.build_center_index = build_allowed_center_index
    core.build_offset_index = build_allowed_offset_index
    core.directory_has_center_wav = directory_has_allowed_center_wav
    paths = core.run_analysis(cfg)

    output_dir = Path(cfg.output_dir)
    old_diag = output_dir / "11_opposite_pair_diagnostics.csv"
    new_diag = output_dir / "11_outer40_plane_point_diagnostics.csv"
    if old_diag.exists():
        new_diag.write_bytes(old_diag.read_bytes())
        paths["plane_points"] = new_diag

    run_info_path = output_dir / "00_run_info.json"
    if run_info_path.exists():
        run_info = json.loads(run_info_path.read_text(encoding="utf-8"))
    else:
        run_info = {}
    run_info.update({
        "program_version": "spatial-prior-fusion-v1.1-center00-only",
        "method": "outer40 robust plane + 0.5mm prior supplement + 0.1mm similarity",
        "data_semantics": "NO_TRAIN_TEST_SPLIT",
        "sample_specific_spatial_learning": True,
        "processed_center_ids": list(ALLOWED_CENTER_IDS),
        "center_filter_policy": "STRICT_WHITELIST_BEFORE_CENTER_AND_OFFSET_INDEXING",
        "fusion_parameters": {
            key: getattr(cfg.algorithm, key) for key in FUSION_DEFAULTS
        },
    })
    algorithm_info = run_info.get("config", {}).get("algorithm", {})
    for legacy_key in (
        "lab_split_mode",
        "lab_train_groups",
        "lab_validation_groups",
        "lab_train_fraction",
        "max_lab_training_frames",
    ):
        algorithm_info.pop(legacy_key, None)
    algorithm_info["max_lab_prior_frames"] = int(cfg.algorithm.max_lab_prior_frames)
    core.write_json(run_info_path, run_info)
    return paths


def run_self_test() -> None:
    print("开始融合方法 SELF-TEST...")
    rng = np.random.default_rng(1234)
    fs = 192_000
    seconds = 0.35
    with tempfile.TemporaryDirectory(prefix="spatial_prior_fusion_test_") as temp_dir:
        root = Path(temp_dir)
        lab01 = core.ensure_dir(root / "lab" / "0.1mm")
        lab05 = core.ensure_dir(root / "lab" / "0.5mm")
        for folder, shift in ((lab05, 1.4), (lab01, 0.0)):
            for index in range(4):
                signal_data = core.synth_leak(fs, seconds, rng, shift + 0.1 * index)
                wavfile.write(str(folder / f"lab_{index}.wav"), fs, signal_data.astype(np.float32))

        leak = core.synth_leak(fs, seconds, rng, 0.25)
        t_center, t_near, t_far = core.write_synthetic_factory(root, "T", fs, seconds, rng, leak)
        f_center, f_near, f_far = core.write_synthetic_factory(root, "F", fs, seconds, rng, leak)
        # 为每个数据集加入允许的 00_01 和必须被忽略的 00_02。
        for center_root, near_root, far_root, folder in (
            (t_center, t_near, t_far, "condition"),
            (f_center, f_near, f_far, "condition_null"),
        ):
            center_folder = center_root / folder
            offset_folders = [near_root / folder, far_root / folder]
            source_center = center_folder / "synthetic_00_00_beamform_result.wav"
            for target_id in ("00_01", "00_02"):
                shutil.copyfile(
                    source_center,
                    center_folder / f"synthetic_{target_id}_beamform_result.wav",
                )
                for offset_folder in offset_folders:
                    for source in list(offset_folder.glob("synthetic_00_00d*.wav")):
                        shutil.copyfile(
                            source,
                            offset_folder / source.name.replace("00_00d", f"{target_id}d", 1),
                        )
        cfg = core.RunConfig(
            lab_groups={"0.1mm": [str(lab01)], "0.5mm": [str(lab05)]},
            factory_datasets=[
                core.FactoryDataset("synthetic_T", str(t_center), [str(t_near), str(t_far)], ["condition"], "T", {}),
                core.FactoryDataset("synthetic_F", str(f_center), [str(f_near), str(f_far)], ["condition_null"], "F", {}),
            ],
            output_dir=str(root / "out"),
            pairing_remove_tokens=["_null", "null"],
            algorithm=core.AlgorithmConfig(
                time_slice_seconds=seconds,
                segment_mode="first",
                nperseg=1024,
                hop_length=512,
                nfft=2048,
                minimum_frequency_bins=20,
                leak_components=4,
                max_lab_training_frames=3000,
                nmf_max_iter=100,
                lab_projection_iterations=60,
                min_neighbors=100,
                save_plots=False,
                save_wavs=True,
                save_npz=True,
                plot_limit=0,
            ),
        )
        _attach_fusion_config(cfg, {"max_lab_prior_frames": 3000})
        paths = run_analysis(cfg)
        summary = pd.read_csv(paths["summary"])
        if len(summary) != 4:
            raise AssertionError(f"期望 2 个数据集各处理 00_00/00_01，共 4 个样本；实际 {len(summary)}")
        if set(summary["center_id"].astype(str)) != set(ALLOWED_CENTER_IDS):
            raise AssertionError(f"中心点白名单失效: {sorted(summary['center_id'].astype(str).unique())}")
        if "00_02" in set(summary["center_id"].astype(str)):
            raise AssertionError("00_02 不得参与处理")
        if not np.all(summary["prior_similarity_gain_over_spatial"].to_numpy(float) >= -1e-12):
            raise AssertionError("逐样本 alpha 搜索不应降低 0.1 mm 相似度")
        if not np.all(summary["n_outer40_points"].to_numpy(int) == 40):
            raise AssertionError("空间拟合必须使用 outer40")
        if not np.all(summary["data_semantics"] == "NO_TRAIN_TEST_SPLIT"):
            raise AssertionError("数据口径字段错误")
        for sample_dir in (root / "out" / "samples").glob("**/center_*"):
            if not sample_dir.is_dir():
                continue
            with np.load(sample_dir / "spatial_prior_fusion_result.npz") as result:
                if np.any(result["final_fused_leak_power"] + 1e-14 < result["spatial_only_residual_power"]):
                    raise AssertionError("融合输出不得剪掉空间正残差")
    print("SELF-TEST PASSED")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="空间拟合降噪 + 0.5mm实验室先验补偿；0.1mm用于相似度计算；无训练集"
    )
    parser.add_argument("--config", type=str, default="spatial_prior_fusion_config.json")
    parser.add_argument("--self-test", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if args.self_test:
        run_self_test()
        return
    cfg = load_config(Path(args.config))
    run_analysis(cfg)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n用户中止。")
        sys.exit(130)
    except Exception as exc:
        print(f"\n程序失败: {type(exc).__name__}: {exc}")
        traceback.print_exc()
        sys.exit(1)
