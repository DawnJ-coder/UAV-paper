v22：E/F/G真实TRUE/FALSE，RAW与PLANE公平验证，并与消声室0.1mm、0.5mm比较
================================================================================

一、这版程序回答三个问题
------------------------
1. RAW和PLANE谁更能区分E、F、G中的TRUE与FALSE？
2. 空间拟合后的剩余部分，距离消声室纯泄漏特征到底多远？
3. PLANE是只让TRUE更像消声室，还是把FALSE也一起拉近？

注意：
- 不再做人工泄漏注入。
- 不把PLANE残差直接叫作“纯泄漏”。
- 消声室距离和相似度不是泄漏概率，必须同时比较TRUE与FALSE。

二、三步处理流程
----------------
第1步：生成同一样本的两路结果
    RAW   = 中心点原始功率
    PLANE = 中心点功率 - 外圈40点空间平面背景，负数截为0

第2步：真实工厂跨场景分类
    E+F训练，G测试
    E+G训练，F测试
    F+G训练，E测试

第3步：与消声室比较
    参考1：0.1mm全部WAV
    参考2：0.5mm全部WAV
    参考3：0.1mm和0.5mm合并后的ALL_LEAKS

每个工厂样本的RAW和PLANE都计算：
- median_distance：100ms时间窗马氏距离中位数，越小越接近消声室；
- p90_distance：90%时间窗不超过的距离，越小越稳定地接近；
- median_distance_ratio：距离除以消声室内部99%参考距离，1附近表示接近参考边界；
- balanced_similarity：由中位距离和p90距离共同得到，0~1，越大越接近；
- cosine_similarity：频谱方向相似度；
- spectral_overlap：频带能量重叠度；
- pearson_similarity：频谱起伏形状相关；
- combined_similarity：后三种频谱相似度的综合值，0~1。

三、输入目录格式
----------------
沿用outer40程序格式：

中心点根目录：
    center_root_dir/
        某个time_folder/
            xxx_00_00_beamform_result.wav
            xxx_00_01_beamform_result.wav

周围点根目录：
    offset_root_dir/
        同名time_folder/
            xxx_00_00d5_up.wav
            ...
            xxx_00_00d40_up_right.wav

每个中心点应有64个周围点。程序排除最近24点，只用最外圈40点拟合。

消声室目录：
    0.1mm目录中可放多个子目录和多个WAV；
    0.5mm目录中也可放多个子目录和多个WAV；
    程序会递归读取全部.wav。

四、配置文件需要修改什么
------------------------
打开：
    v22_EFG_raw_plane_anechoic_config.json

1. 修改E/F/G六组工厂路径：
    factory_E_TRUE
    factory_E_FALSE
    factory_F_TRUE
    factory_F_FALSE
    factory_G_TRUE
    factory_G_FALSE

2. 修改消声室路径：
    anechoic_comparison.lab_groups.0.1mm
    anechoic_comparison.lab_groups.0.5mm

3. 修改三个输出路径：
    output_dir
    comparison.output_dir
    anechoic_comparison.output_dir

同一场景TRUE和FALSE必须使用相同scene：
    E都写factory_E
    F都写factory_F
    G都写factory_G

五、00_00、00_01到底取哪一秒
-----------------------------
默认：
    "segment_mode": "center_id"

含义：
    00_00读取第0~1秒
    00_01读取第1~2秒
    00_02读取第2~3秒

如果每个WAV文件本身只有约1秒，00_00、00_01只是不同文件，请改成：
    "segment_mode": "first"

此时每个WAV都读取自身第0~1秒。

六、运行方法
------------
第一次：
    1. 双击 install_requirements.bat
    2. 双击 run_v22_self_test.bat
    3. 出现“全部自检通过”后，修改配置路径
    4. 双击 run_v22_all.bat

也可以分三步运行：
    run_1_extract_RAW_PLANE.bat
    run_2_RAW_vs_PLANE_classification.bat
    run_3_RAW_PLANE_vs_anechoic.bat

如果第1步以前已经成功完成，后面修改消声室路径后，只运行第3步即可，不必重新空间拟合。

七、工厂分类结果看哪里
----------------------
打开：
    comparison.output_dir

先看：
    00_最先看这个.csv

它回答PLANE在EF→G、EG→F、FG→E中是：
    PLANE明显有效
    PLANE没有明显帮助
    PLANE跨场景不稳定
    PLANE破坏了真假泄漏特征

八、消声室距离和相似度看哪里
----------------------------
打开：
    anechoic_comparison.output_dir

1. 00_最先看这个.csv
   每个参考模型各一行，直接并排给出：
       raw_true_median_distance
       plane_true_median_distance
       raw_false_median_distance
       plane_false_median_distance
       raw_true_median_distance_ratio
       plane_true_median_distance_ratio
       raw_false_median_distance_ratio
       plane_false_median_distance_ratio
       raw_true_combined_similarity
       plane_true_combined_similarity
       raw_false_combined_similarity
       plane_false_combined_similarity
       final_conclusion

   建议先看ALL_LEAKS，再分别看0.1mm和0.5mm。

2. 01_每个样本_距离与相似度_long.csv
   每个E/F/G样本、RAW/PLANE、0.1mm/0.5mm/ALL_LEAKS的完整结果。

3. 02_每个场景_TRUE_FALSE分离.csv
   E、F、G分别统计TRUE和FALSE距离、相似度。

4. 03_RAW变PLANE后的场景变化.csv
   最关键的公平对照：PLANE有没有扩大TRUE与FALSE的差距。

5. 04_同一样本_RAW变PLANE后的变化.csv
   同一个样本从RAW变PLANE后，距离和相似度具体改变多少。

6. 05_每个特征与消声室差异.csv
   查看差异来自哪一项：平坦度、展宽、自适应SNR或时间波动。

7. 99_errors.csv
   必须先检查。正常情况下应为空。

九、怎样才算PLANE真的有效
-------------------------
只看TRUE距离变小不够。

合理结果应同时表现为：
1. TRUE的距离减小或相似度提高；
2. FALSE没有以同样程度一起变近；
3. FALSE距离 - TRUE距离变大；
4. TRUE相似度 - FALSE相似度变大；
5. E、F、G至少两个场景方向一致。

如果TRUE和FALSE都明显变近，结论是：
    PLANE让所有局部异常都更像消声室，不能证明它提取出了真泄漏。

十、关于马氏距离
----------------
程序使用5维特征：
    spectral_flatness
    spectral_spread_hz
    adaptive_snr_db
    flatness_local_std
    spread_local_std_hz

消声室只用于建立参考中心、标准差和协方差。
工厂TRUE/FALSE不会参与消声室模型拟合。

为了防止消声室文件过于相似、标准差接近0导致距离无意义地爆炸，程序为每项特征设置了很小的物理下限。
仍建议优先比较同一参考模型下RAW与PLANE的变化，以及TRUE与FALSE的相对差距，不要把不同模型的绝对距离直接硬比。

十一、依赖
----------
    numpy
    pandas
    scipy
    matplotlib
    scikit-learn
