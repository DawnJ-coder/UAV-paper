# -*- coding: utf-8 -*-
"""
v22_EFG_vs_anechoic_similarity.py

读取 v22 E/F/G RAW 与 PLANE 的 component_power NPZ，直接读取消声室 0.1mm、0.5mm WAV，
使用完全一致的频带与时间窗，计算：
1. 5维时窗特征马氏距离：median_distance、p90_distance、window_inside_fraction、balanced_similarity；
2. 频谱形状相似度：cosine、spectral_overlap、pearson、combined_similarity；
3. TRUE/FALSE 在 RAW 与 PLANE 下的分离差；
4. PLANE 是否只让 TRUE 更接近，还是把 FALSE 也一起拉近。

注意：距离与相似度用于描述，不单独作为泄漏概率或最终真假结论。
"""
from __future__ import annotations

import argparse
import json
import math
import tempfile
import traceback
import warnings
from dataclasses import asdict, dataclass, fields
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd

try:
    from scipy import signal
    from scipy.io import wavfile
except Exception as exc:
    raise RuntimeError("缺少 scipy，请先运行: pip install scipy") from exc

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
except Exception:
    plt = None

EPS = 1.0e-20
METHODS = ("raw", "plane")
MODEL_NAMES = ("0.1mm", "0.5mm", "ALL_LEAKS")
VALID_LABELS = {"FALSE_LEAK": 0, "TRUE_LEAK": 1}
FEATURE_NAMES = [
    "spectral_flatness",
    "spectral_spread_hz",
    "adaptive_snr_db",
    "flatness_local_std",
    "spread_local_std_hz",
]


@dataclass(frozen=True)
class CompareConfig:
    freq_low_hz: float = 20_000.0
    freq_high_hz: float = 80_000.0
    nperseg: int = 4096
    hop_length: int = 2048
    nfft: int = 4096
    window_ms: float = 100.0
    hop_ms: float = 50.0
    snr_floor_percentile: float = 10.0
    consistency_window_frames: int = 10
    minimum_windows_per_record: int = 3
    fingerprint_bin_hz: float = 1000.0
    covariance_shrinkage: float = 0.08
    covariance_ridge: float = 1.0e-6
    reference_inside_percentile: float = 99.0
    max_lab_seconds_per_file: Optional[float] = None
    max_windows_per_lab_file: int = 500
    require_plane_valid: bool = False
    require_plane_geometry_ok: bool = False
    save_window_details: bool = False
    save_plots: bool = True
    distance_gain_threshold: float = 0.15
    similarity_gain_threshold: float = 0.02


@dataclass
class PowerRecord:
    source_id: str
    file_path: str
    freq_hz: np.ndarray
    time_s: np.ndarray
    power: np.ndarray
    feature_matrix: np.ndarray
    feature_all: np.ndarray
    bands: np.ndarray
    probability: np.ndarray
    shape: np.ndarray


@dataclass
class ReferenceModel:
    model_name: str
    feature_names: List[str]
    raw_mean: np.ndarray
    raw_median: np.ndarray
    raw_std: np.ndarray
    standardized_center: np.ndarray
    inverse_covariance: np.ndarray
    window_distance_threshold: float
    reference_probability: np.ndarray
    reference_shape: np.ndarray
    lab_records: List[PowerRecord]

    def distances(self, matrix: np.ndarray) -> np.ndarray:
        x = np.asarray(matrix, dtype=float)
        if x.ndim != 2 or x.shape[1] != len(self.feature_names):
            raise ValueError(
                f"{self.model_name}待测矩阵应为(N,{len(self.feature_names)})，实际为{x.shape}"
            )
        z = (x - self.raw_mean) / np.maximum(self.raw_std, 1.0e-12)
        delta = z - self.standardized_center
        d2 = np.einsum("ij,jk,ik->i", delta, self.inverse_covariance, delta, optimize=True)
        return np.sqrt(np.maximum(d2, 0.0))

    def similarity_from_distance(self, distance: float | np.ndarray) -> np.ndarray:
        tau = max(float(self.window_distance_threshold), EPS)
        d = np.asarray(distance, dtype=float)
        return np.exp(-0.5 * np.square(d / tau))

    def file_statistics(self, matrix: np.ndarray) -> Tuple[Dict[str, float], np.ndarray]:
        distances = self.distances(matrix)
        if distances.size == 0:
            return {
                "n_windows": 0,
                "median_distance": np.nan,
                "p90_distance": np.nan,
                "mean_distance": np.nan,
                "std_distance": np.nan,
                "window_inside_fraction": 0.0,
                "median_similarity": 0.0,
                "p90_guard_similarity": 0.0,
                "balanced_similarity": 0.0,
            }, distances
        median_d = float(np.median(distances))
        p90_d = float(np.percentile(distances, 90.0))
        med_sim = float(self.similarity_from_distance(median_d))
        p90_sim = float(self.similarity_from_distance(p90_d))
        return {
            "n_windows": int(distances.size),
            "median_distance": median_d,
            "p90_distance": p90_d,
            "mean_distance": float(np.mean(distances)),
            "std_distance": float(np.std(distances)),
            "window_inside_fraction": float(np.mean(distances <= self.window_distance_threshold)),
            "median_similarity": med_sim,
            "p90_guard_similarity": p90_sim,
            "balanced_similarity": float(math.sqrt(max(med_sim * p90_sim, 0.0))),
            "median_distance_ratio": float(median_d / max(self.window_distance_threshold, EPS)),
            "p90_distance_ratio": float(p90_d / max(self.window_distance_threshold, EPS)),
        }, distances


def dataclass_from_dict(cls: Any, raw: Mapping[str, Any]) -> Any:
    allowed = {item.name for item in fields(cls)}
    unknown = sorted(set(raw) - allowed)
    if unknown:
        raise ValueError(f"anechoic_comparison中存在未知参数: {unknown}")
    return cls(**dict(raw))


def safe_slug(value: Any, max_len: int = 180) -> str:
    text = str(value).strip().replace("\\", "_").replace("/", "_")
    text = "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in text)
    return text[:max_len] or "unnamed"


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def pcm_to_float(data: np.ndarray) -> np.ndarray:
    x = np.asarray(data)
    if x.ndim == 2:
        x = np.mean(x.astype(np.float64), axis=1)
    if np.issubdtype(x.dtype, np.floating):
        y = x.astype(np.float64)
    elif x.dtype == np.uint8:
        y = (x.astype(np.float64) - 128.0) / 128.0
    elif np.issubdtype(x.dtype, np.integer):
        info = np.iinfo(x.dtype)
        scale = max(abs(info.min), abs(info.max))
        y = x.astype(np.float64) / float(scale)
    else:
        raise ValueError(f"不支持的WAV数据类型: {x.dtype}")
    if not np.all(np.isfinite(y)):
        y = np.nan_to_num(y)
    return y


def read_wav_power(path: Path, cfg: CompareConfig) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    fs, raw = wavfile.read(path)
    if int(fs) <= 0:
        raise ValueError("采样率无效")
    x = pcm_to_float(raw)
    if cfg.max_lab_seconds_per_file is not None:
        n = int(round(float(cfg.max_lab_seconds_per_file) * int(fs)))
        if n > 0:
            x = x[:n]
    if x.size < 256:
        raise ValueError(f"WAV太短: {path}")
    if fs / 2.0 < cfg.freq_high_hz:
        raise ValueError(
            f"{path.name}采样率={fs}Hz，Nyquist={fs/2:g}Hz，低于{cfg.freq_high_hz:g}Hz"
        )
    nperseg = min(int(cfg.nperseg), int(x.size))
    hop = min(int(cfg.hop_length), nperseg)
    noverlap = max(0, nperseg - hop)
    nfft = max(int(cfg.nfft), nperseg)
    freq, time_s, z = signal.stft(
        x,
        fs=int(fs),
        window="hann",
        nperseg=nperseg,
        noverlap=noverlap,
        nfft=nfft,
        detrend=False,
        return_onesided=True,
        boundary=None,
        padded=False,
    )
    mask = (freq >= cfg.freq_low_hz) & (freq <= cfg.freq_high_hz)
    if int(np.sum(mask)) < 10:
        raise ValueError(f"{path.name}在指定频带内有效频点不足")
    return freq[mask].astype(float), time_s.astype(float), np.maximum(np.abs(z[mask]) ** 2, EPS)


def make_bin_edges(cfg: CompareConfig) -> np.ndarray:
    width = float(cfg.fingerprint_bin_hz)
    if width <= 0:
        raise ValueError("fingerprint_bin_hz必须大于0")
    edges = np.arange(cfg.freq_low_hz, cfg.freq_high_hz + width, width, dtype=float)
    if edges[-1] < cfg.freq_high_hz:
        edges = np.append(edges, cfg.freq_high_hz)
    else:
        edges[-1] = cfg.freq_high_hz
    if len(edges) < 3:
        raise ValueError("频谱指纹频带过少")
    return edges


def spectrum_to_bins(freq_hz: np.ndarray, spectrum: np.ndarray, edges: np.ndarray) -> np.ndarray:
    freq = np.asarray(freq_hz, dtype=float).ravel()
    power = np.maximum(np.asarray(spectrum, dtype=float).ravel(), 0.0)
    if len(freq) != len(power):
        raise ValueError("频率轴和频谱长度不一致")
    values = np.zeros(len(edges) - 1, dtype=float)
    for i, (left, right) in enumerate(zip(edges[:-1], edges[1:])):
        mask = (freq >= left) & ((freq <= right) if i == len(values) - 1 else (freq < right))
        values[i] = float(np.mean(power[mask])) if np.any(mask) else 0.0
    return np.maximum(values, 0.0)


def probability_vector(values: np.ndarray) -> np.ndarray:
    x = np.maximum(np.asarray(values, dtype=float), 0.0)
    total = float(np.sum(x))
    if not np.isfinite(total) or total <= EPS:
        return np.full(len(x), 1.0 / max(len(x), 1), dtype=float)
    return x / total


def robust_shape(values: np.ndarray) -> np.ndarray:
    x = np.log10(np.maximum(np.asarray(values, dtype=float), EPS))
    med = float(np.median(x))
    mad = float(np.median(np.abs(x - med)))
    scale = max(1.4826 * mad, 1.0e-6)
    return np.clip((x - med) / scale, -8.0, 8.0)


def calculate_similarity(
    probability: np.ndarray,
    shape: np.ndarray,
    reference_probability: np.ndarray,
    reference_shape: np.ndarray,
) -> Dict[str, float]:
    p = np.asarray(probability, dtype=float)
    q = np.asarray(reference_probability, dtype=float)
    s = np.asarray(shape, dtype=float)
    r = np.asarray(reference_shape, dtype=float)
    denom = float(np.linalg.norm(p) * np.linalg.norm(q))
    cosine = float(np.dot(p, q) / denom) if denom > EPS else 0.0
    overlap = float(np.sum(np.minimum(p, q)))
    if np.std(s) <= 1.0e-12 or np.std(r) <= 1.0e-12:
        pearson = 0.0
    else:
        pearson = float(np.corrcoef(s, r)[0, 1])
        if not np.isfinite(pearson):
            pearson = 0.0
    pearson_01 = 0.5 * (pearson + 1.0)
    combined = float(np.mean([
        np.clip(cosine, 0.0, 1.0),
        np.clip(overlap, 0.0, 1.0),
        np.clip(pearson_01, 0.0, 1.0),
    ]))
    return {
        "cosine_similarity": float(np.clip(cosine, -1.0, 1.0)),
        "spectral_overlap": float(np.clip(overlap, 0.0, 1.0)),
        "pearson_similarity": float(np.clip(pearson, -1.0, 1.0)),
        "combined_similarity": float(np.clip(combined, 0.0, 1.0)),
    }


def rolling_std(values: np.ndarray, width: int) -> np.ndarray:
    v = np.asarray(values, dtype=float)
    out = np.zeros_like(v)
    half = max(int(width) // 2, 0)
    for i in range(len(v)):
        start = max(0, i - half)
        end = min(len(v), i + half + 1)
        out[i] = float(np.std(v[start:end]))
    return out


def spectral_values(freq: np.ndarray, spectrum: np.ndarray) -> Tuple[float, float, float, float]:
    p = np.maximum(np.asarray(spectrum, dtype=float), EPS)
    f = np.asarray(freq, dtype=float)
    total = float(np.sum(p))
    energy_db = float(10.0 * np.log10(total + EPS))
    flatness = float(np.exp(np.mean(np.log(p))) / (np.mean(p) + EPS))
    centroid = float(np.sum(f * p) / (total + EPS))
    spread = float(np.sqrt(np.sum(np.square(f - centroid) * p) / (total + EPS)))
    return energy_db, flatness, centroid, spread


def extract_window_features(
    freq_hz: np.ndarray,
    time_s: np.ndarray,
    power: np.ndarray,
    cfg: CompareConfig,
) -> Tuple[np.ndarray, np.ndarray]:
    freq = np.asarray(freq_hz, dtype=float).ravel()
    time = np.asarray(time_s, dtype=float).ravel()
    matrix = np.maximum(np.asarray(power, dtype=float), EPS)
    if matrix.ndim == 1:
        matrix = matrix[:, None]
    if matrix.ndim != 2 or matrix.shape != (len(freq), len(time)):
        raise ValueError(f"power维度异常: {matrix.shape}, freq={len(freq)}, time={len(time)}")
    if len(time) == 0:
        raise ValueError("没有时间帧")
    rel = time - float(np.min(time))
    frame_step = float(np.median(np.diff(rel))) if len(rel) >= 2 else cfg.window_ms / 1000.0
    total_duration = float(np.max(rel) + max(frame_step, 1.0e-6))
    win = float(cfg.window_ms) / 1000.0
    hop = float(cfg.hop_ms) / 1000.0
    if win <= 0 or hop <= 0:
        raise ValueError("window_ms和hop_ms必须大于0")
    if total_duration <= win:
        starts = np.asarray([0.0])
    else:
        starts = np.arange(0.0, total_duration - win + 1.0e-9, hop)
        if len(starts) == 0:
            starts = np.asarray([0.0])

    rows: List[List[float]] = []
    for start in starts:
        mask = (rel >= start) & (rel < start + win)
        if not np.any(mask):
            nearest = int(np.argmin(np.abs(rel - (start + 0.5 * win))))
            mask = np.zeros(len(rel), dtype=bool)
            mask[nearest] = True
        spectrum = np.mean(matrix[:, mask], axis=1)
        rows.append(list(spectral_values(freq, spectrum)))
    base = np.asarray(rows, dtype=float)
    energy = base[:, 0]
    flatness = base[:, 1]
    centroid = base[:, 2]
    spread = base[:, 3]
    floor = float(np.percentile(energy, cfg.snr_floor_percentile))
    adaptive_snr = energy - floor
    flat_std = rolling_std(flatness, cfg.consistency_window_frames)
    spread_std = rolling_std(spread, cfg.consistency_window_frames)
    all_features = np.column_stack([
        energy, flatness, centroid, spread, adaptive_snr, flat_std, spread_std,
    ])
    discrim = np.column_stack([
        flatness, spread, adaptive_snr, flat_std, spread_std,
    ])
    if len(discrim) < cfg.minimum_windows_per_record:
        raise ValueError(
            f"有效时间窗={len(discrim)}，少于minimum_windows_per_record={cfg.minimum_windows_per_record}"
        )
    return discrim, all_features


def build_power_record(
    source_id: str,
    file_path: str,
    freq: np.ndarray,
    time_s: np.ndarray,
    power: np.ndarray,
    cfg: CompareConfig,
) -> PowerRecord:
    mask = (freq >= cfg.freq_low_hz) & (freq <= cfg.freq_high_hz)
    if int(np.sum(mask)) < 10:
        raise ValueError("指定频带内有效频点不足")
    f = np.asarray(freq, dtype=float)[mask]
    p = np.maximum(np.asarray(power, dtype=float)[mask], EPS)
    features, feature_all = extract_window_features(f, time_s, p, cfg)
    spectrum = np.mean(p, axis=1)
    bands = spectrum_to_bins(f, spectrum, make_bin_edges(cfg))
    return PowerRecord(
        source_id=source_id,
        file_path=file_path,
        freq_hz=f,
        time_s=np.asarray(time_s, dtype=float),
        power=p,
        feature_matrix=features,
        feature_all=feature_all,
        bands=bands,
        probability=probability_vector(bands),
        shape=robust_shape(bands),
    )


def discover_wavs(paths: Sequence[Path]) -> List[Path]:
    files: List[Path] = []
    for value in paths:
        path = Path(value)
        if path.is_file() and path.suffix.lower() == ".wav":
            files.append(path)
        elif path.exists():
            files.extend(p for p in path.rglob("*.wav") if p.is_file())
    return sorted({p.resolve() for p in files}, key=lambda p: str(p).lower())


def uniformly_select_rows(matrix: np.ndarray, maximum: int) -> np.ndarray:
    x = np.asarray(matrix, dtype=float)
    if maximum <= 0 or len(x) <= maximum:
        return x.copy()
    idx = np.linspace(0, len(x) - 1, maximum).round().astype(int)
    return x[idx]


def build_reference_model(
    model_name: str,
    records: Sequence[PowerRecord],
    cfg: CompareConfig,
) -> ReferenceModel:
    if not records:
        raise ValueError(f"{model_name}没有有效消声室记录")
    parts = [uniformly_select_rows(r.feature_matrix, cfg.max_windows_per_lab_file) for r in records]
    x = np.vstack(parts)
    if len(x) < max(8, x.shape[1] + 2):
        raise ValueError(f"{model_name}有效特征窗太少: {len(x)}")
    mean = np.mean(x, axis=0)
    median = np.median(x, axis=0)
    std = np.std(x, axis=0, ddof=1)
    # 防止消声室样本过于一致时，极小标准差把马氏距离无意义地放大。
    # 顺序对应：平坦度、频谱展宽、自适应SNR、平坦度波动、展宽波动。
    physical_floors = np.asarray([0.01, 100.0, 0.5, 0.002, 50.0], dtype=float)
    std = np.maximum(std, physical_floors)
    z = (x - mean) / std
    center = np.median(z, axis=0)
    delta = z - center
    cov = np.cov(delta, rowvar=False)
    if np.ndim(cov) == 0:
        cov = np.eye(x.shape[1]) * float(cov)
    cov = np.asarray(cov, dtype=float)
    mean_diag = max(float(np.mean(np.diag(cov))), 1.0e-6)
    shrink = float(np.clip(cfg.covariance_shrinkage, 0.0, 1.0))
    cov = (1.0 - shrink) * cov + shrink * np.eye(cov.shape[0]) * mean_diag
    cov = cov + np.eye(cov.shape[0]) * float(cfg.covariance_ridge)
    inv_cov = np.linalg.pinv(cov, rcond=1.0e-12)
    d2 = np.einsum("ij,jk,ik->i", delta, inv_cov, delta, optimize=True)
    distances = np.sqrt(np.maximum(d2, 0.0))
    threshold = float(np.percentile(distances, cfg.reference_inside_percentile))
    threshold = max(threshold, 1.0e-6)
    probs = np.stack([r.probability for r in records], axis=0)
    shapes = np.stack([r.shape for r in records], axis=0)
    ref_prob = probability_vector(np.median(probs, axis=0))
    ref_shape = np.median(shapes, axis=0)
    return ReferenceModel(
        model_name=model_name,
        feature_names=list(FEATURE_NAMES),
        raw_mean=mean,
        raw_median=median,
        raw_std=std,
        standardized_center=center,
        inverse_covariance=inv_cov,
        window_distance_threshold=threshold,
        reference_probability=ref_prob,
        reference_shape=ref_shape,
        lab_records=list(records),
    )


def build_lab_models(
    lab_groups: Mapping[str, Sequence[Path]],
    cfg: CompareConfig,
) -> Tuple[Dict[str, ReferenceModel], pd.DataFrame, pd.DataFrame]:
    records_by_group: Dict[str, List[PowerRecord]] = {}
    record_rows: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []
    for group in ("0.1mm", "0.5mm"):
        files = discover_wavs(lab_groups[group])
        if not files:
            raise FileNotFoundError(f"消声室{group}没有找到WAV: {[str(p) for p in lab_groups[group]]}")
        records: List[PowerRecord] = []
        for path in files:
            try:
                freq, time_s, power = read_wav_power(path, cfg)
                record = build_power_record(path.stem, str(path), freq, time_s, power, cfg)
                records.append(record)
                record_rows.append({
                    "reference_group": group,
                    "file_name": path.name,
                    "file_path": str(path),
                    "n_windows": len(record.feature_matrix),
                    "duration_seconds": float(time_s[-1] - time_s[0]) if len(time_s) > 1 else 0.0,
                    "status": "OK",
                })
            except Exception as exc:
                errors.append({
                    "stage": "LAB_WAV",
                    "reference_group": group,
                    "file_path": str(path),
                    "error": f"{type(exc).__name__}: {exc}",
                })
        if not records:
            raise RuntimeError(f"消声室{group}全部WAV处理失败")
        records_by_group[group] = records
    models = {
        "0.1mm": build_reference_model("0.1mm", records_by_group["0.1mm"], cfg),
        "0.5mm": build_reference_model("0.5mm", records_by_group["0.5mm"], cfg),
    }
    models["ALL_LEAKS"] = build_reference_model(
        "ALL_LEAKS", records_by_group["0.1mm"] + records_by_group["0.5mm"], cfg
    )
    return models, pd.DataFrame(record_rows), pd.DataFrame(errors)


def resolve_metadata(input_root: Path) -> Path:
    for name in ("v22_EFG_all_features.csv", "v21_EFG_all_features.csv"):
        path = input_root / name
        if path.exists():
            return path
    raise FileNotFoundError(f"找不到v22_EFG_all_features.csv: {input_root}")


def load_factory_record(npz_path: Path, cfg: CompareConfig) -> Tuple[PowerRecord, Dict[str, float]]:
    with np.load(npz_path, allow_pickle=False) as data:
        freq = np.asarray(data["freq_hz"], dtype=float).ravel()
        time_s = np.asarray(data["time_s"], dtype=float).ravel()
        power = np.asarray(data["component_power"], dtype=float)
        if power.ndim == 1:
            power = power[:, None]
        quality = {
            "plane_valid": float(data["plane_valid"].item()) if "plane_valid" in data.files else np.nan,
            "plane_geometry_ok": float(data["plane_geometry_ok"].item()) if "plane_geometry_ok" in data.files else np.nan,
        }
    record = build_power_record(npz_path.stem, str(npz_path), freq, time_s, power, cfg)
    return record, quality


def individual_similarity_stats(record: PowerRecord, model: ReferenceModel) -> Dict[str, float]:
    values = [
        calculate_similarity(record.probability, record.shape, lab.probability, lab.shape)[
            "combined_similarity"
        ]
        for lab in model.lab_records
    ]
    x = np.asarray(values, dtype=float)
    return {
        "individual_lab_similarity_median": float(np.median(x)),
        "individual_lab_similarity_p90": float(np.percentile(x, 90.0)),
        "individual_lab_similarity_max": float(np.max(x)),
    }


def feature_comparison_rows(
    base: Mapping[str, Any],
    record: PowerRecord,
    model: ReferenceModel,
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    sample_med = np.median(record.feature_matrix, axis=0)
    sample_mean = np.mean(record.feature_matrix, axis=0)
    for i, name in enumerate(model.feature_names):
        z = float((sample_med[i] - model.raw_mean[i]) / max(model.raw_std[i], 1.0e-12))
        rows.append({
            **base,
            "feature": name,
            "factory_mean": float(sample_mean[i]),
            "factory_median": float(sample_med[i]),
            "lab_mean": float(model.raw_mean[i]),
            "lab_median": float(model.raw_median[i]),
            "lab_std": float(model.raw_std[i]),
            "factory_median_z_to_lab": z,
            "absolute_z_difference": abs(z),
        })
    return rows


def process_factory(
    input_root: Path,
    models: Mapping[str, ReferenceModel],
    cfg: CompareConfig,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    metadata_path = resolve_metadata(input_root)
    meta = pd.read_csv(metadata_path, dtype={"sample_id": str, "scene": str, "label": str})
    required = {"sample_id", "scene", "label"}
    missing = sorted(required - set(meta.columns))
    if missing:
        raise ValueError(f"工厂元数据缺少列: {missing}")
    meta["label"] = meta["label"].astype(str).str.upper().str.strip()
    meta = meta[meta["label"].isin(VALID_LABELS)].copy()
    scenes = sorted(meta["scene"].astype(str).unique())
    if len(scenes) != 3:
        raise ValueError(f"必须正好有E/F/G三个场景，当前为: {scenes}")

    long_rows: List[Dict[str, Any]] = []
    feature_rows: List[Dict[str, Any]] = []
    window_rows: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []

    for _, series in meta.iterrows():
        row = series.to_dict()
        sample_id = str(row["sample_id"])
        scene = str(row["scene"])
        label = str(row["label"])
        for method in METHODS:
            path = input_root / safe_slug(scene) / "methods" / method / "residual_npz" / f"{safe_slug(sample_id)}.npz"
            try:
                if not path.exists():
                    raise FileNotFoundError(path)
                record, quality = load_factory_record(path, cfg)
                if method == "plane":
                    if cfg.require_plane_valid and int(quality["plane_valid"]) != 1:
                        raise ValueError("plane_valid不是1")
                    if cfg.require_plane_geometry_ok and int(quality["plane_geometry_ok"]) != 1:
                        raise ValueError("plane_geometry_ok不是1")
                for model_name, model in models.items():
                    stats, distances = model.file_statistics(record.feature_matrix)
                    spec = calculate_similarity(
                        record.probability,
                        record.shape,
                        model.reference_probability,
                        model.reference_shape,
                    )
                    individual = individual_similarity_stats(record, model)
                    base = {
                        "sample_id": sample_id,
                        "dataset": row.get("dataset", ""),
                        "scene": scene,
                        "label": label,
                        "y_true": VALID_LABELS[label],
                        "time_folder": row.get("time_folder", row.get("time", "")),
                        "center": row.get("center", ""),
                        "method": method,
                        "reference_group": model_name,
                        "npz_path": str(path),
                        "plane_valid": quality["plane_valid"],
                        "plane_geometry_ok": quality["plane_geometry_ok"],
                        "window_distance_threshold": model.window_distance_threshold,
                    }
                    long_rows.append({**base, **stats, **spec, **individual})
                    feature_rows.extend(feature_comparison_rows(base, record, model))
                    if cfg.save_window_details:
                        for index, distance in enumerate(distances):
                            window_rows.append({
                                **base,
                                "window_index": index,
                                "mahalanobis_distance": float(distance),
                                "distance_similarity": float(model.similarity_from_distance(distance)),
                                "inside_reference": int(distance <= model.window_distance_threshold),
                            })
            except Exception as exc:
                errors.append({
                    "sample_id": sample_id,
                    "scene": scene,
                    "label": label,
                    "method": method,
                    "npz_path": str(path),
                    "error": f"{type(exc).__name__}: {exc}",
                    "traceback": traceback.format_exc(),
                })
    return (
        pd.DataFrame(long_rows),
        pd.DataFrame(feature_rows),
        pd.DataFrame(window_rows),
        pd.DataFrame(errors),
    )


def make_scene_summary(long_df: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for (scene, ref, method), group in long_df.groupby(["scene", "reference_group", "method"]):
        true = group[group["label"] == "TRUE_LEAK"]
        false = group[group["label"] == "FALSE_LEAK"]
        if true.empty or false.empty:
            continue
        row = {
            "scene": scene,
            "reference_group": ref,
            "method": method,
            "n_true": len(true),
            "n_false": len(false),
            "true_median_distance": float(true["median_distance"].median()),
            "false_median_distance": float(false["median_distance"].median()),
            "true_p90_distance": float(true["p90_distance"].median()),
            "false_p90_distance": float(false["p90_distance"].median()),
            "true_median_distance_ratio": float(true["median_distance_ratio"].median()),
            "false_median_distance_ratio": float(false["median_distance_ratio"].median()),
            "true_p90_distance_ratio": float(true["p90_distance_ratio"].median()),
            "false_p90_distance_ratio": float(false["p90_distance_ratio"].median()),
            "true_balanced_similarity": float(true["balanced_similarity"].median()),
            "false_balanced_similarity": float(false["balanced_similarity"].median()),
            "true_combined_similarity": float(true["combined_similarity"].median()),
            "false_combined_similarity": float(false["combined_similarity"].median()),
            "true_cosine_similarity": float(true["cosine_similarity"].median()),
            "false_cosine_similarity": float(false["cosine_similarity"].median()),
            "true_spectral_overlap": float(true["spectral_overlap"].median()),
            "false_spectral_overlap": float(false["spectral_overlap"].median()),
            "true_pearson_similarity": float(true["pearson_similarity"].median()),
            "false_pearson_similarity": float(false["pearson_similarity"].median()),
        }
        row["distance_separation_false_minus_true"] = (
            row["false_median_distance"] - row["true_median_distance"]
        )
        row["p90_distance_separation_false_minus_true"] = (
            row["false_p90_distance"] - row["true_p90_distance"]
        )
        row["distance_ratio_separation_false_minus_true"] = (
            row["false_median_distance_ratio"] - row["true_median_distance_ratio"]
        )
        row["p90_distance_ratio_separation_false_minus_true"] = (
            row["false_p90_distance_ratio"] - row["true_p90_distance_ratio"]
        )
        row["distance_similarity_separation_true_minus_false"] = (
            row["true_balanced_similarity"] - row["false_balanced_similarity"]
        )
        row["spectral_similarity_separation_true_minus_false"] = (
            row["true_combined_similarity"] - row["false_combined_similarity"]
        )
        rows.append(row)
    return pd.DataFrame(rows)


def classify_change(row: Mapping[str, Any], cfg: CompareConfig) -> str:
    d_gain = float(row["plane_minus_raw_distance_separation"])
    m_gain = float(row["plane_minus_raw_distance_similarity_separation"])
    s_gain = float(row["plane_minus_raw_spectral_similarity_separation"])
    true_change = float(row["true_distance_change_plane_minus_raw"])
    false_change = float(row["false_distance_change_plane_minus_raw"])
    positive = sum([
        d_gain >= cfg.distance_gain_threshold,
        m_gain >= cfg.similarity_gain_threshold,
        s_gain >= cfg.similarity_gain_threshold,
    ])
    negative = sum([
        d_gain <= -cfg.distance_gain_threshold,
        m_gain <= -cfg.similarity_gain_threshold,
        s_gain <= -cfg.similarity_gain_threshold,
    ])
    if true_change < -cfg.distance_gain_threshold and false_change <= true_change + cfg.distance_gain_threshold:
        return "TRUE_FALSE都被拉近_不能说明PLANE有效"
    if positive >= 2 and true_change <= cfg.distance_gain_threshold:
        return "PLANE更有利"
    if negative >= 2 or true_change >= cfg.distance_gain_threshold:
        return "PLANE更差"
    return "变化不明显"


def compare_raw_plane(scene_summary: pd.DataFrame, cfg: CompareConfig) -> pd.DataFrame:
    raw = scene_summary[scene_summary["method"] == "raw"].copy()
    plane = scene_summary[scene_summary["method"] == "plane"].copy()
    merged = raw.merge(
        plane,
        on=["scene", "reference_group"],
        suffixes=("_raw", "_plane"),
        how="inner",
    )
    if merged.empty:
        return merged
    merged["plane_minus_raw_distance_separation_raw"] = (
        merged["distance_separation_false_minus_true_plane"]
        - merged["distance_separation_false_minus_true_raw"]
    )
    merged["plane_minus_raw_distance_separation"] = (
        merged["distance_ratio_separation_false_minus_true_plane"]
        - merged["distance_ratio_separation_false_minus_true_raw"]
    )
    merged["plane_minus_raw_p90_distance_separation"] = (
        merged["p90_distance_separation_false_minus_true_plane"]
        - merged["p90_distance_separation_false_minus_true_raw"]
    )
    merged["plane_minus_raw_distance_similarity_separation"] = (
        merged["distance_similarity_separation_true_minus_false_plane"]
        - merged["distance_similarity_separation_true_minus_false_raw"]
    )
    merged["plane_minus_raw_spectral_similarity_separation"] = (
        merged["spectral_similarity_separation_true_minus_false_plane"]
        - merged["spectral_similarity_separation_true_minus_false_raw"]
    )
    merged["true_distance_change_plane_minus_raw_raw"] = (
        merged["true_median_distance_plane"] - merged["true_median_distance_raw"]
    )
    merged["false_distance_change_plane_minus_raw_raw"] = (
        merged["false_median_distance_plane"] - merged["false_median_distance_raw"]
    )
    merged["true_distance_change_plane_minus_raw"] = (
        merged["true_median_distance_ratio_plane"] - merged["true_median_distance_ratio_raw"]
    )
    merged["false_distance_change_plane_minus_raw"] = (
        merged["false_median_distance_ratio_plane"] - merged["false_median_distance_ratio_raw"]
    )
    merged["true_spectral_similarity_change_plane_minus_raw"] = (
        merged["true_combined_similarity_plane"] - merged["true_combined_similarity_raw"]
    )
    merged["false_spectral_similarity_change_plane_minus_raw"] = (
        merged["false_combined_similarity_plane"] - merged["false_combined_similarity_raw"]
    )
    merged["scene_conclusion"] = merged.apply(lambda r: classify_change(r, cfg), axis=1)
    return merged


def overall_summary(comparison: pd.DataFrame) -> pd.DataFrame:
    rows: List[Dict[str, Any]] = []
    for ref, group in comparison.groupby("reference_group"):
        counts = group["scene_conclusion"].value_counts()
        beneficial = int(counts.get("PLANE更有利", 0))
        worse = int(counts.get("PLANE更差", 0))
        both = int(counts.get("TRUE_FALSE都被拉近_不能说明PLANE有效", 0))
        if beneficial >= 2 and worse == 0:
            conclusion = "PLANE更有利"
        elif worse >= 2:
            conclusion = "PLANE更差"
        elif both >= 2:
            conclusion = "TRUE和FALSE都被拉近_不能证明有效"
        else:
            conclusion = "跨场景不稳定或变化不明显"
        rows.append({
            "reference_group": ref,
            "scene_count": len(group),
            "raw_true_median_distance": float(group["true_median_distance_raw"].mean()),
            "plane_true_median_distance": float(group["true_median_distance_plane"].mean()),
            "raw_false_median_distance": float(group["false_median_distance_raw"].mean()),
            "plane_false_median_distance": float(group["false_median_distance_plane"].mean()),
            "raw_true_median_distance_ratio": float(group["true_median_distance_ratio_raw"].mean()),
            "plane_true_median_distance_ratio": float(group["true_median_distance_ratio_plane"].mean()),
            "raw_false_median_distance_ratio": float(group["false_median_distance_ratio_raw"].mean()),
            "plane_false_median_distance_ratio": float(group["false_median_distance_ratio_plane"].mean()),
            "raw_true_combined_similarity": float(group["true_combined_similarity_raw"].mean()),
            "plane_true_combined_similarity": float(group["true_combined_similarity_plane"].mean()),
            "raw_false_combined_similarity": float(group["false_combined_similarity_raw"].mean()),
            "plane_false_combined_similarity": float(group["false_combined_similarity_plane"].mean()),
            "plane_better_scene_count": beneficial,
            "plane_worse_scene_count": worse,
            "both_closer_scene_count": both,
            "mean_plane_minus_raw_distance_separation": float(group["plane_minus_raw_distance_separation"].mean()),
            "mean_plane_minus_raw_distance_similarity_separation": float(group["plane_minus_raw_distance_similarity_separation"].mean()),
            "mean_plane_minus_raw_spectral_similarity_separation": float(group["plane_minus_raw_spectral_similarity_separation"].mean()),
            "mean_true_distance_change_plane_minus_raw": float(group["true_distance_change_plane_minus_raw"].mean()),
            "mean_false_distance_change_plane_minus_raw": float(group["false_distance_change_plane_minus_raw"].mean()),
            "final_conclusion": conclusion,
        })
    return pd.DataFrame(rows)


def paired_sample_changes(long_df: pd.DataFrame) -> pd.DataFrame:
    keys = ["sample_id", "scene", "label", "reference_group"]
    raw = long_df[long_df["method"] == "raw"].copy()
    plane = long_df[long_df["method"] == "plane"].copy()
    merged = raw.merge(plane, on=keys, suffixes=("_raw", "_plane"), how="inner")
    for col in [
        "median_distance", "p90_distance", "balanced_similarity", "combined_similarity",
        "cosine_similarity", "spectral_overlap", "pearson_similarity",
    ]:
        merged[f"{col}_change_plane_minus_raw"] = merged[f"{col}_plane"] - merged[f"{col}_raw"]
    return merged


def lab_summary(models: Mapping[str, ReferenceModel]) -> pd.DataFrame:
    rows = []
    for name, model in models.items():
        total_windows = sum(len(r.feature_matrix) for r in model.lab_records)
        rows.append({
            "reference_group": name,
            "lab_wav_count": len(model.lab_records),
            "lab_window_count": total_windows,
            "window_distance_threshold": model.window_distance_threshold,
            **{f"mean_{feature}": float(model.raw_mean[i]) for i, feature in enumerate(model.feature_names)},
            **{f"std_{feature}": float(model.raw_std[i]) for i, feature in enumerate(model.feature_names)},
        })
    return pd.DataFrame(rows)


def save_plots(
    scene_summary: pd.DataFrame,
    comparison: pd.DataFrame,
    output_dir: Path,
) -> None:
    if plt is None or scene_summary.empty:
        return
    fig_dir = output_dir / "figures"
    ensure_dir(fig_dir)
    for ref in MODEL_NAMES:
        subset = scene_summary[scene_summary["reference_group"] == ref]
        if subset.empty:
            continue
        pivot = subset.pivot(index="scene", columns="method", values="distance_ratio_separation_false_minus_true")
        ax = pivot.plot(kind="bar", figsize=(9, 5))
        ax.axhline(0.0, linewidth=1)
        ax.set_ylabel("FALSE relative distance - TRUE relative distance (larger is better)")
        ax.set_title(f"{ref}: RAW vs PLANE Mahalanobis separation")
        ax.grid(axis="y", alpha=0.3)
        ax.figure.tight_layout()
        ax.figure.savefig(fig_dir / f"01_{safe_slug(ref)}_distance_separation.png", dpi=150)
        plt.close(ax.figure)

        pivot2 = subset.pivot(index="scene", columns="method", values="spectral_similarity_separation_true_minus_false")
        ax2 = pivot2.plot(kind="bar", figsize=(9, 5))
        ax2.axhline(0.0, linewidth=1)
        ax2.set_ylabel("TRUE similarity - FALSE similarity (larger is better)")
        ax2.set_title(f"{ref}: RAW vs PLANE spectral similarity separation")
        ax2.grid(axis="y", alpha=0.3)
        ax2.figure.tight_layout()
        ax2.figure.savefig(fig_dir / f"02_{safe_slug(ref)}_spectral_similarity_separation.png", dpi=150)
        plt.close(ax2.figure)

    if not comparison.empty:
        table = comparison.pivot(index="scene", columns="reference_group", values="plane_minus_raw_distance_separation")
        ax3 = table.plot(kind="bar", figsize=(10, 5.5))
        ax3.axhline(0.0, linewidth=1)
        ax3.set_ylabel("PLANE separation - RAW separation")
        ax3.set_title("Does PLANE enlarge TRUE/FALSE distance separation?")
        ax3.grid(axis="y", alpha=0.3)
        ax3.figure.tight_layout()
        ax3.figure.savefig(fig_dir / "03_PLANE_minus_RAW_distance_separation.png", dpi=150)
        plt.close(ax3.figure)


def write_report(overall: pd.DataFrame, output_dir: Path) -> None:
    lines = [
        "v22 E/F/G RAW、PLANE与消声室0.1mm/0.5mm比较",
        "=" * 78,
        "",
        "最重要的判断：",
        "1. 距离越小，只表示更接近消声室特征分布。",
        "2. 相似度越大，只表示频谱形状更相似。",
        "3. 必须同时比较TRUE和FALSE；只有TRUE更近、FALSE不跟着变近，才支持PLANE有效。",
        "",
    ]
    for _, row in overall.iterrows():
        lines.extend([
            f"参考模型: {row['reference_group']}",
            f"  最终结论: {row['final_conclusion']}",
            f"  PLANE更有利场景数: {int(row['plane_better_scene_count'])}",
            f"  PLANE更差场景数: {int(row['plane_worse_scene_count'])}",
            f"  TRUE/FALSE都被拉近场景数: {int(row['both_closer_scene_count'])}",
            f"  平均距离分离改善: {row['mean_plane_minus_raw_distance_separation']:.6f}",
            f"  平均频谱相似度分离改善: {row['mean_plane_minus_raw_spectral_similarity_separation']:.6f}",
            "",
        ])
    (output_dir / "00_最先看这个.txt").write_text("\n".join(lines), encoding="utf-8")


def run_analysis(config_path: Path) -> Dict[str, Path]:
    payload = json.loads(config_path.read_text(encoding="utf-8-sig"))
    input_root = Path(str(payload.get("output_dir", "")))
    if not str(input_root):
        raise ValueError("配置缺少output_dir")
    section = dict(payload.get("anechoic_comparison", {}))
    output_value = section.pop("output_dir", None)
    lab_raw = section.pop("lab_groups", None)
    if not output_value:
        raise ValueError("anechoic_comparison缺少output_dir")
    if not isinstance(lab_raw, dict):
        raise ValueError("anechoic_comparison.lab_groups必须是字典")
    for required in ("0.1mm", "0.5mm"):
        if required not in lab_raw:
            raise ValueError(f"lab_groups缺少{required}")
    lab_groups: Dict[str, List[Path]] = {}
    for name in ("0.1mm", "0.5mm"):
        values = lab_raw[name]
        if isinstance(values, str):
            values = [values]
        if not isinstance(values, list) or not values:
            raise ValueError(f"lab_groups[{name}]必须是非空路径列表")
        lab_groups[name] = [Path(str(v)) for v in values]

    algorithm = dict(payload.get("algorithm", {}))
    inherited = {
        key: algorithm[key]
        for key in ("freq_low_hz", "freq_high_hz", "nperseg", "hop_length", "nfft")
        if key in algorithm
    }
    cfg = dataclass_from_dict(CompareConfig, {**inherited, **section})
    if cfg.freq_low_hz >= cfg.freq_high_hz:
        raise ValueError("freq_low_hz必须小于freq_high_hz")
    output_dir = Path(str(output_value))
    ensure_dir(output_dir)

    print("建立消声室0.1mm、0.5mm、ALL_LEAKS参考模型...")
    models, lab_files_df, lab_errors_df = build_lab_models(lab_groups, cfg)
    print("读取E/F/G RAW与PLANE残差并计算距离、相似度...")
    long_df, feature_df, window_df, factory_errors_df = process_factory(input_root, models, cfg)
    if long_df.empty:
        raise RuntimeError("没有成功得到任何工厂-消声室比较结果")
    scene_df = make_scene_summary(long_df)
    compare_df = compare_raw_plane(scene_df, cfg)
    overall_df = overall_summary(compare_df)
    paired_df = paired_sample_changes(long_df)
    lab_model_df = lab_summary(models)
    errors_df = pd.concat([lab_errors_df, factory_errors_df], ignore_index=True, sort=False)

    paths = {
        "first": output_dir / "00_最先看这个.csv",
        "long": output_dir / "01_每个样本_距离与相似度_long.csv",
        "scene": output_dir / "02_每个场景_TRUE_FALSE分离.csv",
        "compare": output_dir / "03_RAW变PLANE后的场景变化.csv",
        "paired": output_dir / "04_同一样本_RAW变PLANE后的变化.csv",
        "features": output_dir / "05_每个特征与消声室差异.csv",
        "lab": output_dir / "06_消声室参考模型摘要.csv",
        "lab_files": output_dir / "07_消声室WAV处理清单.csv",
        "windows": output_dir / "08_窗口距离明细.csv",
        "errors": output_dir / "99_errors.csv",
        "run_info": output_dir / "10_run_info.json",
    }
    overall_df.to_csv(paths["first"], index=False, encoding="utf-8-sig")
    long_df.to_csv(paths["long"], index=False, encoding="utf-8-sig")
    scene_df.to_csv(paths["scene"], index=False, encoding="utf-8-sig")
    compare_df.to_csv(paths["compare"], index=False, encoding="utf-8-sig")
    paired_df.to_csv(paths["paired"], index=False, encoding="utf-8-sig")
    feature_df.to_csv(paths["features"], index=False, encoding="utf-8-sig")
    lab_model_df.to_csv(paths["lab"], index=False, encoding="utf-8-sig")
    lab_files_df.to_csv(paths["lab_files"], index=False, encoding="utf-8-sig")
    if cfg.save_window_details:
        window_df.to_csv(paths["windows"], index=False, encoding="utf-8-sig")
    errors_df.to_csv(paths["errors"], index=False, encoding="utf-8-sig")
    run_info = {
        "version": "v22_EFG_vs_anechoic_similarity",
        "input_root": str(input_root),
        "output_dir": str(output_dir),
        "lab_groups": {k: [str(p) for p in v] for k, v in lab_groups.items()},
        "config": asdict(cfg),
        "factory_result_count": len(long_df),
        "factory_error_count": len(factory_errors_df),
        "lab_error_count": len(lab_errors_df),
    }
    paths["run_info"].write_text(json.dumps(run_info, ensure_ascii=False, indent=2), encoding="utf-8")
    write_report(overall_df, output_dir)
    if cfg.save_plots:
        save_plots(scene_df, compare_df, output_dir)

    print("\n处理完成")
    print("最先看:", paths["first"])
    print("每个样本:", paths["long"])
    print("每个场景:", paths["scene"])
    print("错误记录:", paths["errors"])
    return paths


def synth_wave(fs: int, seconds: float, kind: str, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    t = np.arange(int(fs * seconds)) / fs
    if kind == "leak01":
        x = 0.45 * np.sin(2 * np.pi * 36_000 * t) + 0.35 * np.sin(2 * np.pi * 58_000 * t)
        x += 0.12 * rng.normal(size=len(t))
    elif kind == "leak05":
        x = 0.30 * np.sin(2 * np.pi * 42_000 * t) + 0.48 * np.sin(2 * np.pi * 66_000 * t)
        x += 0.14 * rng.normal(size=len(t))
    else:
        x = 0.55 * np.sin(2 * np.pi * 24_000 * t) + 0.08 * rng.normal(size=len(t))
    x = x / max(np.max(np.abs(x)), 1.0)
    return np.int16(np.clip(x, -1, 1) * 30000)


def run_self_test() -> None:
    cfg = CompareConfig(freq_low_hz=20_000, freq_high_hz=80_000)
    with tempfile.TemporaryDirectory(prefix="v22_anechoic_selftest_") as td:
        root = Path(td)
        p01 = root / "01.wav"
        p05 = root / "05.wav"
        pn = root / "noise.wav"
        wavfile.write(p01, 192000, synth_wave(192000, 1.2, "leak01", 1))
        wavfile.write(p05, 192000, synth_wave(192000, 1.2, "leak05", 2))
        wavfile.write(pn, 192000, synth_wave(192000, 1.2, "noise", 3))
        lab_records = []
        for p in (p01, p05):
            f, t, power = read_wav_power(p, cfg)
            lab_records.append(build_power_record(p.stem, str(p), f, t, power, cfg))
        model = build_reference_model("ALL_LEAKS", lab_records, cfg)
        f1, t1, p1 = read_wav_power(p01, cfg)
        near = build_power_record("near", str(p01), f1, t1, p1, cfg)
        fn, tn, pn_power = read_wav_power(pn, cfg)
        far = build_power_record("far", str(pn), fn, tn, pn_power, cfg)
        near_stats, _ = model.file_statistics(near.feature_matrix)
        far_stats, _ = model.file_statistics(far.feature_matrix)
        near_sim = calculate_similarity(
            near.probability, near.shape, model.reference_probability, model.reference_shape
        )["combined_similarity"]
        far_sim = calculate_similarity(
            far.probability, far.shape, model.reference_probability, model.reference_shape
        )["combined_similarity"]
        if not near_stats["median_distance"] < far_stats["median_distance"]:
            raise AssertionError("自检失败：相似泄漏的马氏距离没有更小")
        if not near_sim > far_sim:
            raise AssertionError("自检失败：相似泄漏的频谱相似度没有更高")
        print("v22消声室比较自检通过")
        print(f"相似泄漏 median distance={near_stats['median_distance']:.4f}, similarity={near_sim:.4f}")
        print(f"不同声音 median distance={far_stats['median_distance']:.4f}, similarity={far_sim:.4f}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="E/F/G RAW与PLANE对消声室0.1mm、0.5mm距离和相似度")
    parser.add_argument("--config", type=str, help="v22配置文件")
    parser.add_argument("--self-test", action="store_true", help="运行自检")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.self_test:
        run_self_test()
        return
    if not args.config:
        raise SystemExit("请使用 --config 指定配置文件，或使用 --self-test")
    run_analysis(Path(args.config))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n用户中止。")
        raise SystemExit(130)
    except Exception as exc:
        print("\n程序失败:", f"{type(exc).__name__}: {exc}")
        traceback.print_exc()
        raise SystemExit(1)
