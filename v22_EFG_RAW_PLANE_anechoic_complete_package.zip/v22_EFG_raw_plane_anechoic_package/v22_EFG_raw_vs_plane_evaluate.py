# -*- coding: utf-8 -*-
"""
v22_EFG_raw_vs_plane_evaluate.py

目的
----
使用真实工厂 E/F/G 三个场景的 TRUE_LEAK 与 FALSE_LEAK，公平比较：
    1. RAW：中心点原始信号；
    2. PLANE：中心点减去外圈40点空间平面背景后的正功率残差。

严格验证方式
------------
做三次整场景留出：
    E+F训练 -> G测试
    E+G训练 -> F测试
    F+G训练 -> E测试

RAW和PLANE必须满足：
    - 同一批样本；
    - 完全相同的特征定义；
    - 完全相同的模型候选；
    - 完全相同的训练/测试场景；
    - 测试场景标签不参与特征选择、参数选择和阈值选择。

依赖
----
pip install numpy pandas matplotlib scikit-learn
"""

from __future__ import annotations

import argparse
import json
import math
import sys
import tempfile
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
except Exception as exc:
    raise RuntimeError("缺少 matplotlib，请运行: pip install matplotlib") from exc

try:
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import (
        accuracy_score,
        balanced_accuracy_score,
        confusion_matrix,
        roc_auc_score,
    )
except Exception as exc:
    raise RuntimeError("缺少 scikit-learn，请运行: pip install scikit-learn") from exc



try:
    from matplotlib import font_manager
    _available_fonts = {f.name for f in font_manager.fontManager.ttflist}
    for _font_name in ("Microsoft YaHei", "SimHei", "Noto Sans CJK SC", "Noto Sans CJK JP", "Arial Unicode MS"):
        if _font_name in _available_fonts:
            plt.rcParams["font.sans-serif"] = [_font_name]
            break
except Exception:
    pass
plt.rcParams["axes.unicode_minus"] = False

EPS = 1.0e-20
METHODS = ("raw", "plane")
VALID_LABELS = {"TRUE_LEAK": 1, "FALSE_LEAK": 0}
TOP_K_GRID = (5, 10, 20, 40)
C_GRID = (0.03, 0.1, 0.3, 1.0)


@dataclass
class FittedPipeline:
    selected_indices: np.ndarray
    feature_names: List[str]
    median: np.ndarray
    scale: np.ndarray
    model: LogisticRegression


@dataclass
class FoldResult:
    method: str
    test_scene: str
    train_scenes: List[str]
    selected_top_k: int
    selected_c: float
    threshold: float
    oof_auc: float
    oof_balanced_accuracy: float
    test_auc: float
    test_balanced_accuracy: float
    test_accuracy: float
    sensitivity: float
    specificity: float
    n_train: int
    n_test: int
    n_test_true: int
    n_test_false: int
    plane_valid_fraction: float
    plane_geometry_ok_fraction: float


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def safe_slug(value: Any, max_len: int = 180) -> str:
    import re
    text = str(value).strip() or "sample"
    text = re.sub(r"[^0-9A-Za-z_\-.]+", "_", text)
    return text.strip("._")[:max_len] or "sample"


def safe_float(value: Any, default: float = np.nan) -> float:
    try:
        x = float(value)
        return x if np.isfinite(x) else default
    except Exception:
        return default


def power_db(power: np.ndarray) -> np.ndarray:
    return 10.0 * np.log10(np.maximum(np.asarray(power, dtype=float), EPS))


def normalized_entropy(values: np.ndarray) -> float:
    x = np.maximum(np.asarray(values, dtype=float).ravel(), 0.0)
    total = float(np.sum(x))
    if total <= EPS or len(x) <= 1:
        return 0.0
    p = x / total
    return float(-np.sum(p * np.log(p + EPS)) / np.log(len(p)))


def spectral_flatness(values: np.ndarray) -> float:
    x = np.maximum(np.asarray(values, dtype=float).ravel(), EPS)
    return float(np.exp(np.mean(np.log(x))) / max(float(np.mean(x)), EPS))


def robust_center_scale(X: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    X = np.asarray(X, dtype=float)
    med = np.nanmedian(X, axis=0)
    q25 = np.nanpercentile(X, 25, axis=0)
    q75 = np.nanpercentile(X, 75, axis=0)
    scale = q75 - q25
    std = np.nanstd(X, axis=0)
    scale = np.where(scale > 1.0e-9, scale, std)
    scale = np.where(scale > 1.0e-9, scale, 1.0)
    med = np.nan_to_num(med, nan=0.0, posinf=0.0, neginf=0.0)
    scale = np.nan_to_num(scale, nan=1.0, posinf=1.0, neginf=1.0)
    return med, scale


def transform_robust(X: np.ndarray, med: np.ndarray, scale: np.ndarray) -> np.ndarray:
    X = np.asarray(X, dtype=float)
    X = np.nan_to_num(X, nan=med, posinf=med, neginf=med)
    return np.clip((X - med) / scale, -12.0, 12.0)


def feature_effect_scores(X: np.ndarray, y: np.ndarray) -> np.ndarray:
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=int)
    scores = np.zeros(X.shape[1], dtype=float)
    for j in range(X.shape[1]):
        a = X[y == 1, j]
        b = X[y == 0, j]
        if len(a) == 0 or len(b) == 0:
            continue
        ma = float(np.nanmedian(a))
        mb = float(np.nanmedian(b))
        pooled = np.concatenate([a, b])
        med = float(np.nanmedian(pooled))
        mad = float(np.nanmedian(np.abs(pooled - med)))
        std = float(np.nanstd(pooled))
        scale = max(1.4826 * mad, std, 1.0e-9)
        scores[j] = abs(ma - mb) / scale
    return np.nan_to_num(scores, nan=0.0, posinf=0.0, neginf=0.0)


def fit_pipeline(
    X: np.ndarray,
    y: np.ndarray,
    feature_names: Sequence[str],
    top_k: int,
    c_value: float,
    random_state: int,
) -> FittedPipeline:
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=int)
    if len(np.unique(y)) != 2:
        raise ValueError("训练数据必须同时包含TRUE_LEAK和FALSE_LEAK")
    scores = feature_effect_scores(X, y)
    nonconstant = np.flatnonzero(np.nanstd(X, axis=0) > 1.0e-10)
    if len(nonconstant) == 0:
        raise ValueError("所有特征都是常数，无法训练")
    order = nonconstant[np.argsort(scores[nonconstant])[::-1]]
    k = max(1, min(int(top_k), len(order)))
    selected = order[:k]
    med, scale = robust_center_scale(X[:, selected])
    Xs = transform_robust(X[:, selected], med, scale)
    model = LogisticRegression(
        C=float(c_value),
            solver="liblinear",
        class_weight="balanced",
        max_iter=5000,
        random_state=int(random_state),
    )
    model.fit(Xs, y)
    return FittedPipeline(
        selected_indices=selected,
        feature_names=[str(feature_names[i]) for i in selected],
        median=med,
        scale=scale,
        model=model,
    )


def predict_pipeline(pipe: FittedPipeline, X: np.ndarray) -> np.ndarray:
    Xs = transform_robust(np.asarray(X)[:, pipe.selected_indices], pipe.median, pipe.scale)
    return pipe.model.predict_proba(Xs)[:, 1]


def best_threshold(y_true: np.ndarray, scores: np.ndarray) -> Tuple[float, float]:
    y = np.asarray(y_true, dtype=int)
    s = np.asarray(scores, dtype=float)
    candidates = np.unique(np.concatenate([[0.0], s, [1.0]]))
    if len(candidates) > 501:
        candidates = np.linspace(0.0, 1.0, 501)
    best = (0.5, -np.inf, -np.inf)
    for threshold in candidates:
        pred = (s >= threshold).astype(int)
        bal = balanced_accuracy_score(y, pred)
        acc = accuracy_score(y, pred)
        candidate = (float(threshold), float(bal), float(acc))
        if candidate[1] > best[1] + 1.0e-12:
            best = candidate
        elif abs(candidate[1] - best[1]) <= 1.0e-12:
            if candidate[2] > best[2] + 1.0e-12:
                best = candidate
            elif abs(candidate[2] - best[2]) <= 1.0e-12:
                if abs(candidate[0] - 0.5) < abs(best[0] - 0.5):
                    best = candidate
    return best[0], best[1]


def binary_metrics(y_true: np.ndarray, scores: np.ndarray, threshold: float) -> Dict[str, float]:
    y = np.asarray(y_true, dtype=int)
    s = np.asarray(scores, dtype=float)
    pred = (s >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {
        "auc": float(roc_auc_score(y, s)) if len(np.unique(y)) == 2 else np.nan,
        "balanced_accuracy": float(balanced_accuracy_score(y, pred)),
        "accuracy": float(accuracy_score(y, pred)),
        "sensitivity": float(tp / max(tp + fn, 1)),
        "specificity": float(tn / max(tn + fp, 1)),
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp),
    }


def interpolate_vector(values: np.ndarray, n_out: int) -> np.ndarray:
    x = np.asarray(values, dtype=float).ravel()
    if len(x) == 0:
        return np.zeros(n_out, dtype=float)
    if len(x) == 1:
        return np.full(n_out, x[0], dtype=float)
    old = np.linspace(0.0, 1.0, len(x))
    new = np.linspace(0.0, 1.0, n_out)
    return np.interp(new, old, x)


def extract_npz_features(
    npz_path: Path,
    freq_low_hz: float,
    freq_high_hz: float,
    spectral_bin_hz: float,
    temporal_blocks: int,
) -> Tuple[np.ndarray, List[str], Dict[str, float]]:
    with np.load(npz_path, allow_pickle=False) as data:
        freq = np.asarray(data["freq_hz"], dtype=float).ravel()
        component = np.asarray(data["component_power"], dtype=float)
        if component.ndim == 1:
            component = component[:, None]
        if component.ndim != 2 or component.shape[0] != len(freq):
            raise ValueError(f"component_power维度异常: {component.shape}, freq={len(freq)}")
        plane_valid = safe_float(data["plane_valid"].item() if "plane_valid" in data.files else np.nan)
        geometry_ok = safe_float(data["plane_geometry_ok"].item() if "plane_geometry_ok" in data.files else np.nan)

    mask = (freq >= freq_low_hz) & (freq <= freq_high_hz)
    if int(np.sum(mask)) < 5:
        raise ValueError(
            f"有效频点太少：{int(np.sum(mask))}，请求频带={freq_low_hz:g}-{freq_high_hz:g}Hz"
        )
    freq = freq[mask]
    component = np.maximum(component[mask], 0.0)

    edges = np.arange(freq_low_hz, freq_high_hz + spectral_bin_hz, spectral_bin_hz)
    if edges[-1] < freq_high_hz:
        edges = np.append(edges, freq_high_hz)
    spec_power: List[float] = []
    spec_names: List[str] = []
    for left, right in zip(edges[:-1], edges[1:]):
        if right == edges[-1]:
            m = (freq >= left) & (freq <= right)
        else:
            m = (freq >= left) & (freq < right)
        val = float(np.mean(component[m])) if np.any(m) else 0.0
        spec_power.append(max(val, 0.0))
        spec_names.append(f"spec_shape_{left/1000:.1f}_{right/1000:.1f}kHz")
    spec_power_arr = np.asarray(spec_power, dtype=float)
    spec_db = power_db(spec_power_arr)
    spec_shape = np.clip(spec_db - np.median(spec_db), -50.0, 50.0)

    frame_power = np.sum(component, axis=0)
    frame_db = power_db(frame_power)
    time_shape = interpolate_vector(frame_db - np.median(frame_db), temporal_blocks)
    time_shape = np.clip(time_shape, -50.0, 50.0)
    time_names = [f"time_shape_block_{i:02d}" for i in range(temporal_blocks)]

    total = float(np.sum(component))
    mean_spec = np.mean(component, axis=1)
    spec_db_full = power_db(mean_spec)
    temporal_mean = float(np.mean(frame_power))
    temporal_std = float(np.std(frame_power))
    q10, q50, q90 = np.percentile(spec_db_full, [10, 50, 90])
    peak_index = int(np.argmax(mean_spec))
    peak_freq = float(freq[peak_index])
    scalar_values = np.asarray([
        10.0 * math.log10(total + EPS),
        float(q50),
        float(q90 - q10),
        normalized_entropy(mean_spec),
        spectral_flatness(mean_spec),
        float(np.max(mean_spec) / max(float(np.mean(mean_spec)), EPS)),
        peak_freq / 1000.0,
        float(temporal_std / max(temporal_mean, EPS)),
        float(np.percentile(frame_db, 90) - np.percentile(frame_db, 10)),
        float(np.mean(frame_power > (np.median(frame_power) + EPS))),
        float(np.mean(component > EPS)),
    ], dtype=float)
    scalar_names = [
        "log_total_power_db",
        "median_spectral_level_db",
        "spectral_dynamic_range_db",
        "spectral_entropy",
        "spectral_flatness",
        "spectral_peak_to_mean",
        "spectral_peak_frequency_khz",
        "temporal_cv",
        "temporal_dynamic_range_db",
        "temporal_above_median_fraction",
        "nonzero_time_frequency_ratio",
    ]

    values = np.concatenate([scalar_values, spec_shape, time_shape])
    names = scalar_names + spec_names + time_names
    quality = {
        "plane_valid": plane_valid,
        "plane_geometry_ok": geometry_ok,
    }
    return values, names, quality


def resolve_metadata_path(input_dir: Path) -> Path:
    candidates = [
        input_dir / "v22_EFG_all_features.csv",
        input_dir / "v9_EFG_all_features.csv",
        input_dir / "v9_ABCD_all_features.csv",
    ]
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(
        "找不到全场景特征表。应先运行v22_EFG_raw_plane_outer40.py；\n"
        + "检查过的路径：\n" + "\n".join(str(x) for x in candidates)
    )


def load_all_method_features(
    input_dir: Path,
    freq_low_hz: float,
    freq_high_hz: float,
    spectral_bin_hz: float,
    temporal_blocks: int,
) -> Tuple[pd.DataFrame, Dict[str, np.ndarray], List[str], pd.DataFrame]:
    metadata_path = resolve_metadata_path(input_dir)
    meta = pd.read_csv(metadata_path, dtype={"sample_id": str, "scene": str, "label": str})
    required = {"sample_id", "scene", "label"}
    missing = sorted(required - set(meta.columns))
    if missing:
        raise ValueError(f"元数据缺少字段: {missing}")
    meta["label"] = meta["label"].astype(str).str.upper().str.strip()
    meta = meta[meta["label"].isin(VALID_LABELS)].copy()
    meta["y_true"] = meta["label"].map(VALID_LABELS).astype(int)

    scenes = sorted(meta["scene"].astype(str).unique())
    if len(scenes) != 3:
        raise ValueError(f"必须正好有3个场景，当前检测到: {scenes}")
    for scene in scenes:
        labels = set(meta.loc[meta["scene"] == scene, "label"])
        missing_labels = set(VALID_LABELS) - labels
        if missing_labels:
            raise ValueError(f"场景 {scene} 缺少成功样本标签: {sorted(missing_labels)}")

    rows: List[Dict[str, Any]] = []
    vectors: Dict[str, List[np.ndarray]] = {m: [] for m in METHODS}
    feature_names: Optional[List[str]] = None
    errors: List[Dict[str, Any]] = []

    for _, row in meta.iterrows():
        scene = str(row["scene"])
        sample_id = str(row["sample_id"])
        scene_dir = input_dir / safe_slug(scene)
        method_paths = {
            method: scene_dir / "methods" / method / "residual_npz" / f"{safe_slug(sample_id)}.npz"
            for method in METHODS
        }
        if not all(path.exists() for path in method_paths.values()):
            errors.append({
                "sample_id": sample_id,
                "scene": scene,
                "label": row["label"],
                "error": "缺少RAW或PLANE方法NPZ",
                "raw_path": str(method_paths["raw"]),
                "plane_path": str(method_paths["plane"]),
            })
            continue
        try:
            method_values: Dict[str, np.ndarray] = {}
            qualities: Dict[str, Dict[str, float]] = {}
            for method in METHODS:
                values, names, quality = extract_npz_features(
                    method_paths[method],
                    freq_low_hz=freq_low_hz,
                    freq_high_hz=freq_high_hz,
                    spectral_bin_hz=spectral_bin_hz,
                    temporal_blocks=temporal_blocks,
                )
                if feature_names is None:
                    feature_names = names
                elif names != feature_names:
                    raise ValueError("不同样本产生的特征名称不一致")
                method_values[method] = values
                qualities[method] = quality
            if method_values["raw"].shape != method_values["plane"].shape:
                raise ValueError("RAW与PLANE特征维度不一致")
            record = row.to_dict()
            record.update({
                "raw_npz": str(method_paths["raw"]),
                "plane_npz": str(method_paths["plane"]),
                "plane_valid": qualities["plane"]["plane_valid"],
                "plane_geometry_ok": qualities["plane"]["plane_geometry_ok"],
            })
            rows.append(record)
            for method in METHODS:
                vectors[method].append(method_values[method])
        except Exception as exc:
            errors.append({
                "sample_id": sample_id,
                "scene": scene,
                "label": row["label"],
                "error": f"{type(exc).__name__}: {exc}",
                "raw_path": str(method_paths["raw"]),
                "plane_path": str(method_paths["plane"]),
            })

    valid_meta = pd.DataFrame(rows).reset_index(drop=True)
    if valid_meta.empty or feature_names is None:
        raise RuntimeError("没有任何RAW/PLANE配对样本成功读取")
    arrays = {method: np.vstack(vectors[method]) for method in METHODS}
    if arrays["raw"].shape != arrays["plane"].shape:
        raise AssertionError("RAW与PLANE总特征矩阵形状不一致")
    return valid_meta, arrays, feature_names, pd.DataFrame(errors)


def tune_on_training_scenes(
    X: np.ndarray,
    y: np.ndarray,
    scenes: np.ndarray,
    feature_names: Sequence[str],
    random_state: int,
) -> Dict[str, Any]:
    unique_scenes = sorted(np.unique(scenes).tolist())
    if len(unique_scenes) != 2:
        raise ValueError(f"内部调参要求正好2个训练场景，当前={unique_scenes}")
    best: Optional[Dict[str, Any]] = None
    for top_k in TOP_K_GRID:
        for c_value in C_GRID:
            oof = np.full(len(y), np.nan, dtype=float)
            selected_records: List[Tuple[str, List[str]]] = []
            ok = True
            for valid_scene in unique_scenes:
                train_mask = scenes != valid_scene
                valid_mask = scenes == valid_scene
                try:
                    pipe = fit_pipeline(
                        X[train_mask], y[train_mask], feature_names,
                        top_k=top_k, c_value=c_value, random_state=random_state,
                    )
                    oof[valid_mask] = predict_pipeline(pipe, X[valid_mask])
                    selected_records.append((str(valid_scene), pipe.feature_names))
                except Exception:
                    ok = False
                    break
            if not ok or not np.all(np.isfinite(oof)):
                continue
            threshold, oof_bal = best_threshold(y, oof)
            oof_auc = float(roc_auc_score(y, oof))
            candidate = {
                "top_k": int(top_k),
                "c_value": float(c_value),
                "threshold": float(threshold),
                "oof_balanced_accuracy": float(oof_bal),
                "oof_auc": oof_auc,
                "oof_scores": oof,
                "selected_records": selected_records,
            }
            if best is None:
                best = candidate
            else:
                old_key = (
                    best["oof_balanced_accuracy"],
                    best["oof_auc"],
                    -best["top_k"],
                    -abs(math.log10(best["c_value"]) - math.log10(0.1)),
                )
                new_key = (
                    candidate["oof_balanced_accuracy"],
                    candidate["oof_auc"],
                    -candidate["top_k"],
                    -abs(math.log10(candidate["c_value"]) - math.log10(0.1)),
                )
                if new_key > old_key:
                    best = candidate
    if best is None:
        raise RuntimeError("所有模型候选都训练失败")
    return best


def run_cross_scene_validation(
    meta: pd.DataFrame,
    method_arrays: Dict[str, np.ndarray],
    feature_names: Sequence[str],
    random_state: int,
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    y_all = meta["y_true"].to_numpy(dtype=int)
    scenes_all = meta["scene"].astype(str).to_numpy()
    unique_scenes = sorted(np.unique(scenes_all).tolist())
    fold_rows: List[Dict[str, Any]] = []
    prediction_rows: List[Dict[str, Any]] = []
    selected_rows: List[Dict[str, Any]] = []

    for test_scene in unique_scenes:
        train_mask = scenes_all != test_scene
        test_mask = scenes_all == test_scene
        train_scenes = sorted(np.unique(scenes_all[train_mask]).tolist())
        y_train = y_all[train_mask]
        y_test = y_all[test_mask]
        train_scene_values = scenes_all[train_mask]

        for method in METHODS:
            X = method_arrays[method]
            tuned = tune_on_training_scenes(
                X[train_mask], y_train, train_scene_values,
                feature_names=feature_names,
                random_state=random_state,
            )
            final_pipe = fit_pipeline(
                X[train_mask], y_train, feature_names,
                top_k=tuned["top_k"],
                c_value=tuned["c_value"],
                random_state=random_state,
            )
            test_scores = predict_pipeline(final_pipe, X[test_mask])
            threshold = float(tuned["threshold"])
            metrics = binary_metrics(y_test, test_scores, threshold)
            plane_valid_fraction = float(np.nanmean(meta.loc[test_mask, "plane_valid"]))
            geometry_fraction = float(np.nanmean(meta.loc[test_mask, "plane_geometry_ok"]))
            fold_rows.append({
                "method": method.upper(),
                "test_scene": test_scene,
                "train_scenes": "+".join(train_scenes),
                "selected_top_k": tuned["top_k"],
                "selected_c": tuned["c_value"],
                "threshold_from_training_oof": threshold,
                "training_oof_auc": tuned["oof_auc"],
                "training_oof_balanced_accuracy": tuned["oof_balanced_accuracy"],
                "test_auc": metrics["auc"],
                "test_balanced_accuracy": metrics["balanced_accuracy"],
                "test_accuracy": metrics["accuracy"],
                "sensitivity_TRUE": metrics["sensitivity"],
                "specificity_FALSE": metrics["specificity"],
                "tn": metrics["tn"],
                "fp": metrics["fp"],
                "fn": metrics["fn"],
                "tp": metrics["tp"],
                "n_train": int(np.sum(train_mask)),
                "n_test": int(np.sum(test_mask)),
                "n_test_true": int(np.sum(y_test == 1)),
                "n_test_false": int(np.sum(y_test == 0)),
                "plane_valid_fraction_in_test": plane_valid_fraction,
                "plane_geometry_ok_fraction_in_test": geometry_fraction,
            })
            coef = final_pipe.model.coef_[0]
            for rank, (name, coefficient) in enumerate(
                sorted(zip(final_pipe.feature_names, coef), key=lambda x: abs(x[1]), reverse=True),
                start=1,
            ):
                selected_rows.append({
                    "method": method.upper(),
                    "test_scene": test_scene,
                    "train_scenes": "+".join(train_scenes),
                    "rank": rank,
                    "feature": name,
                    "coefficient": float(coefficient),
                    "absolute_coefficient": float(abs(coefficient)),
                })

            test_indices = np.flatnonzero(test_mask)
            preds = (test_scores >= threshold).astype(int)
            for local_i, global_i in enumerate(test_indices):
                base = meta.iloc[global_i]
                prediction_rows.append({
                    "sample_id": base["sample_id"],
                    "dataset": base.get("dataset", ""),
                    "scene": base["scene"],
                    "time_folder": base.get("time_folder", ""),
                    "second_index": base.get("second_index", np.nan),
                    "center": base.get("center", ""),
                    "label": base["label"],
                    "y_true": int(base["y_true"]),
                    "method": method.upper(),
                    "train_scenes": "+".join(train_scenes),
                    "test_scene": test_scene,
                    "probability_TRUE": float(test_scores[local_i]),
                    "threshold": threshold,
                    "prediction": "TRUE_LEAK" if preds[local_i] == 1 else "FALSE_LEAK",
                    "correct": int(preds[local_i] == y_test[local_i]),
                    "plane_valid": base.get("plane_valid", np.nan),
                    "plane_geometry_ok": base.get("plane_geometry_ok", np.nan),
                })

    return pd.DataFrame(fold_rows), pd.DataFrame(prediction_rows), pd.DataFrame(selected_rows)


def make_paired_predictions(pred_long: pd.DataFrame) -> pd.DataFrame:
    id_cols = [
        "sample_id", "dataset", "scene", "time_folder", "second_index",
        "center", "label", "y_true", "test_scene",
    ]
    available = [c for c in id_cols if c in pred_long.columns]
    raw = pred_long[pred_long["method"] == "RAW"].copy()
    plane = pred_long[pred_long["method"] == "PLANE"].copy()
    raw = raw[available + ["probability_TRUE", "threshold", "prediction", "correct"]].rename(columns={
        "probability_TRUE": "raw_probability_TRUE",
        "threshold": "raw_threshold",
        "prediction": "raw_prediction",
        "correct": "raw_correct",
    })
    plane = plane[available + ["probability_TRUE", "threshold", "prediction", "correct", "plane_valid", "plane_geometry_ok"]].rename(columns={
        "probability_TRUE": "plane_probability_TRUE",
        "threshold": "plane_threshold",
        "prediction": "plane_prediction",
        "correct": "plane_correct",
    })
    paired = raw.merge(plane, on=available, how="inner", validate="one_to_one")
    paired["plane_minus_raw_probability"] = paired["plane_probability_TRUE"] - paired["raw_probability_TRUE"]
    conditions = [
        (paired["raw_correct"] == 1) & (paired["plane_correct"] == 1),
        (paired["raw_correct"] == 0) & (paired["plane_correct"] == 1),
        (paired["raw_correct"] == 1) & (paired["plane_correct"] == 0),
    ]
    choices = ["BOTH_CORRECT", "PLANE_FIXED_RAW_ERROR", "PLANE_BROKE_RAW_CORRECT"]
    paired["change_category"] = np.select(conditions, choices, default="BOTH_WRONG")
    return paired


def bootstrap_mean_scene_balanced_accuracy_difference(
    paired: pd.DataFrame,
    n_bootstrap: int,
    random_state: int,
) -> Dict[str, float]:
    rng = np.random.default_rng(random_state)
    scenes = sorted(paired["scene"].astype(str).unique())
    strata: Dict[Tuple[str, int], np.ndarray] = {}
    for scene in scenes:
        for y in (0, 1):
            idx = np.flatnonzero((paired["scene"].astype(str).to_numpy() == scene) & (paired["y_true"].to_numpy() == y))
            if len(idx) == 0:
                raise ValueError(f"bootstrap缺少分层: scene={scene}, y={y}")
            strata[(scene, y)] = idx

    diffs: List[float] = []
    y_all = paired["y_true"].to_numpy(dtype=int)
    raw_pred = (paired["raw_prediction"].astype(str) == "TRUE_LEAK").to_numpy(dtype=int)
    plane_pred = (paired["plane_prediction"].astype(str) == "TRUE_LEAK").to_numpy(dtype=int)
    scene_arr = paired["scene"].astype(str).to_numpy()
    for _ in range(int(n_bootstrap)):
        chosen: List[int] = []
        for key, idx in strata.items():
            chosen.extend(rng.choice(idx, size=len(idx), replace=True).tolist())
        chosen_arr = np.asarray(chosen, dtype=int)
        scene_diffs: List[float] = []
        for scene in scenes:
            m = scene_arr[chosen_arr] == scene
            yy = y_all[chosen_arr][m]
            rb = balanced_accuracy_score(yy, raw_pred[chosen_arr][m])
            pb = balanced_accuracy_score(yy, plane_pred[chosen_arr][m])
            scene_diffs.append(float(pb - rb))
        diffs.append(float(np.mean(scene_diffs)))
    arr = np.asarray(diffs, dtype=float)
    return {
        "bootstrap_delta_balacc_mean": float(np.mean(arr)),
        "bootstrap_delta_balacc_ci_low": float(np.percentile(arr, 2.5)),
        "bootstrap_delta_balacc_ci_high": float(np.percentile(arr, 97.5)),
        "bootstrap_repetitions": int(n_bootstrap),
    }


def build_final_summary(
    fold_df: pd.DataFrame,
    paired: pd.DataFrame,
    bootstrap: Dict[str, float],
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    pivot_bal = fold_df.pivot(index="test_scene", columns="method", values="test_balanced_accuracy")
    pivot_auc = fold_df.pivot(index="test_scene", columns="method", values="test_auc")
    scene_rows: List[Dict[str, Any]] = []
    for scene in pivot_bal.index:
        raw_bal = float(pivot_bal.loc[scene, "RAW"])
        plane_bal = float(pivot_bal.loc[scene, "PLANE"])
        raw_auc = float(pivot_auc.loc[scene, "RAW"])
        plane_auc = float(pivot_auc.loc[scene, "PLANE"])
        scene_rows.append({
            "test_scene": scene,
            "raw_balanced_accuracy": raw_bal,
            "plane_balanced_accuracy": plane_bal,
            "plane_minus_raw_balanced_accuracy": plane_bal - raw_bal,
            "raw_auc": raw_auc,
            "plane_auc": plane_auc,
            "plane_minus_raw_auc": plane_auc - raw_auc,
            "scene_judgement": (
                "PLANE更好" if plane_bal - raw_bal >= 0.05 else
                "PLANE更差" if plane_bal - raw_bal <= -0.05 else
                "差别不明显"
            ),
        })
    scene_compare = pd.DataFrame(scene_rows)
    mean_raw_bal = float(scene_compare["raw_balanced_accuracy"].mean())
    mean_plane_bal = float(scene_compare["plane_balanced_accuracy"].mean())
    mean_delta_bal = mean_plane_bal - mean_raw_bal
    mean_raw_auc = float(scene_compare["raw_auc"].mean())
    mean_plane_auc = float(scene_compare["plane_auc"].mean())
    mean_delta_auc = mean_plane_auc - mean_raw_auc
    improved = int(np.sum(scene_compare["plane_minus_raw_balanced_accuracy"] >= 0.05))
    worsened = int(np.sum(scene_compare["plane_minus_raw_balanced_accuracy"] <= -0.05))
    severe_drop = float(scene_compare["plane_minus_raw_balanced_accuracy"].min())

    if mean_delta_bal >= 0.05 and improved >= 2 and severe_drop > -0.05:
        judgement = "PLANE明显有效"
        explanation = "三个整场景测试中至少两个明显提升，平均平衡准确率也提升，且没有场景明显变差。"
    elif mean_delta_bal <= -0.05 and worsened >= 2:
        judgement = "PLANE破坏了真假泄漏特征"
        explanation = "三个整场景测试中至少两个明显下降，平均平衡准确率也下降。"
    elif improved >= 1 and worsened >= 1:
        judgement = "PLANE跨场景不稳定"
        explanation = "有的场景变好、有的场景变差，不能作为统一的通用降噪方法。"
    else:
        judgement = "PLANE没有明显帮助"
        explanation = "RAW与PLANE平均差别不足5个百分点，现有数据不能证明空间拟合带来稳定收益。"

    change_counts = paired["change_category"].value_counts()
    summary = pd.DataFrame([{
        "最终结论": judgement,
        "人话解释": explanation,
        "RAW三场景平均平衡准确率": mean_raw_bal,
        "PLANE三场景平均平衡准确率": mean_plane_bal,
        "PLANE减RAW平均平衡准确率": mean_delta_bal,
        "RAW三场景平均AUC": mean_raw_auc,
        "PLANE三场景平均AUC": mean_plane_auc,
        "PLANE减RAW平均AUC": mean_delta_auc,
        "PLANE明显变好场景数": improved,
        "PLANE明显变差场景数": worsened,
        "PLANE修正RAW错误样本数": int(change_counts.get("PLANE_FIXED_RAW_ERROR", 0)),
        "PLANE破坏RAW正确样本数": int(change_counts.get("PLANE_BROKE_RAW_CORRECT", 0)),
        "配对样本总数": int(len(paired)),
        **bootstrap,
        "判断规则": "主要看整场景留出平衡准确率；提升或下降达到0.05视为明显变化。",
    }])
    return summary, scene_compare


def save_plots(fold_df: pd.DataFrame, paired: pd.DataFrame, output_dir: Path) -> None:
    plot_dir = output_dir / "figures"
    ensure_dir(plot_dir)
    scenes = sorted(fold_df["test_scene"].astype(str).unique())
    x = np.arange(len(scenes), dtype=float)
    width = 0.36

    fig, ax = plt.subplots(figsize=(9.0, 5.5))
    raw_vals = [float(fold_df[(fold_df.method == "RAW") & (fold_df.test_scene == s)]["test_balanced_accuracy"].iloc[0]) for s in scenes]
    plane_vals = [float(fold_df[(fold_df.method == "PLANE") & (fold_df.test_scene == s)]["test_balanced_accuracy"].iloc[0]) for s in scenes]
    ax.bar(x - width/2, raw_vals, width=width, label="RAW")
    ax.bar(x + width/2, plane_vals, width=width, label="PLANE")
    ax.set_xticks(x)
    ax.set_xticklabels(scenes)
    ax.set_ylim(0.0, 1.05)
    ax.set_ylabel("Balanced accuracy")
    ax.set_title("RAW vs PLANE：整场景留出平衡准确率")
    ax.grid(True, axis="y", alpha=0.3)
    ax.legend()
    for xpos, vals in [(x-width/2, raw_vals), (x+width/2, plane_vals)]:
        for xx, val in zip(xpos, vals):
            ax.text(xx, val + 0.02, f"{val:.3f}", ha="center", fontsize=9)
    fig.tight_layout()
    fig.savefig(plot_dir / "01_RAW_vs_PLANE_balanced_accuracy.png", dpi=160)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(9.0, 5.5))
    raw_vals = [float(fold_df[(fold_df.method == "RAW") & (fold_df.test_scene == s)]["test_auc"].iloc[0]) for s in scenes]
    plane_vals = [float(fold_df[(fold_df.method == "PLANE") & (fold_df.test_scene == s)]["test_auc"].iloc[0]) for s in scenes]
    ax.bar(x - width/2, raw_vals, width=width, label="RAW")
    ax.bar(x + width/2, plane_vals, width=width, label="PLANE")
    ax.set_xticks(x)
    ax.set_xticklabels(scenes)
    ax.set_ylim(0.0, 1.05)
    ax.set_ylabel("AUC")
    ax.set_title("RAW vs PLANE：整场景留出AUC")
    ax.grid(True, axis="y", alpha=0.3)
    ax.legend()
    for xpos, vals in [(x-width/2, raw_vals), (x+width/2, plane_vals)]:
        for xx, val in zip(xpos, vals):
            ax.text(xx, val + 0.02, f"{val:.3f}", ha="center", fontsize=9)
    fig.tight_layout()
    fig.savefig(plot_dir / "02_RAW_vs_PLANE_AUC.png", dpi=160)
    plt.close(fig)

    order = ["BOTH_CORRECT", "PLANE_FIXED_RAW_ERROR", "PLANE_BROKE_RAW_CORRECT", "BOTH_WRONG"]
    counts = [int(np.sum(paired["change_category"] == key)) for key in order]
    fig, ax = plt.subplots(figsize=(10.0, 5.5))
    bars = ax.bar(np.arange(len(order)), counts)
    ax.set_xticks(np.arange(len(order)))
    ax.set_xticklabels(["都正确", "PLANE修正RAW错误", "PLANE破坏RAW正确", "都错误"], rotation=10)
    ax.set_ylabel("样本数")
    ax.set_title("同一样本从RAW换成PLANE后发生了什么")
    ax.grid(True, axis="y", alpha=0.3)
    for bar, count in zip(bars, counts):
        ax.text(bar.get_x()+bar.get_width()/2, count+0.2, str(count), ha="center")
    fig.tight_layout()
    fig.savefig(plot_dir / "03_sample_change_counts.png", dpi=160)
    plt.close(fig)


def write_text_report(summary: pd.DataFrame, scene_compare: pd.DataFrame, output_dir: Path) -> None:
    row = summary.iloc[0]
    lines = [
        "v22 E/F/G RAW 与 PLANE 公平对照结果",
        "=" * 60,
        "",
        f"最终结论：{row['最终结论']}",
        f"解释：{row['人话解释']}",
        "",
        f"RAW三场景平均平衡准确率：{row['RAW三场景平均平衡准确率']:.4f}",
        f"PLANE三场景平均平衡准确率：{row['PLANE三场景平均平衡准确率']:.4f}",
        f"PLANE - RAW：{row['PLANE减RAW平均平衡准确率']:+.4f}",
        "",
        "每个测试场景：",
    ]
    for _, r in scene_compare.iterrows():
        lines.append(
            f"  {r['test_scene']}: RAW={r['raw_balanced_accuracy']:.4f}, "
            f"PLANE={r['plane_balanced_accuracy']:.4f}, "
            f"差值={r['plane_minus_raw_balanced_accuracy']:+.4f}, "
            f"结论={r['scene_judgement']}"
        )
    lines.extend([
        "",
        "怎么看：",
        "  1. PLANE比RAW稳定提高，空间拟合才算有效。",
        "  2. 有的场景提高、有的场景下降，说明方法不稳定。",
        "  3. PLANE整体更差，说明空间拟合把有用泄漏特征一起减掉了。",
        "",
        "注意：本程序完全不用消声室距离，也不做不合理的单点人工注入。",
    ])
    (output_dir / "00_最先看这个.txt").write_text("\n".join(lines), encoding="utf-8")


def run_evaluation(
    input_dir: Path,
    output_dir: Path,
    freq_low_hz: float,
    freq_high_hz: float,
    spectral_bin_hz: float,
    temporal_blocks: int,
    bootstrap_repetitions: int,
    random_state: int,
) -> Dict[str, Path]:
    ensure_dir(output_dir)
    meta, arrays, feature_names, errors = load_all_method_features(
        input_dir=input_dir,
        freq_low_hz=freq_low_hz,
        freq_high_hz=freq_high_hz,
        spectral_bin_hz=spectral_bin_hz,
        temporal_blocks=temporal_blocks,
    )
    fold_df, pred_long, selected_df = run_cross_scene_validation(
        meta=meta,
        method_arrays=arrays,
        feature_names=feature_names,
        random_state=random_state,
    )
    paired = make_paired_predictions(pred_long)
    bootstrap = bootstrap_mean_scene_balanced_accuracy_difference(
        paired, n_bootstrap=bootstrap_repetitions, random_state=random_state
    )
    summary, scene_compare = build_final_summary(fold_df, paired, bootstrap)

    paths = {
        "summary": output_dir / "00_最先看这个.csv",
        "scene_compare": output_dir / "01_每个场景_RAW_vs_PLANE.csv",
        "fold_metrics": output_dir / "02_完整跨场景指标.csv",
        "predictions": output_dir / "03_全部样本预测_long.csv",
        "paired": output_dir / "04_同一样本_RAW_vs_PLANE.csv",
        "selected_features": output_dir / "05_每折模型选中的特征.csv",
        "input_samples": output_dir / "06_实际使用的配对样本.csv",
        "errors": output_dir / "99_读取错误.csv",
    }
    summary.to_csv(paths["summary"], index=False, encoding="utf-8-sig")
    scene_compare.to_csv(paths["scene_compare"], index=False, encoding="utf-8-sig")
    fold_df.to_csv(paths["fold_metrics"], index=False, encoding="utf-8-sig")
    pred_long.to_csv(paths["predictions"], index=False, encoding="utf-8-sig")
    paired.to_csv(paths["paired"], index=False, encoding="utf-8-sig")
    selected_df.to_csv(paths["selected_features"], index=False, encoding="utf-8-sig")
    meta.to_csv(paths["input_samples"], index=False, encoding="utf-8-sig")
    errors.to_csv(paths["errors"], index=False, encoding="utf-8-sig")
    save_plots(fold_df, paired, output_dir)
    write_text_report(summary, scene_compare, output_dir)
    run_info = {
        "input_dir": str(input_dir),
        "output_dir": str(output_dir),
        "n_paired_samples": int(len(meta)),
        "scenes": sorted(meta["scene"].astype(str).unique().tolist()),
        "feature_count_per_method": int(len(feature_names)),
        "feature_names": feature_names,
        "frequency_band_hz": [freq_low_hz, freq_high_hz],
        "spectral_bin_hz": spectral_bin_hz,
        "temporal_blocks": temporal_blocks,
        "bootstrap_repetitions": bootstrap_repetitions,
        "random_state": random_state,
    }
    (output_dir / "00_run_info.json").write_text(
        json.dumps(run_info, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print("\n" + "=" * 80)
    print(summary.iloc[0]["最终结论"])
    print(summary.iloc[0]["人话解释"])
    print("最先查看:", paths["summary"])
    print("=" * 80)
    return paths


def load_config(config_path: Path) -> Dict[str, Any]:
    payload = json.loads(config_path.read_text(encoding="utf-8"))
    input_dir = Path(str(payload["output_dir"]))
    compare = dict(payload.get("comparison", {}))
    output_dir = Path(str(compare.get("output_dir", input_dir / "RAW_vs_PLANE_comparison")))
    return {
        "input_dir": input_dir,
        "output_dir": output_dir,
        "freq_low_hz": float(compare.get("freq_low_hz", 20_000.0)),
        "freq_high_hz": float(compare.get("freq_high_hz", 80_000.0)),
        "spectral_bin_hz": float(compare.get("spectral_bin_hz", 1_000.0)),
        "temporal_blocks": int(compare.get("temporal_blocks", 12)),
        "bootstrap_repetitions": int(compare.get("bootstrap_repetitions", 2000)),
        "random_state": int(compare.get("random_state", 42)),
    }


def make_self_test_dataset(root: Path, random_state: int = 42) -> None:
    rng = np.random.default_rng(random_state)
    scenes = ["factory_E", "factory_F", "factory_G"]
    rows: List[Dict[str, Any]] = []
    freq = np.linspace(20_000.0, 80_000.0, 241)
    n_frames = 20
    for scene_idx, scene in enumerate(scenes):
        for y, label in [(0, "FALSE_LEAK"), (1, "TRUE_LEAK")]:
            for i in range(18):
                sample_id = f"{scene}_{label}_{i:03d}"
                rows.append({
                    "sample_id": sample_id,
                    "dataset": f"{scene}_{label}",
                    "scene": scene,
                    "time_folder": f"folder_{i//3:02d}",
                    "second_index": i,
                    "center": f"00_{i:02d}",
                    "label": label,
                })
                base = 1.0 + 0.20 * scene_idx
                noise = rng.lognormal(mean=-0.1, sigma=0.55, size=(len(freq), n_frames))
                false_peak = np.exp(-0.5 * ((freq - (50_000 + 1000*scene_idx)) / 2600.0) ** 2)[:, None]
                leak_peak = np.exp(-0.5 * ((freq - 60_000.0) / 6500.0) ** 2)[:, None]
                raw = base * noise + 1.4 * false_peak
                if y == 1:
                    raw = raw + 0.9 * leak_peak
                plane = 0.25 * noise + 0.25 * false_peak
                if y == 1:
                    plane = plane + 1.3 * leak_peak
                center_db = power_db(raw)
                for method, component in [("raw", raw), ("plane", plane)]:
                    path = root / safe_slug(scene) / "methods" / method / "residual_npz" / f"{safe_slug(sample_id)}.npz"
                    ensure_dir(path.parent)
                    np.savez_compressed(
                        path,
                        sample_id=np.asarray(sample_id),
                        method=np.asarray(method),
                        freq_hz=freq,
                        time_s=np.arange(n_frames) / n_frames,
                        component_power=component,
                        center_power_db=center_db,
                        plane_valid=np.asarray(1),
                        plane_geometry_ok=np.asarray(1),
                    )
    pd.DataFrame(rows).to_csv(root / "v22_EFG_all_features.csv", index=False, encoding="utf-8-sig")


def run_self_test() -> None:
    print("开始 v22 E/F/G RAW vs PLANE 自检...")
    with tempfile.TemporaryDirectory(prefix="v22_efg_compare_") as td:
        root = Path(td) / "input"
        out = Path(td) / "output"
        ensure_dir(root)
        make_self_test_dataset(root)
        paths = run_evaluation(
            input_dir=root,
            output_dir=out,
            freq_low_hz=20_000.0,
            freq_high_hz=80_000.0,
            spectral_bin_hz=1_000.0,
            temporal_blocks=12,
            bootstrap_repetitions=100,
            random_state=42,
        )
        for path in paths.values():
            if not path.exists():
                raise AssertionError(f"自检缺少输出: {path}")
        summary = pd.read_csv(paths["summary"])
        if len(summary) != 1:
            raise AssertionError("自检汇总行数异常")
        fold = pd.read_csv(paths["fold_metrics"])
        if len(fold) != 6:
            raise AssertionError(f"应有3场景×2方法=6行，当前={len(fold)}")
    print("SELF-TEST PASSED：三场景留出、RAW/PLANE配对和全部输出均正常。")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="E/F/G真实TRUE/FALSE：RAW与PLANE公平对照")
    parser.add_argument("--config", default="v22_EFG_raw_plane_anechoic_config.json")
    parser.add_argument("--self-test", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.self_test:
        run_self_test()
        return
    cfg = load_config(Path(args.config))
    run_evaluation(**cfg)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n用户中止。")
        sys.exit(130)
    except Exception as exc:
        print("\n程序失败:", f"{type(exc).__name__}: {exc}")
        traceback.print_exc()
        sys.exit(1)
