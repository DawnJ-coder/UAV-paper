﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ============================================================
echo A+B FALSE学习背景，C+D独立测试，实验室BF验证
echo ============================================================
python false_background_leak_pipeline.py --config false_background_config.json

echo.
echo 程序结束。
pause
