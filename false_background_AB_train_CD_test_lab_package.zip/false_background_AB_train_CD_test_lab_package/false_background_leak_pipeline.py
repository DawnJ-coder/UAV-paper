# -*- coding: utf-8 -*-
"""
false_background_leak_pipeline.py

目标
====
不再假设“距离40 cm处就是纯环境噪声”，而是：

1. 使用场景A+B的FALSE样本，学习：
       周围全部空间点的频谱状态 -> 无泄漏时中心背景频谱
2. A、B内部采用留一场景方式生成OOF背景预测：
       A样本由B的FALSE训练模型预测
       B样本由A的FALSE训练模型预测
3. 使用A+B全部FALSE训练最终冻结模型。
4. 冻结模型分别预测场景C和D，C/D不参与训练或参数选择。
5. 同时比较三种方法：
       raw              中心原始频谱
       plane            原outer40空间平面残差
       false_prediction FALSE学习背景后的残差
6. A+B发现候选频带，C+D独立验证。
7. 对每个实验室_bf.wav分别计算与AB候选模板的相似度。
8. 检查“被减掉的背景”是否反而比残差更像实验室泄漏。

输入要求
========
每个场景目录必须是v9结果目录，至少包含：
    v9_all_features.csv
    v9_run_config.json

v9_all_features.csv中必须保留：
    sample_id, label, time, center, center_file, offset_dir

center_file和offset_dir对应的原始WAV仍需存在。
本程序会重新读取中心及周围WAV，构建每个空间点的1 kHz频带功率。

运行
====
python false_background_leak_pipeline.py --self-test
python false_background_leak_pipeline.py --config false_background_config.json
"""

from __future__ import annotations

import argparse
import json
import math
import re
import sys
import traceback
from dataclasses import asdict, dataclass, fields
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    from scipy.io import wavfile
    from scipy.signal import welch
    from scipy.spatial.distance import jensenshannon
except Exception as exc:
    raise RuntimeError("缺少scipy，请运行：pip install scipy") from exc

try:
    from sklearn.linear_model import Ridge
    from sklearn.metrics import balanced_accuracy_score, roc_auc_score
    from sklearn.preprocessing import StandardScaler
except Exception as exc:
    raise RuntimeError("缺少scikit-learn，请运行：pip install scikit-learn") from exc

try:
    import matplotlib.pyplot as plt
except Exception as exc:
    raise RuntimeError("缺少matplotlib，请运行：pip install matplotlib") from exc

try:
    import joblib
except Exception as exc:
    raise RuntimeError("缺少joblib，请运行：pip install joblib") from exc

try:
    import v9_ABCD_raw_plane_outer40 as v9
except Exception as exc:
    raise RuntimeError(
        "无法导入v9_ABCD_raw_plane_outer40.py。请把该文件与本程序放在同一目录。"
    ) from exc


EPS = 1.0e-20
VALID_LABELS = {"TRUE_LEAK", "FALSE_LEAK"}
METHODS = ("raw", "plane", "false_prediction")
DIRECTIONS = (
    "up", "down", "left", "right",
    "up_left", "down_left", "up_right", "down_right",
)


@dataclass(frozen=True)
class RunConfig:
    freq_low_hz: float = 20_000.0
    freq_high_hz: float = 80_000.0
    band_width_hz: float = 1_000.0

    # Ridge正则候选。每个频带分别通过A<->B的FALSE留一场景误差选择。
    ridge_alphas: Tuple[float, ...] = (
        0.01, 0.1, 1.0, 10.0, 100.0, 1000.0
    )

    # AB候选频带条件
    min_train_scene_auc: float = 0.60
    min_train_scene_effect: float = 0.10

    # C/D外部验证支持条件
    min_test_scene_auc: float = 0.55
    min_test_scene_effect: float = 0.00
    min_factory_support_count: int = 3

    # 实验室支持：实验室所有WAV的中位归一化频谱位于全部频带的多少分位以上。
    # 0.60表示该频带至少位于实验室中位频谱的前40%。
    lab_support_quantile: float = 0.60

    # 实验室文件过滤
    lab_required_suffix: str = "_bf.wav"
    lab_recursive: bool = True

    # Welch参数：与v9尽量保持一致。
    lab_nperseg: int = 4096
    lab_noverlap_ratio: float = 0.5
    lab_nfft: int = 4096

    # 读取限制；0表示不限制。调试时可设为较小值。
    max_samples_per_scene: int = 0
    random_state: int = 42


@dataclass
class SampleRecord:
    scene: str
    sample_id: str
    label: str
    time: str
    center: str
    center_file: str
    offset_dir: str
    center_band_power: np.ndarray
    plane_background_band_power: np.ndarray
    features: np.ndarray                 # shape=(n_bands,n_features)
    feature_names: List[str]


@dataclass
class BandModel:
    scaler: StandardScaler
    ridge: Ridge
    alpha: float


@dataclass
class BackgroundModel:
    band_models: List[BandModel]
    feature_names: List[str]
    band_edges_hz: np.ndarray
    training_scenes: List[str]


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def safe_float_array(x: Any) -> np.ndarray:
    return np.asarray(x, dtype=np.float64)


def normalize_nonnegative(x: np.ndarray) -> np.ndarray:
    arr = np.maximum(np.asarray(x, dtype=float), 0.0)
    s = float(np.sum(arr))
    if s <= EPS:
        return np.zeros_like(arr)
    return arr / s


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    x = np.asarray(a, dtype=float)
    y = np.asarray(b, dtype=float)
    den = float(np.linalg.norm(x) * np.linalg.norm(y))
    if den <= EPS:
        return float("nan")
    return float(np.dot(x, y) / den)


def pearson_safe(a: np.ndarray, b: np.ndarray) -> float:
    x = np.asarray(a, dtype=float)
    y = np.asarray(b, dtype=float)
    valid = np.isfinite(x) & np.isfinite(y)
    x = x[valid]
    y = y[valid]
    if x.size < 3 or np.std(x) <= EPS or np.std(y) <= EPS:
        return float("nan")
    return float(np.corrcoef(x, y)[0, 1])


def overlap_similarity(a: np.ndarray, b: np.ndarray) -> float:
    x = normalize_nonnegative(a)
    y = normalize_nonnegative(b)
    if np.sum(x) <= EPS or np.sum(y) <= EPS:
        return float("nan")
    return float(np.sum(np.minimum(x, y)))


def js_similarity(a: np.ndarray, b: np.ndarray) -> float:
    x = normalize_nonnegative(a)
    y = normalize_nonnegative(b)
    if np.sum(x) <= EPS or np.sum(y) <= EPS:
        return float("nan")
    distance = float(jensenshannon(x + EPS, y + EPS, base=2.0))
    return float(1.0 - distance)


def safe_auc(labels: Sequence[str], scores: np.ndarray) -> float:
    y = np.asarray([1 if str(v) == "TRUE_LEAK" else 0 for v in labels], dtype=int)
    s = np.asarray(scores, dtype=float)
    valid = np.isfinite(s)
    y = y[valid]
    s = s[valid]
    if len(np.unique(y)) < 2:
        return float("nan")
    try:
        return float(roc_auc_score(y, s))
    except Exception:
        return float("nan")


def best_balanced_accuracy(labels: Sequence[str], scores: np.ndarray) -> Tuple[float, float]:
    y = np.asarray([1 if str(v) == "TRUE_LEAK" else 0 for v in labels], dtype=int)
    s = np.asarray(scores, dtype=float)
    valid = np.isfinite(s)
    y = y[valid]
    s = s[valid]
    if y.size == 0 or len(np.unique(y)) < 2:
        return float("nan"), float("nan")
    candidates = np.unique(np.quantile(s, np.linspace(0.0, 1.0, min(101, len(s) + 2))))
    best_ba = -np.inf
    best_thr = float("nan")
    for thr in candidates:
        pred = (s >= thr).astype(int)
        ba = float(balanced_accuracy_score(y, pred))
        if ba > best_ba:
            best_ba = ba
            best_thr = float(thr)
    return best_ba, best_thr


def robust_scale(x: np.ndarray) -> float:
    arr = np.asarray(x, dtype=float)
    med = float(np.nanmedian(arr))
    mad = float(np.nanmedian(np.abs(arr - med)))
    return max(1.4826 * mad, float(np.nanstd(arr)), EPS)


def band_edges(cfg: RunConfig) -> np.ndarray:
    n = int(math.ceil((cfg.freq_high_hz - cfg.freq_low_hz) / cfg.band_width_hz))
    edges = cfg.freq_low_hz + np.arange(n + 1, dtype=float) * cfg.band_width_hz
    edges[-1] = cfg.freq_high_hz
    return edges


def aggregate_power_to_bands(
    freq_hz: np.ndarray,
    power: np.ndarray,
    edges: np.ndarray,
    freq_axis: int = 0,
) -> np.ndarray:
    """把线性功率聚合为频带均值。最后一维为band。"""
    freq = np.asarray(freq_hz, dtype=float)
    arr = np.asarray(power, dtype=float)
    arr = np.moveaxis(arr, freq_axis, 0)
    out_shape = arr.shape[1:] + (len(edges) - 1,)
    out = np.zeros(out_shape, dtype=float)
    for k in range(len(edges) - 1):
        lo, hi = edges[k], edges[k + 1]
        mask = (freq >= lo) & (freq < hi if k < len(edges) - 2 else freq <= hi)
        if np.any(mask):
            out[..., k] = np.nanmean(np.maximum(arr[mask], 0.0), axis=0)
    return out


def parse_direction(point_id: str) -> Optional[str]:
    text = str(point_id).lower()
    for direction in sorted(DIRECTIONS, key=len, reverse=True):
        if text.endswith("_" + direction) or text == direction or direction in text:
            return direction
    return None


def build_features_from_cube(
    sample: Dict[str, Any],
    v9_cfg: Any,
    cfg: RunConfig,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, List[str]]:
    """
    返回：
      center_band_power: (n_bands,)
      plane_background_band_power: (n_bands,)
      features: (n_bands,n_features)
      feature_names
    """
    power = np.maximum(np.asarray(sample["power"], dtype=float), 0.0)
    freq = np.asarray(sample["freq_hz"], dtype=float)
    xy = np.asarray(sample["xy"], dtype=float)
    point_ids = np.asarray(sample.get("point_ids", []), dtype=str)
    center_index = int(sample.get("center_index", 0))
    edges = band_edges(cfg)

    # 每个点每个band每个时帧的功率，随后对时间取中位数。
    # aggregate结果：(n_points,n_frames,n_bands)
    point_frame_band = aggregate_power_to_bands(freq, power, edges, freq_axis=1)
    point_band = np.nanmedian(point_frame_band, axis=1)  # (n_points,n_bands)

    center_band = np.maximum(point_band[center_index], 0.0)
    neighbor_idx = np.array([i for i in range(len(point_band)) if i != center_index], dtype=int)
    neighbors = np.maximum(point_band[neighbor_idx], 0.0)

    # 当前plane背景，仅作为一个输入特征和对照，不再被视为正确答案。
    estimate = v9.estimate_local_background(power, xy, center_index, v9_cfg)
    plane_bg_power = np.maximum(
        np.asarray(estimate["background_power_plane"], dtype=float), 0.0
    )
    plane_frame_band = aggregate_power_to_bands(freq, plane_bg_power, edges, freq_axis=0)
    plane_band = np.nanmedian(plane_frame_band, axis=0)

    distances = np.linalg.norm(xy - xy[center_index], axis=1)
    neighbor_dist = distances[neighbor_idx]
    neighbor_ids = point_ids[neighbor_idx] if len(point_ids) == len(point_band) else np.asarray(
        [f"point_{i}" for i in neighbor_idx], dtype=str
    )

    feature_columns: List[np.ndarray] = []
    names: List[str] = []

    def add(name: str, values: np.ndarray) -> None:
        names.append(name)
        feature_columns.append(np.asarray(values, dtype=float))

    # 全部周围点的稳健统计。
    add("neighbor_median", np.nanmedian(neighbors, axis=0))
    add("neighbor_q25", np.nanquantile(neighbors, 0.25, axis=0))
    add("neighbor_q75", np.nanquantile(neighbors, 0.75, axis=0))
    add("neighbor_mean", np.nanmean(neighbors, axis=0))
    add("neighbor_std", np.nanstd(neighbors, axis=0))
    add("neighbor_min", np.nanmin(neighbors, axis=0))
    add("neighbor_max", np.nanmax(neighbors, axis=0))
    med = np.nanmedian(neighbors, axis=0)
    add("neighbor_mad", np.nanmedian(np.abs(neighbors - med[None, :]), axis=0))

    # 八方向分别取所有距离点的中位数。
    global_med = np.nanmedian(neighbors, axis=0)
    for direction in DIRECTIONS:
        mask = np.array([parse_direction(pid) == direction for pid in neighbor_ids], dtype=bool)
        values = np.nanmedian(neighbors[mask], axis=0) if np.any(mask) else global_med
        add(f"direction_{direction}_median", values)

    # 四个距离环，不要求能量随距离单调，仅描述当前空间状态。
    ring_bounds = [(0, 10), (10, 20), (20, 30), (30, np.inf)]
    for lo, hi in ring_bounds:
        mask = (neighbor_dist > lo) & (neighbor_dist <= hi)
        values = np.nanmedian(neighbors[mask], axis=0) if np.any(mask) else global_med
        hi_name = "inf" if not np.isfinite(hi) else f"{int(hi)}"
        add(f"ring_{int(lo)}_{hi_name}_median", values)

    # 左右、上下方向差异，描述空间梯度，但不强制使用平面。
    def dir_value(direction: str) -> np.ndarray:
        mask = np.array([parse_direction(pid) == direction for pid in neighbor_ids], dtype=bool)
        return np.nanmedian(neighbors[mask], axis=0) if np.any(mask) else global_med

    left = np.nanmedian(np.vstack([dir_value("left"), dir_value("up_left"), dir_value("down_left")]), axis=0)
    right = np.nanmedian(np.vstack([dir_value("right"), dir_value("up_right"), dir_value("down_right")]), axis=0)
    up = np.nanmedian(np.vstack([dir_value("up"), dir_value("up_left"), dir_value("up_right")]), axis=0)
    down = np.nanmedian(np.vstack([dir_value("down"), dir_value("down_left"), dir_value("down_right")]), axis=0)
    add("left_minus_right", left - right)
    add("up_minus_down", up - down)

    add("current_plane_background", plane_band)

    features = np.column_stack(feature_columns)
    features = np.nan_to_num(features, nan=0.0, posinf=0.0, neginf=0.0)
    return center_band, plane_band, features, names


def read_v9_metadata(v9_dir: Path) -> pd.DataFrame:
    path = v9_dir / "v9_all_features.csv"
    if not path.exists():
        raise FileNotFoundError(f"找不到：{path}")
    df = pd.read_csv(
        path,
        dtype={
            "sample_id": str,
            "time": str,
            "center": str,
            "center_file": str,
            "offset_dir": str,
            "label": str,
        },
    )
    required = ["sample_id", "label", "time", "center", "center_file", "offset_dir"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"{path}缺少列：{missing}")
    df["label"] = df["label"].astype(str).str.upper().str.strip()
    df = df[df["label"].isin(VALID_LABELS)].copy()
    return df


def load_v9_config(v9_dir: Path) -> Any:
    path = v9_dir / "v9_run_config.json"
    base = v9.V9Config(save_residual_npz=True)
    if not path.exists():
        print(f"提醒：{path}不存在，使用v9默认参数。")
        return base
    payload = json.loads(path.read_text(encoding="utf-8"))
    overrides = dict(payload.get("config", {}))
    valid = {f.name for f in fields(v9.V9Config)}
    overrides = {k: v for k, v in overrides.items() if k in valid}
    # JSON会把tuple变成list。
    if "residual_thresholds_db" in overrides:
        overrides["residual_thresholds_db"] = tuple(overrides["residual_thresholds_db"])
    return v9.V9Config(**{**asdict(base), **overrides, "save_residual_npz": True})


def load_scene_records(
    scene: str,
    v9_dir: Path,
    cfg: RunConfig,
) -> Tuple[List[SampleRecord], pd.DataFrame]:
    metadata = read_v9_metadata(v9_dir)
    v9_cfg = load_v9_config(v9_dir)
    records: List[SampleRecord] = []
    failures: List[Dict[str, str]] = []

    if cfg.max_samples_per_scene > 0:
        # 保持每类尽可能平衡。
        parts = []
        each = max(1, cfg.max_samples_per_scene // 2)
        for label in sorted(VALID_LABELS):
            parts.append(metadata[metadata["label"] == label].head(each))
        metadata = pd.concat(parts, ignore_index=True)

    offset_cache: Dict[str, Any] = {}
    center_cache: Dict[str, Any] = {}

    for _, row in metadata.iterrows():
        sample_id = str(row["sample_id"])
        try:
            center_file = Path(str(row["center_file"]))
            offset_dir = Path(str(row["offset_dir"]))
            center_id = v9.normalize_center_id(str(row["center"]))

            if not center_file.exists():
                raise FileNotFoundError(f"中心WAV不存在：{center_file}")
            if not offset_dir.is_dir():
                raise FileNotFoundError(f"周围点目录不存在：{offset_dir}")

            center_dir_key = str(center_file.parent)
            if center_dir_key not in center_cache:
                center_cache[center_dir_key] = v9.detect_center_files(center_file.parent)
            center_map = center_cache[center_dir_key]
            center_paths = center_map.get(center_id, [center_file])

            offset_key = str(offset_dir)
            if offset_key not in offset_cache:
                offset_cache[offset_key] = v9.parse_offset_files(offset_dir)

            cube = v9.load_one_center_cube(
                center_paths=center_paths,
                offset_mapping=offset_cache[offset_key],
                center_id=center_id,
                config=v9_cfg,
            )
            center_band, plane_band, feature_matrix, feature_names = build_features_from_cube(
                cube, v9_cfg, cfg
            )

            records.append(
                SampleRecord(
                    scene=scene,
                    sample_id=sample_id,
                    label=str(row["label"]),
                    time=str(row["time"]),
                    center=str(row["center"]),
                    center_file=str(center_file),
                    offset_dir=str(offset_dir),
                    center_band_power=center_band,
                    plane_background_band_power=plane_band,
                    features=feature_matrix,
                    feature_names=feature_names,
                )
            )
            print(f"  成功：{scene} | {row['label']} | {sample_id}")
        except Exception as exc:
            failures.append(
                {
                    "scene": scene,
                    "sample_id": sample_id,
                    "label": str(row.get("label", "")),
                    "error": f"{type(exc).__name__}: {exc}",
                    "traceback": traceback.format_exc(),
                }
            )
            print(f"  失败：{scene} | {sample_id} | {type(exc).__name__}: {exc}")

    if not records:
        raise RuntimeError(f"场景{scene}没有成功读取任何样本")
    return records, pd.DataFrame(failures)


def records_to_arrays(
    records: Sequence[SampleRecord],
) -> Tuple[np.ndarray, np.ndarray]:
    X = np.stack([r.features for r in records], axis=0)  # n,bands,features
    Y = np.stack([r.center_band_power for r in records], axis=0)
    return X, Y


def fit_one_band(X: np.ndarray, y: np.ndarray, alpha: float) -> BandModel:
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)
    ridge = Ridge(alpha=float(alpha), fit_intercept=True)
    ridge.fit(Xs, y)
    return BandModel(scaler=scaler, ridge=ridge, alpha=float(alpha))


def predict_one_band(model: BandModel, X: np.ndarray) -> np.ndarray:
    pred = model.ridge.predict(model.scaler.transform(X))
    return np.maximum(np.asarray(pred, dtype=float), 0.0)


def select_alpha_for_band(
    train_false_by_scene: Dict[str, List[SampleRecord]],
    band_index: int,
    cfg: RunConfig,
) -> float:
    scenes = list(train_false_by_scene)
    if len(scenes) < 2:
        return float(cfg.ridge_alphas[len(cfg.ridge_alphas) // 2])

    best_alpha = None
    best_error = np.inf

    for alpha in cfg.ridge_alphas:
        errors = []
        for held_scene in scenes:
            train_records = [
                r for s, rs in train_false_by_scene.items() if s != held_scene for r in rs
            ]
            test_records = list(train_false_by_scene[held_scene])
            if len(train_records) < 2 or not test_records:
                continue
            Xtr = np.stack([r.features[band_index] for r in train_records])
            ytr = np.asarray([r.center_band_power[band_index] for r in train_records])
            Xte = np.stack([r.features[band_index] for r in test_records])
            yte = np.asarray([r.center_band_power[band_index] for r in test_records])
            model = fit_one_band(Xtr, ytr, alpha)
            pred = predict_one_band(model, Xte)
            scale = max(float(np.median(np.abs(yte))), EPS)
            errors.extend((np.abs(pred - yte) / scale).tolist())
        error = float(np.mean(errors)) if errors else np.inf
        if error < best_error:
            best_error = error
            best_alpha = float(alpha)

    return float(best_alpha if best_alpha is not None else cfg.ridge_alphas[-1])


def fit_background_model(
    false_records_by_scene: Dict[str, List[SampleRecord]],
    edges: np.ndarray,
    cfg: RunConfig,
) -> Tuple[BackgroundModel, pd.DataFrame]:
    all_false = [r for records in false_records_by_scene.values() for r in records]
    if len(all_false) < 4:
        raise ValueError("A+B的FALSE样本太少，无法训练背景模型")

    n_bands = len(edges) - 1
    feature_names = all_false[0].feature_names
    band_models: List[BandModel] = []
    alpha_rows = []

    for b in range(n_bands):
        alpha = select_alpha_for_band(false_records_by_scene, b, cfg)
        X = np.stack([r.features[b] for r in all_false])
        y = np.asarray([r.center_band_power[b] for r in all_false])
        model = fit_one_band(X, y, alpha)
        band_models.append(model)
        alpha_rows.append(
            {
                "band_index": b,
                "freq_low_hz": edges[b],
                "freq_high_hz": edges[b + 1],
                "selected_alpha": alpha,
                "n_false_training_samples": len(all_false),
            }
        )

    return (
        BackgroundModel(
            band_models=band_models,
            feature_names=feature_names,
            band_edges_hz=edges,
            training_scenes=list(false_records_by_scene),
        ),
        pd.DataFrame(alpha_rows),
    )


def predict_background(model: BackgroundModel, records: Sequence[SampleRecord]) -> np.ndarray:
    if not records:
        return np.empty((0, len(model.band_models)), dtype=float)
    out = np.zeros((len(records), len(model.band_models)), dtype=float)
    for b, band_model in enumerate(model.band_models):
        X = np.stack([r.features[b] for r in records])
        out[:, b] = predict_one_band(band_model, X)
    return np.maximum(out, 0.0)


def oof_predict_training_scenes(
    records_by_scene: Dict[str, List[SampleRecord]],
    edges: np.ndarray,
    cfg: RunConfig,
) -> Tuple[Dict[str, np.ndarray], pd.DataFrame]:
    """A样本用B的FALSE训练，B样本用A的FALSE训练。"""
    predictions: Dict[str, np.ndarray] = {}
    alpha_frames = []
    scenes = list(records_by_scene)
    if len(scenes) < 2:
        raise ValueError("训练场景至少需要两个")

    for held_scene in scenes:
        train_false_by_scene = {
            scene: [r for r in records if r.label == "FALSE_LEAK"]
            for scene, records in records_by_scene.items()
            if scene != held_scene
        }
        held_records = records_by_scene[held_scene]
        model, alpha_df = fit_background_model(train_false_by_scene, edges, cfg)
        predictions[held_scene] = predict_background(model, held_records)
        alpha_df.insert(0, "held_out_training_scene", held_scene)
        alpha_frames.append(alpha_df)

    return predictions, pd.concat(alpha_frames, ignore_index=True)


def component_spectra(
    records: Sequence[SampleRecord],
    predicted_background: np.ndarray,
) -> Dict[str, np.ndarray]:
    center = np.stack([r.center_band_power for r in records])
    plane_bg = np.stack([r.plane_background_band_power for r in records])
    return {
        "raw": np.maximum(center, 0.0),
        "plane": np.maximum(center - plane_bg, 0.0),
        "false_prediction": np.maximum(center - predicted_background, 0.0),
        "predicted_background": np.maximum(predicted_background, 0.0),
        "plane_background": np.maximum(plane_bg, 0.0),
    }


def relative_component(component: np.ndarray, center: np.ndarray) -> np.ndarray:
    den = np.sum(center, axis=1, keepdims=True) + EPS
    return np.maximum(component, 0.0) / den


def sample_prediction_rows(
    records: Sequence[SampleRecord],
    pred_bg: np.ndarray,
    source: str,
) -> pd.DataFrame:
    products = component_spectra(records, pred_bg)
    center = np.stack([r.center_band_power for r in records])
    rows = []
    for i, r in enumerate(records):
        base = {
            "scene": r.scene,
            "sample_id": r.sample_id,
            "label": r.label,
            "time": r.time,
            "center": r.center,
            "prediction_source": source,
            "center_total_power": float(np.sum(center[i])),
            "false_predicted_background_total_power": float(np.sum(products["predicted_background"][i])),
            "plane_background_total_power": float(np.sum(products["plane_background"][i])),
        }
        for method in METHODS:
            comp = products[method][i]
            base[f"{method}_component_total_power"] = float(np.sum(comp))
            base[f"{method}_component_fraction_of_center"] = float(
                np.sum(comp) / (np.sum(center[i]) + EPS)
            )
        rows.append(base)
    return pd.DataFrame(rows)


def false_background_metrics(
    records: Sequence[SampleRecord],
    pred_bg: np.ndarray,
    source: str,
) -> pd.DataFrame:
    rows = []
    for i, r in enumerate(records):
        if r.label != "FALSE_LEAK":
            continue
        center = np.maximum(r.center_band_power, 0.0)
        pred = np.maximum(pred_bg[i], 0.0)
        plane = np.maximum(r.plane_background_band_power, 0.0)
        for name, bg in [("false_prediction", pred), ("plane", plane)]:
            residual = np.maximum(center - bg, 0.0)
            rows.append(
                {
                    "scene": r.scene,
                    "sample_id": r.sample_id,
                    "prediction_source": source,
                    "background_method": name,
                    "relative_absolute_error": float(
                        np.sum(np.abs(center - bg)) / (np.sum(center) + EPS)
                    ),
                    "background_to_center_ratio": float(
                        np.sum(bg) / (np.sum(center) + EPS)
                    ),
                    "positive_residual_fraction": float(
                        np.sum(residual) / (np.sum(center) + EPS)
                    ),
                }
            )
    return pd.DataFrame(rows)


def summarize_false_metrics(details: pd.DataFrame) -> pd.DataFrame:
    if details.empty:
        return pd.DataFrame()
    return (
        details.groupby(["scene", "prediction_source", "background_method"], as_index=False)
        .agg(
            n_false=("sample_id", "count"),
            relative_absolute_error_median=("relative_absolute_error", "median"),
            relative_absolute_error_mean=("relative_absolute_error", "mean"),
            background_to_center_ratio_median=("background_to_center_ratio", "median"),
            positive_residual_fraction_median=("positive_residual_fraction", "median"),
        )
    )


def scene_method_separation(
    records_by_scene: Dict[str, List[SampleRecord]],
    pred_by_scene: Dict[str, np.ndarray],
) -> pd.DataFrame:
    rows = []
    for scene, records in records_by_scene.items():
        products = component_spectra(records, pred_by_scene[scene])
        center = np.stack([r.center_band_power for r in records])
        labels = [r.label for r in records]
        for method in METHODS:
            # 使用残差占中心比例作为总体分数，减少不同样本绝对增益差异。
            score = np.sum(products[method], axis=1) / (np.sum(center, axis=1) + EPS)
            auc = safe_auc(labels, score)
            ba, threshold = best_balanced_accuracy(labels, score)
            true_values = score[np.asarray(labels) == "TRUE_LEAK"]
            false_values = score[np.asarray(labels) == "FALSE_LEAK"]
            rows.append(
                {
                    "scene": scene,
                    "method": method,
                    "n_true": int(len(true_values)),
                    "n_false": int(len(false_values)),
                    "auc": auc,
                    "best_balanced_accuracy_descriptive": ba,
                    "best_threshold_descriptive": threshold,
                    "true_score_median": float(np.median(true_values)) if len(true_values) else np.nan,
                    "false_score_median": float(np.median(false_values)) if len(false_values) else np.nan,
                    "true_minus_false_median": (
                        float(np.median(true_values) - np.median(false_values))
                        if len(true_values) and len(false_values) else np.nan
                    ),
                }
            )
    return pd.DataFrame(rows)


def directional_auc(labels: Sequence[str], values: np.ndarray) -> float:
    auc = safe_auc(labels, values)
    if not np.isfinite(auc):
        return float("nan")
    return float(auc)


def band_effect_table(
    records_by_scene: Dict[str, List[SampleRecord]],
    pred_by_scene: Dict[str, np.ndarray],
    edges: np.ndarray,
    cfg: RunConfig,
    training_scenes: Sequence[str],
    test_scenes: Sequence[str],
) -> pd.DataFrame:
    scene_products: Dict[str, Dict[str, np.ndarray]] = {}
    for scene, records in records_by_scene.items():
        products = component_spectra(records, pred_by_scene[scene])
        center = np.stack([r.center_band_power for r in records])
        scene_products[scene] = {
            method: relative_component(products[method], center) for method in METHODS
        }

    rows = []
    for method in METHODS:
        for b in range(len(edges) - 1):
            row: Dict[str, Any] = {
                "method": method,
                "band_index": b,
                "freq_low_hz": edges[b],
                "freq_high_hz": edges[b + 1],
                "freq_center_khz": 0.5 * (edges[b] + edges[b + 1]) / 1000.0,
            }
            train_selected = True
            support_count = 0
            effects = []
            for scene, records in records_by_scene.items():
                labels = np.asarray([r.label for r in records])
                values = scene_products[scene][method][:, b]
                true_v = values[labels == "TRUE_LEAK"]
                false_v = values[labels == "FALSE_LEAK"]
                delta = (
                    float(np.median(true_v) - np.median(false_v))
                    if len(true_v) and len(false_v) else np.nan
                )
                scale = robust_scale(np.concatenate([true_v, false_v])) if len(true_v) and len(false_v) else np.nan
                effect = delta / scale if np.isfinite(delta) and np.isfinite(scale) else np.nan
                auc = directional_auc(labels, values)
                row[f"{scene}_delta"] = delta
                row[f"{scene}_effect"] = effect
                row[f"{scene}_auc"] = auc
                effects.append(effect)

                if scene in training_scenes:
                    supported = (
                        np.isfinite(effect)
                        and effect >= cfg.min_train_scene_effect
                        and np.isfinite(auc)
                        and auc >= cfg.min_train_scene_auc
                    )
                    train_selected = train_selected and supported
                else:
                    supported = (
                        np.isfinite(effect)
                        and effect >= cfg.min_test_scene_effect
                        and np.isfinite(auc)
                        and auc >= cfg.min_test_scene_auc
                    )

                if supported:
                    support_count += 1

            row["AB_selected"] = int(train_selected)
            row["factory_support_count"] = int(support_count)
            row["factory_effect_median"] = float(np.nanmedian(effects))
            row["CD_validated"] = int(
                train_selected
                and sum(
                    int(
                        np.isfinite(row.get(f"{s}_effect", np.nan))
                        and row.get(f"{s}_effect", np.nan) >= cfg.min_test_scene_effect
                        and np.isfinite(row.get(f"{s}_auc", np.nan))
                        and row.get(f"{s}_auc", np.nan) >= cfg.min_test_scene_auc
                    )
                    for s in test_scenes
                ) >= 1
            )
            rows.append(row)
    return pd.DataFrame(rows)


def build_ab_templates(
    records_by_scene: Dict[str, List[SampleRecord]],
    pred_by_scene: Dict[str, np.ndarray],
    band_table: pd.DataFrame,
    training_scenes: Sequence[str],
) -> Tuple[pd.DataFrame, Dict[str, np.ndarray], Dict[str, np.ndarray]]:
    rows = []
    templates: Dict[str, np.ndarray] = {}
    removed_templates: Dict[str, np.ndarray] = {}

    n_bands = int(band_table["band_index"].max()) + 1
    for method in METHODS:
        selected = (
            band_table[band_table["method"] == method]
            .sort_values("band_index")["AB_selected"]
            .to_numpy(dtype=int)
            .astype(bool)
        )
        effects_by_scene = []
        true_profiles = []
        removed_profiles = []

        for scene in training_scenes:
            records = records_by_scene[scene]
            labels = np.asarray([r.label for r in records])
            products = component_spectra(records, pred_by_scene[scene])
            center = np.stack([r.center_band_power for r in records])
            rel = relative_component(products[method], center)
            true_profiles.append(np.median(rel[labels == "TRUE_LEAK"], axis=0))
            if method == "false_prediction":
                removed = np.maximum(products["predicted_background"], 0.0)
            elif method == "plane":
                removed = np.maximum(products["plane_background"], 0.0)
            else:
                removed = np.zeros_like(center)
            removed_profiles.append(
                np.median(
                    removed[labels == "TRUE_LEAK"]
                    / (np.sum(center[labels == "TRUE_LEAK"], axis=1, keepdims=True) + EPS),
                    axis=0,
                )
            )

            bt = band_table[
                (band_table["method"] == method)
            ].sort_values("band_index")
            effects_by_scene.append(
                np.maximum(bt[f"{scene}_effect"].to_numpy(dtype=float), 0.0)
            )

        effect = np.nanmedian(np.vstack(effects_by_scene), axis=0)
        profile = np.nanmedian(np.vstack(true_profiles), axis=0)
        template = np.maximum(effect, 0.0) * np.maximum(profile, 0.0) * selected.astype(float)

        # 若条件过严导致空模板，退回AB正效应，不让程序崩溃，同时在报告中警告。
        fallback_used = 0
        if np.sum(template) <= EPS:
            template = np.maximum(effect, 0.0) * np.maximum(profile, 0.0)
            fallback_used = 1
        template = normalize_nonnegative(template)

        removed_template = normalize_nonnegative(np.nanmedian(np.vstack(removed_profiles), axis=0))
        templates[method] = template
        removed_templates[method] = removed_template

        for b in range(n_bands):
            rows.append(
                {
                    "method": method,
                    "band_index": b,
                    "AB_selected": int(selected[b]),
                    "AB_effect_nonnegative": float(effect[b]),
                    "AB_true_profile": float(profile[b]),
                    "AB_common_template": float(template[b]),
                    "AB_removed_background_template": float(removed_template[b]),
                    "fallback_without_AB_mask": fallback_used,
                }
            )

    return pd.DataFrame(rows), templates, removed_templates


def read_wav_float(path: Path) -> Tuple[int, np.ndarray]:
    fs, y = wavfile.read(path)
    arr = np.asarray(y)
    if arr.ndim > 1:
        arr = np.mean(arr.astype(float), axis=1)
    if np.issubdtype(arr.dtype, np.integer):
        info = np.iinfo(arr.dtype)
        scale = float(max(abs(info.min), abs(info.max)))
        arr = arr.astype(np.float64) / max(scale, 1.0)
    else:
        arr = arr.astype(np.float64)
    arr = np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)
    arr -= np.mean(arr)
    return int(fs), arr


def lab_wav_profile(path: Path, edges: np.ndarray, cfg: RunConfig) -> np.ndarray:
    fs, y = read_wav_float(path)
    if len(y) < 32:
        raise ValueError("WAV过短")
    nperseg = min(cfg.lab_nperseg, len(y))
    noverlap = min(int(nperseg * cfg.lab_noverlap_ratio), nperseg - 1)
    freq, psd = welch(
        y,
        fs=fs,
        window="hann",
        nperseg=nperseg,
        noverlap=noverlap,
        nfft=max(cfg.lab_nfft, nperseg),
        detrend="constant",
        scaling="density",
    )
    band = aggregate_power_to_bands(freq, psd, edges, freq_axis=0)
    return normalize_nonnegative(np.maximum(band, 0.0))


def find_lab_wavs(lab_groups: Dict[str, Sequence[str]], cfg: RunConfig) -> List[Tuple[str, Path]]:
    out: List[Tuple[str, Path]] = []
    suffix = cfg.lab_required_suffix.lower().strip()
    for group, roots in lab_groups.items():
        for root_str in roots:
            root = Path(root_str)
            if root.is_file() and root.suffix.lower() == ".wav":
                candidates = [root]
            elif root.is_dir():
                candidates = list(root.rglob("*.wav")) if cfg.lab_recursive else list(root.glob("*.wav"))
            else:
                print(f"提醒：实验室路径不存在：{root}")
                continue
            for path in candidates:
                if suffix and not path.name.lower().endswith(suffix):
                    continue
                out.append((str(group), path))
    # 去重
    unique = {}
    for group, path in out:
        unique[(group, str(path.resolve()))] = (group, path)
    return sorted(unique.values(), key=lambda x: (x[0], str(x[1])))


def aggregate_profile(profile: np.ndarray, base_width_hz: float, target_width_hz: float) -> np.ndarray:
    factor = max(1, int(round(target_width_hz / base_width_hz)))
    p = np.asarray(profile, dtype=float)
    chunks = [np.sum(p[i:i + factor]) for i in range(0, len(p), factor)]
    return normalize_nonnegative(np.asarray(chunks, dtype=float))


def similarity_metrics(template: np.ndarray, profile: np.ndarray, cfg: RunConfig) -> Dict[str, float]:
    out = {
        "pearson_1k": pearson_safe(template, profile),
        "cosine_1k": cosine_similarity(template, profile),
        "overlap_1k": overlap_similarity(template, profile),
        "js_similarity_1k": js_similarity(template, profile),
    }
    for width in (2_000.0, 5_000.0, 10_000.0):
        tag = f"{int(width / 1000)}k"
        a = aggregate_profile(template, cfg.band_width_hz, width)
        b = aggregate_profile(profile, cfg.band_width_hz, width)
        out[f"pearson_{tag}"] = pearson_safe(a, b)
        out[f"cosine_{tag}"] = cosine_similarity(a, b)
        out[f"overlap_{tag}"] = overlap_similarity(a, b)
        out[f"js_similarity_{tag}"] = js_similarity(a, b)
    return out


def evaluate_lab(
    lab_groups: Dict[str, Sequence[str]],
    templates: Dict[str, np.ndarray],
    removed_templates: Dict[str, np.ndarray],
    edges: np.ndarray,
    cfg: RunConfig,
) -> Tuple[pd.DataFrame, pd.DataFrame, np.ndarray, pd.DataFrame]:
    wavs = find_lab_wavs(lab_groups, cfg)
    rows = []
    failures = []
    profiles = []

    for group, path in wavs:
        try:
            profile = lab_wav_profile(path, edges, cfg)
            profiles.append(profile)
            for method in METHODS:
                result = {
                    "method": method,
                    "lab_group": group,
                    "wav_name": path.name,
                    "wav_file": str(path),
                }
                for key, value in similarity_metrics(templates[method], profile, cfg).items():
                    result[f"residual_{key}"] = value
                for key, value in similarity_metrics(removed_templates[method], profile, cfg).items():
                    result[f"removed_background_{key}"] = value
                rows.append(result)
            print(f"  实验室成功：{group} | {path.name}")
        except Exception as exc:
            failures.append(
                {
                    "lab_group": group,
                    "wav_file": str(path),
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )
            print(f"  实验室失败：{path.name} | {exc}")

    detail = pd.DataFrame(rows)
    failure_df = pd.DataFrame(failures)
    lab_median = np.median(np.vstack(profiles), axis=0) if profiles else np.zeros(len(edges) - 1)
    lab_median = normalize_nonnegative(lab_median)

    summary_rows = []
    if not detail.empty:
        metric_cols = [
            c for c in detail.columns
            if c.startswith("residual_") or c.startswith("removed_background_")
        ]
        scopes = []
        for method in METHODS:
            method_df = detail[detail["method"] == method]
            for group in sorted(method_df["lab_group"].unique()):
                scopes.append((method, group, method_df[method_df["lab_group"] == group]))
            scopes.append((method, "ALL_FILES", method_df))

        for method, group, frame in scopes:
            row: Dict[str, Any] = {
                "method": method,
                "lab_group": group,
                "n_wavs": int(frame["wav_file"].nunique()),
            }
            for col in metric_cols:
                values = pd.to_numeric(frame[col], errors="coerce")
                valid = values.dropna()
                row[f"{col}_median"] = float(valid.median()) if len(valid) else np.nan
                row[f"{col}_max"] = float(valid.max()) if len(valid) else np.nan
                if len(valid):
                    idx = valid.idxmax()
                    row[f"{col}_max_wav_name"] = frame.loc[idx, "wav_name"]
                    row[f"{col}_max_wav_file"] = frame.loc[idx, "wav_file"]
                else:
                    row[f"{col}_max_wav_name"] = ""
                    row[f"{col}_max_wav_file"] = ""
            summary_rows.append(row)

    return detail, pd.DataFrame(summary_rows), lab_median, failure_df


def add_lab_and_final_support(
    band_table: pd.DataFrame,
    lab_median: np.ndarray,
    cfg: RunConfig,
) -> pd.DataFrame:
    out = band_table.copy()
    if np.sum(lab_median) <= EPS:
        out["lab_median_normalized_power"] = 0.0
        out["lab_percentile_rank"] = np.nan
        out["lab_supported"] = 0
        out["final_candidate"] = 0
        return out

    order = np.argsort(np.argsort(lab_median))
    percentile = order / max(len(lab_median) - 1, 1)
    map_power = {i: lab_median[i] for i in range(len(lab_median))}
    map_pct = {i: percentile[i] for i in range(len(lab_median))}
    out["lab_median_normalized_power"] = out["band_index"].map(map_power)
    out["lab_percentile_rank"] = out["band_index"].map(map_pct)
    out["lab_supported"] = (out["lab_percentile_rank"] >= cfg.lab_support_quantile).astype(int)
    out["final_candidate"] = (
        (out["AB_selected"] == 1)
        & (out["factory_support_count"] >= cfg.min_factory_support_count)
        & (out["lab_supported"] == 1)
    ).astype(int)
    return out


def save_model(model: BackgroundModel, path: Path) -> None:
    ensure_dir(path.parent)
    joblib.dump(model, path)


def plot_false_metrics(summary: pd.DataFrame, output_dir: Path) -> None:
    if summary.empty:
        return
    fig, ax = plt.subplots(figsize=(10, 5))
    labels = [
        f"{r.scene}\n{r.background_method}"
        for r in summary.itertuples()
    ]
    values = summary["positive_residual_fraction_median"].to_numpy(dtype=float)
    ax.bar(np.arange(len(values)), values)
    ax.set_xticks(np.arange(len(values)))
    ax.set_xticklabels(labels, rotation=30, ha="right")
    ax.set_ylabel("FALSE positive residual fraction (median)")
    ax.set_title("FALSE背景预测后剩余比例：越低越好")
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_dir / "false_residual_fraction.png", dpi=160)
    plt.close(fig)


def plot_templates(
    templates: Dict[str, np.ndarray],
    edges: np.ndarray,
    output_dir: Path,
) -> None:
    centers = 0.5 * (edges[:-1] + edges[1:]) / 1000.0
    fig, ax = plt.subplots(figsize=(11, 5))
    for method, values in templates.items():
        ax.plot(centers, values, label=method)
    ax.set_xlabel("Frequency (kHz)")
    ax.set_ylabel("Normalized AB common template")
    ax.set_title("A+B候选共同频谱模板")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_dir / "AB_common_templates.png", dpi=160)
    plt.close(fig)


def recommendation_text(
    false_summary: pd.DataFrame,
    separation: pd.DataFrame,
    lab_summary: pd.DataFrame,
    band_table: pd.DataFrame,
) -> str:
    lines = []
    lines.append("结果判断顺序")
    lines.append("=" * 80)
    lines.append("")
    lines.append("1. 先看 03_false_background_metrics_summary.csv")
    lines.append("   positive_residual_fraction_median越低越好；")
    lines.append("   background_to_center_ratio_median应接近1；")
    lines.append("   如果false_prediction在C/D的FALSE上也明显优于plane，才说明新背景模型可靠。")
    lines.append("")
    lines.append("2. 再看 04_scene_method_TRUE_FALSE_separation.csv")
    lines.append("   false_prediction需要在A/B/C/D中TRUE分数高于FALSE，并保持较高AUC。")
    lines.append("")
    lines.append("3. 再看 08_lab_similarity_summary.csv")
    lines.append("   residual_*：保留下来的残差与实验室泄漏的相似度；")
    lines.append("   removed_background_*：被减掉部分与实验室泄漏的相似度。")
    lines.append("   理想情况：residual相似度高于removed_background。")
    lines.append("")
    lines.append("4. 最后看 05_band_effects_factory_lab_support.csv")
    lines.append("   AB_selected=1：A与B同时支持；")
    lines.append("   factory_support_count>=3：至少三个工厂场景支持；")
    lines.append("   lab_supported=1：实验室多数WAV的中位频谱也支持；")
    lines.append("   final_candidate=1：最终候选频带，但仍不能直接称为纯泄漏。")
    lines.append("")

    if not false_summary.empty:
        fp = false_summary[false_summary["background_method"] == "false_prediction"]
        pl = false_summary[false_summary["background_method"] == "plane"]
        if not fp.empty and not pl.empty:
            fp_med = float(fp["positive_residual_fraction_median"].median())
            pl_med = float(pl["positive_residual_fraction_median"].median())
            lines.append(
                f"总体FALSE剩余比例中位数：false_prediction={fp_med:.4f}，plane={pl_med:.4f}。"
            )
            if fp_med < pl_med:
                lines.append("初步判断：新FALSE背景模型比当前plane更能解释无泄漏中心背景。")
            else:
                lines.append("警告：新FALSE背景模型没有优于plane，不建议直接替换。")
    n_final = int(band_table.get("final_candidate", pd.Series(dtype=int)).sum())
    lines.append(f"最终候选频带数量：{n_final}")
    lines.append("")
    lines.append("重要：不要只看A/B相似度。方法必须同时通过FALSE背景误差、C/D外部测试和实验室验证。")
    return "\n".join(lines)


def load_config(path: Path) -> Tuple[Dict[str, Path], List[str], List[str], Dict[str, List[str]], Path, RunConfig]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    scenes = {str(k): Path(str(v)) for k, v in payload["scenes"].items()}
    training_scenes = [str(v) for v in payload.get("training_scenes", ["factory_A", "factory_B"])]
    test_scenes = [str(v) for v in payload.get("test_scenes", ["factory_C", "factory_D"])]
    lab_groups = {
        str(k): [str(x) for x in v]
        for k, v in payload.get("lab_groups", {}).items()
    }
    output_dir = Path(str(payload.get("output_dir", "false_background_results")))
    base = RunConfig()
    overrides = dict(payload.get("algorithm", {}))
    valid = {f.name for f in fields(RunConfig)}
    unknown = sorted(set(overrides) - valid)
    if unknown:
        raise ValueError(f"未知algorithm参数：{unknown}")
    if "ridge_alphas" in overrides:
        overrides["ridge_alphas"] = tuple(float(x) for x in overrides["ridge_alphas"])
    cfg = RunConfig(**{**asdict(base), **overrides})
    return scenes, training_scenes, test_scenes, lab_groups, output_dir, cfg


def run_pipeline(config_path: Path) -> None:
    scenes, training_scenes, test_scenes, lab_groups, output_dir, cfg = load_config(config_path)
    ensure_dir(output_dir)
    ensure_dir(output_dir / "figures")
    ensure_dir(output_dir / "models")

    required_scenes = training_scenes + test_scenes
    missing = [s for s in required_scenes if s not in scenes]
    if missing:
        raise ValueError(f"配置scenes中缺少：{missing}")

    edges = band_edges(cfg)
    records_by_scene: Dict[str, List[SampleRecord]] = {}
    failure_frames = []
    preflight_rows = []

    print("=" * 90)
    print("读取A/B/C/D原始中心与周围WAV")
    print("=" * 90)
    for scene in required_scenes:
        print(f"\n场景：{scene}")
        records, failures = load_scene_records(scene, scenes[scene], cfg)
        records_by_scene[scene] = records
        if not failures.empty:
            failure_frames.append(failures)
        preflight_rows.append(
            {
                "scene": scene,
                "v9_dir": str(scenes[scene]),
                "n_success": len(records),
                "n_true": sum(r.label == "TRUE_LEAK" for r in records),
                "n_false": sum(r.label == "FALSE_LEAK" for r in records),
                "n_failed": len(failures),
            }
        )

    pd.DataFrame(preflight_rows).to_csv(
        output_dir / "00_preflight_scene_summary.csv", index=False, encoding="utf-8-sig"
    )
    failures_all = pd.concat(failure_frames, ignore_index=True) if failure_frames else pd.DataFrame()
    failures_all.to_csv(
        output_dir / "00_sample_loading_failures.csv", index=False, encoding="utf-8-sig"
    )

    # A/B OOF预测
    train_records = {s: records_by_scene[s] for s in training_scenes}
    oof_pred, oof_alpha = oof_predict_training_scenes(train_records, edges, cfg)
    oof_alpha.to_csv(
        output_dir / "01_AB_OOF_selected_ridge_alpha.csv", index=False, encoding="utf-8-sig"
    )

    # A+B全部FALSE训练最终冻结模型
    false_by_scene = {
        s: [r for r in records_by_scene[s] if r.label == "FALSE_LEAK"]
        for s in training_scenes
    }
    final_model, final_alpha = fit_background_model(false_by_scene, edges, cfg)
    final_alpha.to_csv(
        output_dir / "01_final_AB_selected_ridge_alpha.csv", index=False, encoding="utf-8-sig"
    )
    save_model(final_model, output_dir / "models" / "AB_FALSE_background_model.joblib")

    pred_by_scene: Dict[str, np.ndarray] = {}
    source_by_scene: Dict[str, str] = {}
    for s in training_scenes:
        pred_by_scene[s] = oof_pred[s]
        source_by_scene[s] = "AB_leave_one_scene_out_OOF"
    for s in test_scenes:
        pred_by_scene[s] = predict_background(final_model, records_by_scene[s])
        source_by_scene[s] = "frozen_AB_FALSE_model"

    # 样本级结果与FALSE诊断
    prediction_frames = []
    false_detail_frames = []
    for scene in required_scenes:
        prediction_frames.append(
            sample_prediction_rows(records_by_scene[scene], pred_by_scene[scene], source_by_scene[scene])
        )
        false_detail_frames.append(
            false_background_metrics(records_by_scene[scene], pred_by_scene[scene], source_by_scene[scene])
        )
    sample_predictions = pd.concat(prediction_frames, ignore_index=True)
    false_details = pd.concat(false_detail_frames, ignore_index=True)
    false_summary = summarize_false_metrics(false_details)

    sample_predictions.to_csv(
        output_dir / "02_sample_predictions_all_methods.csv", index=False, encoding="utf-8-sig"
    )
    false_details.to_csv(
        output_dir / "03_false_background_metrics_each_sample.csv", index=False, encoding="utf-8-sig"
    )
    false_summary.to_csv(
        output_dir / "03_false_background_metrics_summary.csv", index=False, encoding="utf-8-sig"
    )

    separation = scene_method_separation(records_by_scene, pred_by_scene)
    separation.to_csv(
        output_dir / "04_scene_method_TRUE_FALSE_separation.csv", index=False, encoding="utf-8-sig"
    )

    band_table = band_effect_table(
        records_by_scene, pred_by_scene, edges, cfg, training_scenes, test_scenes
    )
    template_df, templates, removed_templates = build_ab_templates(
        records_by_scene, pred_by_scene, band_table, training_scenes
    )

    print("\n" + "=" * 90)
    print("逐个读取实验室_bf.wav并计算相似度")
    print("=" * 90)
    lab_detail, lab_summary, lab_median, lab_failures = evaluate_lab(
        lab_groups, templates, removed_templates, edges, cfg
    )
    band_table = add_lab_and_final_support(band_table, lab_median, cfg)

    band_table.to_csv(
        output_dir / "05_band_effects_factory_lab_support.csv", index=False, encoding="utf-8-sig"
    )
    template_df.insert(2, "freq_low_hz", template_df["band_index"].map(
        {i: edges[i] for i in range(len(edges) - 1)}
    ))
    template_df.insert(3, "freq_high_hz", template_df["band_index"].map(
        {i: edges[i + 1] for i in range(len(edges) - 1)}
    ))
    template_df.to_csv(
        output_dir / "06_AB_common_templates.csv", index=False, encoding="utf-8-sig"
    )

    lab_detail.to_csv(
        output_dir / "07_lab_each_wav_similarity.csv", index=False, encoding="utf-8-sig"
    )
    lab_summary.to_csv(
        output_dir / "08_lab_similarity_summary.csv", index=False, encoding="utf-8-sig"
    )
    lab_failures.to_csv(
        output_dir / "08_lab_wav_failures.csv", index=False, encoding="utf-8-sig"
    )

    lab_profile_df = pd.DataFrame(
        {
            "band_index": np.arange(len(edges) - 1),
            "freq_low_hz": edges[:-1],
            "freq_high_hz": edges[1:],
            "lab_all_wavs_median_normalized_profile": lab_median,
        }
    )
    lab_profile_df.to_csv(
        output_dir / "09_lab_median_profile.csv", index=False, encoding="utf-8-sig"
    )

    # 保存全部频带数组，便于后续复核。
    npz_payload: Dict[str, Any] = {
        "band_edges_hz": edges,
        "lab_median_profile": lab_median,
    }
    for method in METHODS:
        npz_payload[f"AB_template_{method}"] = templates[method]
        npz_payload[f"AB_removed_template_{method}"] = removed_templates[method]
    for scene in required_scenes:
        records = records_by_scene[scene]
        products = component_spectra(records, pred_by_scene[scene])
        npz_payload[f"{scene}_sample_ids"] = np.asarray([r.sample_id for r in records], dtype="U")
        npz_payload[f"{scene}_labels"] = np.asarray([r.label for r in records], dtype="U")
        npz_payload[f"{scene}_center"] = np.stack([r.center_band_power for r in records])
        npz_payload[f"{scene}_predicted_background"] = products["predicted_background"]
        npz_payload[f"{scene}_plane_background"] = products["plane_background"]
        for method in METHODS:
            npz_payload[f"{scene}_{method}"] = products[method]
    np.savez_compressed(output_dir / "10_all_band_spectra.npz", **npz_payload)

    plot_false_metrics(false_summary, output_dir / "figures")
    plot_templates(templates, edges, output_dir / "figures")

    report = recommendation_text(false_summary, separation, lab_summary, band_table)
    (output_dir / "README_结果怎么判断.txt").write_text(report, encoding="utf-8")

    run_manifest = {
        "config_file": str(config_path),
        "run_config": asdict(cfg),
        "training_scenes": training_scenes,
        "test_scenes": test_scenes,
        "scene_paths": {k: str(v) for k, v in scenes.items()},
        "lab_groups": lab_groups,
        "outputs": sorted(p.name for p in output_dir.iterdir()),
    }
    (output_dir / "run_manifest.json").write_text(
        json.dumps(run_manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print("\n" + "=" * 90)
    print("全部完成")
    print("结果目录：", output_dir)
    print("最先查看：")
    print("  03_false_background_metrics_summary.csv")
    print("  04_scene_method_TRUE_FALSE_separation.csv")
    print("  08_lab_similarity_summary.csv")
    print("  05_band_effects_factory_lab_support.csv")
    print("=" * 90)


def synthetic_records(
    rng: np.random.Generator,
    scene: str,
    n_false: int,
    n_true: int,
    n_bands: int,
    n_features: int,
    leak_profile: np.ndarray,
) -> List[SampleRecord]:
    records = []
    scene_shift = {"factory_A": 0.0, "factory_B": 0.15, "factory_C": -0.10, "factory_D": 0.08}[scene]
    coef = rng.normal(0.0, 0.15, size=(n_bands, n_features))
    for label, n in [("FALSE_LEAK", n_false), ("TRUE_LEAK", n_true)]:
        for i in range(n):
            features = rng.lognormal(mean=scene_shift, sigma=0.35, size=(n_bands, n_features))
            bg = 1.0 + np.sum(features * coef, axis=1)
            bg = np.maximum(bg, 0.2)
            noise = rng.normal(0.0, 0.03, size=n_bands)
            center = np.maximum(bg + noise, 0.0)
            if label == "TRUE_LEAK":
                center = center + 0.9 * leak_profile
            plane_bg = np.maximum(bg + rng.normal(0.0, 0.15, size=n_bands), 0.0)
            records.append(
                SampleRecord(
                    scene=scene,
                    sample_id=f"{scene}_{label}_{i}",
                    label=label,
                    time=str(i),
                    center=str(i),
                    center_file="synthetic",
                    offset_dir="synthetic",
                    center_band_power=center,
                    plane_background_band_power=plane_bg,
                    features=features,
                    feature_names=[f"f{k}" for k in range(n_features)],
                )
            )
    return records


def run_self_test() -> None:
    print("开始合成自检……")
    rng = np.random.default_rng(42)
    cfg = RunConfig(
        freq_low_hz=20_000,
        freq_high_hz=30_000,
        band_width_hz=1_000,
        ridge_alphas=(0.1, 1.0, 10.0),
        min_train_scene_auc=0.55,
        min_train_scene_effect=0.0,
    )
    edges = band_edges(cfg)
    n_bands = len(edges) - 1
    leak = np.exp(-0.5 * ((np.arange(n_bands) - 5.0) / 1.2) ** 2)
    records_by_scene = {
        scene: synthetic_records(rng, scene, 14, 14, n_bands, 12, leak)
        for scene in ["factory_A", "factory_B", "factory_C", "factory_D"]
    }
    train = {s: records_by_scene[s] for s in ["factory_A", "factory_B"]}
    oof, _ = oof_predict_training_scenes(train, edges, cfg)
    false_by_scene = {
        s: [r for r in records_by_scene[s] if r.label == "FALSE_LEAK"]
        for s in ["factory_A", "factory_B"]
    }
    final, _ = fit_background_model(false_by_scene, edges, cfg)
    pred = {
        "factory_A": oof["factory_A"],
        "factory_B": oof["factory_B"],
        "factory_C": predict_background(final, records_by_scene["factory_C"]),
        "factory_D": predict_background(final, records_by_scene["factory_D"]),
    }
    false_frames = [
        false_background_metrics(records_by_scene[s], pred[s], "self_test")
        for s in records_by_scene
    ]
    summary = summarize_false_metrics(pd.concat(false_frames, ignore_index=True))
    separation = scene_method_separation(records_by_scene, pred)
    bands = band_effect_table(
        records_by_scene, pred, edges, cfg,
        ["factory_A", "factory_B"], ["factory_C", "factory_D"]
    )
    _, templates, _ = build_ab_templates(
        records_by_scene, pred, bands, ["factory_A", "factory_B"]
    )

    assert not summary.empty
    assert not separation.empty
    assert np.sum(templates["false_prediction"]) > 0
    fp_sep = separation[separation["method"] == "false_prediction"]
    if not np.all(fp_sep["auc"].to_numpy(dtype=float) > 0.70):
        raise AssertionError(f"合成自检AUC不合格：\n{fp_sep}")
    print("SELF-TEST PASSED")
    print(fp_sep[["scene", "auc", "true_minus_false_median"]].to_string(index=False))


def main() -> None:
    parser = argparse.ArgumentParser(
        description="A+B FALSE学习环境背景，C+D独立测试，并与实验室_bf.wav验证。"
    )
    parser.add_argument("--config", type=str, help="配置JSON路径")
    parser.add_argument("--self-test", action="store_true", help="运行合成自检")
    args = parser.parse_args()

    if args.self_test:
        run_self_test()
        return
    if not args.config:
        parser.error("正式运行必须提供 --config")
    run_pipeline(Path(args.config))


if __name__ == "__main__":
    main()
