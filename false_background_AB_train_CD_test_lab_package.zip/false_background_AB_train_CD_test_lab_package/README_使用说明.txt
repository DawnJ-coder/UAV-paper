A+B FALSE学习环境背景、C+D独立验证、实验室BF验证
====================================================

一、这版程序解决什么问题
------------------------

这版不再假定“40 cm就是纯环境噪声”。

新的逻辑是：

    A+B中的FALSE样本
          ↓
    学习周围全部空间点的状态与无泄漏中心背景之间的关系
          ↓
    A、B内部留一场景预测，避免同场景自我拟合
          ↓
    A+B全部FALSE训练最终冻结模型
          ↓
    C、D分别独立测试
          ↓
    与每一个实验室_bf.wav验证

比较三种方法：

    raw
    plane
    false_prediction


二、输入要求
------------

每个场景目录必须是v9结果目录，例如：

    D:\wurenji\factory_A_v9_results

目录中至少需要：

    v9_all_features.csv
    v9_run_config.json

更重要的是，v9_all_features.csv中记录的：

    center_file
    offset_dir

对应的原始WAV和周围点目录仍然必须存在。

原因是这版程序要重新读取每个中心及周围点的完整频谱，
不能只依赖v9已经汇总好的少量特征。


三、为什么只用FALSE训练背景
--------------------------

FALSE没有泄漏，因此FALSE中心就是真实工厂背景。

程序训练：

    周围点频谱状态 -> FALSE中心频谱

模型没有使用TRUE中心作为背景训练目标，因此不会直接学习把TRUE泄漏复制成背景。


四、A、B、C、D怎么分工
----------------------

A、B：
    用于训练环境背景模型和发现候选频带。

A、B内部预测：
    A样本由B的FALSE训练模型预测；
    B样本由A的FALSE训练模型预测。

C、D：
    完全不参与训练和参数选择；
    使用冻结的A+B FALSE模型分别测试。


五、修改配置
------------

打开：

    false_background_config.json

修改：

    factory_A、factory_B、factory_C、factory_D的v9结果目录
    0.1mm、0.5mm实验室目录
    output_dir

程序只读取文件名以：

    _bf.wav

结尾的实验室音频。


六、安装依赖
------------

    pip install numpy pandas scipy scikit-learn matplotlib joblib


七、先运行自检
--------------

    python false_background_leak_pipeline.py --self-test

出现：

    SELF-TEST PASSED

再正式运行。


八、正式运行
------------

    python false_background_leak_pipeline.py --config false_background_config.json

也可以双击：

    run_false_background_pipeline.bat


九、最重要的结果
----------------

1. 03_false_background_metrics_summary.csv

这是第一张必须看的表。

主要列：

    relative_absolute_error_median
        预测背景和FALSE真实中心之间的相对误差，越低越好。

    background_to_center_ratio_median
        预测背景/真实FALSE中心，越接近1越好。

    positive_residual_fraction_median
        FALSE扣除背景后还剩多少，越低越好。

必须先确认false_prediction在C和D的FALSE中也能保持低误差，
才可以把它用于TRUE。


2. 04_scene_method_TRUE_FALSE_separation.csv

比较：

    raw
    plane
    false_prediction

在A、B、C、D中的TRUE/FALSE区分。

主要看：

    auc
    true_minus_false_median

要求不仅A、B有效，C、D也应保持正向。


3. 08_lab_similarity_summary.csv

每个方法都有两组相似度：

    residual_*
        保留下来的AB共同残差与实验室泄漏的相似度。

    removed_background_*
        被模型减掉的背景与实验室泄漏的相似度。

理想情况：

    residual相似度 > removed_background相似度

如果被减掉部分反而更像实验室泄漏，说明方法仍在误减泄漏。


4. 07_lab_each_wav_similarity.csv

逐个实验室WAV输出相似度。

一行对应：

    一个方法 × 一个真实_bf.wav


5. 05_band_effects_factory_lab_support.csv

主要列：

    AB_selected
        A与B同时支持的候选频带。

    factory_support_count
        A/B/C/D中有几个场景支持该频带。

    lab_supported
        实验室全部WAV的中位频谱是否支持。

    final_candidate
        同时满足AB发现、至少三个工厂场景支持、实验室支持的最终候选频带。

注意：
    final_candidate仍然叫“泄漏候选”，不能直接宣称是纯泄漏。


十、为什么模型不是神经网络
--------------------------

样本量较小，神经网络很容易记住场景。

本版按每个1 kHz频带使用Ridge回归，输入包括：

    周围点中位数、分位数、均值、标准差
    八个方向的中位频谱
    四个距离环的中位频谱
    左右差异、上下差异
    当前plane估计结果

它利用空间信息，但不要求能量必须随距离下降，也不要求背景必须是平面。


十一、完整输出
--------------

    00_preflight_scene_summary.csv
    00_sample_loading_failures.csv
    01_AB_OOF_selected_ridge_alpha.csv
    01_final_AB_selected_ridge_alpha.csv
    02_sample_predictions_all_methods.csv
    03_false_background_metrics_each_sample.csv
    03_false_background_metrics_summary.csv
    04_scene_method_TRUE_FALSE_separation.csv
    05_band_effects_factory_lab_support.csv
    06_AB_common_templates.csv
    07_lab_each_wav_similarity.csv
    08_lab_similarity_summary.csv
    08_lab_wav_failures.csv
    09_lab_median_profile.csv
    10_all_band_spectra.npz
    README_结果怎么判断.txt
    run_manifest.json
    models\AB_FALSE_background_model.joblib
    figures\*.png
