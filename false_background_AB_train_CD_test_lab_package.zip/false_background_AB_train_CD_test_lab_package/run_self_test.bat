﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
python false_background_leak_pipeline.py --self-test
pause
