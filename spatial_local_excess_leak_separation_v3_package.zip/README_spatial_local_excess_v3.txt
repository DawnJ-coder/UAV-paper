空间局部超额 + 消声室辅助验证：泄漏分离 v3
================================================

一、先安装依赖
    pip install numpy pandas scipy matplotlib scikit-learn

二、修改配置文件
    spatial_local_excess_config_v3.json

只需要先填写：
    D:\请填写消声室路径\0.1mm
    D:\请填写消声室路径\0.5mm

T/F工厂路径已经按用户提供的路径写好：
T：
    D:\gas\beamform_results_gc
    D:\gas\beamform_results_offset_multiple_gc_0001
    D:\gas\beamform_results_offset_multiple_gc_gy_0001
F：
    D:\gas\beamform_results_gc_cs
    D:\gas\beamform_results_offset_multiple_gc_cs_0001
    D:\gas\beamform_results_offset_multiple_gc_gy_cs_0001

三、先自检
    python spatial_local_excess_leak_separation_v3.py --self-test

看到 SELF-TEST PASSED 后再正式运行。

四、正式运行
    python spatial_local_excess_leak_separation_v3.py --config spatial_local_excess_config_v3.json

五、优先查看
    00_READ_ME_FIRST.txt
    10_factory_sample_summary.csv
    12_TF_group_summary.csv
    13_TF_metric_auc.csv
    15_TF_paired_summary.csv

六、最重要的判断
v3不是看单个PROMISING，而是看：
    source_center_score
    center_local_excess_power_fraction
    opposite_axis_support_ratio_power_weighted

这些指标是否在T组整体高于F组。
