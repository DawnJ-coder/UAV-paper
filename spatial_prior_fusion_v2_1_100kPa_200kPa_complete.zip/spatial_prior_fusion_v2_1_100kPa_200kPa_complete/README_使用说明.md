# 双空间自适应拟合 + 100 kPa 中心额外先验补偿 v2.1

## 数据规则

- 没有工厂训练集；工厂数据全部逐样本直接处理。
- 严格只处理中心编号 `00_00`、`00_01`。
- `100 kPa`：构建泄露先验字典，并计算中心相对周围额外出现的先验激活。
- `200 kPa`：所有分离结果冻结后，才用于最终相似度、AUC和成对统计。
- `200 kPa` 不参与空间模型、模型权重、门控或补偿量。

## 方法

每个样本并行计算：

1. `fixed_ring`：固定使用20、25、30、35、40 cm五圈，每圈8方向，共40点做鲁棒平面中心背景预测。5–15 cm和45–80 cm均不参与这个平面分支。
2. `opposite_pair`：按 v3.1.2 使用同半径相反方向、多半径和多轴支持预测中心背景。
3. `dual_spatial`：根据两种模型在该样本上的预测不确定度逐时频点分配权重；当两种背景预测分歧较大时，采用较低背景，避免剪掉泄露。
4. `final`：中心和所有周围点先投影到100 kPa字典，再用同一双空间方法预测中心位置正常环境先验激活。只有中心显著超过周围预测的先验激活才能补偿，并且只补双空间结果未保留的部分。

补偿具有时频点上限和单样本总能量上限，避免假泄露被大幅增强。

## 运行

```powershell
python -m pip install -r requirements.txt
python spatial_prior_fusion_v2.py --self-test
python spatial_prior_fusion_v2.py --config spatial_prior_fusion_v2_config.json
```

虽然入口文件名沿用 `spatial_prior_fusion_v2.py`，包版本和运行信息均标记为 v2.1（100 kPa先验/200 kPa相似度参照）。

也可双击 `运行自检.bat` 或 `运行正式程序.bat`。

`spatial_prior_fusion_v1.py` 是 v2 复用的底层公共函数文件，请勿直接运行；正式入口只有 `spatial_prior_fusion_v2.py`。

正式运行前修改配置中的100 kPa/200 kPa实验室路径、工厂中心/偏移目录和输出目录。两个实验室组必须使用独立路径，且WAV采样率和STFT频率轴必须一致。

## 主要输出

- `10_factory_sample_summary.csv`：四条方法链的主结果。
- `11_v2_spatial_diagnostics.csv`：20–40 cm固定环带点权重与相反方向诊断。
- `13_TF_metric_auc.csv`：四条方法链的事后AUC。
- `14_TF_paired_comparison.csv`、`15_TF_paired_summary.csv`：同工况同中心的T/F成对结果。
- `samples/.../spatial_prior_fusion_v2_result.npz`：四条方法链的完整时频矩阵。
- `samples/.../estimated_v2_fused_leak.wav`：最终泄露估计。

重点比较以下相似度指标：

- `fixed_ring_lab_similarity_combined_median`
- `opposite_pair_lab_similarity_combined_median`
- `dual_spatial_lab_similarity_combined_median`
- `final_lab_similarity_combined_median`
- `final_vs_remaining_similarity_contrast`

重点观察补偿是否过量：

- `center_prior_supplement_power_fraction`
- `prior_center_extra_activation_ratio_power_weighted`

新方法同时输出固定20–40 cm环带平面和相反方向方法，因此可以直接判断两种空间方法及双空间/先验补偿是否真正改善结果。相反方向分支仍使用5–80 cm全部有效距离。
