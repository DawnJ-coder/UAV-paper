# -*- coding: utf-8 -*-
"""双空间自适应拟合 + 100 kPa 中心额外先验补偿 v2。

约束：
- 没有工厂训练集；标签只在运行结束后计算统计指标。
- 每个样本独立计算20-40cm固定环带平面和相反方向空间模型及其权重。
- 100 kPa 用于泄露先验；200 kPa 只在分离结果冻结后计算相似度。
- 只处理中心编号 00_00、00_01。
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import traceback
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from scipy.io import wavfile
from sklearn.metrics import roc_auc_score

import _spatial_v3_engine as core
import spatial_prior_fusion_v1 as common


EPS = core.EPS
ALLOWED_CENTER_IDS = common.ALLOWED_CENTER_IDS

V2_DEFAULTS: Dict[str, Any] = {
    "spatial_disagreement_midpoint_db": 3.0,
    "spatial_disagreement_softness_db": 1.0,
    "spatial_confidence_floor": 0.10,
    "outer_geometry_fallback_confidence": 0.35,
    "prior_activation_base_margin_db": 1.5,
    "prior_activation_uncertainty_weight": 0.50,
    "prior_extra_ratio_midpoint": 0.10,
    "prior_extra_ratio_softness": 0.04,
    "prior_supplement_bin_cap": 0.25,
    "prior_supplement_total_fraction_cap": 0.10,
}


def _attach_v2_config(
    cfg: core.RunConfig,
    raw_algorithm: Optional[Mapping[str, Any]] = None,
) -> None:
    raw = dict(raw_algorithm or {})
    for key, default in V2_DEFAULTS.items():
        setattr(cfg.algorithm, key, raw.get(key, default))
    a = cfg.algorithm
    if float(a.spatial_disagreement_softness_db) <= 0:
        raise ValueError("spatial_disagreement_softness_db 必须>0")
    if not 0 <= float(a.spatial_confidence_floor) <= 1:
        raise ValueError("spatial_confidence_floor 必须位于[0,1]")
    if not 0 <= float(a.prior_supplement_bin_cap) <= 1:
        raise ValueError("prior_supplement_bin_cap 必须位于[0,1]")
    if not 0 <= float(a.prior_supplement_total_fraction_cap) <= 1:
        raise ValueError("prior_supplement_total_fraction_cap 必须位于[0,1]")


def load_config(path: Path) -> core.RunConfig:
    cfg = common.load_config(path)
    with path.open("r", encoding="utf-8-sig") as handle:
        raw = json.load(handle)
    _attach_v2_config(cfg, raw.get("algorithm", {}))
    return cfg


def _weighted_mean_matrix(values: np.ndarray, power: np.ndarray) -> float:
    return core.weighted_mean(np.asarray(values, dtype=float), np.asarray(power, dtype=float))


def _model_confidence(
    uncertainty_db: np.ndarray,
    availability: float,
    cfg: core.AlgorithmConfig,
) -> np.ndarray:
    floor = float(cfg.spatial_confidence_floor)
    confidence = floor + (1.0 - floor) * np.exp(
        -np.maximum(uncertainty_db, 0.0)
        / max(float(cfg.prediction_uncertainty_ref_db), 1e-6)
    )
    return np.clip(float(availability) * confidence, EPS, 1.0)


def fuse_spatial_predictions(
    center_power: np.ndarray,
    outer: Dict[str, Any],
    pair: Optional[Dict[str, Any]],
    cfg: core.AlgorithmConfig,
) -> Dict[str, np.ndarray | float]:
    """按单样本预测不确定度融合两种空间背景；分歧大时转向较低背景。"""
    outer_bg = np.maximum(np.asarray(outer["background_power"], dtype=float), EPS)
    outer_uncertainty = np.maximum(
        np.asarray(outer["prediction_uncertainty_db"], dtype=float), 0.0
    )
    outer_availability = (
        1.0 if int(outer.get("geometry_ok", 0)) else float(cfg.outer_geometry_fallback_confidence)
    )
    outer_confidence = _model_confidence(outer_uncertainty, outer_availability, cfg)

    if pair is None:
        residual = np.maximum(center_power - outer_bg, 0.0)
        ones = np.ones_like(center_power, dtype=float)
        zeros = np.zeros_like(center_power, dtype=float)
        return {
            "background_power": outer_bg,
            "local_excess_power": residual,
            "spatial_output_power": residual,
            "outer_weight": ones,
            "pair_weight": zeros,
            "outer_confidence": outer_confidence,
            "pair_confidence": zeros,
            "combined_confidence": outer_confidence,
            "prediction_uncertainty_db": outer_uncertainty,
            "background_disagreement_db": zeros,
            "conservative_gate": zeros,
            "dual_spatial_gate": ones,
        }

    pair_bg = np.maximum(np.asarray(pair["background_power"], dtype=float), EPS)
    pair_uncertainty = np.maximum(
        np.asarray(pair["prediction_uncertainty_db"], dtype=float), 0.0
    )
    pair_confidence = _model_confidence(pair_uncertainty, 1.0, cfg)
    confidence_sum = outer_confidence + pair_confidence + EPS
    outer_weight = outer_confidence / confidence_sum
    pair_weight = pair_confidence / confidence_sum

    outer_db = 10.0 * np.log10(outer_bg)
    pair_db = 10.0 * np.log10(pair_bg)
    weighted_db = outer_weight * outer_db + pair_weight * pair_db
    disagreement_db = np.abs(outer_db - pair_db)
    conservative_gate = core.sigmoid(
        (disagreement_db - float(cfg.spatial_disagreement_midpoint_db))
        / max(float(cfg.spatial_disagreement_softness_db), 1e-6)
    )
    fused_db = (
        (1.0 - conservative_gate) * weighted_db
        + conservative_gate * np.minimum(outer_db, pair_db)
    )
    fused_bg = np.power(10.0, np.clip(fused_db, -300.0, 300.0) / 10.0)
    local_excess = np.maximum(center_power - fused_bg, 0.0)

    pair_gate = np.clip(np.asarray(pair["spatial_gate"], dtype=float), 0.0, 1.0)
    # 固定20-40cm环带分支保留正残差；pair分支沿用v3多方向支持门控。
    dual_gate = np.clip(outer_weight + pair_weight * pair_gate, 0.0, 1.0)
    spatial_output = np.minimum(local_excess * dual_gate, center_power)
    combined_confidence = np.clip(
        outer_weight * outer_confidence + pair_weight * pair_confidence,
        0.0,
        1.0,
    )
    fused_uncertainty = (
        outer_weight * outer_uncertainty
        + pair_weight * pair_uncertainty
        + outer_weight * pair_weight * disagreement_db
    )
    return {
        "background_power": fused_bg,
        "local_excess_power": local_excess,
        "spatial_output_power": spatial_output,
        "outer_weight": outer_weight,
        "pair_weight": pair_weight,
        "outer_confidence": outer_confidence,
        "pair_confidence": pair_confidence,
        "combined_confidence": combined_confidence,
        "prediction_uncertainty_db": fused_uncertainty,
        "background_disagreement_db": disagreement_db,
        "conservative_gate": conservative_gate,
        "dual_spatial_gate": dual_gate,
    }


def _project_center_and_points(
    center_power: np.ndarray,
    point_cache: Sequence[Tuple[core.SpatialFile, np.ndarray]],
    dictionary: np.ndarray,
    cfg: core.AlgorithmConfig,
    seed: int,
) -> Tuple[np.ndarray, List[Tuple[core.SpatialFile, np.ndarray]], np.ndarray]:
    n_frames = center_power.shape[1]
    blocks = [center_power] + [power for _, power in point_cache]
    all_power = np.concatenate(blocks, axis=1)
    activation, reconstruction = core.infer_single_dictionary(
        np.maximum(all_power, 0.0),
        dictionary,
        cfg.lab_projection_iterations,
        cfg.lab_projection_l1_ratio,
        seed,
    )
    center_activation = activation[:, :n_frames]
    point_activations: List[Tuple[core.SpatialFile, np.ndarray]] = []
    for index, (point, _) in enumerate(point_cache):
        start = (index + 1) * n_frames
        point_activations.append((point, activation[:, start : start + n_frames]))
    center_reconstruction = reconstruction[:, :n_frames]
    return center_activation, point_activations, center_reconstruction


def build_center_extra_prior_supplement(
    center_power: np.ndarray,
    point_cache: Sequence[Tuple[core.SpatialFile, np.ndarray]],
    dual_spatial_power: np.ndarray,
    dictionary: np.ndarray,
    cfg: core.AlgorithmConfig,
    seed: int,
) -> Dict[str, Any]:
    """只补中心相对周围额外出现的 100 kPa 先验激活。"""
    center_h, point_h, center_prior_power = _project_center_and_points(
        center_power, point_cache, dictionary, cfg, seed
    )
    outer_h, _ = common.build_fixed_ring_plane_prediction(center_h, point_h, cfg)
    pair_h: Optional[Dict[str, Any]]
    try:
        pair_h, _ = core.build_opposite_pair_prediction(center_h, point_h, cfg)
    except Exception:
        pair_h = None
    fused_h = fuse_spatial_predictions(center_h, outer_h, pair_h, cfg)
    environment_h = np.maximum(np.asarray(fused_h["background_power"], dtype=float), 0.0)
    uncertainty_db = np.maximum(
        np.asarray(fused_h["prediction_uncertainty_db"], dtype=float), 0.0
    )
    required_margin_db = (
        float(cfg.prior_activation_base_margin_db)
        + float(cfg.prior_activation_uncertainty_weight) * np.minimum(uncertainty_db, 12.0)
    )
    environment_upper = environment_h * np.power(10.0, required_margin_db / 10.0)
    extra_h = np.maximum(center_h - environment_upper, 0.0)
    extra_prior_power = np.maximum(dictionary @ extra_h, 0.0)

    extra_ratio_frame = np.sum(extra_h, axis=0) / (np.sum(center_h, axis=0) + EPS)
    extra_gate_frame = core.sigmoid(
        (extra_ratio_frame - float(cfg.prior_extra_ratio_midpoint))
        / max(float(cfg.prior_extra_ratio_softness), 1e-6)
    )
    activation_confidence = np.clip(
        np.asarray(fused_h["combined_confidence"], dtype=float), 0.0, 1.0
    )
    atom_confidence_frame = np.sum(
        activation_confidence * extra_h, axis=0
    ) / (np.sum(extra_h, axis=0) + EPS)
    prior_gate = extra_gate_frame * atom_confidence_frame

    absorbed_by_spatial = np.maximum(center_power - dual_spatial_power, 0.0)
    nonoverlap_prior = np.maximum(extra_prior_power - dual_spatial_power, 0.0)
    candidate = np.minimum(absorbed_by_spatial, nonoverlap_prior)
    supplement = candidate * prior_gate[None, :]
    supplement = np.minimum(
        supplement,
        float(cfg.prior_supplement_bin_cap) * np.maximum(center_power, 0.0),
    )
    total_cap = float(cfg.prior_supplement_total_fraction_cap) * float(np.sum(center_power))
    if float(np.sum(supplement)) > total_cap > 0:
        supplement *= total_cap / (float(np.sum(supplement)) + EPS)
    return {
        "supplement_power": np.maximum(supplement, 0.0),
        "center_activation": center_h,
        "environment_activation": environment_h,
        "extra_activation": extra_h,
        "center_prior_power": center_prior_power,
        "extra_prior_power": extra_prior_power,
        "activation_uncertainty_db": uncertainty_db,
        "extra_ratio_frame": extra_ratio_frame,
        "prior_gate_frame": prior_gate,
        "activation_outer_weight": fused_h["outer_weight"],
        "activation_pair_weight": fused_h["pair_weight"],
    }


def _similarity(power: np.ndarray, references: Sequence[Tuple[str, Path, np.ndarray]]) -> Dict[str, Any]:
    return core.evaluate_against_lab(core.representative_spectrum(power), references)


def _enrich_rows(
    rows: Sequence[Mapping[str, Any]],
    diagnostic_type: str,
    dataset: core.FactoryDataset,
    normalized_folder: str,
    center_id: str,
    label: str,
    leak_type: str,
    condition_name: str,
    pair_key: str,
) -> List[Dict[str, Any]]:
    return [{
        "diagnostic_type": diagnostic_type,
        "dataset": dataset.name,
        "leak_type": leak_type,
        "condition_name": condition_name,
        "time_folder": normalized_folder,
        "condition_relative_path": normalized_folder,
        "pair_key": pair_key,
        "center_id": center_id,
        "label": label,
        **dict(row),
    } for row in rows]


def process_factory_sample(
    dataset: core.FactoryDataset,
    time_folder: str,
    center_id: str,
    center_path: Path,
    spatial_files: Sequence[core.SpatialFile],
    lab: Dict[str, Any],
    cfg: core.RunConfig,
    sample_dir: Path,
    seed: int,
) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[Dict[str, Any]]]:
    a = cfg.algorithm
    core.ensure_dir(sample_dir)
    center_slice = core.read_wav_slice(center_path, center_id, a)
    neighbors: List[Tuple[core.SpatialFile, core.WavSlice]] = []
    errors: List[Dict[str, Any]] = []
    for point in spatial_files:
        try:
            item = core.read_wav_slice(point.path, center_id, a)
            if item.fs != center_slice.fs or len(item.x) != len(center_slice.x):
                raise ValueError("邻点与中心点采样率或片段长度不一致")
            neighbors.append((point, item))
        except Exception as exc:
            errors.append({
                "dataset": dataset.name,
                "time_folder": time_folder,
                "center_id": center_id,
                "file": str(point.path),
                "stage": "read_neighbor",
                "error": f"{type(exc).__name__}: {exc}",
            })
    if len(neighbors) < a.min_neighbors:
        raise RuntimeError(f"有效邻点不足: {len(neighbors)} < {a.min_neighbors}")

    amplitude_info = core.amplitude_diagnostics(
        [center_slice] + [item for _, item in neighbors], a
    )
    freq_full, time_stft, z_center = core.stft_full(center_slice.x, center_slice.fs, a)
    freq_band, center_power, band_mask = core.power_band_from_stft(freq_full, z_center, a)
    if len(freq_band) != len(lab["freq_hz"]) or np.max(np.abs(freq_band - lab["freq_hz"])) > 1e-6:
        raise ValueError("工厂样本与实验室参照频率轴不一致")

    point_cache: List[Tuple[core.SpatialFile, np.ndarray]] = []
    for point, item in neighbors:
        freq, _, z = core.stft_full(item.x, item.fs, a)
        point_freq, power, _ = core.power_band_from_stft(freq, z, a)
        if len(point_freq) != len(freq_band) or np.max(np.abs(point_freq - freq_band)) > 1e-6:
            raise ValueError(f"邻点频率轴不一致: {point.path.name}")
        point_cache.append((point, power))

    outer, outer_rows = common.build_fixed_ring_plane_prediction(center_power, point_cache, a)
    pair_error = ""
    pair_rows: List[Dict[str, Any]] = []
    try:
        pair, pair_rows = core.build_opposite_pair_prediction(center_power, point_cache, a)
    except Exception as exc:
        pair = None
        pair_error = f"{type(exc).__name__}: {exc}"

    outer_power = np.minimum(np.asarray(outer["local_excess_power"], dtype=float), center_power)
    pair_power = (
        np.minimum(np.asarray(pair["spatial_local_power"], dtype=float), center_power)
        if pair is not None else np.zeros_like(center_power)
    )
    dual = fuse_spatial_predictions(center_power, outer, pair, a)
    dual_power = np.minimum(np.asarray(dual["spatial_output_power"], dtype=float), center_power)

    prior = build_center_extra_prior_supplement(
        center_power, point_cache, dual_power, lab["ws"], a, seed + 1000
    )
    supplement = np.asarray(prior["supplement_power"], dtype=float)
    final_power = np.minimum(dual_power + supplement, center_power)
    remaining_power = np.maximum(center_power - final_power, 0.0)

    # 到这里为止算法结果已经冻结；下面才首次使用 200 kPa。
    references_0p1 = lab["similarity_specs"]
    raw_sim = _similarity(center_power, references_0p1)
    background_sim = _similarity(np.asarray(dual["background_power"]), references_0p1)
    outer_sim = _similarity(outer_power, references_0p1)
    pair_sim = _similarity(pair_power, references_0p1)
    dual_sim = _similarity(dual_power, references_0p1)
    final_sim = _similarity(final_power, references_0p1)
    remaining_sim = _similarity(remaining_power, references_0p1)
    final_similarity = float(final_sim["lab_similarity_combined_median"])
    remaining_similarity = float(remaining_sim["lab_similarity_combined_median"])
    background_similarity = float(background_sim["lab_similarity_combined_median"])
    final_vs_remaining = final_similarity - remaining_similarity
    final_vs_background = final_similarity - background_similarity

    amplitude_mask = np.sqrt(final_power / np.maximum(center_power, EPS))
    z_leak = np.zeros_like(z_center)
    z_leak[band_mask] = amplitude_mask * z_center[band_mask]
    z_remaining = z_center - z_leak
    leak_wav = core.reconstruct_wav(z_leak, center_slice.fs, a, len(center_slice.x))
    remaining_wav = core.reconstruct_wav(z_remaining, center_slice.fs, a, len(center_slice.x))
    if a.save_wavs:
        wavfile.write(str(sample_dir / "estimated_v2_fused_leak.wav"), center_slice.fs, leak_wav.astype(np.float32))
        wavfile.write(str(sample_dir / "estimated_v2_remaining_environment.wav"), center_slice.fs, remaining_wav.astype(np.float32))
        wavfile.write(str(sample_dir / "raw_center_slice.wav"), center_slice.fs, center_slice.x.astype(np.float32))

    total = float(np.sum(center_power)) + EPS
    outer_fraction = float(np.sum(outer_power) / total)
    pair_fraction = float(np.sum(pair_power) / total)
    dual_fraction = float(np.sum(dual_power) / total)
    supplement_fraction = float(np.sum(supplement) / total)
    final_fraction = float(np.sum(final_power) / total)
    excess_median, excess_weighted = core.robust_positive_summary(
        10.0 * np.log10(
            np.maximum(center_power, EPS) / np.maximum(np.asarray(dual["background_power"]), EPS)
        ),
        np.maximum(center_power - np.asarray(dual["background_power"]), 0.0),
    )
    pair_support = (
        _weighted_mean_matrix(pair["pair_support_ratio"], center_power) if pair is not None else 0.0
    )
    axis_support = (
        _weighted_mean_matrix(pair["axis_support_ratio"], center_power) if pair is not None else 0.0
    )
    confidence_weighted = _weighted_mean_matrix(dual["combined_confidence"], center_power)
    uncertainty_weighted = _weighted_mean_matrix(dual["prediction_uncertainty_db"], center_power)
    outer_weighted = _weighted_mean_matrix(dual["outer_weight"], center_power)
    pair_weighted = _weighted_mean_matrix(dual["pair_weight"], center_power)
    disagreement_weighted = _weighted_mean_matrix(dual["background_disagreement_db"], center_power)
    prior_extra_ratio = _weighted_mean_matrix(prior["extra_ratio_frame"][None, :], center_power)
    prior_gate_weighted = _weighted_mean_matrix(prior["prior_gate_frame"][None, :], center_power)

    label = core.sample_label(dataset, time_folder)
    leak_type, condition_name = core.infer_leak_type_and_condition(time_folder)
    normalized_folder = core.normalize_relative_folder(time_folder)
    canonical = core.canonical_condition(normalized_folder, cfg.pairing_remove_tokens)
    pair_key = f"{canonical}::{center_id}"
    evidence_flag = (
        "STRONG_FINAL_200KPA_CONTRAST"
        if final_vs_remaining > 0 and final_vs_background > 0
        else "WEAK_FINAL_200KPA_CONTRAST"
    )
    summary: Dict[str, Any] = {
        "method": "V2_DUAL_SPATIAL_PLUS_CENTER_EXTRA_100KPA_PRIOR",
        "data_semantics": "NO_FACTORY_TRAINING_SET",
        "similarity_200kpa_usage": "POST_SEPARATION_EVALUATION_ONLY",
        "dataset": dataset.name,
        "leak_type": leak_type,
        "condition_name": condition_name,
        "time_folder": normalized_folder,
        "condition_relative_path": normalized_folder,
        "canonical_condition": canonical,
        "pair_key": pair_key,
        "center_id": center_id,
        "label": label,
        "center_file": str(center_path),
        "segment_start_seconds": center_slice.segment_start_seconds,
        "segment_end_seconds": center_slice.segment_end_seconds,
        "sample_rate_hz": center_slice.fs,
        "n_neighbors_used": len(neighbors),
        "n_fixed_ring_points": outer["n_ring_points"],
        "fixed_ring_distances_cm": "20;25;30;35;40",
        "n_complete_opposite_pairs": int(pair["pair_delta_db_stack"].shape[0]) if pair is not None else 0,
        "n_complete_axes": int(pair["axis_delta_db_stack"].shape[0]) if pair is not None else 0,
        "pair_method_status": "OK" if pair is not None else "FALLBACK_OUTER40_ONLY",
        "pair_method_error": pair_error,
        "plane_valid": outer["plane_valid"],
        "plane_used": outer["plane_used"],
        "plane_geometry_ok": outer["geometry_ok"],
        "plane_condition_number": outer["fit_condition_number"],
        "plane_fit_mae_db": outer["fit_plane_mae_db"],
        "fixed_ring_weight_power_weighted": outer_weighted,
        "opposite_pair_weight_power_weighted": pair_weighted,
        "dual_background_disagreement_db_power_weighted": disagreement_weighted,
        "background_prediction_uncertainty_db_power_weighted": uncertainty_weighted,
        "background_prediction_confidence_power_weighted": confidence_weighted,
        "opposite_pair_support_ratio_power_weighted": pair_support,
        "opposite_axis_support_ratio_power_weighted": axis_support,
        "fixed_ring_power_fraction": outer_fraction,
        "opposite_pair_power_fraction": pair_fraction,
        "dual_spatial_power_fraction": dual_fraction,
        "center_local_excess_power_fraction": dual_fraction,
        "center_spatial_filtered_power_fraction": dual_fraction,
        "center_prior_supplement_power_fraction": supplement_fraction,
        "center_final_leak_power_fraction": final_fraction,
        "prior_center_extra_activation_ratio_power_weighted": prior_extra_ratio,
        "prior_supplement_gate_power_weighted": prior_gate_weighted,
        "center_excess_db_positive_median": excess_median,
        "center_excess_db_power_weighted_mean": excess_weighted,
        "final_vs_remaining_similarity_contrast": final_vs_remaining,
        "final_vs_background_similarity_contrast": final_vs_background,
        "source_center_score": final_vs_remaining,
        "spatial_evidence_flag": evidence_flag,
        "lab_validation_mode": "200KPA_POST_SEPARATION_SIMILARITY_ONLY",
        **amplitude_info,
        **{f"raw_{key}": value for key, value in raw_sim.items()},
        **{f"background_{key}": value for key, value in background_sim.items()},
        **{f"fixed_ring_{key}": value for key, value in outer_sim.items()},
        **{f"opposite_pair_{key}": value for key, value in pair_sim.items()},
        **{f"dual_spatial_{key}": value for key, value in dual_sim.items()},
        **{f"final_{key}": value for key, value in final_sim.items()},
        **{f"remaining_{key}": value for key, value in remaining_sim.items()},
    }
    # 兼容既有汇总列。
    summary["spatial_local_lab_similarity_combined_median"] = float(
        dual_sim["lab_similarity_combined_median"]
    )
    summary["leak_lab_similarity_combined_median"] = final_similarity
    summary["raw_lab_similarity_combined_median"] = float(raw_sim["lab_similarity_combined_median"])
    summary["leak_similarity_gain_over_raw"] = final_similarity - float(
        raw_sim["lab_similarity_combined_median"]
    )
    summary["leak_vs_remaining_similarity_gap"] = final_vs_remaining

    diagnostic_rows = _enrich_rows(
        outer_rows, "OUTER40_POINT", dataset, normalized_folder, center_id,
        label, leak_type, condition_name, pair_key,
    )
    diagnostic_rows += _enrich_rows(
        pair_rows, "OPPOSITE_PAIR", dataset, normalized_folder, center_id,
        label, leak_type, condition_name, pair_key,
    )
    core.write_json(sample_dir / "summary.json", summary)
    core.write_csv(sample_dir / "v2_spatial_diagnostics.csv", diagnostic_rows)
    core.write_csv(sample_dir / "fixed_ring_20_40cm_plane_point_diagnostics.csv", outer_rows)
    core.write_csv(sample_dir / "opposite_pair_diagnostics.csv", pair_rows)

    if a.save_npz:
        np.savez_compressed(
            sample_dir / "spatial_prior_fusion_v2_result.npz",
            freq_hz=freq_band,
            time_s=time_stft,
            raw_center_power=center_power,
            fixed_ring_20_40cm_background_power=outer["background_power"],
            fixed_ring_20_40cm_output_power=outer_power,
            opposite_pair_background_power=(pair["background_power"] if pair is not None else np.zeros_like(center_power)),
            opposite_pair_output_power=pair_power,
            dual_spatial_background_power=dual["background_power"],
            dual_spatial_output_power=dual_power,
            prior_supplement_power=supplement,
            final_fused_leak_power=final_power,
            remaining_environment_power=remaining_power,
            fixed_ring_weight=dual["outer_weight"],
            opposite_pair_weight=dual["pair_weight"],
            background_disagreement_db=dual["background_disagreement_db"],
            combined_prediction_uncertainty_db=dual["prediction_uncertainty_db"],
            prior_center_activation=prior["center_activation"],
            prior_environment_activation=prior["environment_activation"],
            prior_extra_activation=prior["extra_activation"],
            prior_extra_ratio_frame=prior["extra_ratio_frame"],
            prior_gate_frame=prior["prior_gate_frame"],
            leak_dictionary_100kpa=lab["ws"],
            similarity_200kpa_usage=np.asarray("POST_SEPARATION_EVALUATION_ONLY"),
        )

    if a.save_plots:
        title = f"{dataset.name} | {time_folder} | {center_id}"
        core.plot_sample_spectra(
            freq_band,
            core.representative_spectrum(center_power),
            core.representative_spectrum(np.asarray(dual["background_power"])),
            core.representative_spectrum(final_power),
            core.representative_spectrum(remaining_power),
            lab["lab_proto"],
            title,
            sample_dir / "spectrum_comparison.png",
        )
        common._plot_fusion_diagnostics(
            freq_band,
            time_stft,
            dual_power,
            supplement,
            final_power,
            np.asarray(dual["prediction_uncertainty_db"]),
            title,
            sample_dir / "fusion_diagnostics.png",
        )
    return summary, diagnostic_rows, errors


EVALUATION_METRICS = [
    "fixed_ring_power_fraction",
    "opposite_pair_power_fraction",
    "dual_spatial_power_fraction",
    "center_prior_supplement_power_fraction",
    "center_final_leak_power_fraction",
    "fixed_ring_lab_similarity_combined_median",
    "opposite_pair_lab_similarity_combined_median",
    "dual_spatial_lab_similarity_combined_median",
    "final_lab_similarity_combined_median",
    "final_vs_remaining_similarity_contrast",
    "final_vs_background_similarity_contrast",
    "prior_center_extra_activation_ratio_power_weighted",
]


def _write_v2_evaluation(output_dir: Path, summary: pd.DataFrame) -> None:
    if summary.empty or "label" not in summary:
        return
    labels = summary["label"].astype(str).str.upper().replace({"TRUE": "T", "FALSE": "F"})
    valid = labels.isin(["T", "F"])
    sub = summary.loc[valid].copy()
    y = labels.loc[valid].eq("T").astype(int).to_numpy()
    auc_rows: List[Dict[str, Any]] = []
    if len(np.unique(y)) == 2:
        for metric in EVALUATION_METRICS:
            values = pd.to_numeric(sub.get(metric), errors="coerce")
            mask = values.notna().to_numpy()
            if np.sum(mask) < 2 or len(np.unique(y[mask])) < 2:
                continue
            auc = float(roc_auc_score(y[mask], values.to_numpy()[mask]))
            auc_rows.append({
                "metric": metric,
                "auc_T_higher": auc,
                "auc_best_direction": max(auc, 1.0 - auc),
                "expected_direction": "T_HIGHER",
                "n_samples": int(np.sum(mask)),
            })
    pd.DataFrame(auc_rows).to_csv(
        output_dir / "13_TF_metric_auc.csv", index=False, encoding="utf-8-sig"
    )

    sub["label_norm"] = labels.loc[valid]
    grouped = sub.groupby(["pair_key", "label_norm"], as_index=False)[EVALUATION_METRICS].mean(numeric_only=True)
    true_rows = grouped[grouped["label_norm"] == "T"].set_index("pair_key")
    false_rows = grouped[grouped["label_norm"] == "F"].set_index("pair_key")
    common_keys = sorted(set(true_rows.index) & set(false_rows.index))
    paired_rows: List[Dict[str, Any]] = []
    for key in common_keys:
        row: Dict[str, Any] = {"pair_key": key}
        for metric in EVALUATION_METRICS:
            t_value = float(true_rows.loc[key, metric])
            f_value = float(false_rows.loc[key, metric])
            row[f"T_{metric}"] = t_value
            row[f"F_{metric}"] = f_value
            row[f"T_minus_F_{metric}"] = t_value - f_value
        paired_rows.append(row)
    paired = pd.DataFrame(paired_rows)
    paired.to_csv(output_dir / "14_TF_paired_comparison.csv", index=False, encoding="utf-8-sig")
    paired_summary: List[Dict[str, Any]] = []
    if not paired.empty:
        for metric in EVALUATION_METRICS:
            values = pd.to_numeric(paired[f"T_minus_F_{metric}"], errors="coerce").dropna()
            paired_summary.append({
                "metric": metric,
                "n_pairs": len(values),
                "T_greater_F_fraction": float(np.mean(values > 0)),
                "T_minus_F_mean": float(values.mean()),
                "T_minus_F_median": float(values.median()),
            })
    pd.DataFrame(paired_summary).to_csv(
        output_dir / "15_TF_paired_summary.csv", index=False, encoding="utf-8-sig"
    )


def write_read_me_first(output_dir: Path, cfg: core.RunConfig, lab: Dict[str, Any]) -> None:
    text = f"""双空间自适应拟合 + 100 kPa 中心额外先验补偿 v2
=====================================================

仅处理中心点：{', '.join(ALLOWED_CENTER_IDS)}
没有工厂训练集；所有空间参数均由单个样本计算。

四条输出链：
1. fixed_ring：固定使用20/25/30/35/40cm五圈，每圈8方向，共40点做鲁棒平面。
2. opposite_pair：v3同半径相反方向、多轴支持门控。
3. dual_spatial：按两种模型的单样本预测不确定度融合；分歧大时采用较低背景。
4. final：dual_spatial + 100kPa中心相对周围的额外先验激活补偿。

200 kPa 使用时点：所有分离结果冻结之后，仅计算最终相似度和事后AUC/成对统计；
不参与空间模型、模型权重、100kPa门控或补偿量。

主要文件：
- 10_factory_sample_summary.csv：四条方法链的功率、相似度、权重和补偿。
- 13_TF_metric_auc.csv：四条方法链的事后AUC。
- 15_TF_paired_summary.csv：四条方法链的T/F成对差异。
- samples/.../spatial_prior_fusion_v2_result.npz：完整时频矩阵。
- samples/.../v2_spatial_diagnostics.csv：20-40cm环带点权重和相反方向诊断。

重点比较：
- fixed_ring_lab_similarity_combined_median
- opposite_pair_lab_similarity_combined_median
- dual_spatial_lab_similarity_combined_median
- final_lab_similarity_combined_median
- final_vs_remaining_similarity_contrast
- center_prior_supplement_power_fraction

真实数据上的跨场景效果必须以工厂和泰州各自的AUC及成对差异验证，程序不会伪造保证。
"""
    (output_dir / "00_READ_ME_FIRST.txt").write_text(text, encoding="utf-8")


def run_analysis(cfg: core.RunConfig) -> Dict[str, Path]:
    core.prepare_lab_reference = common.prepare_lab_reference
    core.process_factory_sample = process_factory_sample
    core.write_read_me_first = write_read_me_first
    core.build_center_index = common.build_allowed_center_index
    core.build_offset_index = common.build_allowed_offset_index
    core.directory_has_center_wav = common.directory_has_allowed_center_wav
    paths = core.run_analysis(cfg)
    output_dir = Path(cfg.output_dir)
    summary = pd.read_csv(paths["summary"])
    _write_v2_evaluation(output_dir, summary)

    old_diagnostics = output_dir / "11_opposite_pair_diagnostics.csv"
    new_diagnostics = output_dir / "11_v2_spatial_diagnostics.csv"
    if old_diagnostics.exists():
        new_diagnostics.write_bytes(old_diagnostics.read_bytes())
        paths["v2_spatial_diagnostics"] = new_diagnostics

    run_info_path = output_dir / "00_run_info.json"
    run_info = json.loads(run_info_path.read_text(encoding="utf-8")) if run_info_path.exists() else {}
    run_info.update({
        "program_version": "spatial-prior-fusion-v2.1-100kpa-prior-200kpa-reference-fixed-ring-20-40cm",
        "processed_center_ids": list(ALLOWED_CENTER_IDS),
        "factory_training_set_used": False,
        "sample_specific_spatial_learning": True,
        "lab_100kpa_role": "PRIOR_DICTIONARY_AND_CENTER_EXTRA_ACTIVATION",
        "lab_200kpa_role": "POST_SEPARATION_SIMILARITY_ONLY",
        "v2_parameters": {key: getattr(cfg.algorithm, key) for key in V2_DEFAULTS},
        "plane_point_policy": "FIXED_20_25_30_35_40_CM_X_8_DIRECTIONS",
        "output_chains": ["fixed_ring_20_40cm", "opposite_pair", "dual_spatial", "final_100kpa_supplemented"],
    })
    algorithm_info = run_info.get("config", {}).get("algorithm", {})
    for legacy_key in (
        "lab_split_mode",
        "lab_train_groups",
        "lab_validation_groups",
        "lab_train_fraction",
        "max_lab_training_frames",
        "prior_mix_max",
        "prior_mix_steps",
    ):
        algorithm_info.pop(legacy_key, None)
    algorithm_info.update({
        "lab_prior_groups": list(cfg.algorithm.lab_prior_groups),
        "lab_similarity_groups": list(cfg.algorithm.lab_similarity_groups),
        "max_lab_prior_frames": int(cfg.algorithm.max_lab_prior_frames),
        **{key: getattr(cfg.algorithm, key) for key in V2_DEFAULTS},
    })
    core.write_json(run_info_path, run_info)
    return paths


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="v2.1：20-40cm固定环带平面 + 相反方向双空间融合 + 100kPa中心额外先验"
    )
    parser.add_argument("--config", default="spatial_prior_fusion_v2_config.json")
    parser.add_argument("--self-test", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if args.self_test:
        common.run_self_test_v2 = run_self_test
        run_self_test()
        return
    run_analysis(load_config(Path(args.config)))


def run_self_test() -> None:
    """复用 v1 合成数据生成器，另外验证 v2 四链和 200 kPa 隔离字段。"""
    import shutil
    import tempfile

    print("开始 v2.1 SELF-TEST（固定20-40cm环带）...")
    rng = np.random.default_rng(2345)
    fs = 192_000
    seconds = 0.35
    with tempfile.TemporaryDirectory(prefix="spatial_prior_fusion_v2_test_") as temp_dir:
        root = Path(temp_dir)
        lab100 = core.ensure_dir(root / "lab" / "100kPa")
        lab200 = core.ensure_dir(root / "lab" / "200kPa")
        for folder, shift in ((lab100, 1.2), (lab200, 0.0)):
            for index in range(4):
                x = core.synth_leak(fs, seconds, rng, shift + 0.1 * index)
                wavfile.write(str(folder / f"lab_{index}.wav"), fs, x.astype(np.float32))
        leak = core.synth_leak(fs, seconds, rng, 0.2)
        t_center, t_near, t_far = core.write_synthetic_factory(root, "T", fs, seconds, rng, leak)
        f_center, f_near, f_far = core.write_synthetic_factory(root, "F", fs, seconds, rng, leak)
        for center_root, near_root, far_root, folder in (
            (t_center, t_near, t_far, "condition"),
            (f_center, f_near, f_far, "condition_null"),
        ):
            center_folder = center_root / folder
            offset_folders = [near_root / folder, far_root / folder]
            source_center = center_folder / "synthetic_00_00_beamform_result.wav"
            for target_id in ("00_01", "00_02"):
                shutil.copyfile(source_center, center_folder / f"synthetic_{target_id}_beamform_result.wav")
                for offset_folder in offset_folders:
                    for source in list(offset_folder.glob("synthetic_00_00d*.wav")):
                        shutil.copyfile(
                            source,
                            offset_folder / source.name.replace("00_00d", f"{target_id}d", 1),
                        )
        cfg = core.RunConfig(
            lab_groups={"100kPa": [str(lab100)], "200kPa": [str(lab200)]},
            factory_datasets=[
                core.FactoryDataset("synthetic_T", str(t_center), [str(t_near), str(t_far)], ["condition"], "T", {}),
                core.FactoryDataset("synthetic_F", str(f_center), [str(f_near), str(f_far)], ["condition_null"], "F", {}),
            ],
            output_dir=str(root / "out"),
            pairing_remove_tokens=["_null", "null"],
            algorithm=core.AlgorithmConfig(
                time_slice_seconds=seconds,
                segment_mode="first",
                nperseg=1024,
                hop_length=512,
                nfft=2048,
                minimum_frequency_bins=20,
                leak_components=4,
                max_lab_training_frames=3000,
                nmf_max_iter=100,
                lab_projection_iterations=60,
                min_neighbors=100,
                min_complete_opposite_pairs=50,
                save_plots=False,
                save_wavs=True,
                save_npz=True,
                plot_limit=0,
            ),
        )
        common._attach_fusion_config(cfg, {"max_lab_prior_frames": 3000})
        _attach_v2_config(cfg)
        paths = run_analysis(cfg)
        summary = pd.read_csv(paths["summary"])
        if len(summary) != 4 or set(summary["center_id"].astype(str)) != set(ALLOWED_CENTER_IDS):
            raise AssertionError("严格中心白名单 00_00/00_01 失效")
        required = {
            "fixed_ring_lab_similarity_combined_median",
            "opposite_pair_lab_similarity_combined_median",
            "dual_spatial_lab_similarity_combined_median",
            "final_lab_similarity_combined_median",
            "similarity_200kpa_usage",
        }
        if not required.issubset(summary.columns):
            raise AssertionError(f"v2 汇总缺少列: {required - set(summary.columns)}")
        if not np.all(summary["similarity_200kpa_usage"] == "POST_SEPARATION_EVALUATION_ONLY"):
            raise AssertionError("200 kPa 使用阶段字段错误")
        if np.any(
            summary["center_prior_supplement_power_fraction"].to_numpy(float)
            > cfg.algorithm.prior_supplement_total_fraction_cap + 1e-12
        ):
            raise AssertionError("先验补偿超过单样本总功率上限")
        for sample_dir in (root / "out" / "samples").glob("**/center_*"):
            if not sample_dir.is_dir():
                continue
            with np.load(sample_dir / "spatial_prior_fusion_v2_result.npz") as result:
                final = result["final_fused_leak_power"]
                dual = result["dual_spatial_output_power"]
                center = result["raw_center_power"]
                if np.any(final + 1e-14 < dual) or np.any(final > center + 1e-14):
                    raise AssertionError("v2 补偿边界错误")
                if str(result["similarity_200kpa_usage"]) != "POST_SEPARATION_EVALUATION_ONLY":
                    raise AssertionError("NPZ 的 200 kPa 隔离审计字段错误")
            point_table = pd.read_csv(sample_dir / "fixed_ring_20_40cm_plane_point_diagnostics.csv")
            used = point_table.loc[
                point_table["point_role"] == "USED_FIXED_RING_20_TO_40_CM"
            ]
            if len(used) != 40 or set(used["distance_cm"].astype(int)) != {20, 25, 30, 35, 40}:
                raise AssertionError("固定环带必须严格为20/25/30/35/40cm共40点")
        if not (root / "out" / "13_TF_metric_auc.csv").exists():
            raise AssertionError("缺少 v2 AUC 输出")
        auc = pd.read_csv(root / "out" / "13_TF_metric_auc.csv")
        required_auc = {
            "fixed_ring_lab_similarity_combined_median",
            "opposite_pair_lab_similarity_combined_median",
            "dual_spatial_lab_similarity_combined_median",
            "final_lab_similarity_combined_median",
        }
        if not required_auc.issubset(set(auc["metric"].astype(str))):
            raise AssertionError("AUC未完整包含四条输出链")
    print("V2.1 SELF-TEST PASSED")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n用户中止。")
        sys.exit(130)
    except Exception as exc:
        print(f"\n程序失败: {type(exc).__name__}: {exc}")
        traceback.print_exc()
        sys.exit(1)
