outer40 修改版使用说明
======================

一、这次修改了什么
------------------
1. 不再按“排除最近35%”选择背景点。
2. 对每个样本的64个周围点按离中心的距离排序：
   - 最近24个：EXCLUDED_INNER_24，完全不用，权重固定为0。
   - 最外圈40个：USED_OUTER_40，用于空间平面背景拟合。
3. v13的空间指纹也只使用外圈40点，防止内圈24点再次进入空间特征。
4. 输出全部点的权重和实际影响系数。

二、必须按什么顺序运行
----------------------
必须先重新运行v9，再重新训练/测试v13。

原因：旧v9生成的background_power_db、residual_db、excess_power仍然来自旧的35%选点。
只运行新v13只能修正“空间指纹”，不能把旧的频谱残差和时间残差重新计算成outer40结果。

三、程序文件
------------
1. v9_ABCD_raw_plane_outer40.py
   重新读取原始WAV，用outer40计算背景、残差和权重。

2. v12_shared_leak_component_discovery.py
   v13运行依赖文件，请与v13放在同一目录。
   本包只调整了合成自检点数，真实数据算法接口不变。

3. v13_1_AB_train_CD_test_outer40.py
   A+B训练、C和D分别测试；空间指纹固定只使用outer40。

四、运行命令
------------
1. v9：
python v9_ABCD_raw_plane_outer40.py --config v9_ABCD_raw_plane_outer40_config.json

2. v13训练：
python v13_1_AB_train_CD_test_outer40.py train --config v13_1_train_AB_config.json

3. v13测试C/D：
python v13_1_AB_train_CD_test_outer40.py evaluate --config v13_1_test_CD_config.json

4. 自检：
python v9_ABCD_raw_plane_outer40.py --self-test
python v13_1_AB_train_CD_test_outer40.py --self-test

五、权重输出文件
----------------
v9每个场景：
<scene>/v9_all_point_weights.csv

v9四场景总表：
v9_ABCD_all_point_weights.csv

v13训练：
v13_train_all_point_weights.csv

v13外部测试：
v13_external_test_all_point_weights.csv
以及：
v13_test_factory_C_all_point_weights.csv
v13_test_factory_D_all_point_weights.csv

六、权重表中最重要的列
----------------------
role
- CENTER：中心泄漏点，不作为背景点。
- EXCLUDED_INNER_24：离中心最近24点，权重为0。
- USED_OUTER_40：最外圈40点，参与背景拟合。

robust_fit_weight_raw
- 鲁棒拟合可靠性权重，范围约0.05~1。
- 越接近1，说明该点与外圈整体背景更一致。
- 越小，说明该点可能受到局部声源或异常噪声污染。

robust_fit_weight_percent
- 外圈40点的鲁棒权重归一化百分比，总和为100%。

plane_influence_coefficient_signed
- 该点对中心位置平面背景估计的实际线性系数。
- 正值表示该点升高会推高中心背景估计；负值表示可能向相反方向修正空间梯度。

plane_absolute_influence_percent
- 忽略正负方向后的实际影响大小百分比，总和为100%。
- 看“哪个点影响最大”时，优先按这一列从大到小排序。

influence_rank_within_outer40
- 外圈40点按实际影响大小排序，1代表影响最大。

weight_source
- V9_OUTER40_FULL_TIME_FREQUENCY_WEIGHTS：来自新v9完整时频数据，最可信。
- V13_FALLBACK_FROM_POINT_BAND_DB：使用旧NPZ时，v13根据单个频带值后备估算；建议重新运行新v9。
