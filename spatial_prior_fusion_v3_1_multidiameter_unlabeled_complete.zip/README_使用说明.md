# 多孔径消声室T字典 + 工厂无标签相似度判定 v3.1

## 适用数据情况

本版本针对以下情况：

- 有很多消声室真实泄漏录音，包含多种孔径。
- 所有消声室录音都可以确认是泄漏 `T`，但孔径不同。
- 工厂数据无法确认真实泄漏类型，也没有可靠的T/F标签。
- 工厂样本只能根据其处理后频谱与多孔径T字典/参照的相似度进行判断。

程序输出的是 `T_LIKE` 或 `F_LIKE`，含义分别是“与已知泄漏T相似”或“与已知泄漏T不相似”。由于没有已知工厂F，本程序不能估计真实F误报率，也不能声称这是经过监督验证的T/F分类器。

## 配置所有消声室孔径

在 `spatial_prior_fusion_v2_config.json` 的 `lab_groups` 中填写所有孔径。组名可以自行增加或删除，例如：

```json
"lab_groups": {
  "0.1mm": ["D:\\anechoic\\0.1mm"],
  "0.2mm": ["D:\\anechoic\\0.2mm"],
  "0.5mm": ["D:\\anechoic\\0.5mm"],
  "1.0mm": ["D:\\anechoic\\1.0mm"],
  "2.0mm": ["D:\\anechoic\\2.0mm"]
}
```

要求：

- 每一个目录中的WAV都必须是真实泄漏T。
- 同一个WAV不能重复配置到多个孔径组。
- 每个孔径至少需要3个完整WAV，分别保留给训练、相似度参照和T阈值校准。
- `dictionary_positive_groups: []` 表示自动使用 `lab_groups` 中全部孔径；也可以显式填写希望使用的组名。

## 工厂数据配置

每个工厂数据集都使用：

```json
"default_label": "UNLABELED",
"label_by_folder": {}
```

可以配置多个工厂批次，但都保持 `UNLABELED`。程序不会根据目录名推测T/F，也不会计算AUC。

## 预训练方法

每个孔径都按完整WAV分层拆成三部分：

1. `T_DICTIONARY_TRAIN`：训练整体非负字典。
2. `T_SIMILARITY_REFERENCE`：形成多孔径T相似度参照库。
3. `T_THRESHOLD_CALIBRATION`：只用于标定T相似度阈值。

相邻时频帧不会跨集合随机拆分。训练还包括：

- 从整段录音均匀取窗，不只使用开头部分。
- 归一化前过滤低能量帧。
- 每个WAV限制相同最大帧数，防止长录音主导。
- T-only平滑频响和轻微频移增强。
- 搜索字典原子数、激活L1和随机种子。
- 训练与工厂固定字典投影使用相同beta损失和激活正则。

## 多孔径相似度和阈值

对于一个工厂样本，程序同时计算：

1. 工厂最终频谱被整体泄漏字典重构时的帧余弦相似度。
2. 工厂最终频谱与多孔径留出T参照的相似度。由于孔径不同，不取全部参照中位数，而取最相近一部分参照的平均值。

最终判定分数是两者的几何平均，要求样本同时匹配整体字典和真实T参照：

```text
reference_score = 最相近25% T参照的综合相似度均值
dictionary_score = 固定整体字典重构的帧余弦相似度中位数
similarity_decision_score = sqrt(reference_score × dictionary_score)
```

比例由 `dictionary_similarity_top_fraction` 控制，默认 `0.25`。

原始消声室T阈值为：

```text
Q = 留出T校准分数的第5分位数
```

考虑消声室到工厂的域差异，最终阈值为：

```text
threshold = Q - dictionary_factory_domain_margin
```

默认域容差为 `0.05`，没有使用任何F。判定规则：

```text
score >= threshold  → T_LIKE
score <  threshold  → F_LIKE
```

容差越大，越不容易漏掉T，但越可能把环境判成T_LIKE；容差越小则相反。在没有已知F时，不建议根据未知工厂结果反复调整它。

## 运行顺序

安装依赖：

```powershell
python -m pip install -r requirements.txt
```

第一次或消声室数据变化后，重新预训练：

```powershell
python spatial_prior_fusion_v2.py --pretrain-dictionary --config spatial_prior_fusion_v2_config.json
```

也可以双击 `预训练T字典.bat`。

运行自检：

```powershell
python spatial_prior_fusion_v2.py --self-test
```

运行工厂数据：

```powershell
python spatial_prior_fusion_v2.py --config spatial_prior_fusion_v2_config.json
```

也可以双击 `运行正式程序.bat`。

## 预训练输出

- `pretrained_t_dictionary.npz`：整体字典、参照、阈值和模型语义。
- `pretrained_t_dictionary_cv.csv`：候选字典结果。
- `pretrained_t_dictionary_files.csv`：各孔径WAV角色和能量过滤记录。
- `pretrained_t_dictionary_threshold_calibration.csv`：留出T阈值校准分数。
- `pretrained_t_dictionary_manifest.json`：最终参数、阈值公式和文件角色。
- `pretrained_t_dictionary_atoms.png`：整体字典原子。

冻结包语义必须为：

```text
MULTI_DIAMETER_T_ONLY_NO_FACTORY_LABELS
```

## 工厂输出

主要查看：

- `13_unlabeled_factory_similarity_decisions.csv`：无标签工厂判定主表，已按相似度从高到低排序。
- `10_factory_sample_summary.csv`：全部空间、字典和相似度诊断。
- `12_unlabeled_group_summary.csv`：按工厂批次的数值汇总。
- `02_loaded_t_only_dictionary.json`：实际加载的冻结模型、阈值和指纹。

关键字段：

- `similarity_decision`：`T_LIKE` 或 `F_LIKE`。
- `similarity_decision_score`：多孔径T相似度分数。
- `similarity_dictionary_frame_cosine_median`：与整体字典的匹配程度。
- `similarity_multi_reference_score`：与最相近多孔径T参照的匹配程度。
- `similarity_decision_threshold`：冻结阈值。
- `similarity_decision_margin`：分数减阈值；越大越偏向T_LIKE。
- `similarity_decision_confidence`：离阈值的相对距离，仅表示判定稳定程度，不是统计概率。

没有真实T/F标签时不会生成AUC和T/F成对比较文件。
