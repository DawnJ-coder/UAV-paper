# -*- coding: utf-8 -*-
"""多孔径消声室T整体字典 + 工厂无标签相似度判定 v3.1。

约束：
- 工厂数据没有T/F真值，不进行监督训练、AUC选参或T/F配对验证。
- 每个样本独立计算20-40cm固定环带平面和相反方向空间模型及其权重。
- 任意孔径消声室数据均视为泄漏T，并按孔径分层拆分训练/参照/阈值校准。
- 只处理中心编号 00_00、00_01。
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import traceback
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from scipy.io import wavfile
from sklearn.metrics import roc_auc_score

import _spatial_v3_engine as core
import spatial_prior_fusion_v1 as common
import t_only_dictionary as tdict


EPS = core.EPS
ALLOWED_CENTER_IDS = common.ALLOWED_CENTER_IDS

V2_DEFAULTS: Dict[str, Any] = {
    "spatial_disagreement_midpoint_db": 3.0,
    "spatial_disagreement_softness_db": 1.0,
    "spatial_confidence_floor": 0.10,
    "outer_geometry_fallback_confidence": 0.35,
    "prior_activation_base_margin_db": 1.5,
    "prior_activation_uncertainty_weight": 0.50,
    "prior_extra_ratio_midpoint": 0.10,
    "prior_extra_ratio_softness": 0.04,
    "prior_supplement_bin_cap": 0.25,
    "prior_supplement_total_fraction_cap": 0.10,
}


def _attach_v2_config(
    cfg: core.RunConfig,
    raw_algorithm: Optional[Mapping[str, Any]] = None,
) -> None:
    raw = dict(raw_algorithm or {})
    for key, default in V2_DEFAULTS.items():
        setattr(cfg.algorithm, key, raw.get(key, default))
    a = cfg.algorithm
    if float(a.spatial_disagreement_softness_db) <= 0:
        raise ValueError("spatial_disagreement_softness_db 必须>0")
    if not 0 <= float(a.spatial_confidence_floor) <= 1:
        raise ValueError("spatial_confidence_floor 必须位于[0,1]")
    if not 0 <= float(a.prior_supplement_bin_cap) <= 1:
        raise ValueError("prior_supplement_bin_cap 必须位于[0,1]")
    if not 0 <= float(a.prior_supplement_total_fraction_cap) <= 1:
        raise ValueError("prior_supplement_total_fraction_cap 必须位于[0,1]")


def load_config(path: Path) -> core.RunConfig:
    cfg = common.load_config(path)
    with path.open("r", encoding="utf-8-sig") as handle:
        raw = json.load(handle)
    _attach_v2_config(cfg, raw.get("algorithm", {}))
    for dataset in cfg.factory_datasets:
        if str(dataset.default_label).upper() != "UNLABELED" or dataset.label_by_folder:
            raise ValueError(
                f"工厂数据集 {dataset.name!r} 没有可靠T/F真值："
                "default_label必须为UNLABELED且label_by_folder必须为空"
            )
    return cfg


def _weighted_mean_matrix(values: np.ndarray, power: np.ndarray) -> float:
    return core.weighted_mean(np.asarray(values, dtype=float), np.asarray(power, dtype=float))


def _model_confidence(
    uncertainty_db: np.ndarray,
    availability: float,
    cfg: core.AlgorithmConfig,
) -> np.ndarray:
    floor = float(cfg.spatial_confidence_floor)
    confidence = floor + (1.0 - floor) * np.exp(
        -np.maximum(uncertainty_db, 0.0)
        / max(float(cfg.prediction_uncertainty_ref_db), 1e-6)
    )
    return np.clip(float(availability) * confidence, EPS, 1.0)


def fuse_spatial_predictions(
    center_power: np.ndarray,
    outer: Dict[str, Any],
    pair: Optional[Dict[str, Any]],
    cfg: core.AlgorithmConfig,
) -> Dict[str, np.ndarray | float]:
    """按单样本预测不确定度融合两种空间背景；分歧大时转向较低背景。"""
    outer_bg = np.maximum(np.asarray(outer["background_power"], dtype=float), EPS)
    outer_uncertainty = np.maximum(
        np.asarray(outer["prediction_uncertainty_db"], dtype=float), 0.0
    )
    outer_availability = (
        1.0 if int(outer.get("geometry_ok", 0)) else float(cfg.outer_geometry_fallback_confidence)
    )
    outer_confidence = _model_confidence(outer_uncertainty, outer_availability, cfg)

    if pair is None:
        residual = np.maximum(center_power - outer_bg, 0.0)
        ones = np.ones_like(center_power, dtype=float)
        zeros = np.zeros_like(center_power, dtype=float)
        return {
            "background_power": outer_bg,
            "local_excess_power": residual,
            "spatial_output_power": residual,
            "outer_weight": ones,
            "pair_weight": zeros,
            "outer_confidence": outer_confidence,
            "pair_confidence": zeros,
            "combined_confidence": outer_confidence,
            "prediction_uncertainty_db": outer_uncertainty,
            "background_disagreement_db": zeros,
            "conservative_gate": zeros,
            "dual_spatial_gate": ones,
        }

    pair_bg = np.maximum(np.asarray(pair["background_power"], dtype=float), EPS)
    pair_uncertainty = np.maximum(
        np.asarray(pair["prediction_uncertainty_db"], dtype=float), 0.0
    )
    pair_confidence = _model_confidence(pair_uncertainty, 1.0, cfg)
    confidence_sum = outer_confidence + pair_confidence + EPS
    outer_weight = outer_confidence / confidence_sum
    pair_weight = pair_confidence / confidence_sum

    outer_db = 10.0 * np.log10(outer_bg)
    pair_db = 10.0 * np.log10(pair_bg)
    weighted_db = outer_weight * outer_db + pair_weight * pair_db
    disagreement_db = np.abs(outer_db - pair_db)
    conservative_gate = core.sigmoid(
        (disagreement_db - float(cfg.spatial_disagreement_midpoint_db))
        / max(float(cfg.spatial_disagreement_softness_db), 1e-6)
    )
    fused_db = (
        (1.0 - conservative_gate) * weighted_db
        + conservative_gate * np.minimum(outer_db, pair_db)
    )
    fused_bg = np.power(10.0, np.clip(fused_db, -300.0, 300.0) / 10.0)
    local_excess = np.maximum(center_power - fused_bg, 0.0)

    pair_gate = np.clip(np.asarray(pair["spatial_gate"], dtype=float), 0.0, 1.0)
    # 固定20-40cm环带分支保留正残差；pair分支沿用v3多方向支持门控。
    dual_gate = np.clip(outer_weight + pair_weight * pair_gate, 0.0, 1.0)
    spatial_output = np.minimum(local_excess * dual_gate, center_power)
    combined_confidence = np.clip(
        outer_weight * outer_confidence + pair_weight * pair_confidence,
        0.0,
        1.0,
    )
    fused_uncertainty = (
        outer_weight * outer_uncertainty
        + pair_weight * pair_uncertainty
        + outer_weight * pair_weight * disagreement_db
    )
    return {
        "background_power": fused_bg,
        "local_excess_power": local_excess,
        "spatial_output_power": spatial_output,
        "outer_weight": outer_weight,
        "pair_weight": pair_weight,
        "outer_confidence": outer_confidence,
        "pair_confidence": pair_confidence,
        "combined_confidence": combined_confidence,
        "prediction_uncertainty_db": fused_uncertainty,
        "background_disagreement_db": disagreement_db,
        "conservative_gate": conservative_gate,
        "dual_spatial_gate": dual_gate,
    }


def _project_center_and_points(
    center_power: np.ndarray,
    point_cache: Sequence[Tuple[core.SpatialFile, np.ndarray]],
    dictionary: np.ndarray,
    cfg: core.AlgorithmConfig,
    seed: int,
) -> Tuple[np.ndarray, List[Tuple[core.SpatialFile, np.ndarray]], np.ndarray]:
    n_frames = center_power.shape[1]
    blocks = [center_power] + [power for _, power in point_cache]
    all_power = np.concatenate(blocks, axis=1)
    activation, reconstruction, _ = tdict.infer_fixed_dictionary(
        np.maximum(all_power, 0.0),
        dictionary,
        cfg.dictionary_beta_loss,
        cfg.dictionary_activation_l1,
        cfg.lab_projection_iterations,
        seed,
    )
    center_activation = activation[:, :n_frames]
    point_activations: List[Tuple[core.SpatialFile, np.ndarray]] = []
    for index, (point, _) in enumerate(point_cache):
        start = (index + 1) * n_frames
        point_activations.append((point, activation[:, start : start + n_frames]))
    center_reconstruction = reconstruction[:, :n_frames]
    return center_activation, point_activations, center_reconstruction


def build_center_extra_prior_supplement(
    center_power: np.ndarray,
    point_cache: Sequence[Tuple[core.SpatialFile, np.ndarray]],
    dual_spatial_power: np.ndarray,
    dictionary: np.ndarray,
    cfg: core.AlgorithmConfig,
    seed: int,
) -> Dict[str, Any]:
    """只补中心相对周围额外出现的 0.5 mm 先验激活。"""
    center_h, point_h, center_prior_power = _project_center_and_points(
        center_power, point_cache, dictionary, cfg, seed
    )
    outer_h, _ = common.build_fixed_ring_plane_prediction(center_h, point_h, cfg)
    pair_h: Optional[Dict[str, Any]]
    try:
        pair_h, _ = core.build_opposite_pair_prediction(center_h, point_h, cfg)
    except Exception:
        pair_h = None
    fused_h = fuse_spatial_predictions(center_h, outer_h, pair_h, cfg)
    environment_h = np.maximum(np.asarray(fused_h["background_power"], dtype=float), 0.0)
    uncertainty_db = np.maximum(
        np.asarray(fused_h["prediction_uncertainty_db"], dtype=float), 0.0
    )
    required_margin_db = (
        float(cfg.prior_activation_base_margin_db)
        + float(cfg.prior_activation_uncertainty_weight) * np.minimum(uncertainty_db, 12.0)
    )
    environment_upper = environment_h * np.power(10.0, required_margin_db / 10.0)
    extra_h = np.maximum(center_h - environment_upper, 0.0)
    extra_prior_power = np.maximum(dictionary @ extra_h, 0.0)

    extra_ratio_frame = np.sum(extra_h, axis=0) / (np.sum(center_h, axis=0) + EPS)
    extra_gate_frame = core.sigmoid(
        (extra_ratio_frame - float(cfg.prior_extra_ratio_midpoint))
        / max(float(cfg.prior_extra_ratio_softness), 1e-6)
    )
    activation_confidence = np.clip(
        np.asarray(fused_h["combined_confidence"], dtype=float), 0.0, 1.0
    )
    atom_confidence_frame = np.sum(
        activation_confidence * extra_h, axis=0
    ) / (np.sum(extra_h, axis=0) + EPS)
    prior_gate = extra_gate_frame * atom_confidence_frame

    absorbed_by_spatial = np.maximum(center_power - dual_spatial_power, 0.0)
    nonoverlap_prior = np.maximum(extra_prior_power - dual_spatial_power, 0.0)
    candidate = np.minimum(absorbed_by_spatial, nonoverlap_prior)
    supplement = candidate * prior_gate[None, :]
    supplement = np.minimum(
        supplement,
        float(cfg.prior_supplement_bin_cap) * np.maximum(center_power, 0.0),
    )
    total_cap = float(cfg.prior_supplement_total_fraction_cap) * float(np.sum(center_power))
    if float(np.sum(supplement)) > total_cap > 0:
        supplement *= total_cap / (float(np.sum(supplement)) + EPS)
    return {
        "supplement_power": np.maximum(supplement, 0.0),
        "center_activation": center_h,
        "environment_activation": environment_h,
        "extra_activation": extra_h,
        "center_prior_power": center_prior_power,
        "extra_prior_power": extra_prior_power,
        "activation_uncertainty_db": uncertainty_db,
        "extra_ratio_frame": extra_ratio_frame,
        "prior_gate_frame": prior_gate,
        "activation_outer_weight": fused_h["outer_weight"],
        "activation_pair_weight": fused_h["pair_weight"],
    }


def _similarity(power: np.ndarray, references: Sequence[Tuple[str, Path, np.ndarray]]) -> Dict[str, Any]:
    return core.evaluate_against_lab(core.representative_spectrum(power), references)


def _enrich_rows(
    rows: Sequence[Mapping[str, Any]],
    diagnostic_type: str,
    dataset: core.FactoryDataset,
    normalized_folder: str,
    center_id: str,
    label: str,
    leak_type: str,
    condition_name: str,
    pair_key: str,
) -> List[Dict[str, Any]]:
    return [{
        "diagnostic_type": diagnostic_type,
        "dataset": dataset.name,
        "leak_type": leak_type,
        "condition_name": condition_name,
        "time_folder": normalized_folder,
        "condition_relative_path": normalized_folder,
        "pair_key": pair_key,
        "center_id": center_id,
        "label": label,
        **dict(row),
    } for row in rows]


def process_factory_sample(
    dataset: core.FactoryDataset,
    time_folder: str,
    center_id: str,
    center_path: Path,
    spatial_files: Sequence[core.SpatialFile],
    lab: Dict[str, Any],
    cfg: core.RunConfig,
    sample_dir: Path,
    seed: int,
) -> Tuple[Dict[str, Any], List[Dict[str, Any]], List[Dict[str, Any]]]:
    a = cfg.algorithm
    core.ensure_dir(sample_dir)
    center_slice = core.read_wav_slice(center_path, center_id, a)
    neighbors: List[Tuple[core.SpatialFile, core.WavSlice]] = []
    errors: List[Dict[str, Any]] = []
    for point in spatial_files:
        try:
            item = core.read_wav_slice(point.path, center_id, a)
            if item.fs != center_slice.fs or len(item.x) != len(center_slice.x):
                raise ValueError("邻点与中心点采样率或片段长度不一致")
            neighbors.append((point, item))
        except Exception as exc:
            errors.append({
                "dataset": dataset.name,
                "time_folder": time_folder,
                "center_id": center_id,
                "file": str(point.path),
                "stage": "read_neighbor",
                "error": f"{type(exc).__name__}: {exc}",
            })
    if len(neighbors) < a.min_neighbors:
        raise RuntimeError(f"有效邻点不足: {len(neighbors)} < {a.min_neighbors}")

    amplitude_info = core.amplitude_diagnostics(
        [center_slice] + [item for _, item in neighbors], a
    )
    freq_full, time_stft, z_center = core.stft_full(center_slice.x, center_slice.fs, a)
    freq_band, center_power, band_mask = core.power_band_from_stft(freq_full, z_center, a)
    if len(freq_band) != len(lab["freq_hz"]) or np.max(np.abs(freq_band - lab["freq_hz"])) > 1e-6:
        raise ValueError("工厂样本与实验室参照频率轴不一致")

    point_cache: List[Tuple[core.SpatialFile, np.ndarray]] = []
    for point, item in neighbors:
        freq, _, z = core.stft_full(item.x, item.fs, a)
        point_freq, power, _ = core.power_band_from_stft(freq, z, a)
        if len(point_freq) != len(freq_band) or np.max(np.abs(point_freq - freq_band)) > 1e-6:
            raise ValueError(f"邻点频率轴不一致: {point.path.name}")
        point_cache.append((point, power))

    outer, outer_rows = common.build_fixed_ring_plane_prediction(center_power, point_cache, a)
    pair_error = ""
    pair_rows: List[Dict[str, Any]] = []
    try:
        pair, pair_rows = core.build_opposite_pair_prediction(center_power, point_cache, a)
    except Exception as exc:
        pair = None
        pair_error = f"{type(exc).__name__}: {exc}"

    outer_power = np.minimum(np.asarray(outer["local_excess_power"], dtype=float), center_power)
    pair_power = (
        np.minimum(np.asarray(pair["spatial_local_power"], dtype=float), center_power)
        if pair is not None else np.zeros_like(center_power)
    )
    dual = fuse_spatial_predictions(center_power, outer, pair, a)
    dual_power = np.minimum(np.asarray(dual["spatial_output_power"], dtype=float), center_power)

    prior = build_center_extra_prior_supplement(
        center_power, point_cache, dual_power, lab["ws"], a, seed + 1000
    )
    supplement = np.asarray(prior["supplement_power"], dtype=float)
    final_power = np.minimum(dual_power + supplement, center_power)
    remaining_power = np.maximum(center_power - final_power, 0.0)

    # 到这里为止空间分离已经冻结；下面使用多孔径消声室T参照计算无标签判定。
    t_references = lab["similarity_specs"]
    raw_sim = _similarity(center_power, t_references)
    background_sim = _similarity(np.asarray(dual["background_power"]), t_references)
    outer_sim = _similarity(outer_power, t_references)
    pair_sim = _similarity(pair_power, t_references)
    dual_sim = _similarity(dual_power, t_references)
    final_sim = _similarity(final_power, t_references)
    remaining_sim = _similarity(remaining_power, t_references)
    final_similarity = float(final_sim["lab_similarity_combined_median"])
    remaining_similarity = float(remaining_sim["lab_similarity_combined_median"])
    background_similarity = float(background_sim["lab_similarity_combined_median"])
    final_vs_remaining = final_similarity - remaining_similarity
    final_vs_background = final_similarity - background_similarity
    decision_parts = tdict.decision_similarity_for_power(
        final_power,
        lab["ws"],
        t_references,
        str(a.dictionary_beta_loss),
        float(a.dictionary_activation_l1),
        int(a.lab_projection_iterations),
        seed + 9000,
        float(lab["similarity_top_fraction"]),
    )
    decision_score = float(decision_parts["combined"])
    decision_threshold = float(lab["decision_threshold"])
    decision_scale = max(float(lab["decision_scale"]), 1.0e-6)
    decision_margin = decision_score - decision_threshold
    similarity_decision = "T_LIKE" if decision_margin >= 0.0 else "F_LIKE"
    decision_confidence = float(1.0 - np.exp(-abs(decision_margin) / decision_scale))

    amplitude_mask = np.sqrt(final_power / np.maximum(center_power, EPS))
    z_leak = np.zeros_like(z_center)
    z_leak[band_mask] = amplitude_mask * z_center[band_mask]
    z_remaining = z_center - z_leak
    leak_wav = core.reconstruct_wav(z_leak, center_slice.fs, a, len(center_slice.x))
    remaining_wav = core.reconstruct_wav(z_remaining, center_slice.fs, a, len(center_slice.x))
    if a.save_wavs:
        wavfile.write(str(sample_dir / "estimated_v2_fused_leak.wav"), center_slice.fs, leak_wav.astype(np.float32))
        wavfile.write(str(sample_dir / "estimated_v2_remaining_environment.wav"), center_slice.fs, remaining_wav.astype(np.float32))
        wavfile.write(str(sample_dir / "raw_center_slice.wav"), center_slice.fs, center_slice.x.astype(np.float32))

    total = float(np.sum(center_power)) + EPS
    outer_fraction = float(np.sum(outer_power) / total)
    pair_fraction = float(np.sum(pair_power) / total)
    dual_fraction = float(np.sum(dual_power) / total)
    supplement_fraction = float(np.sum(supplement) / total)
    final_fraction = float(np.sum(final_power) / total)
    excess_median, excess_weighted = core.robust_positive_summary(
        10.0 * np.log10(
            np.maximum(center_power, EPS) / np.maximum(np.asarray(dual["background_power"]), EPS)
        ),
        np.maximum(center_power - np.asarray(dual["background_power"]), 0.0),
    )
    pair_support = (
        _weighted_mean_matrix(pair["pair_support_ratio"], center_power) if pair is not None else 0.0
    )
    axis_support = (
        _weighted_mean_matrix(pair["axis_support_ratio"], center_power) if pair is not None else 0.0
    )
    confidence_weighted = _weighted_mean_matrix(dual["combined_confidence"], center_power)
    uncertainty_weighted = _weighted_mean_matrix(dual["prediction_uncertainty_db"], center_power)
    outer_weighted = _weighted_mean_matrix(dual["outer_weight"], center_power)
    pair_weighted = _weighted_mean_matrix(dual["pair_weight"], center_power)
    disagreement_weighted = _weighted_mean_matrix(dual["background_disagreement_db"], center_power)
    prior_extra_ratio = _weighted_mean_matrix(prior["extra_ratio_frame"][None, :], center_power)
    prior_gate_weighted = _weighted_mean_matrix(prior["prior_gate_frame"][None, :], center_power)

    label = core.sample_label(dataset, time_folder)
    leak_type, condition_name = core.infer_leak_type_and_condition(time_folder)
    normalized_folder = core.normalize_relative_folder(time_folder)
    canonical = core.canonical_condition(normalized_folder, cfg.pairing_remove_tokens)
    pair_key = f"{canonical}::{center_id}"
    evidence_flag = (
        "STRONG_FINAL_T_REFERENCE_CONTRAST"
        if final_vs_remaining > 0 and final_vs_background > 0
        else "WEAK_FINAL_T_REFERENCE_CONTRAST"
    )
    summary: Dict[str, Any] = {
        "method": "V3_1_MULTI_DIAMETER_T_DICTIONARY_UNLABELED_FACTORY_DECISION",
        "data_semantics": "MULTI_DIAMETER_T_ONLY_NO_FACTORY_LABELS",
        "similarity_reference_usage": "FROZEN_MULTI_DIAMETER_T_REFERENCE",
        "similarity_0p1mm_usage": "LEGACY_COLUMN_MULTI_DIAMETER_T_REFERENCE",
        "dataset": dataset.name,
        "leak_type": leak_type,
        "condition_name": condition_name,
        "time_folder": normalized_folder,
        "condition_relative_path": normalized_folder,
        "canonical_condition": canonical,
        "pair_key": pair_key,
        "center_id": center_id,
        "label": label,
        "ground_truth_available": str(label).upper() in {"T", "F", "TRUE", "FALSE"},
        "similarity_decision": similarity_decision,
        "similarity_decision_score": decision_score,
        "similarity_dictionary_frame_cosine_median": float(
            decision_parts["dictionary_frame_cosine_median"]
        ),
        "similarity_multi_reference_score": float(decision_parts["multi_reference_similarity"]),
        "similarity_decision_threshold": decision_threshold,
        "similarity_decision_margin": decision_margin,
        "similarity_decision_confidence": decision_confidence,
        "similarity_decision_rule": "T_LIKE_IF_SCORE_GTE_THRESHOLD_ELSE_F_LIKE",
        "similarity_decision_calibration": "HELD_OUT_ANECHOIC_T_ONLY_NO_KNOWN_F",
        "center_file": str(center_path),
        "segment_start_seconds": center_slice.segment_start_seconds,
        "segment_end_seconds": center_slice.segment_end_seconds,
        "sample_rate_hz": center_slice.fs,
        "n_neighbors_used": len(neighbors),
        "n_fixed_ring_points": outer["n_ring_points"],
        "fixed_ring_distances_cm": "20;25;30;35;40",
        "n_complete_opposite_pairs": int(pair["pair_delta_db_stack"].shape[0]) if pair is not None else 0,
        "n_complete_axes": int(pair["axis_delta_db_stack"].shape[0]) if pair is not None else 0,
        "pair_method_status": "OK" if pair is not None else "FALLBACK_OUTER40_ONLY",
        "pair_method_error": pair_error,
        "plane_valid": outer["plane_valid"],
        "plane_used": outer["plane_used"],
        "plane_geometry_ok": outer["geometry_ok"],
        "plane_condition_number": outer["fit_condition_number"],
        "plane_fit_mae_db": outer["fit_plane_mae_db"],
        "fixed_ring_weight_power_weighted": outer_weighted,
        "opposite_pair_weight_power_weighted": pair_weighted,
        "dual_background_disagreement_db_power_weighted": disagreement_weighted,
        "background_prediction_uncertainty_db_power_weighted": uncertainty_weighted,
        "background_prediction_confidence_power_weighted": confidence_weighted,
        "opposite_pair_support_ratio_power_weighted": pair_support,
        "opposite_axis_support_ratio_power_weighted": axis_support,
        "fixed_ring_power_fraction": outer_fraction,
        "opposite_pair_power_fraction": pair_fraction,
        "dual_spatial_power_fraction": dual_fraction,
        "center_local_excess_power_fraction": dual_fraction,
        "center_spatial_filtered_power_fraction": dual_fraction,
        "center_prior_supplement_power_fraction": supplement_fraction,
        "center_final_leak_power_fraction": final_fraction,
        "prior_center_extra_activation_ratio_power_weighted": prior_extra_ratio,
        "prior_supplement_gate_power_weighted": prior_gate_weighted,
        "center_excess_db_positive_median": excess_median,
        "center_excess_db_power_weighted_mean": excess_weighted,
        "final_vs_remaining_similarity_contrast": final_vs_remaining,
        "final_vs_background_similarity_contrast": final_vs_background,
        "source_center_score": final_vs_remaining,
        "spatial_evidence_flag": evidence_flag,
        "lab_validation_mode": "MULTI_DIAMETER_T_REFERENCE_AND_T_ONLY_THRESHOLD",
        **amplitude_info,
        **{f"raw_{key}": value for key, value in raw_sim.items()},
        **{f"background_{key}": value for key, value in background_sim.items()},
        **{f"fixed_ring_{key}": value for key, value in outer_sim.items()},
        **{f"opposite_pair_{key}": value for key, value in pair_sim.items()},
        **{f"dual_spatial_{key}": value for key, value in dual_sim.items()},
        **{f"final_{key}": value for key, value in final_sim.items()},
        **{f"remaining_{key}": value for key, value in remaining_sim.items()},
    }
    # 兼容既有汇总列。
    summary["spatial_local_lab_similarity_combined_median"] = float(
        dual_sim["lab_similarity_combined_median"]
    )
    summary["leak_lab_similarity_combined_median"] = final_similarity
    summary["raw_lab_similarity_combined_median"] = float(raw_sim["lab_similarity_combined_median"])
    summary["leak_similarity_gain_over_raw"] = final_similarity - float(
        raw_sim["lab_similarity_combined_median"]
    )
    summary["leak_vs_remaining_similarity_gap"] = final_vs_remaining

    diagnostic_rows = _enrich_rows(
        outer_rows, "OUTER40_POINT", dataset, normalized_folder, center_id,
        label, leak_type, condition_name, pair_key,
    )
    diagnostic_rows += _enrich_rows(
        pair_rows, "OPPOSITE_PAIR", dataset, normalized_folder, center_id,
        label, leak_type, condition_name, pair_key,
    )
    core.write_json(sample_dir / "summary.json", summary)
    core.write_csv(sample_dir / "v2_spatial_diagnostics.csv", diagnostic_rows)
    core.write_csv(sample_dir / "fixed_ring_20_40cm_plane_point_diagnostics.csv", outer_rows)
    core.write_csv(sample_dir / "opposite_pair_diagnostics.csv", pair_rows)

    if a.save_npz:
        np.savez_compressed(
            sample_dir / "spatial_prior_fusion_v2_result.npz",
            freq_hz=freq_band,
            time_s=time_stft,
            raw_center_power=center_power,
            fixed_ring_20_40cm_background_power=outer["background_power"],
            fixed_ring_20_40cm_output_power=outer_power,
            opposite_pair_background_power=(pair["background_power"] if pair is not None else np.zeros_like(center_power)),
            opposite_pair_output_power=pair_power,
            dual_spatial_background_power=dual["background_power"],
            dual_spatial_output_power=dual_power,
            prior_supplement_power=supplement,
            final_fused_leak_power=final_power,
            remaining_environment_power=remaining_power,
            fixed_ring_weight=dual["outer_weight"],
            opposite_pair_weight=dual["pair_weight"],
            background_disagreement_db=dual["background_disagreement_db"],
            combined_prediction_uncertainty_db=dual["prediction_uncertainty_db"],
            prior_center_activation=prior["center_activation"],
            prior_environment_activation=prior["environment_activation"],
            prior_extra_activation=prior["extra_activation"],
            prior_extra_ratio_frame=prior["extra_ratio_frame"],
            prior_gate_frame=prior["prior_gate_frame"],
            leak_dictionary_multi_diameter=lab["ws"],
            leak_dictionary_0p5mm=lab["ws"],
            similarity_reference_usage=np.asarray("FROZEN_MULTI_DIAMETER_T_REFERENCE"),
            similarity_decision=np.asarray(similarity_decision),
            similarity_decision_score=np.asarray(decision_score),
            similarity_dictionary_frame_cosine_median=np.asarray(
                decision_parts["dictionary_frame_cosine_median"]
            ),
            similarity_multi_reference_score=np.asarray(
                decision_parts["multi_reference_similarity"]
            ),
            similarity_decision_threshold=np.asarray(decision_threshold),
            similarity_0p1mm_usage=np.asarray("LEGACY_COLUMN_MULTI_DIAMETER_T_REFERENCE"),
        )

    if a.save_plots:
        title = f"{dataset.name} | {time_folder} | {center_id}"
        core.plot_sample_spectra(
            freq_band,
            core.representative_spectrum(center_power),
            core.representative_spectrum(np.asarray(dual["background_power"])),
            core.representative_spectrum(final_power),
            core.representative_spectrum(remaining_power),
            lab["lab_proto"],
            title,
            sample_dir / "spectrum_comparison.png",
        )
        common._plot_fusion_diagnostics(
            freq_band,
            time_stft,
            dual_power,
            supplement,
            final_power,
            np.asarray(dual["prediction_uncertainty_db"]),
            title,
            sample_dir / "fusion_diagnostics.png",
        )
    return summary, diagnostic_rows, errors


EVALUATION_METRICS = [
    "fixed_ring_power_fraction",
    "opposite_pair_power_fraction",
    "dual_spatial_power_fraction",
    "center_prior_supplement_power_fraction",
    "center_final_leak_power_fraction",
    "fixed_ring_lab_similarity_combined_median",
    "opposite_pair_lab_similarity_combined_median",
    "dual_spatial_lab_similarity_combined_median",
    "final_lab_similarity_combined_median",
    "final_vs_remaining_similarity_contrast",
    "final_vs_background_similarity_contrast",
    "prior_center_extra_activation_ratio_power_weighted",
]


def _write_v2_evaluation(output_dir: Path, summary: pd.DataFrame) -> None:
    if summary.empty:
        return
    decision_columns = [
        column for column in (
            "dataset", "time_folder", "center_id", "center_file",
            "similarity_decision", "similarity_decision_score",
            "similarity_dictionary_frame_cosine_median",
            "similarity_multi_reference_score",
            "similarity_decision_threshold", "similarity_decision_margin",
            "similarity_decision_confidence", "final_lab_similarity_combined_median",
        ) if column in summary.columns
    ]
    decisions = summary[decision_columns].copy()
    if "similarity_decision_score" in decisions:
        decisions = decisions.sort_values("similarity_decision_score", ascending=False, kind="stable")
    decisions.to_csv(
        output_dir / "13_unlabeled_factory_similarity_decisions.csv",
        index=False,
        encoding="utf-8-sig",
    )

    if "label" not in summary:
        return
    labels = summary["label"].astype(str).str.upper().replace({"TRUE": "T", "FALSE": "F"})
    valid = labels.isin(["T", "F"])
    sub = summary.loc[valid].copy()
    y = labels.loc[valid].eq("T").astype(int).to_numpy()
    if len(np.unique(y)) < 2:
        return
    auc_rows: List[Dict[str, Any]] = []
    for metric in EVALUATION_METRICS:
        values = pd.to_numeric(sub.get(metric), errors="coerce")
        mask = values.notna().to_numpy()
        if np.sum(mask) < 2 or len(np.unique(y[mask])) < 2:
            continue
        auc = float(roc_auc_score(y[mask], values.to_numpy()[mask]))
        auc_rows.append({
            "metric": metric,
            "auc_T_higher": auc,
            "expected_direction": "T_HIGHER",
            "n_samples": int(np.sum(mask)),
        })
    pd.DataFrame(auc_rows).to_csv(
        output_dir / "13_TF_metric_auc.csv", index=False, encoding="utf-8-sig"
    )

    sub["label_norm"] = labels.loc[valid]
    grouped = sub.groupby(["pair_key", "label_norm"], as_index=False)[EVALUATION_METRICS].mean(numeric_only=True)
    true_rows = grouped[grouped["label_norm"] == "T"].set_index("pair_key")
    false_rows = grouped[grouped["label_norm"] == "F"].set_index("pair_key")
    common_keys = sorted(set(true_rows.index) & set(false_rows.index))
    paired_rows: List[Dict[str, Any]] = []
    for key in common_keys:
        row: Dict[str, Any] = {"pair_key": key}
        for metric in EVALUATION_METRICS:
            t_value = float(true_rows.loc[key, metric])
            f_value = float(false_rows.loc[key, metric])
            row[f"T_{metric}"] = t_value
            row[f"F_{metric}"] = f_value
            row[f"T_minus_F_{metric}"] = t_value - f_value
        paired_rows.append(row)
    paired = pd.DataFrame(paired_rows)
    paired.to_csv(output_dir / "14_TF_paired_comparison.csv", index=False, encoding="utf-8-sig")
    paired_summary: List[Dict[str, Any]] = []
    if not paired.empty:
        for metric in EVALUATION_METRICS:
            values = pd.to_numeric(paired[f"T_minus_F_{metric}"], errors="coerce").dropna()
            paired_summary.append({
                "metric": metric,
                "n_pairs": len(values),
                "T_greater_F_fraction": float(np.mean(values > 0)),
                "T_minus_F_mean": float(values.mean()),
                "T_minus_F_median": float(values.median()),
            })
    pd.DataFrame(paired_summary).to_csv(
        output_dir / "15_TF_paired_summary.csv", index=False, encoding="utf-8-sig"
    )


def write_read_me_first(output_dir: Path, cfg: core.RunConfig, lab: Dict[str, Any]) -> None:
    text = f"""多孔径消声室T字典 + 工厂无标签相似度判定 v3.1
 =====================================================

仅处理中心点：{', '.join(ALLOWED_CENTER_IDS)}
冻结字典：{lab.get('bundle_path', '')}
字典训练语义：MULTI_DIAMETER_T_ONLY_NO_FACTORY_LABELS
所有消声室孔径均作为泄漏T的不同子域；工厂样本没有真实T/F标签。
T_LIKE阈值：{lab.get('decision_threshold', float('nan')):.6f}
判定规则：similarity_decision_score >= 阈值 => T_LIKE，否则F_LIKE。

四条输出链：
1. fixed_ring：固定使用20/25/30/35/40cm五圈，每圈8方向，共40点做鲁棒平面。
2. opposite_pair：v3同半径相反方向、多轴支持门控。
3. dual_spatial：按两种模型的单样本预测不确定度融合；分歧大时采用较低背景。
4. final：dual_spatial + 多孔径T冻结字典的中心相对周围额外激活补偿。

相似度使用每个孔径留出的T参照，并取最相近一部分参照的均值。
阈值只由另一批留出的消声室T低分位数标定，没有使用任何已知工厂F。

主要文件：
- 10_factory_sample_summary.csv：四条方法链的功率、相似度、权重和补偿。
- 13_unlabeled_factory_similarity_decisions.csv：工厂样本T_LIKE/F_LIKE判定主表。
- samples/.../spatial_prior_fusion_v2_result.npz：完整时频矩阵。
- samples/.../v2_spatial_diagnostics.csv：20-40cm环带点权重和相反方向诊断。

重点字段：similarity_decision、similarity_decision_score、similarity_decision_threshold、
similarity_decision_margin、similarity_decision_confidence。

没有已知F，因此本阈值只能标定消声室T覆盖率，不能给出真实工厂F误报率。
"""
    (output_dir / "00_READ_ME_FIRST.txt").write_text(text, encoding="utf-8")


def run_analysis(cfg: core.RunConfig) -> Dict[str, Path]:
    core.prepare_lab_reference = common.prepare_lab_reference
    core.process_factory_sample = process_factory_sample
    core.write_read_me_first = write_read_me_first
    core.build_center_index = common.build_allowed_center_index
    core.build_offset_index = common.build_allowed_offset_index
    core.directory_has_center_wav = common.directory_has_allowed_center_wav
    paths = core.run_analysis(cfg)
    output_dir = Path(cfg.output_dir)
    summary = pd.read_csv(paths["summary"])
    _write_v2_evaluation(output_dir, summary)
    paths["unlabeled_similarity_decisions"] = output_dir / "13_unlabeled_factory_similarity_decisions.csv"

    old_diagnostics = output_dir / "11_opposite_pair_diagnostics.csv"
    new_diagnostics = output_dir / "11_v2_spatial_diagnostics.csv"
    if old_diagnostics.exists():
        new_diagnostics.write_bytes(old_diagnostics.read_bytes())
        paths["v2_spatial_diagnostics"] = new_diagnostics

    run_info_path = output_dir / "00_run_info.json"
    run_info = json.loads(run_info_path.read_text(encoding="utf-8")) if run_info_path.exists() else {}
    run_info.update({
        "program_version": "spatial-prior-fusion-v3.1-multi-diameter-unlabeled-factory",
        "processed_center_ids": list(ALLOWED_CENTER_IDS),
        "factory_training_set_used": False,
        "sample_specific_spatial_learning": True,
        "dictionary_training_semantics": "MULTI_DIAMETER_T_ONLY_NO_FACTORY_LABELS",
        "pretrained_dictionary_path": str(cfg.algorithm.pretrained_dictionary_path),
        "dictionary_beta_loss": str(cfg.algorithm.dictionary_beta_loss),
        "dictionary_activation_l1": float(cfg.algorithm.dictionary_activation_l1),
        "factory_ground_truth_available": False,
        "dictionary_positive_groups": list(cfg.algorithm.dictionary_positive_groups) or sorted(cfg.lab_groups),
        "similarity_decision_threshold": float(cfg.algorithm.dictionary_decision_threshold),
        "similarity_decision_top_fraction": float(cfg.algorithm.dictionary_similarity_top_fraction),
        "v2_parameters": {key: getattr(cfg.algorithm, key) for key in V2_DEFAULTS},
        "plane_point_policy": "FIXED_20_25_30_35_40_CM_X_8_DIRECTIONS",
        "output_chains": ["fixed_ring_20_40cm", "opposite_pair", "dual_spatial", "final_multi_diameter_T_supplemented"],
    })
    algorithm_info = run_info.get("config", {}).get("algorithm", {})
    for legacy_key in (
        "lab_split_mode",
        "lab_train_groups",
        "lab_validation_groups",
        "lab_train_fraction",
        "max_lab_training_frames",
        "prior_mix_max",
        "prior_mix_steps",
    ):
        algorithm_info.pop(legacy_key, None)
    algorithm_info.update({
        "dictionary_positive_groups": list(cfg.algorithm.dictionary_positive_groups) or sorted(cfg.lab_groups),
        "dictionary_decision_threshold": float(cfg.algorithm.dictionary_decision_threshold),
        "dictionary_similarity_top_fraction": float(cfg.algorithm.dictionary_similarity_top_fraction),
        "max_lab_prior_frames": int(cfg.algorithm.max_lab_prior_frames),
        **{key: getattr(cfg.algorithm, key) for key in V2_DEFAULTS},
    })
    core.write_json(run_info_path, run_info)
    return paths


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="v3.1：多孔径消声室T字典 + 工厂无标签T_LIKE/F_LIKE相似度判定"
    )
    parser.add_argument("--config", default="spatial_prior_fusion_v2_config.json")
    parser.add_argument(
        "--pretrain-dictionary",
        action="store_true",
        help="只使用实验室泄漏T进行离线预训练并保存冻结字典，然后退出",
    )
    parser.add_argument("--self-test", action="store_true")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if args.self_test:
        common.run_self_test_v2 = run_self_test
        run_self_test()
        return
    cfg = load_config(Path(args.config))
    if args.pretrain_dictionary:
        tdict.run_pretraining(cfg)
        return
    run_analysis(cfg)


def run_self_test() -> None:
    """验证多孔径T预训练、无标签工厂判定和四条空间输出链。"""
    import shutil
    import tempfile

    print("开始 v3.1 SELF-TEST（多孔径T字典 + 无标签工厂判定）...")
    rng = np.random.default_rng(2345)
    fs = 192_000
    seconds = 0.35
    with tempfile.TemporaryDirectory(prefix="spatial_prior_fusion_v2_test_") as temp_dir:
        root = Path(temp_dir)
        lab05 = core.ensure_dir(root / "lab" / "0.5mm")
        lab01 = core.ensure_dir(root / "lab" / "0.1mm")
        lab10 = core.ensure_dir(root / "lab" / "1.0mm")
        for folder, shift in ((lab01, 0.0), (lab05, 1.2), (lab10, 2.0)):
            for index in range(4):
                x = core.synth_leak(fs, seconds, rng, shift + 0.1 * index)
                wavfile.write(str(folder / f"lab_{index}.wav"), fs, x.astype(np.float32))
        leak = core.synth_leak(fs, seconds, rng, 0.2)
        t_center, t_near, t_far = core.write_synthetic_factory(root, "T", fs, seconds, rng, leak)
        f_center, f_near, f_far = core.write_synthetic_factory(root, "F", fs, seconds, rng, leak)
        for center_root, near_root, far_root, folder in (
            (t_center, t_near, t_far, "condition"),
            (f_center, f_near, f_far, "condition_null"),
        ):
            center_folder = center_root / folder
            offset_folders = [near_root / folder, far_root / folder]
            source_center = center_folder / "synthetic_00_00_beamform_result.wav"
            for target_id in ("00_01", "00_02"):
                shutil.copyfile(source_center, center_folder / f"synthetic_{target_id}_beamform_result.wav")
                for offset_folder in offset_folders:
                    for source in list(offset_folder.glob("synthetic_00_00d*.wav")):
                        shutil.copyfile(
                            source,
                            offset_folder / source.name.replace("00_00d", f"{target_id}d", 1),
                        )
        cfg = core.RunConfig(
            lab_groups={
                "0.1mm": [str(lab01)],
                "0.5mm": [str(lab05)],
                "1.0mm": [str(lab10)],
            },
            factory_datasets=[
                core.FactoryDataset("synthetic_leak_case", str(t_center), [str(t_near), str(t_far)], ["condition"], "UNLABELED", {}),
                core.FactoryDataset("synthetic_nonleak_case", str(f_center), [str(f_near), str(f_far)], ["condition_null"], "UNLABELED", {}),
            ],
            output_dir=str(root / "out"),
            pairing_remove_tokens=["_null", "null"],
            algorithm=core.AlgorithmConfig(
                time_slice_seconds=seconds,
                segment_mode="first",
                nperseg=1024,
                hop_length=512,
                nfft=2048,
                minimum_frequency_bins=20,
                leak_components=4,
                max_lab_training_frames=3000,
                nmf_max_iter=100,
                lab_projection_iterations=60,
                min_neighbors=100,
                min_complete_opposite_pairs=50,
                save_plots=False,
                save_wavs=True,
                save_npz=True,
                plot_limit=0,
            ),
        )
        common._attach_fusion_config(cfg, {
            "max_lab_prior_frames": 3000,
            "pretrained_dictionary_path": str(root / "pretrained_t_dictionary.npz"),
            "dictionary_candidate_components": [4],
            "dictionary_candidate_beta_losses": ["kullback-leibler"],
            "dictionary_candidate_activation_l1": [0.0, 1.0e-5],
            "dictionary_candidate_seeds": [23, 42],
            "dictionary_positive_groups": [],
            "dictionary_reference_fraction": 0.25,
            "dictionary_validation_fraction": 0.25,
            "dictionary_t_accept_quantile": 0.05,
            "dictionary_similarity_top_fraction": 0.5,
            "dictionary_window_seconds": seconds,
            "dictionary_max_windows_per_file": 1,
            "dictionary_max_frames_per_file": 1000,
            "dictionary_max_total_frames": 3000,
            "dictionary_augment_copies": 1,
        })
        _attach_v2_config(cfg)
        tdict.run_pretraining(cfg)
        paths = run_analysis(cfg)
        summary = pd.read_csv(paths["summary"])
        if len(summary) != 4 or set(summary["center_id"].astype(str)) != set(ALLOWED_CENTER_IDS):
            raise AssertionError("严格中心白名单 00_00/00_01 失效")
        required = {
            "fixed_ring_lab_similarity_combined_median",
            "opposite_pair_lab_similarity_combined_median",
            "dual_spatial_lab_similarity_combined_median",
            "final_lab_similarity_combined_median",
            "similarity_decision",
            "similarity_decision_score",
            "similarity_decision_threshold",
            "similarity_decision_margin",
        }
        if not required.issubset(summary.columns):
            raise AssertionError(f"v2 汇总缺少列: {required - set(summary.columns)}")
        if not np.all(summary["label"] == "UNLABELED"):
            raise AssertionError("工厂合成样本不应携带T/F真实标签")
        if not set(summary["similarity_decision"]).issubset({"T_LIKE", "F_LIKE"}):
            raise AssertionError("无标签相似度判定字段错误")
        decisions_by_dataset = summary.groupby("dataset")["similarity_decision"].agg(lambda x: set(x))
        if decisions_by_dataset.get("synthetic_leak_case") != {"T_LIKE"}:
            raise AssertionError("合成泄漏场景未判为T_LIKE")
        if decisions_by_dataset.get("synthetic_nonleak_case") != {"F_LIKE"}:
            raise AssertionError("合成非泄漏场景未判为F_LIKE")
        if np.any(
            summary["center_prior_supplement_power_fraction"].to_numpy(float)
            > cfg.algorithm.prior_supplement_total_fraction_cap + 1e-12
        ):
            raise AssertionError("先验补偿超过单样本总功率上限")
        for sample_dir in (root / "out" / "samples").glob("**/center_*"):
            if not sample_dir.is_dir():
                continue
            with np.load(sample_dir / "spatial_prior_fusion_v2_result.npz") as result:
                final = result["final_fused_leak_power"]
                dual = result["dual_spatial_output_power"]
                center = result["raw_center_power"]
                if np.any(final + 1e-14 < dual) or np.any(final > center + 1e-14):
                    raise AssertionError("v2 补偿边界错误")
                if str(result["similarity_reference_usage"]) != "FROZEN_MULTI_DIAMETER_T_REFERENCE":
                    raise AssertionError("NPZ 的多孔径T参照审计字段错误")
            point_table = pd.read_csv(sample_dir / "fixed_ring_20_40cm_plane_point_diagnostics.csv")
            used = point_table.loc[
                point_table["point_role"] == "USED_FIXED_RING_20_TO_40_CM"
            ]
            if len(used) != 40 or set(used["distance_cm"].astype(int)) != {20, 25, 30, 35, 40}:
                raise AssertionError("固定环带必须严格为20/25/30/35/40cm共40点")
        decision_path = root / "out" / "13_unlabeled_factory_similarity_decisions.csv"
        if not decision_path.exists() or len(pd.read_csv(decision_path)) != 4:
            raise AssertionError("缺少完整的无标签工厂相似度判定表")
        if (root / "out" / "13_TF_metric_auc.csv").exists():
            raise AssertionError("无真实T/F标签时不应生成AUC结果")
        with np.load(cfg.algorithm.pretrained_dictionary_path, allow_pickle=False) as bundle:
            if str(bundle["data_semantics"].item()) != "MULTI_DIAMETER_T_ONLY_NO_FACTORY_LABELS":
                raise AssertionError("冻结字典训练语义错误")
    print("V3.1 SELF-TEST PASSED")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n用户中止。")
        sys.exit(130)
    except Exception as exc:
        print(f"\n程序失败: {type(exc).__name__}: {exc}")
        traceback.print_exc()
        sys.exit(1)
