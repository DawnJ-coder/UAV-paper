@echo off
python v13_1_AB_train_CD_test.py evaluate --config v13_1_test_CD_config.json
pause
