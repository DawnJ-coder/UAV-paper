@echo off
python v13_1_AB_train_CD_test.py train --config v13_1_train_AB_config.json
pause
