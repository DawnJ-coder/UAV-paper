V13.1：A+B训练，C和D分别外部测试
====================================

一、程序用途
------------
本版专门支持：

    Factory A + Factory B（有TRUE/FALSE标签）
                    ↓
              建立冻结模型
                    ↓
       Factory C、Factory D分别独立测试

C和D不会参与：
- 公共特征选择
- FALSE基线计算
- 概率映射
- TRUE/FALSE/SUSPECT阈值确定

C/D标签只在模型已经输出分数和判断后，用于计算AUC、准确率和混淆矩阵。


二、相对原V13的关键修改
----------------------
1. 原V13至少要求3个有标签训练场景；本版允许2个训练场景。
2. A+B训练时，内部验证为：
       A训练 → 测B
       B训练 → 测A
3. probability_TRUE继续输出，但只作为参考和排序值。
4. 正式prediction不再使用固定概率0.35/0.65，而是使用A/B交叉OOF的
   shared_leak_score分布自动学习三个分数阈值：
       score <= FALSE阈值 → FALSE_LEAK
       score >= TRUE阈值  → TRUE_LEAK
       中间                → SUSPECT
5. 加入evaluate模式，可一次配置C和D，但程序分别评分、分别统计结果。

这样可以避免原程序中“原始分数已经明显分开，但probability_TRUE都在0.5附近，
因此大量样本被固定0.35/0.65规则判为SUSPECT”的问题。


三、文件
--------
v13_1_AB_train_CD_test.py          主程序
v12_shared_leak_component_discovery.py  指纹核心依赖，必须与主程序放在同一目录
v13_1_train_AB_config.json          A+B训练配置
v13_1_test_CD_config.json           C+D外部测试配置
v13_1_predict_unlabeled_config.json 无标签场景预测示例
run_v13_1_train_AB.bat              双击训练A+B
run_v13_1_test_CD.bat               双击测试C和D
requirements_v13.txt                Python依赖


四、运行前要求
------------
A、B、C、D的v9结果目录必须包含：

    v9_all_features.csv
    residual_npz\*.npz
    v9_run_config.json（建议保留）

每个A/B/C/D场景都必须同时具有TRUE_LEAK和FALSE_LEAK标签。

最重要：四个场景必须采用相同的v9主残差方法，例如全部：

    primary=median

或者全部：

    primary=selected

不要使用：

    A/B为plane，C/D为median

否则测试中会混入预处理方法差异。


五、安装依赖
------------
pip install -r requirements_v13.txt


六、自检
--------
python v13_1_AB_train_CD_test.py --self-test

最后应显示：

    V13.1自检通过：A+B训练，C和D分别外部测试。


七、训练A+B
-----------
先检查v13_1_train_AB_config.json中的路径，然后运行：

python v13_1_AB_train_CD_test.py train --config v13_1_train_AB_config.json

默认模型目录：

C:\Users\jiangxinru6\Desktop\wurenji\leak_v13_1_AB_model_results

最重要的模型：

v13_frozen_shared_leak_model.npz

训练输出中：
- v13_loso_oof_scores.csv：A→B、B→A的交叉OOF样本结果
- v13_loso_calibrated_scene_summary.csv：A/B内部验证汇总
- v13_model_manifest.json：训练场景、阈值和参数
- v13_train_report.txt：训练报告


八、分别测试C和D
---------------
检查v13_1_test_CD_config.json，然后运行：

python v13_1_AB_train_CD_test.py evaluate --config v13_1_test_CD_config.json

程序会先冻结A+B模型，然后分别执行：

    A+B模型 → C
    A+B模型 → D

输出目录中：

v13_test_factory_C_predictions.csv  C逐样本结果
v13_test_factory_D_predictions.csv  D逐样本结果
v13_external_test_predictions.csv   C/D合并逐样本结果
v13_external_test_summary.csv       C和D各一行测试汇总
v13_external_test_report.txt        文本报告


九、结果重点看什么
----------------
1. v13_external_test_summary.csv

重点字段：
- score_auc：shared_leak_score的排序能力；最重要
- balanced_accuracy：使用A/B学到的二分类分数阈值
- tp、tn、fp、fn：二分类混淆矩阵
- decisive_rate：非SUSPECT比例
- decisive_accuracy：明确判断样本中的准确率
- n_pred_TRUE_LEAK / FALSE_LEAK / SUSPECT
- true_score_median / false_score_median

2. 每个场景逐样本CSV

重点字段：
- shared_leak_score：正式判断使用的分数
- prediction：正式TRUE/FALSE/SUSPECT结果
- score_false_threshold
- score_binary_threshold
- score_true_threshold
- probability_TRUE：仅供参考，不再直接决定prediction
- probability_reference_prediction：旧0.35/0.65规则的参考结果
- quality_warning
- needs_review


十、如何解释probability_TRUE
--------------------------
本版仍保留probability_TRUE，便于排序和与旧结果比较。

但正式prediction使用shared_leak_score阈值，所以可能出现：

    probability_TRUE = 0.52
    prediction = TRUE_LEAK

这不是冲突。它表示：
- 逻辑回归概率映射比较保守，数值仍在0.5附近；
- 但该样本的原始公共泄漏分数已经达到A/B交叉OOF的TRUE区域。

同样也可能出现：

    probability_TRUE = 0.48
    prediction = FALSE_LEAK

正式判断请看prediction和shared_leak_score，不要只看probability_TRUE。


十一、两个训练场景的限制
----------------------
A+B训练可以用于实验，但只有两个场景时：
- 公共成分只证明A、B一致；
- 阈值只来自A→B和B→A；
- 对C/D的可靠性必须以外部测试结果为准；
- 最终无标签现场部署仍建议增加更多独立训练场景。

不要根据C或D测试结果反复调整阈值后，再把同一个C/D称为独立测试。
