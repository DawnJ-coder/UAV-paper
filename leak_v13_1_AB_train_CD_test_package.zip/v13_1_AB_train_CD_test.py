# -*- coding: utf-8 -*-
"""
v13_1_AB_train_CD_test.py

用途
----
1. train：允许只使用两个有标签场景，例如 A+B，建立冻结公共泄漏模型。
   A/B内部执行双向留一场景验证：A训练测B、B训练测A。
2. evaluate：使用冻结的A+B模型，分别测试有标签场景C和D。
   C/D标签只在预测全部完成后用于计算AUC和准确率，绝不参与训练和阈值。
3. predict：对没有标签的新场景进行TRUE_LEAK/FALSE_LEAK/SUSPECT预测。

本版重要修改
------------
- 原v13至少要求3个训练场景，本版允许2个训练场景。
- probability_TRUE仍然输出，但只用于参考和排序。
- 正式三档prediction改用A/B交叉OOF shared_leak_score分布自动学习阈值，
  避免概率都被压在0.5附近而产生大量不合理SUSPECT。

依赖
----
本脚本同目录必须包含：v12_shared_leak_component_discovery.py

运行
----
python v13_1_AB_train_CD_test.py --self-test
python v13_1_AB_train_CD_test.py train --config v13_1_train_AB_config.json
python v13_1_AB_train_CD_test.py evaluate --config v13_1_test_CD_config.json
python v13_1_AB_train_CD_test.py predict --config v13_1_predict_unlabeled_config.json
"""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import tempfile
import traceback
from dataclasses import asdict, dataclass, fields
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    from sklearn.linear_model import HuberRegressor, LogisticRegression
    from sklearn.metrics import (
        accuracy_score,
        balanced_accuracy_score,
        confusion_matrix,
        roc_auc_score,
    )
except Exception as exc:
    raise RuntimeError("缺少 scikit-learn，请运行: pip install scikit-learn") from exc

try:
    import matplotlib.pyplot as plt
except Exception as exc:
    raise RuntimeError("缺少 matplotlib，请运行: pip install matplotlib") from exc

try:
    import v12_shared_leak_component_discovery as core
except Exception as exc:
    raise RuntimeError(
        "无法导入 v12_shared_leak_component_discovery.py。请把它与本程序放在同一目录。"
    ) from exc


# =============================================================================
# 1. 配置
# =============================================================================

EPS = 1.0e-12
MODEL_VERSION = "v13_shared_leak_model_1.1"
BLOCKS = ("spectral", "temporal", "spatial")


@dataclass(frozen=True)
class V13Config:
    # 至少多少比例的训练场景支持，维度才进入预测模型。
    # A+B两场景建议设为1.0，表示最终特征必须同时得到A和B支持。
    model_support_fraction: float = 2.0 / 3.0

    # 三类证据权重。
    spectral_score_weight: float = 1.0
    temporal_score_weight: float = 1.0
    spatial_score_weight: float = 0.75

    # probability_TRUE 仅作为参考显示，不再直接决定三档分类。
    probability_false_max: float = 0.35
    probability_true_min: float = 0.65

    # 正式三档判定使用训练场景OOF原始分数阈值。
    # FALSE阈值取OOF FALSE分数的该分位数；TRUE阈值取OOF TRUE分数的该分位数。
    false_score_quantile: float = 0.90
    true_score_quantile: float = 0.10

    # 当两类OOF分数重叠、分位数阈值发生交叉时，
    # 在最佳二分类阈值两侧保留多少个稳健尺度作为SUSPECT区。
    overlap_suspect_margin_scale: float = 0.10

    # 超出训练分布的质量提示。
    ood_robust_z_threshold: float = 6.0
    ood_fraction_warning: float = 0.25

    # 分数映射与数值设置。
    score_clip: float = 12.0
    random_state: int = 42


@dataclass
class ScoringBlock:
    weights: np.ndarray
    baseline_false: np.ndarray
    scale: np.ndarray
    train_q01: np.ndarray
    train_q99: np.ndarray
    selected: np.ndarray
    dim_names: List[str]
    support_count: np.ndarray
    support_ratio: np.ndarray
    common_effect: np.ndarray


@dataclass
class ScoringModel:
    scene_names: List[str]
    blocks: Dict[str, ScoringBlock]
    frequency_grid: np.ndarray
    shared_positive_spectrum: np.ndarray


# =============================================================================
# 2. 通用工具
# =============================================================================


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def safe_auc(y_true: np.ndarray, score: np.ndarray) -> float:
    y = np.asarray(y_true, dtype=int)
    s = np.asarray(score, dtype=float)
    if len(np.unique(y)) < 2:
        return float("nan")
    try:
        return float(roc_auc_score(y, s))
    except Exception:
        return float("nan")


def sigmoid(x: np.ndarray) -> np.ndarray:
    z = np.clip(np.asarray(x, dtype=float), -60.0, 60.0)
    return 1.0 / (1.0 + np.exp(-z))


def logit(p: float) -> float:
    p = float(np.clip(p, 1.0e-6, 1.0 - 1.0e-6))
    return float(math.log(p / (1.0 - p)))


def confusion_metrics(y_true: np.ndarray, pred: np.ndarray) -> Dict[str, Any]:
    y = np.asarray(y_true, dtype=int)
    p = np.asarray(pred, dtype=int)
    tn, fp, fn, tp = confusion_matrix(y, p, labels=[0, 1]).ravel()
    return {
        "accuracy": float(accuracy_score(y, p)),
        "balanced_accuracy": float(balanced_accuracy_score(y, p)),
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp),
    }


def decisive_metrics(labels: np.ndarray, decisions: Sequence[str]) -> Dict[str, Any]:
    y_labels = np.asarray(labels).astype(str)
    d = np.asarray(list(decisions)).astype(str)
    decisive = np.isin(d, ["TRUE_LEAK", "FALSE_LEAK"])
    n_decisive = int(np.sum(decisive))
    if n_decisive:
        decisive_accuracy = float(np.mean(d[decisive] == y_labels[decisive]))
    else:
        decisive_accuracy = float("nan")
    strict_accuracy = float(np.mean((d == y_labels) & decisive)) if len(d) else float("nan")
    return {
        "decisive_rate": float(np.mean(decisive)) if len(d) else 0.0,
        "decisive_accuracy": decisive_accuracy,
        "strict_accuracy_suspect_as_wrong": strict_accuracy,
        "n_decisive": n_decisive,
        "n_suspect": int(len(d) - n_decisive),
    }


def probability_decision(prob: np.ndarray, cfg: V13Config) -> np.ndarray:
    """旧版概率三档结果，仅作为参考列保留。"""
    p = np.asarray(prob, dtype=float)
    return np.where(
        p >= cfg.probability_true_min,
        "TRUE_LEAK",
        np.where(p <= cfg.probability_false_max, "FALSE_LEAK", "SUSPECT"),
    )


def score_decision(score: np.ndarray, calibration: Dict[str, Any]) -> np.ndarray:
    """使用训练阶段OOF原始分数阈值做正式三档判定。"""
    s = np.asarray(score, dtype=float)
    false_threshold = float(calibration["score_false_threshold"])
    true_threshold = float(calibration["score_true_threshold"])
    return np.where(
        s >= true_threshold,
        "TRUE_LEAK",
        np.where(s <= false_threshold, "FALSE_LEAK", "SUSPECT"),
    )


def optimize_binary_threshold(y_true: np.ndarray, score: np.ndarray) -> Tuple[float, float]:
    """在OOF分数上选择平衡准确率最高的二分类阈值。"""
    y = np.asarray(y_true, dtype=int)
    s = np.asarray(score, dtype=float)
    valid = np.isfinite(s)
    y = y[valid]
    s = s[valid]
    if len(s) < 2 or len(np.unique(y)) < 2:
        return float(np.median(s)) if len(s) else 0.0, float("nan")

    unique = np.unique(s)
    if len(unique) == 1:
        return float(unique[0]), 0.5
    candidates = np.concatenate(
        ([unique[0] - EPS], (unique[:-1] + unique[1:]) / 2.0, [unique[-1] + EPS])
    )
    class_midpoint = 0.5 * (float(np.median(s[y == 0])) + float(np.median(s[y == 1])))
    best_threshold = float(np.median(s))
    best_bal = -np.inf
    best_distance = np.inf
    for threshold in candidates:
        pred = (s >= threshold).astype(int)
        bal = float(balanced_accuracy_score(y, pred))
        distance = abs(float(threshold) - class_midpoint)
        if bal > best_bal + 1.0e-12 or (abs(bal - best_bal) <= 1.0e-12 and distance < best_distance):
            best_bal = bal
            best_threshold = float(threshold)
            best_distance = distance
    return best_threshold, best_bal


def robust_scale_1d(values: np.ndarray) -> float:
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) == 0:
        return 1.0
    med = float(np.median(x))
    mad = float(np.median(np.abs(x - med)))
    scale = 1.4826 * mad
    if not np.isfinite(scale) or scale <= EPS:
        scale = float(np.std(x))
    return max(scale, 1.0e-6)


def core_config_from_payload(payload: Dict[str, Any]) -> core.V12Config:
    allowed = {f.name for f in fields(core.V12Config)}
    kwargs = {k: v for k, v in payload.items() if k in allowed}
    return core.V12Config(**kwargs)


def v13_config_from_payload(payload: Dict[str, Any]) -> V13Config:
    allowed = {f.name for f in fields(V13Config)}
    kwargs = {k: v for k, v in payload.items() if k in allowed}
    return V13Config(**kwargs)


def block_weight(cfg: V13Config, block: str) -> float:
    return {
        "spectral": cfg.spectral_score_weight,
        "temporal": cfg.temporal_score_weight,
        "spatial": cfg.spatial_score_weight,
    }[block]


def locate_npz_or_raise(residual_dir: Path, sample_id: str) -> Path:
    path = core.locate_npz_file(residual_dir, sample_id)
    if path is None:
        raise FileNotFoundError(f"找不到 sample_id={sample_id} 对应的 residual NPZ")
    return path


# =============================================================================
# 3. 读取无标签场景
# =============================================================================


def read_metadata_any_label(v9_dir: Path) -> pd.DataFrame:
    csv_path = v9_dir / "v9_all_features.csv"
    if not csv_path.exists():
        raise FileNotFoundError(f"找不到: {csv_path}")
    df = pd.read_csv(
        csv_path,
        dtype={"sample_id": str, "center": str, "time": str, "center_file": str},
    )
    required = ["sample_id", "dataset", "time", "center"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"{csv_path.name} 缺少列: {missing}")
    if "scene" not in df.columns:
        df["scene"] = ""
    if "label" not in df.columns:
        df["label"] = ""
    return df.reset_index(drop=True)


def load_unlabeled_fingerprints(
    scene_name: str,
    v9_dir: Path,
    core_cfg: core.V12Config,
) -> Tuple[List[core.Fingerprint], np.ndarray, pd.DataFrame, pd.DataFrame]:
    metadata = read_metadata_any_label(v9_dir)
    residual_dir = v9_dir / "residual_npz"
    if not residual_dir.exists():
        raise FileNotFoundError(
            f"找不到 {residual_dir}。请先运行v9并使用 --save-residual-npz。"
        )

    fps: List[core.Fingerprint] = []
    failures: List[Dict[str, Any]] = []
    freq_grid: Optional[np.ndarray] = None

    for _, row in metadata.iterrows():
        sample_id = str(row["sample_id"])
        try:
            npz_path = locate_npz_or_raise(residual_dir, sample_id)
            with np.load(npz_path, allow_pickle=False) as data:
                spectral, grid = core.build_spectral_fingerprint(
                    data["freq_hz"], data["excess_power"], core_cfg
                )
                temporal = core.build_temporal_fingerprint(
                    data["excess_power"], data["background_power_db"], core_cfg
                )
                spatial = core.build_spatial_fingerprint(
                    data["xy"], data["point_band_db"], data["background_indices"], core_cfg
                )
            if freq_grid is None:
                freq_grid = grid
            elif not np.allclose(freq_grid, grid):
                raise ValueError("统一频率网格不一致")
            original_label = str(row.get("label", ""))
            fps.append(
                core.Fingerprint(
                    sample_id=sample_id,
                    dataset=str(row.get("dataset", "")),
                    scene=scene_name,
                    time=str(row.get("time", "")),
                    center=str(row.get("center", "")),
                    label=original_label,
                    npz_path=str(npz_path),
                    spectral=spectral,
                    temporal=temporal,
                    spatial=spatial,
                )
            )
        except Exception as exc:
            failures.append(
                {
                    "scene": scene_name,
                    "sample_id": sample_id,
                    "error": f"{type(exc).__name__}: {exc}",
                    "traceback": traceback.format_exc(),
                }
            )

    if not fps:
        raise RuntimeError("没有成功构造任何无标签样本指纹")
    return fps, np.asarray(freq_grid), pd.DataFrame(failures), metadata


# =============================================================================
# 4. 构建固定基线的公共泄漏评分模型
# =============================================================================


def training_false_baseline(
    fps_by_scene: Dict[str, List[core.Fingerprint]],
    block: str,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    scene_false_medians: List[np.ndarray] = []
    scene_false_scales: List[np.ndarray] = []
    all_values: List[np.ndarray] = []

    for scene, fps in fps_by_scene.items():
        labels = np.asarray([fp.label for fp in fps])
        matrix = core.block_matrix(fps, block)
        false_matrix = matrix[labels == "FALSE_LEAK"]
        if len(false_matrix) == 0:
            raise ValueError(f"场景 {scene} 的 {block} 没有 FALSE_LEAK")
        scene_false_medians.append(np.median(false_matrix, axis=0))
        scene_false_scales.append(core.robust_mad(false_matrix, axis=0))
        all_values.append(matrix)

    medians = np.vstack(scene_false_medians)
    within = np.median(np.vstack(scene_false_scales), axis=0)
    between = core.robust_mad(medians, axis=0) if len(medians) > 1 else np.zeros_like(within)
    baseline = np.median(medians, axis=0)

    # 同时考虑FALSE场景内波动与不同场景FALSE基线变化。
    scale = np.sqrt(np.maximum(within, 0.0) ** 2 + np.maximum(between, 0.0) ** 2)
    scale = np.maximum(scale, core.robust_scale_floor(scale))

    all_matrix = np.vstack(all_values)
    q01 = np.quantile(all_matrix, 0.01, axis=0)
    q99 = np.quantile(all_matrix, 0.99, axis=0)
    return baseline, scale, q01, q99


def build_scoring_model(
    fps_by_scene: Dict[str, List[core.Fingerprint]],
    contrasts: Dict[str, core.SceneContrast],
    frequency_grid: np.ndarray,
    core_cfg: core.V12Config,
    cfg: V13Config,
) -> ScoringModel:
    scene_names = list(fps_by_scene)
    shared = core.build_shared_components(
        [contrasts[s] for s in scene_names],
        cfg.model_support_fraction,
        core_cfg,
    )

    blocks: Dict[str, ScoringBlock] = {}
    for block in BLOCKS:
        baseline, scale, q01, q99 = training_false_baseline(fps_by_scene, block)
        info = shared[block]
        blocks[block] = ScoringBlock(
            weights=np.asarray(info["weights"], dtype=float),
            baseline_false=np.asarray(baseline, dtype=float),
            scale=np.asarray(scale, dtype=float),
            train_q01=np.asarray(q01, dtype=float),
            train_q99=np.asarray(q99, dtype=float),
            selected=np.asarray(info["selected"], dtype=bool),
            dim_names=list(info["dim_names"]),
            support_count=np.asarray(info["support_count"], dtype=int),
            support_ratio=np.asarray(info["support_ratio"], dtype=float),
            common_effect=np.asarray(info["common_effect"], dtype=float),
        )

    positive_spectrum = core.build_shared_positive_spectrum(
        [contrasts[s] for s in scene_names], shared["spectral"]
    )
    return ScoringModel(
        scene_names=scene_names,
        blocks=blocks,
        frequency_grid=np.asarray(frequency_grid, dtype=float),
        shared_positive_spectrum=np.asarray(positive_spectrum, dtype=float),
    )


def matrices_from_fps(fps: Sequence[core.Fingerprint]) -> Dict[str, np.ndarray]:
    return {block: core.block_matrix(fps, block) for block in BLOCKS}


def score_fingerprints(
    fps: Sequence[core.Fingerprint],
    model: ScoringModel,
    cfg: V13Config,
) -> Tuple[pd.DataFrame, Dict[str, np.ndarray]]:
    matrices = matrices_from_fps(fps)
    block_scores: Dict[str, np.ndarray] = {}
    ood_z_fraction: Dict[str, np.ndarray] = {}
    ood_range_fraction: Dict[str, np.ndarray] = {}
    contributions: Dict[str, np.ndarray] = {}

    for block in BLOCKS:
        bm = model.blocks[block]
        x = matrices[block]
        if x.shape[1] != bm.weights.size:
            raise ValueError(
                f"{block}维度不一致: 输入={x.shape[1]}, 模型={bm.weights.size}"
            )
        z = np.clip(
            (x - bm.baseline_false[None, :]) / bm.scale[None, :],
            -cfg.score_clip,
            cfg.score_clip,
        )
        contrib = z * bm.weights[None, :]
        contributions[block] = contrib
        block_scores[block] = core.weighted_block_score(z, bm.weights)

        selected = bm.selected
        if np.any(selected):
            ood_z_fraction[block] = np.mean(
                np.abs(z[:, selected]) > cfg.ood_robust_z_threshold, axis=1
            )
            out_range = (x[:, selected] < bm.train_q01[selected][None, :]) | (
                x[:, selected] > bm.train_q99[selected][None, :]
            )
            ood_range_fraction[block] = np.mean(out_range, axis=1)
        else:
            ood_z_fraction[block] = np.ones(len(fps), dtype=float)
            ood_range_fraction[block] = np.ones(len(fps), dtype=float)

    active_scores: List[np.ndarray] = []
    active_weights: List[float] = []
    for block in BLOCKS:
        if np.any(model.blocks[block].selected) and block_weight(cfg, block) > 0:
            active_scores.append(block_scores[block])
            active_weights.append(block_weight(cfg, block))
    if active_scores:
        raw_overall = np.average(np.vstack(active_scores), axis=0, weights=active_weights)
    else:
        raw_overall = np.zeros(len(fps), dtype=float)

    rows: List[Dict[str, Any]] = []
    for i, fp in enumerate(fps):
        warning_parts: List[str] = []
        for block in BLOCKS:
            if not np.any(model.blocks[block].selected):
                warning_parts.append(f"NO_{block.upper()}_DIM")
            elif ood_z_fraction[block][i] > cfg.ood_fraction_warning:
                warning_parts.append(f"{block.upper()}_OOD_Z")
            elif ood_range_fraction[block][i] > cfg.ood_fraction_warning:
                warning_parts.append(f"{block.upper()}_OUT_RANGE")

        row = {
            "sample_id": fp.sample_id,
            "dataset": fp.dataset,
            "scene": fp.scene,
            "time": fp.time,
            "center": fp.center,
            "input_label_ignored": fp.label,
            "score_spectral_raw": float(block_scores["spectral"][i]),
            "score_temporal_raw": float(block_scores["temporal"][i]),
            "score_spatial_raw": float(block_scores["spatial"][i]),
            "shared_leak_score_raw": float(raw_overall[i]),
            "spectral_ood_z_fraction": float(ood_z_fraction["spectral"][i]),
            "temporal_ood_z_fraction": float(ood_z_fraction["temporal"][i]),
            "spatial_ood_z_fraction": float(ood_z_fraction["spatial"][i]),
            "spectral_out_range_fraction": float(ood_range_fraction["spectral"][i]),
            "temporal_out_range_fraction": float(ood_range_fraction["temporal"][i]),
            "spatial_out_range_fraction": float(ood_range_fraction["spatial"][i]),
            "quality_warning": "|".join(warning_parts),
        }

        # 每个模块贡献最大的维度，便于本地排查。
        for block in BLOCKS:
            c = contributions[block][i]
            if c.size and np.any(np.abs(c) > EPS):
                top = np.argsort(np.abs(c))[::-1][:5]
                row[f"top_{block}_evidence"] = ";".join(
                    f"{model.blocks[block].dim_names[j]}:{c[j]:.4g}" for j in top
                )
            else:
                row[f"top_{block}_evidence"] = ""
        rows.append(row)

    return pd.DataFrame(rows), block_scores


# =============================================================================
# 5. 留一场景训练验证与冻结模型
# =============================================================================


def fit_probability_calibrator(score: np.ndarray, y: np.ndarray, random_state: int) -> Tuple[float, float]:
    x = np.asarray(score, dtype=float).reshape(-1, 1)
    labels = np.asarray(y, dtype=int)
    clf = LogisticRegression(
        class_weight="balanced",
        solver="lbfgs",
        random_state=random_state,
    )
    clf.fit(x, labels)
    return float(clf.coef_[0, 0]), float(clf.intercept_[0])


def fit_final_score_mapping(final_raw: np.ndarray, oof_oriented: np.ndarray) -> Tuple[float, float]:
    x = np.asarray(final_raw, dtype=float).reshape(-1, 1)
    y = np.asarray(oof_oriented, dtype=float)
    if np.std(x) <= EPS or np.std(y) <= EPS:
        return 1.0, float(np.median(y) - np.median(x))
    try:
        reg = HuberRegressor(epsilon=1.35, max_iter=500)
        reg.fit(x, y)
        slope = float(reg.coef_[0])
        intercept = float(reg.intercept_)
        if not np.isfinite(slope) or slope <= 0:
            raise ValueError("Huber映射斜率无效")
        return slope, intercept
    except Exception:
        slope, intercept = np.polyfit(x.ravel(), y, 1)
        if not np.isfinite(slope) or slope <= 0:
            return 1.0, float(np.median(y) - np.median(x))
        return float(slope), float(intercept)


def train_loso(
    fps_by_scene: Dict[str, List[core.Fingerprint]],
    contrasts: Dict[str, core.SceneContrast],
    frequency_grid: np.ndarray,
    core_cfg: core.V12Config,
    cfg: V13Config,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    scenes = list(fps_by_scene)
    if len(scenes) < 2:
        raise ValueError("至少需要2个有标签场景才能做留一场景训练验证")

    sample_rows: List[Dict[str, Any]] = []
    summary_rows: List[Dict[str, Any]] = []

    for test_scene in scenes:
        train_scenes = [s for s in scenes if s != test_scene]
        train_fps = {s: fps_by_scene[s] for s in train_scenes}
        train_contrasts = {s: contrasts[s] for s in train_scenes}
        fold_model = build_scoring_model(
            train_fps, train_contrasts, frequency_grid, core_cfg, cfg
        )
        test_fps = fps_by_scene[test_scene]
        score_df, _ = score_fingerprints(test_fps, fold_model, cfg)
        labels = np.asarray([fp.label for fp in test_fps])
        y = (labels == "TRUE_LEAK").astype(int)
        raw = score_df["shared_leak_score_raw"].to_numpy(dtype=float)
        auc = safe_auc(y, raw)

        # 折内只记录原始方向；全体OOF完成后统一确定方向、概率和阈值。
        for i, fp in enumerate(test_fps):
            row = score_df.iloc[i].to_dict()
            row.update(
                {
                    "test_scene": test_scene,
                    "train_scenes": "|".join(train_scenes),
                    "true_label": fp.label,
                    "y_true": int(y[i]),
                }
            )
            sample_rows.append(row)

        pred0 = (raw >= 0.0).astype(int)
        m0 = confusion_metrics(y, pred0)
        summary_rows.append(
            {
                "test_scene": test_scene,
                "train_scenes": "|".join(train_scenes),
                "n_samples": len(test_fps),
                "n_true": int(np.sum(y == 1)),
                "n_false": int(np.sum(y == 0)),
                "raw_score_auc": auc,
                "raw_score0_balanced_accuracy": m0["balanced_accuracy"],
                "spectral_selected_dims": int(np.sum(fold_model.blocks["spectral"].selected)),
                "temporal_selected_dims": int(np.sum(fold_model.blocks["temporal"].selected)),
                "spatial_selected_dims": int(np.sum(fold_model.blocks["spatial"].selected)),
            }
        )

    return pd.DataFrame(sample_rows), pd.DataFrame(summary_rows)


def finalize_oof_calibration(
    oof: pd.DataFrame,
    cfg: V13Config,
) -> Tuple[pd.DataFrame, Dict[str, Any]]:
    """
    使用留一场景OOF分数完成三件事：
    1. 统一分数方向，使分数越高越接近TRUE；
    2. 拟合probability_TRUE，仅作为便于观察的参考值；
    3. 直接从OOF原始分数分布学习FALSE/TRUE/SUSPECT阈值。

    正式prediction使用第3项，不再使用固定0.35/0.65概率阈值，
    避免概率校准被压缩在0.5附近时出现大量无意义SUSPECT。
    """
    out = oof.copy()
    y = out["y_true"].to_numpy(dtype=int)
    raw = out["shared_leak_score_raw"].to_numpy(dtype=float)
    raw_auc = safe_auc(y, raw)
    orientation = 1.0 if (not np.isfinite(raw_auc) or raw_auc >= 0.5) else -1.0
    oriented = orientation * raw

    prob_coef, prob_intercept = fit_probability_calibrator(
        oriented, y, cfg.random_state
    )
    if prob_coef < 0:
        orientation *= -1.0
        oriented = orientation * raw
        prob_coef, prob_intercept = fit_probability_calibrator(
            oriented, y, cfg.random_state
        )
    prob = sigmoid(prob_coef * oriented + prob_intercept)

    binary_threshold, binary_train_bal = optimize_binary_threshold(y, oriented)
    false_scores = oriented[y == 0]
    true_scores = oriented[y == 1]
    if len(false_scores) == 0 or len(true_scores) == 0:
        raise ValueError("OOF结果缺少TRUE或FALSE，无法学习阈值")

    false_q = float(np.quantile(false_scores, cfg.false_score_quantile))
    true_q = float(np.quantile(true_scores, cfg.true_score_quantile))
    thresholds_overlap = bool(false_q >= true_q)

    if not thresholds_overlap:
        score_false_threshold = false_q
        score_true_threshold = true_q
        threshold_method = "OOF_CLASS_QUANTILES"
    else:
        # 两类存在明显重叠时，不强行交换阈值；围绕最佳二分类阈值保留SUSPECT区。
        pooled_scale = robust_scale_1d(oriented)
        margin = max(float(cfg.overlap_suspect_margin_scale) * pooled_scale, 1.0e-6)
        score_false_threshold = float(binary_threshold - margin)
        score_true_threshold = float(binary_threshold + margin)
        threshold_method = "OOF_OVERLAP_MARGIN"

    binary = (oriented >= binary_threshold).astype(int)
    decisions = score_decision(
        oriented,
        {
            "score_false_threshold": score_false_threshold,
            "score_true_threshold": score_true_threshold,
        },
    )
    probability_decisions = probability_decision(prob, cfg)
    metrics = confusion_metrics(y, binary)
    dmetrics = decisive_metrics(out["true_label"].to_numpy(), decisions)

    out["shared_leak_score_oof"] = oriented
    out["probability_TRUE_oof"] = prob
    out["prediction_binary_oof"] = np.where(binary == 1, "TRUE_LEAK", "FALSE_LEAK")
    out["prediction_3way_oof"] = decisions
    out["prediction_3way_probability_reference_oof"] = probability_decisions
    out["correct_binary_oof"] = (binary == y).astype(int)
    out["correct_3way_oof"] = (
        (decisions == out["true_label"].to_numpy())
        & np.isin(decisions, ["TRUE_LEAK", "FALSE_LEAK"])
    ).astype(int)

    info = {
        "raw_oof_auc": raw_auc,
        "score_orientation": orientation,
        "oof_auc": safe_auc(y, oriented),
        "probability_auc": safe_auc(y, prob),
        "prob_coef": prob_coef,
        "prob_intercept": prob_intercept,
        "decision_source": "OOF_SHARED_LEAK_SCORE",
        "threshold_method": threshold_method,
        "thresholds_overlap_before_fallback": int(thresholds_overlap),
        "false_score_quantile": float(cfg.false_score_quantile),
        "true_score_quantile": float(cfg.true_score_quantile),
        "false_score_quantile_value": false_q,
        "true_score_quantile_value": true_q,
        "score_false_threshold": float(score_false_threshold),
        "score_binary_threshold": float(binary_threshold),
        "score_true_threshold": float(score_true_threshold),
        "binary_threshold_oof_balanced_accuracy": float(binary_train_bal),
        # 概率阈值仅用于参考列和旧版兼容，不参与正式三档分类。
        "probability_false_max": cfg.probability_false_max,
        "probability_true_min": cfg.probability_true_min,
        **metrics,
        **dmetrics,
        "true_score_median": float(np.median(oriented[y == 1])),
        "false_score_median": float(np.median(oriented[y == 0])),
        "true_probability_median": float(np.median(prob[y == 1])),
        "false_probability_median": float(np.median(prob[y == 0])),
        "oof_score_q01": float(np.quantile(oriented, 0.01)),
        "oof_score_q99": float(np.quantile(oriented, 0.99)),
    }
    return out, info


# =============================================================================
# 6. 模型保存与读取
# =============================================================================


def save_model(
    path: Path,
    model: ScoringModel,
    core_cfg: core.V12Config,
    cfg: V13Config,
    calibration: Dict[str, Any],
    score_map_slope: float,
    score_map_intercept: float,
) -> None:
    payload: Dict[str, Any] = {
        "version": np.asarray(MODEL_VERSION),
        "created_at": np.asarray(str(datetime.now())),
        "scene_names": np.asarray(model.scene_names, dtype="U"),
        "frequency_grid": model.frequency_grid,
        "shared_positive_spectrum": model.shared_positive_spectrum,
        "core_config_json": np.asarray(json.dumps(asdict(core_cfg), ensure_ascii=False)),
        "v13_config_json": np.asarray(json.dumps(asdict(cfg), ensure_ascii=False)),
        "calibration_json": np.asarray(json.dumps(calibration, ensure_ascii=False)),
        "score_map_slope": np.asarray(score_map_slope),
        "score_map_intercept": np.asarray(score_map_intercept),
    }
    for block, bm in model.blocks.items():
        prefix = f"{block}__"
        payload[prefix + "weights"] = bm.weights
        payload[prefix + "baseline_false"] = bm.baseline_false
        payload[prefix + "scale"] = bm.scale
        payload[prefix + "train_q01"] = bm.train_q01
        payload[prefix + "train_q99"] = bm.train_q99
        payload[prefix + "selected"] = bm.selected.astype(np.uint8)
        payload[prefix + "dim_names"] = np.asarray(bm.dim_names, dtype="U")
        payload[prefix + "support_count"] = bm.support_count
        payload[prefix + "support_ratio"] = bm.support_ratio
        payload[prefix + "common_effect"] = bm.common_effect
    np.savez_compressed(path, **payload)


def load_model(path: Path) -> Tuple[ScoringModel, core.V12Config, V13Config, Dict[str, Any], float, float]:
    if not path.exists():
        raise FileNotFoundError(f"找不到模型: {path}")
    with np.load(path, allow_pickle=False) as data:
        version = str(data["version"].item())
        if not version.startswith("v13_shared_leak_model"):
            raise ValueError(f"模型版本不支持: {version}")
        core_cfg = core_config_from_payload(json.loads(str(data["core_config_json"].item())))
        cfg = v13_config_from_payload(json.loads(str(data["v13_config_json"].item())))
        calibration = json.loads(str(data["calibration_json"].item()))
        blocks: Dict[str, ScoringBlock] = {}
        for block in BLOCKS:
            prefix = f"{block}__"
            blocks[block] = ScoringBlock(
                weights=np.asarray(data[prefix + "weights"], dtype=float),
                baseline_false=np.asarray(data[prefix + "baseline_false"], dtype=float),
                scale=np.asarray(data[prefix + "scale"], dtype=float),
                train_q01=np.asarray(data[prefix + "train_q01"], dtype=float),
                train_q99=np.asarray(data[prefix + "train_q99"], dtype=float),
                selected=np.asarray(data[prefix + "selected"], dtype=bool),
                dim_names=[str(v) for v in data[prefix + "dim_names"]],
                support_count=np.asarray(data[prefix + "support_count"], dtype=int),
                support_ratio=np.asarray(data[prefix + "support_ratio"], dtype=float),
                common_effect=np.asarray(data[prefix + "common_effect"], dtype=float),
            )
        model = ScoringModel(
            scene_names=[str(v) for v in data["scene_names"]],
            blocks=blocks,
            frequency_grid=np.asarray(data["frequency_grid"], dtype=float),
            shared_positive_spectrum=np.asarray(data["shared_positive_spectrum"], dtype=float),
        )
        slope = float(data["score_map_slope"].item())
        intercept = float(data["score_map_intercept"].item())
    return model, core_cfg, cfg, calibration, slope, intercept


# =============================================================================
# 7. 训练流程
# =============================================================================


def plot_oof_scores(oof: pd.DataFrame, output_dir: Path, calibration: Dict[str, Any]) -> Path:
    fig_dir = output_dir / "figures"
    ensure_dir(fig_dir)
    plt.figure(figsize=(11, 6))
    scenes = list(dict.fromkeys(oof["test_scene"].astype(str).tolist()))
    positions: List[float] = []
    labels: List[str] = []
    pos = 0
    for scene in scenes:
        for label in ["FALSE_LEAK", "TRUE_LEAK"]:
            values = oof.loc[
                (oof["test_scene"] == scene) & (oof["true_label"] == label),
                "shared_leak_score_oof",
            ].to_numpy(dtype=float)
            x = np.full(len(values), pos, dtype=float)
            plt.scatter(x, values, alpha=0.75)
            positions.append(pos)
            labels.append(f"{scene}\n{label.replace('_LEAK', '')}")
            pos += 1
        pos += 0.5
    plt.axhline(float(calibration["score_false_threshold"]), linewidth=1, linestyle="--")
    plt.axhline(float(calibration["score_binary_threshold"]), linewidth=1)
    plt.axhline(float(calibration["score_true_threshold"]), linewidth=1, linestyle="--")
    plt.xticks(positions, labels, rotation=35, ha="right")
    plt.ylabel("OOF shared leak score")
    plt.title("V13 leave-one-scene-out scores")
    plt.grid(True, axis="y", alpha=0.25)
    plt.tight_layout()
    path = fig_dir / "v13_loso_scores.png"
    plt.savefig(path, dpi=160)
    plt.close()
    return path


def plot_shared_spectrum(model: ScoringModel, output_dir: Path) -> Path:
    fig_dir = output_dir / "figures"
    ensure_dir(fig_dir)
    plt.figure(figsize=(11, 5))
    plt.plot(model.frequency_grid / 1000.0, model.shared_positive_spectrum)
    plt.xlabel("Frequency (kHz)")
    plt.ylabel("Normalized shared leak enrichment")
    plt.title("V13.1 shared positive leak spectrum")
    plt.grid(True, alpha=0.25)
    plt.tight_layout()
    path = fig_dir / "v13_shared_positive_spectrum.png"
    plt.savefig(path, dpi=160)
    plt.close()
    return path


def run_train(config_path: Path) -> Dict[str, Path]:
    payload = json.loads(config_path.read_text(encoding="utf-8"))
    scenes = payload.get("scenes", [])
    if len(scenes) < 2:
        raise ValueError("训练配置至少需要2个有标签场景")
    output_dir = Path(payload["output_dir"])
    ensure_dir(output_dir)
    algorithm = payload.get("algorithm", {})
    core_cfg = core_config_from_payload(algorithm)
    cfg = v13_config_from_payload(algorithm)

    print("=" * 100)
    print("V13 训练：使用有标签场景建立冻结公共泄漏模型")
    print("=" * 100)

    preflight_rows: List[pd.DataFrame] = []
    preflight_summaries: List[pd.DataFrame] = []
    v9_configs: Dict[str, Optional[Dict[str, Any]]] = {}
    fps_by_scene: Dict[str, List[core.Fingerprint]] = {}
    contrasts: Dict[str, core.SceneContrast] = {}
    failures: List[pd.DataFrame] = []
    frequency_grid: Optional[np.ndarray] = None

    print("第一步：预检有标签场景")
    for scene_cfg in scenes:
        name = str(scene_cfg["name"])
        v9_dir = Path(scene_cfg["v9_dir"])
        report, summary = core.preflight_scene(name, v9_dir)
        preflight_rows.append(report)
        preflight_summaries.append(summary)
        v9_configs[name] = core.load_v9_config(v9_dir)
        print(
            f"  {name}: n={int(summary.iloc[0]['n_samples'])}, "
            f"TRUE={int(summary.iloc[0]['n_true'])}, FALSE={int(summary.iloc[0]['n_false'])}, "
            f"NPZ={int(summary.iloc[0]['n_npz_ok'])}/{int(summary.iloc[0]['n_samples'])}"
        )
        if float(summary.iloc[0]["npz_success_rate"]) < 1.0:
            raise RuntimeError(f"场景 {name} NPZ不完整，停止训练")

    consistency = core.compare_v9_configs(v9_configs)
    mismatch = int((consistency["match"] == 0).sum()) if len(consistency) else 0
    print("  v9参数不一致项:", mismatch)
    if mismatch:
        raise RuntimeError("训练场景v9参数不一致，请先查看参数一致性CSV")

    print("第二步：读取残差并构造指纹")
    for scene_cfg in scenes:
        name = str(scene_cfg["name"])
        v9_dir = Path(scene_cfg["v9_dir"])
        fps, grid, failed = core.load_scene_fingerprints(name, v9_dir, core_cfg)
        fps_by_scene[name] = fps
        if len(failed):
            failures.append(failed)
        if frequency_grid is None:
            frequency_grid = grid
        elif not np.allclose(frequency_grid, grid):
            raise ValueError("各场景频率网格不一致")
        contrasts[name] = core.compute_scene_contrast(name, fps, grid, core_cfg)
        n_true = sum(fp.label == "TRUE_LEAK" for fp in fps)
        n_false = sum(fp.label == "FALSE_LEAK" for fp in fps)
        print(f"  {name}: 成功={len(fps)}, TRUE={n_true}, FALSE={n_false}")

    print("第三步：留一场景OOF验证")
    oof_raw, loso_summary = train_loso(
        fps_by_scene, contrasts, np.asarray(frequency_grid), core_cfg, cfg
    )
    oof, calibration = finalize_oof_calibration(oof_raw, cfg)
    for scene, group in oof.groupby("test_scene"):
        y = group["y_true"].to_numpy(dtype=int)
        score = group["shared_leak_score_oof"].to_numpy(dtype=float)
        pred = (score >= float(calibration["score_binary_threshold"])).astype(int)
        m = confusion_metrics(y, pred)
        print(
            f"  test={scene}: score_AUC={safe_auc(y, score):.4f}, "
            f"bal_acc={m['balanced_accuracy']:.4f}, "
            f"TP={m['tp']}, TN={m['tn']}, FP={m['fp']}, FN={m['fn']}"
        )

    print("第四步：使用全部有标签场景建立最终公共模型")
    final_model = build_scoring_model(
        fps_by_scene, contrasts, np.asarray(frequency_grid), core_cfg, cfg
    )
    all_fps: List[core.Fingerprint] = []
    for scene in fps_by_scene:
        all_fps.extend(fps_by_scene[scene])
    final_train_scores, _ = score_fingerprints(all_fps, final_model, cfg)

    # 将最终模型原始分数映射到OOF分数尺度，避免最终训练场景数量变化造成阈值尺度漂移。
    final_score_by_id = dict(
        zip(
            final_train_scores["sample_id"].astype(str),
            final_train_scores["shared_leak_score_raw"].astype(float),
        )
    )
    aligned_final_raw = np.asarray(
        [final_score_by_id[str(v)] for v in oof["sample_id"]], dtype=float
    )
    score_map_slope, score_map_intercept = fit_final_score_mapping(
        aligned_final_raw,
        oof["shared_leak_score_oof"].to_numpy(dtype=float),
    )

    model_path = output_dir / "v13_frozen_shared_leak_model.npz"
    save_model(
        model_path,
        final_model,
        core_cfg,
        cfg,
        calibration,
        score_map_slope,
        score_map_intercept,
    )

    print("第五步：保存报告和模型")
    pd.concat(preflight_rows, ignore_index=True).to_csv(
        output_dir / "v13_preflight_samples.csv", index=False, encoding="utf-8-sig"
    )
    pd.concat(preflight_summaries, ignore_index=True).to_csv(
        output_dir / "v13_preflight_summary.csv", index=False, encoding="utf-8-sig"
    )
    consistency.to_csv(
        output_dir / "v13_v9_parameter_consistency.csv", index=False, encoding="utf-8-sig"
    )
    pd.concat(failures, ignore_index=True).to_csv(
        output_dir / "v13_fingerprint_failures.csv", index=False, encoding="utf-8-sig"
    ) if failures else pd.DataFrame().to_csv(
        output_dir / "v13_fingerprint_failures.csv", index=False, encoding="utf-8-sig"
    )

    contrast_df = pd.concat(
        [core.contrast_to_rows(contrasts[s], np.asarray(frequency_grid)) for s in contrasts],
        ignore_index=True,
    )
    contrast_df.to_csv(
        output_dir / "v13_scene_internal_contrasts.csv", index=False, encoding="utf-8-sig"
    )
    oof.to_csv(output_dir / "v13_loso_oof_scores.csv", index=False, encoding="utf-8-sig")
    loso_summary.to_csv(
        output_dir / "v13_loso_raw_scene_summary.csv", index=False, encoding="utf-8-sig"
    )

    calibrated_scene_rows: List[Dict[str, Any]] = []
    for scene, group in oof.groupby("test_scene"):
        y = group["y_true"].to_numpy(dtype=int)
        p = group["probability_TRUE_oof"].to_numpy(dtype=float)
        score = group["shared_leak_score_oof"].to_numpy(dtype=float)
        pred = (score >= float(calibration["score_binary_threshold"])).astype(int)
        m = confusion_metrics(y, pred)
        d = decisive_metrics(group["true_label"].to_numpy(), group["prediction_3way_oof"])
        calibrated_scene_rows.append(
            {
                "test_scene": scene,
                "n_samples": len(group),
                "score_auc": safe_auc(y, score),
                "probability_auc": safe_auc(y, p),
                **m,
                **d,
                "true_score_median": float(np.median(score[y == 1])),
                "false_score_median": float(np.median(score[y == 0])),
                "true_probability_median": float(np.median(p[y == 1])),
                "false_probability_median": float(np.median(p[y == 0])),
            }
        )
    pd.DataFrame(calibrated_scene_rows).to_csv(
        output_dir / "v13_loso_calibrated_scene_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )

    model_dim_rows: List[Dict[str, Any]] = []
    for block, bm in final_model.blocks.items():
        for i, dim in enumerate(bm.dim_names):
            row = {
                "block": block,
                "dimension_index": i,
                "dimension": dim,
                "selected": int(bm.selected[i]),
                "weight": float(bm.weights[i]),
                "common_effect": float(bm.common_effect[i]),
                "support_count": int(bm.support_count[i]),
                "support_ratio": float(bm.support_ratio[i]),
                "false_baseline": float(bm.baseline_false[i]),
                "robust_scale": float(bm.scale[i]),
            }
            if block == "spectral":
                row["frequency_hz"] = float(final_model.frequency_grid[i])
            model_dim_rows.append(row)
    pd.DataFrame(model_dim_rows).to_csv(
        output_dir / "v13_model_dimensions.csv", index=False, encoding="utf-8-sig"
    )
    pd.DataFrame(
        {
            "frequency_hz": final_model.frequency_grid,
            "frequency_khz": final_model.frequency_grid / 1000.0,
            "shared_positive_leak_spectrum": final_model.shared_positive_spectrum,
            "selected_for_model": final_model.blocks["spectral"].selected.astype(int),
            "model_weight": final_model.blocks["spectral"].weights,
        }
    ).to_csv(
        output_dir / "v13_shared_positive_leak_spectrum.csv",
        index=False,
        encoding="utf-8-sig",
    )

    manifest = {
        "version": MODEL_VERSION,
        "created_at": str(datetime.now()),
        "training_scenes": list(fps_by_scene),
        "model_file": str(model_path),
        "core_config": asdict(core_cfg),
        "v13_config": asdict(cfg),
        "calibration": calibration,
        "final_score_mapping": {
            "slope": score_map_slope,
            "intercept": score_map_intercept,
        },
        "selected_dimensions": {
            block: int(np.sum(final_model.blocks[block].selected)) for block in BLOCKS
        },
        "important": (
            "预测新场景时不使用新场景标签；input label会被忽略。"
            "正式三档判定使用训练场景留一场景OOF分数阈值。"
        ),
    }
    (output_dir / "v13_model_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    report_lines = [
        "V13.1 公共泄漏模型训练报告",
        "=" * 90,
        f"训练场景: {', '.join(fps_by_scene)}",
        f"总样本数: {sum(len(v) for v in fps_by_scene.values())}",
        f"OOF AUC: {calibration['probability_auc']:.6f}",
        f"OOF balanced accuracy: {calibration['balanced_accuracy']:.6f}",
        f"OOF TP/TN/FP/FN: {calibration['tp']}/{calibration['tn']}/{calibration['fp']}/{calibration['fn']}",
        f"三档明确判定比例: {calibration['decisive_rate']:.6f}",
        f"三档明确样本准确率: {calibration['decisive_accuracy']:.6f}",
        f"正式判定来源: {calibration['decision_source']}",
        f"阈值方法: {calibration['threshold_method']}",
        f"FALSE/BINARY/TRUE分数阈值: "
        f"{calibration['score_false_threshold']:.6g}/"
        f"{calibration['score_binary_threshold']:.6g}/"
        f"{calibration['score_true_threshold']:.6g}",
        f"概率0.35/0.65仅作参考: {cfg.probability_false_max}/{cfg.probability_true_min}",
        f"频谱/时间/空间选择维度: "
        f"{int(np.sum(final_model.blocks['spectral'].selected))}/"
        f"{int(np.sum(final_model.blocks['temporal'].selected))}/"
        f"{int(np.sum(final_model.blocks['spatial'].selected))}",
        f"冻结模型: {model_path}",
        "",
        "预测含义:",
        "  TRUE_LEAK: 分数达到训练场景OOF TRUE阈值。",
        "  FALSE_LEAK: 分数低于训练场景OOF FALSE阈值。",
        "  SUSPECT: 证据位于中间，不强制二选一。",
        "  无标签新场景不能计算准确率；结果需后续人工或独立仪器核验。",
    ]
    report_path = output_dir / "v13_train_report.txt"
    report_path.write_text("\n".join(report_lines), encoding="utf-8")
    plot_oof_scores(oof, output_dir, calibration)
    plot_shared_spectrum(final_model, output_dir)

    print("\n" + "=" * 100)
    print("V13.1训练完成")
    print("冻结模型:", model_path)
    print("OOF明细:", output_dir / "v13_loso_oof_scores.csv")
    print("场景汇总:", output_dir / "v13_loso_calibrated_scene_summary.csv")
    print("报告:", report_path)
    print("=" * 100)
    return {
        "model": model_path,
        "report": report_path,
        "oof": output_dir / "v13_loso_oof_scores.csv",
    }


# =============================================================================
# 8. 无标签预测流程
# =============================================================================


def apply_frozen_model_to_fps(
    fps: Sequence[core.Fingerprint],
    model: ScoringModel,
    cfg: V13Config,
    calibration: Dict[str, Any],
    map_slope: float,
    map_intercept: float,
) -> pd.DataFrame:
    """对指纹评分。任何输入label都不会参与特征、分数或阈值计算。"""
    score_df, _ = score_fingerprints(fps, model, cfg)
    raw = score_df["shared_leak_score_raw"].to_numpy(dtype=float)
    mapped_score = map_slope * raw + map_intercept
    prob = sigmoid(
        float(calibration["prob_coef"]) * mapped_score
        + float(calibration["prob_intercept"])
    )

    decisions = score_decision(mapped_score, calibration)
    binary = np.where(
        mapped_score >= float(calibration["score_binary_threshold"]),
        "TRUE_LEAK",
        "FALSE_LEAK",
    )
    probability_reference = probability_decision(prob, cfg)

    false_threshold = float(calibration["score_false_threshold"])
    true_threshold = float(calibration["score_true_threshold"])
    distance_false = mapped_score - false_threshold
    distance_true = mapped_score - true_threshold
    nearest_boundary_distance = np.minimum(
        np.abs(distance_false), np.abs(distance_true)
    )

    score_df["shared_leak_score"] = mapped_score
    score_df["probability_TRUE"] = prob
    score_df["prediction"] = decisions
    score_df["binary_prediction"] = binary
    score_df["probability_reference_prediction"] = probability_reference
    score_df["decision_source"] = str(calibration.get("decision_source", "OOF_SHARED_LEAK_SCORE"))
    score_df["score_false_threshold"] = false_threshold
    score_df["score_binary_threshold"] = float(calibration["score_binary_threshold"])
    score_df["score_true_threshold"] = true_threshold
    score_df["distance_to_nearest_score_boundary"] = nearest_boundary_distance
    score_df["probability_confidence_reference"] = np.maximum(prob, 1.0 - prob)
    # 兼容旧结果列名，但明确它只是概率参考置信度。
    score_df["confidence"] = score_df["probability_confidence_reference"]
    score_df["needs_review"] = (
        (decisions == "SUSPECT")
        | score_df["quality_warning"].fillna("").astype(str).ne("")
    ).astype(int)
    return score_df


def plot_prediction_scores(
    pred: pd.DataFrame,
    calibration: Dict[str, Any],
    output_dir: Path,
    filename: str = "v13_prediction_scores.png",
    title: str = "V13 prediction scores",
) -> Path:
    fig_dir = output_dir / "figures"
    ensure_dir(fig_dir)
    ordered = pred.sort_values("shared_leak_score").reset_index(drop=True)
    plt.figure(figsize=(11, 5))
    plt.scatter(np.arange(len(ordered)), ordered["shared_leak_score"].to_numpy(dtype=float))
    plt.axhline(float(calibration["score_false_threshold"]), linewidth=1, linestyle="--")
    plt.axhline(float(calibration["score_binary_threshold"]), linewidth=1)
    plt.axhline(float(calibration["score_true_threshold"]), linewidth=1, linestyle="--")
    plt.xlabel("Samples sorted by shared leak score")
    plt.ylabel("Shared leak score")
    plt.title(title)
    plt.grid(True, alpha=0.25)
    plt.tight_layout()
    path = fig_dir / filename
    plt.savefig(path, dpi=160)
    plt.close()
    return path


def run_predict(config_path: Path) -> Dict[str, Path]:
    """预测无标签场景；输入label完全忽略。"""
    payload = json.loads(config_path.read_text(encoding="utf-8"))
    model_path = Path(payload["model_file"])
    v9_dir = Path(payload["v9_dir"])
    output_dir = Path(payload["output_dir"])
    scene_name = str(payload.get("scene_name", "unlabeled_scene"))
    ensure_dir(output_dir)

    model, core_cfg, cfg, calibration, map_slope, map_intercept = load_model(model_path)

    print("=" * 100)
    print("V13.1预测：使用冻结模型判断无标签场景")
    print("=" * 100)
    print("模型训练场景:", " | ".join(model.scene_names))
    print("待预测场景:", scene_name)
    print("正式三档结果使用OOF shared_leak_score阈值；probability_TRUE仅供参考。")
    print("注意: v9 CSV中的label列将被完全忽略，不计算AUC或准确率。")

    fps, grid, failures, metadata = load_unlabeled_fingerprints(
        scene_name, v9_dir, core_cfg
    )
    if not np.allclose(grid, model.frequency_grid):
        raise ValueError("待预测场景频率网格与冻结模型不一致")

    score_df = apply_frozen_model_to_fps(
        fps, model, cfg, calibration, map_slope, map_intercept
    )

    meta_cols = [
        c
        for c in metadata.columns
        if c.startswith("qc_")
        or c.startswith("residual_integrated")
        or c in ["sample_id", "center_file", "offset_dir"]
    ]
    if "sample_id" in meta_cols:
        extra = metadata[meta_cols].drop_duplicates("sample_id")
        score_df = score_df.merge(extra, on="sample_id", how="left")

    prediction_csv = output_dir / "v13_unlabeled_predictions.csv"
    score_df.to_csv(prediction_csv, index=False, encoding="utf-8-sig")
    failures.to_csv(
        output_dir / "v13_prediction_failures.csv", index=False, encoding="utf-8-sig"
    )

    counts = score_df["prediction"].value_counts().to_dict()
    warnings = int(score_df["needs_review"].sum())
    summary = pd.DataFrame(
        [
            {
                "scene": scene_name,
                "n_input_rows": len(metadata),
                "n_success": len(score_df),
                "n_failed": len(failures),
                "n_pred_TRUE_LEAK": int(counts.get("TRUE_LEAK", 0)),
                "n_pred_FALSE_LEAK": int(counts.get("FALSE_LEAK", 0)),
                "n_pred_SUSPECT": int(counts.get("SUSPECT", 0)),
                "n_needs_review": warnings,
                "score_min": float(score_df["shared_leak_score"].min()),
                "score_median": float(score_df["shared_leak_score"].median()),
                "score_max": float(score_df["shared_leak_score"].max()),
                "probability_min": float(score_df["probability_TRUE"].min()),
                "probability_median": float(score_df["probability_TRUE"].median()),
                "probability_max": float(score_df["probability_TRUE"].max()),
                "model_training_scenes": "|".join(model.scene_names),
                "labels_used_for_prediction": 0,
                "decision_source": str(calibration.get("decision_source", "")),
                "score_false_threshold": float(calibration["score_false_threshold"]),
                "score_binary_threshold": float(calibration["score_binary_threshold"]),
                "score_true_threshold": float(calibration["score_true_threshold"]),
            }
        ]
    )
    summary_csv = output_dir / "v13_unlabeled_prediction_summary.csv"
    summary.to_csv(summary_csv, index=False, encoding="utf-8-sig")

    report_lines = [
        "V13.1 无标签场景预测报告",
        "=" * 90,
        f"待预测场景: {scene_name}",
        f"冻结模型训练场景: {', '.join(model.scene_names)}",
        f"成功/失败: {len(score_df)}/{len(failures)}",
        f"预测 TRUE_LEAK: {counts.get('TRUE_LEAK', 0)}",
        f"预测 FALSE_LEAK: {counts.get('FALSE_LEAK', 0)}",
        f"预测 SUSPECT: {counts.get('SUSPECT', 0)}",
        f"需要复核: {warnings}",
        f"分数阈值 FALSE/BINARY/TRUE: "
        f"{calibration['score_false_threshold']:.6g}/"
        f"{calibration['score_binary_threshold']:.6g}/"
        f"{calibration['score_true_threshold']:.6g}",
        "",
        "重要说明:",
        "1. 正式prediction由训练OOF原始分数阈值决定，不再由固定0.35/0.65概率决定。",
        "2. probability_TRUE保留用于排序和观察，不应单独解释为严格统计概率。",
        "3. 本程序完全忽略待预测场景的输入label。",
        "4. SUSPECT或quality_warning非空的文件应优先人工检查。",
    ]
    report_path = output_dir / "v13_unlabeled_prediction_report.txt"
    report_path.write_text("\n".join(report_lines), encoding="utf-8")
    plot_prediction_scores(
        score_df,
        calibration,
        output_dir,
        filename="v13_unlabeled_scores.png",
        title=f"V13.1 unlabeled predictions: {scene_name}",
    )

    print("\n预测完成")
    print("成功样本:", len(score_df))
    print("失败样本:", len(failures))
    print(
        "TRUE/FALSE/SUSPECT:",
        counts.get("TRUE_LEAK", 0),
        "/",
        counts.get("FALSE_LEAK", 0),
        "/",
        counts.get("SUSPECT", 0),
    )
    print("逐样本结果:", prediction_csv)
    print("汇总:", summary_csv)
    print("报告:", report_path)
    return {
        "predictions": prediction_csv,
        "summary": summary_csv,
        "report": report_path,
    }


def run_evaluate(config_path: Path) -> Dict[str, Path]:
    """
    使用冻结模型分别测试多个有标签外部场景。
    场景标签只在全部分数和prediction产生后用于计算AUC/准确率，绝不参与模型构建。
    """
    payload = json.loads(config_path.read_text(encoding="utf-8"))
    model_path = Path(payload["model_file"])
    test_scenes = payload.get("test_scenes", [])
    if not test_scenes:
        raise ValueError("evaluate配置必须包含test_scenes")
    output_dir = Path(payload["output_dir"])
    ensure_dir(output_dir)

    model, core_cfg, cfg, calibration, map_slope, map_intercept = load_model(model_path)
    print("=" * 100)
    print("V13.1外部测试：冻结训练模型，分别测试有标签场景")
    print("=" * 100)
    print("模型训练场景:", " | ".join(model.scene_names))
    print("测试场景:", " | ".join(str(v["name"]) for v in test_scenes))
    overlap = sorted(set(model.scene_names) & {str(v["name"]) for v in test_scenes})
    if overlap:
        raise ValueError(f"测试场景不能参与训练，重复场景: {overlap}")
    print("测试标签仅用于最后计算指标，不参与特征、分数或阈值。")

    prediction_frames: List[pd.DataFrame] = []
    summary_rows: List[Dict[str, Any]] = []
    failure_frames: List[pd.DataFrame] = []

    for scene_cfg in test_scenes:
        scene_name = str(scene_cfg["name"])
        v9_dir = Path(scene_cfg["v9_dir"])
        print("\n" + "-" * 90)
        print("测试:", scene_name)
        fps, grid, failures = core.load_scene_fingerprints(scene_name, v9_dir, core_cfg)
        if not np.allclose(grid, model.frequency_grid):
            raise ValueError(f"{scene_name}频率网格与冻结模型不一致")
        if not failures.empty:
            failure_frames.append(failures)

        # 先生成模型输出，再读取fps中标签计算测试指标。
        score_df = apply_frozen_model_to_fps(
            fps, model, cfg, calibration, map_slope, map_intercept
        )
        labels = np.asarray([fp.label for fp in fps])
        y = (labels == "TRUE_LEAK").astype(int)
        score_df["true_label"] = labels
        score_df["y_true"] = y
        score_df["correct_binary"] = (score_df["binary_prediction"].to_numpy() == labels).astype(int)
        score_df["correct_3way"] = (
            (score_df["prediction"].to_numpy() == labels)
            & score_df["prediction"].isin(["TRUE_LEAK", "FALSE_LEAK"]).to_numpy()
        ).astype(int)
        prediction_frames.append(score_df)
        score_df.to_csv(
            output_dir / f"v13_test_{scene_name}_predictions.csv",
            index=False,
            encoding="utf-8-sig",
        )

        binary_numeric = (score_df["binary_prediction"] == "TRUE_LEAK").astype(int).to_numpy()
        metrics = confusion_metrics(y, binary_numeric)
        dmetrics = decisive_metrics(labels, score_df["prediction"].to_numpy())
        counts = score_df["prediction"].value_counts().to_dict()
        summary_rows.append(
            {
                "test_scene": scene_name,
                "train_scenes": "|".join(model.scene_names),
                "n_samples": len(score_df),
                "n_true": int(np.sum(y == 1)),
                "n_false": int(np.sum(y == 0)),
                "score_auc": safe_auc(y, score_df["shared_leak_score"].to_numpy(dtype=float)),
                "probability_auc": safe_auc(y, score_df["probability_TRUE"].to_numpy(dtype=float)),
                "spectral_auc": safe_auc(y, score_df["score_spectral_raw"].to_numpy(dtype=float)),
                "temporal_auc": safe_auc(y, score_df["score_temporal_raw"].to_numpy(dtype=float)),
                "spatial_auc": safe_auc(y, score_df["score_spatial_raw"].to_numpy(dtype=float)),
                **metrics,
                **dmetrics,
                "n_pred_TRUE_LEAK": int(counts.get("TRUE_LEAK", 0)),
                "n_pred_FALSE_LEAK": int(counts.get("FALSE_LEAK", 0)),
                "n_pred_SUSPECT": int(counts.get("SUSPECT", 0)),
                "true_score_median": float(np.median(score_df.loc[y == 1, "shared_leak_score"])),
                "false_score_median": float(np.median(score_df.loc[y == 0, "shared_leak_score"])),
                "true_probability_median": float(np.median(score_df.loc[y == 1, "probability_TRUE"])),
                "false_probability_median": float(np.median(score_df.loc[y == 0, "probability_TRUE"])),
                "score_false_threshold": float(calibration["score_false_threshold"]),
                "score_binary_threshold": float(calibration["score_binary_threshold"]),
                "score_true_threshold": float(calibration["score_true_threshold"]),
                "labels_used_for_scoring": 0,
                "labels_used_for_metrics_only": 1,
            }
        )
        print(
            f"  AUC={summary_rows[-1]['score_auc']:.4f}, "
            f"bal_acc={summary_rows[-1]['balanced_accuracy']:.4f}, "
            f"TRUE/FALSE/SUSPECT="
            f"{counts.get('TRUE_LEAK', 0)}/{counts.get('FALSE_LEAK', 0)}/{counts.get('SUSPECT', 0)}"
        )
        plot_prediction_scores(
            score_df,
            calibration,
            output_dir,
            filename=f"v13_test_{scene_name}_scores.png",
            title=f"V13.1 external test: {scene_name}",
        )

    predictions = pd.concat(prediction_frames, ignore_index=True)
    summary = pd.DataFrame(summary_rows)
    failures = (
        pd.concat(failure_frames, ignore_index=True)
        if failure_frames
        else pd.DataFrame(columns=["scene", "sample_id", "error", "traceback"])
    )

    predictions_path = output_dir / "v13_external_test_predictions.csv"
    summary_path = output_dir / "v13_external_test_summary.csv"
    failures_path = output_dir / "v13_external_test_failures.csv"
    predictions.to_csv(predictions_path, index=False, encoding="utf-8-sig")
    summary.to_csv(summary_path, index=False, encoding="utf-8-sig")
    failures.to_csv(failures_path, index=False, encoding="utf-8-sig")

    report_lines = [
        "V13.1 A+B训练、C/D独立外部测试报告",
        "=" * 90,
        f"冻结模型训练场景: {', '.join(model.scene_names)}",
        f"正式判定来源: {calibration.get('decision_source', '')}",
        f"分数阈值 FALSE/BINARY/TRUE: "
        f"{calibration['score_false_threshold']:.6g}/"
        f"{calibration['score_binary_threshold']:.6g}/"
        f"{calibration['score_true_threshold']:.6g}",
        "",
    ]
    for row in summary_rows:
        report_lines.extend(
            [
                f"测试场景 {row['test_scene']}:",
                f"  n={row['n_samples']}，TRUE/FALSE={row['n_true']}/{row['n_false']}",
                f"  score AUC={row['score_auc']:.6f}",
                f"  binary balanced accuracy={row['balanced_accuracy']:.6f}",
                f"  TP/TN/FP/FN={row['tp']}/{row['tn']}/{row['fp']}/{row['fn']}",
                f"  三档 TRUE/FALSE/SUSPECT={row['n_pred_TRUE_LEAK']}/"
                f"{row['n_pred_FALSE_LEAK']}/{row['n_pred_SUSPECT']}",
                f"  decisive_rate={row['decisive_rate']:.6f}，"
                f"decisive_accuracy={row['decisive_accuracy']:.6f}",
                "",
            ]
        )
    report_lines.extend(
        [
            "说明:",
            "1. C和D完全不参与A+B模型训练、特征筛选、概率映射或阈值确定。",
            "2. C/D真实标签只在预测完成后计算测试指标。",
            "3. 正式三档prediction使用A/B交叉OOF分数学到的阈值。",
            "4. probability_TRUE仅作参考，因此即使概率在0.5附近，也不必然被判SUSPECT。",
        ]
    )
    report_path = output_dir / "v13_external_test_report.txt"
    report_path.write_text("\n".join(report_lines), encoding="utf-8")

    print("\n外部测试完成")
    print("逐样本结果:", predictions_path)
    print("场景汇总:", summary_path)
    print("报告:", report_path)
    return {
        "predictions": predictions_path,
        "summary": summary_path,
        "failures": failures_path,
        "report": report_path,
    }


# =============================================================================
# 9. 自检
# =============================================================================


def self_test() -> None:
    print("开始V13.1 A+B训练、C/D外部测试合成自检……")
    rng = np.random.default_rng(20260713)
    with tempfile.TemporaryDirectory(prefix="v13_1_selftest_") as temp:
        root = Path(temp)
        scene_dirs: Dict[str, Path] = {}
        for idx, scene in enumerate(["factory_A", "factory_B", "factory_C", "factory_D"]):
            scene_dirs[scene] = core.make_synthetic_v9_scene(
                root, scene, idx, rng, n_each=10
            )

        train_output = root / "train_AB"
        train_cfg = {
            "scenes": [
                {"name": "factory_A", "v9_dir": str(scene_dirs["factory_A"])},
                {"name": "factory_B", "v9_dir": str(scene_dirs["factory_B"])},
            ],
            "output_dir": str(train_output),
            "algorithm": {
                "model_support_fraction": 1.0,
                "min_abs_effect": 0.25,
                "min_directional_auc": 0.56,
                "max_selected_spectral_dims": 100,
                "max_selected_temporal_dims": 40,
                "max_selected_spatial_dims": None,
                "false_score_quantile": 0.90,
                "true_score_quantile": 0.10,
            },
        }
        train_json = root / "train_AB.json"
        train_json.write_text(json.dumps(train_cfg), encoding="utf-8")
        train_result = run_train(train_json)

        test_output = root / "test_CD"
        test_cfg = {
            "model_file": str(train_result["model"]),
            "test_scenes": [
                {"name": "factory_C", "v9_dir": str(scene_dirs["factory_C"])},
                {"name": "factory_D", "v9_dir": str(scene_dirs["factory_D"])},
            ],
            "output_dir": str(test_output),
        }
        test_json = root / "test_CD.json"
        test_json.write_text(json.dumps(test_cfg), encoding="utf-8")
        test_result = run_evaluate(test_json)
        summary = pd.read_csv(test_result["summary"])
        if len(summary) != 2:
            raise AssertionError("外部测试没有生成C/D两行汇总")
        if (summary["score_auc"] < 0.75).any():
            raise AssertionError(
                "V13.1合成C/D外部测试AUC过低: "
                + summary[["test_scene", "score_auc"]].to_string(index=False)
            )

        print("\nV13.1自检通过：A+B训练，C和D分别外部测试。")
        print(summary[["test_scene", "score_auc", "balanced_accuracy", "n_suspect"]].to_string(index=False))


# =============================================================================
# 10. 命令行
# =============================================================================


def main() -> None:
    parser = argparse.ArgumentParser(
        description="V13.1公共泄漏模型：训练、外部有标签测试、无标签预测"
    )
    parser.add_argument(
        "mode",
        nargs="?",
        choices=["train", "evaluate", "predict"],
        help="train训练；evaluate测试有标签C/D；predict预测无标签场景",
    )
    parser.add_argument("--config", type=str, help="JSON配置文件")
    parser.add_argument("--self-test", action="store_true", help="运行A+B训练、C/D测试合成自检")
    args = parser.parse_args()

    if args.self_test:
        self_test()
        return
    if not args.mode or not args.config:
        parser.print_help()
        sys.exit(2)
    config_path = Path(args.config)
    if not config_path.exists():
        raise FileNotFoundError(f"找不到配置文件: {config_path}")
    if args.mode == "train":
        run_train(config_path)
    elif args.mode == "evaluate":
        run_evaluate(config_path)
    else:
        run_predict(config_path)


if __name__ == "__main__":
    main()
