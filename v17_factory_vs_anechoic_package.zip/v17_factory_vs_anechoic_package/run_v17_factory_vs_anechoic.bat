@echo off
chcp 65001 >nul
cd /d "%~dp0"
python v17_factory_vs_anechoic_models.py --config v17_factory_vs_anechoic_config.json
if errorlevel 1 (
  echo.
  echo 运行失败，请查看上方错误信息。
) else (
  echo.
  echo 运行完成。
)
pause
