v17：工厂空间拟合残差与消声室冻结模型比较
================================================

一、现在为什么运行v17
----------------------
消声室模型已经由第一阶段程序保存在：
    D:\gas\xssck

v16_1已经完成：
    00_00 / 00_01
    -> 各自64个周围点
    -> outer40 plane空间拟合
    -> filtered_leak.wav

v17不再重新做空间拟合，而是直接读取v16_1的filtered_leak.wav，
用消声室模型完全相同的18-50 kHz、100 ms窗口、50 ms步长和5维特征进行比较。

二、运行前检查
--------------
1. D:\gas\xssck中应有：
    09_reference_manifest.json
    models\reference_model_0.1mm.json
    models\reference_model_0.5mm.json
    models\reference_model_ALL_LEAKS.json

2. v16结果目录中应有：
    02_all_points_summary.csv
    各样本目录中的 *_filtered_leak.wav

默认v16结果目录：
    D:\gas\v16_two_points_plane_compare_results

如果你的v16输出目录不是这里，只修改：
    v17_factory_vs_anechoic_config.json
中的v16_output_dir。

三、运行
--------
先自检：
    python v17_factory_vs_anechoic_models.py --self-test

正式运行：
    python v17_factory_vs_anechoic_models.py --config v17_factory_vs_anechoic_config.json

也可以双击：
    run_v17_factory_vs_anechoic.bat

四、最先查看的结果
------------------
1. 00_input_check.csv
   检查每个00_00、00_01是否找到filtered_leak.wav并成功提取特征。
   status必须是OK。

2. 01_point_model_similarity_long.csv
   每一行表示：一个工厂点 vs 一个消声室模型。
   重点列：
       median_distance           越小越像
       p90_distance              越小越稳定地像
       window_inside_fraction    越大越好
       balanced_similarity       0~1，越大越像
       classified_as_leak        有噪声阈值时才有硬判断

3. 02_point_summary_wide.csv
   同一个点与0.1mm、0.5mm、ALL_LEAKS模型的结果并排展示。

4. 03_folder_two_point_decision.csv
   每个文件夹比较00_00和00_01。
   优先使用ALL_LEAKS共同泄漏模型。

5. 04_feature_comparison.csv
   查看工厂点具体是哪个特征接近或偏离消声室模型。
   absolute_z_difference越小，表示该项特征越接近。

6. 99_errors.csv
   路径、WAV、采样率或空间拟合检查错误。

五、结论解释
------------
- 如果消声室建模时包含无泄漏噪声：
  threshold_available=true，classified_as_leak可用于冻结阈值判断。

- 如果消声室建模时没有无泄漏噪声：
  threshold_available=false，程序只能比较00_00和00_01谁更接近泄漏，
  不能用一个固定相似度直接宣布“确定泄漏”。

- decision=00_00或00_01：
  该点比另一个点更接近消声室ALL_LEAKS特征。

- decision=BOTH_LIKE_LEAK：
  两个点都通过冻结阈值且相似度接近。

- decision=NEITHER_LIKE_LEAK：
  两个点都没有通过冻结阈值。

- decision=UNCERTAIN：
  没有硬阈值且两个点差异太小。
