v9 局部背景残差提取（WAV目录版）使用说明
========================================

一、文件
1. leak_v9_local_background_residual_wav.py  主程序
2. requirements_v9_wav.txt                   依赖

二、安装
在 PowerShell 中进入脚本目录后执行：

pip install -r requirements_v9_wav.txt

三、先自检

python .\leak_v9_local_background_residual_wav.py --self-test

应看到“自检通过”。

四、修改程序顶部 DATASETS

必须修改：
- name：数据集名称
- scene：工厂/声学场景名称
- label：TRUE_LEAK 或 FALSE_LEAK
- center_root_dir：中心点 WAV 根目录
- offset_root_dir：偏移点 WAV 根目录
- time_folders：指定时间目录；空列表表示自动扫描共有子目录

同一工厂的真泄漏和假泄漏数据应使用相同 scene。
不同工厂应使用不同 scene。

五、正式运行

python .\leak_v9_local_background_residual_wav.py

不生成诊断图：

python .\leak_v9_local_background_residual_wav.py --no-plots

保存完整残差矩阵：

python .\leak_v9_local_background_residual_wav.py --save-residual-npz

临时修改输出目录：

python .\leak_v9_local_background_residual_wav.py --output "D:\gas\leak_v9_results"

六、兼容的文件名
中心点：
    *_01_beamform_result.wav

周围点：
    *_01d5_up*.wav
    *_01d40_up_left*.wav

程序支持任意数量的周围点。40点、64点都可以，不要求固定数量。

七、主要输出
1. v9_failures.csv
   第一份先看。应尽量为空。

2. v9_all_features.csv
   全部残差特征、质量字段和文件信息。

3. v9_model_ready_features.csv
   后续建模可用的相对残差/形态/空间特征。

4. v9_feature_separation.csv
   TRUE/FALSE 单特征探索结果。不能单独证明跨场景有效。

5. v9_cross_scene_feature_summary.csv
   最重要。按整个 scene 留出后的单特征泛化结果。

6. diagnostic_figures/
   中心频谱、估计背景、残差频谱、时间残差和空间点图。

7. residual_npz/
   仅使用 --save-residual-npz 时生成，包含完整 residual_db 和 excess_power。

八、重要注意
1. 程序不会给每个 WAV 单独做峰值归一化，因为那会破坏中心与周围点的幅值关系。
2. 生成这些 WAV 的上游程序也必须保留文件之间可比较的增益/标度。
3. 这一版先验证“局部背景扣除是否有效”，没有强行输出最终 TRUE/FALSE。
4. 若只有一个 scene，跨场景结果表会为空，这是正常现象。
