V14.1 修正版：为什么旧结果只有 raw 和 selected
=================================================

问题原因
--------
旧版 v9 的每个 NPZ 只保存：
    center_power_db
    background_power_db
    residual_db
    excess_power

其中无后缀的 background/residual/excess 是 v9 当时自动选中的结果，
所以旧 NPZ 能得到：
    raw      = center_power_db
    selected = excess_power

但它没有独立保存：
    excess_power_median
    excess_power_plane

因此旧结果无法事后恢复 median 和 plane。原 v14 不应该静默跳过缺失方法后继续排名。

本修正版做了两处改动
--------------------
1. leak_v9_all_methods_v14_ready.py
   每个样本同时保存：
       center_power_db
       background_power_db_median
       residual_db_median
       excess_power_median
       background_power_db_plane
       residual_db_plane
       excess_power_plane
       background_power_db_selected
       residual_db_selected
       excess_power_selected
       selected_method
       plane_valid

   无后缀字段仍指向 selected，保持 v12/v13 兼容。

2. v14_1_lab_reference_strict_all_methods.py
   在分析前检查四种方法。
   任一场景完全缺少 median 或 plane 时：
       - 立即停止；
       - 不生成 v14_method_ranking.csv；
       - 输出 v14_npz_key_audit.csv；
       - 明确指出缺少哪个方法。

必须重新运行 v9
--------------
旧 NPZ 中没有 median/plane 独立结果，不能通过修改 v14 自动补回来。
必须从中心 WAV 和偏移 WAV 重新运行新的 v9。

操作步骤
--------
1. 打开 leak_v9_all_methods_v14_ready.py。
2. 修改顶部 DATASETS 和 OUTPUT_DIR。
3. 每个工厂的 TRUE/FALSE 必须使用相同 scene 名称。
4. 运行：
       python leak_v9_all_methods_v14_ready.py --self-test
       python leak_v9_all_methods_v14_ready.py --save-residual-npz

   建议 A/B/C/D 分别输出到新目录，避免和旧结果混合，例如：
       factory_A_v9_all_methods_results
       factory_B_v9_all_methods_results
       factory_C_v9_all_methods_results
       factory_D_v9_all_methods_results

5. 随机打开一个 residual_npz/*.npz，或者直接运行 v14.1。
   正确输入应包含 raw、median、plane、selected 四套字段。

6. 修改 v14_1_lab_reference_config.json 中：
       lab_wavs
       四个 v9_dir
       output_dir

7. 运行：
       python v14_1_lab_reference_strict_all_methods.py --self-test
       python v14_1_lab_reference_strict_all_methods.py --config v14_1_lab_reference_config.json

8. 首先查看：
       v14_preflight_method_coverage.csv
   应至少出现四种 method：
       raw
       median
       plane
       selected

   再查看：
       v14_method_ranking.csv

说明
----
plane 因几何条件无效时，个别样本可以不可用；这会反映在 coverage 中。
但如果某个场景的 plane 或 median 完全为 0，v14.1 会停止，不再给出误导排名。
