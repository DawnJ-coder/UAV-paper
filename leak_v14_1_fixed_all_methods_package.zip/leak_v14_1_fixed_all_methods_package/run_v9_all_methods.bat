@echo off
chcp 65001 >nul
cd /d "%~dp0"
python leak_v9_all_methods_v14_ready.py --save-residual-npz
pause
