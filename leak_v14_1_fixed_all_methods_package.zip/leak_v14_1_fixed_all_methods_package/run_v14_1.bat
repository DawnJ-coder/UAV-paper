@echo off
chcp 65001 >nul
cd /d "%~dp0"
python v14_1_lab_reference_strict_all_methods.py --config v14_1_lab_reference_config.json
if errorlevel 1 (
  echo.
  echo 运行失败。请查看输出目录中的 v14_npz_key_audit.csv 和 v14_failures.csv。
)
pause
