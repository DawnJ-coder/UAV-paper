v12 多场景公共泄漏成分发现——使用说明
============================================================

一、程序解决什么问题
------------------------------------------------------------
旧方法使用A场景的TRUE/FALSE模板判断B、C，容易受到A场景FALSE类型和分数基线影响。

v12改为：
1. A场景内部：A_TRUE - A_FALSE，得到A泄漏候选成分；
2. B场景内部：B_TRUE - B_FALSE，得到B泄漏候选成分；
3. C场景内部：C_TRUE - C_FALSE，得到C泄漏候选成分；
4. 找A/B/C方向一致的频谱、时间和空间属性；
5. A+B发现、C测试；A+C发现、B测试；B+C发现、A测试。

因此每个场景都使用自己的FALSE去除自己的场景干扰，而不是拿A_FALSE解释所有工厂。

二、运行前提
------------------------------------------------------------
三个场景都必须已经运行v9，并且目录中存在：
    v9_all_features.csv
    residual_npz\*.npz

每个场景都必须同时含TRUE_LEAK和FALSE_LEAK。

三、路径
------------------------------------------------------------
默认路径已经按当前项目填写：
    A: ...\leak_v9_local_background_results
    B: ...\factory_B_v9_results
    C: ...\factory_C_v9_results

可以直接修改程序开头SCENES，或修改v12_scene_config.json。

四、安装和运行
------------------------------------------------------------
pip install -r requirements_v12.txt

先自检：
python v12_shared_leak_component_discovery.py --self-test

正式运行：
python v12_shared_leak_component_discovery.py --config v12_scene_config.json

也可以直接运行程序内默认路径：
python v12_shared_leak_component_discovery.py

五、最重要输出
------------------------------------------------------------
1. v12_preflight_summary.csv
   检查A/B/C样本数、标签数和NPZ完整率。

2. v12_v9_parameter_consistency.csv
   检查各场景v9参数是否一致。match=0表示参数不同。

3. v12_factory_A_leak_contrast.csv 等
   每个场景自己的TRUE-FALSE差异。

4. v12_cross_scene_common_attributes.csv
   所有频谱、时间、空间维度在A/B/C中的效应、AUC、方向和支持比例。
   component_set=strict_all_scenes：所有场景都支持。
   component_set=majority_scenes：至少2/3场景支持。

5. v12_shared_leak_spectrum.csv
   跨场景共同的泄漏残差富集频谱。
   strict_common_leak_enrichment：A/B/C全部稳定增强的频率。
   majority_common_leak_enrichment：至少2/3场景稳定增强的频率。
   strict_common_selected / majority_common_selected：完整公共属性掩码。
   strict_score_selected / majority_score_selected：LOSO评分实际使用的稳健子集。

6. v12_loso_validation_summary.csv
   最关键的验证结果：
       A+B发现 -> C测试
       A+C发现 -> B测试
       B+C发现 -> A测试
   重点看shared_score_auc、spectral_auc、temporal_auc、spatial_auc。

7. v12_loso_sample_scores.csv
   每个测试样本的频谱、时间、空间分数和总分。

8. v12_shared_leak_component.npz
   保存最终公共频谱和公共权重，供后续程序使用。

六、如何判断结果
------------------------------------------------------------
- shared_score_auc接近1：训练场景发现的公共属性在新场景仍能把TRUE排在FALSE前面。
- spectral_auc在三个留出场景均较高：公共频谱最有可能是跨场景稳定属性。
- spatial_auc低：空间形态受距离、反射和定位影响较大，不宜作为通用本质。
- strict公共频谱为空：当前条件下没有所有场景都共同增强的同一频率，不能强行宣称找到纯频谱。
- 多数公共频谱有内容而严格为空：存在2/3场景共性，但第三场景有明显差异。

七、重要边界
------------------------------------------------------------
程序得到的是“跨场景稳定泄漏残差成分”，不是带相位、可逆STFT重建的纯净泄漏WAV。
FALSE必须与同场景TRUE尽量保持相同位置、增益和设备工况，否则TRUE-FALSE还会混入工况差异。
