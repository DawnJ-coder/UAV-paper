@echo off
chcp 65001 >nul
python v12_shared_leak_component_discovery.py --config v12_scene_config.json
pause
