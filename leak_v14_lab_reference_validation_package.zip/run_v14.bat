@echo off
chcp 65001 > nul
python v14_lab_reference_denoising_validation.py --config v14_lab_reference_config.json
pause
