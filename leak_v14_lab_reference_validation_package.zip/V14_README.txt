v14 实验室纯泄漏参考 × 现场降噪方法验证
============================================================

一、这版程序解决什么问题
------------------------------------------------------------
当前v9自动选择median或plane时，依据是“谁更能拟合周围背景”，
但背景拟合更好，不一定代表留下的残差更像真实泄漏。

v14加入实验室纯泄漏WAV作为独立参考，比较：
    raw
    median
    plane
    selected

一个好的方法应同时满足：
1. A、B、C、D每个场景中，TRUE比FALSE更像实验室纯泄漏；
2. A+B发现的共同成分能区分C、D；
3. C+D发现的共同成分能区分A、B；
4. AB共同成分与CD共同成分仍有交集；
5. 最终交集得到实验室纯泄漏频谱支持。

二、运行前必须具备的文件
------------------------------------------------------------
A、B、C、D各自的v9结果目录：
    v9_all_features.csv
    residual_npz\*.npz

推荐使用最新三路残差v9。NPZ中应尽量包含：
    center_power_db
    excess_power_median
    excess_power_plane
    excess_power_selected
    plane_valid

实验室纯泄漏：
    一条或多条.wav

实验室WAV没有空间信息没有关系，本程序只使用其频谱和时间包络。
实验室WAV采样率必须足以覆盖20-80 kHz，建议192 kHz。

三、修改配置
------------------------------------------------------------
打开：
    v14_lab_reference_config.json

修改：
1. lab_wavs：实验室纯泄漏WAV路径；
2. factory_A/B/C/D的v9_dir；
3. output_dir。

A、B必须写group=AB；C、D必须写group=CD。

四、安装与运行
------------------------------------------------------------
安装：
    python -m pip install -r requirements_v14.txt

先自检：
    python v14_lab_reference_denoising_validation.py --self-test

正式运行：
    python v14_lab_reference_denoising_validation.py --config v14_lab_reference_config.json

也可以双击run_v14.bat。

五、最重要输出
------------------------------------------------------------
1. v14_method_ranking.csv
   方法综合排名。重点看：
       eligible_as_primary
       worst_scene_lab_auc
       worst_pair_transfer_auc
       positive_lab_gap_scene_count
       coverage

   eligible_as_primary=1表示：
       覆盖率足够；
       A/B/C/D四个场景的TRUE都比FALSE更像实验室泄漏；
       四个场景都能计算AUC。

2. v14_method_scene_summary.csv
   每种方法、每个场景的：
       TRUE实验室相似度中位数
       FALSE实验室相似度中位数
       TRUE-FALSE相似度差
       AUC

3. v14_pair_transfer_summary.csv
   AB共同成分测试C、D；CD共同成分测试A、B。
   这是判断共同属性能否跨组迁移的关键。

4. v14_core_spectrum_median.csv 等
   包含：
       实验室参考
       AB共同频谱
       CD共同频谱
       AB与CD现场共同频谱
       实验室软锚定核心
       实验室严格重叠核心

5. v14_strict_core_bands_median.csv 等
   最终连续核心频带。

6. v14_sample_lab_similarity.csv
   每个样本、每种方法与实验室纯泄漏的详细相似度，包括：
       cosine
       Jensen-Shannon
       Wasserstein
       temporal
       best_frequency_shift_hz

7. v14_report.txt
   自动总结推荐方法、最差场景、跨组结果和核心频带。

六、怎么判断降噪方法是否有问题
------------------------------------------------------------
情况1：median在A/B/C/D均有正gap，跨组AUC也高
    -> median更适合作为统一跨场景方法。

情况2：plane在A/B好、C/D差
    -> plane具有场景敏感性，不适合作为统一主方法。

情况3：raw反而比所有残差方法好
    -> 当前空间背景相减可能破坏了真实泄漏成分，需要重做v9。

情况4：TRUE和FALSE都很像实验室纯泄漏
    -> 工厂FALSE可能含类似泄漏的机械超声，纯频谱参考不足以区分；
       还需要时间持续性和空间局部性。

情况5：所有方法的AUC都接近0.5
    -> 实验室参考与现场泄漏条件差异过大，或者现场标签/中心定位/背景点存在问题。

七、重要说明
------------------------------------------------------------
程序不会直接输出可试听的纯净泄漏WAV，因为v9 NPZ只保存功率谱，没有完整相位。
当前得到的是“跨场景稳定且受实验室参考支持的泄漏频谱核心”。
后续确认核心有效后，才适合做参考约束NMF或维纳掩膜来重建增强WAV。
