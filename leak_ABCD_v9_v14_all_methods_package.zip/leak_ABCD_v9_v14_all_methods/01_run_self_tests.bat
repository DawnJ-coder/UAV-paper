@echo off
cd /d "%~dp0"
echo [1/2] v9 self-test
python v9_ABCD_raw_median_plane_selected.py --self-test
if errorlevel 1 goto failed
echo.
echo [2/2] v14 self-test
python v14_ABCD_lab_reference_compare.py --self-test
if errorlevel 1 goto failed
echo.
echo ALL SELF-TESTS PASSED.
pause
exit /b 0
:failed
echo.
echo SELF-TEST FAILED.
pause
exit /b 1
