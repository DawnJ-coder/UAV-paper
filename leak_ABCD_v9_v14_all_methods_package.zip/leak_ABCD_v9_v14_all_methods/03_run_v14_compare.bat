@echo off
cd /d "%~dp0"
python v14_ABCD_lab_reference_compare.py --config v14_ABCD_lab_reference_config.json
pause
