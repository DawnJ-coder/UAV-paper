@echo off
cd /d "%~dp0"
python v9_ABCD_raw_median_plane_selected.py --config v9_ABCD_all_methods_config.json
pause
