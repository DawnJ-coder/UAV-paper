ABCD四场景：v9四种方法输出 + v14实验室纯泄漏对照
=====================================================

本文件夹包含两个完整程序：

1. v9_ABCD_raw_median_plane_selected.py
   对A/B/C/D四个场景的每个样本，同时计算并保存：
   - raw：中心点原始功率谱，不做背景相减；
   - median：中心减外圈背景中位数；
   - plane：中心减空间平面背景；
   - selected：v9自动在median和plane中选择。

2. v14_ABCD_lab_reference_compare.py
   使用实验室纯泄漏WAV，对raw/median/plane/selected进行公平比较；
   同时计算A与B共同成分、C与D共同成分、AB与CD最终共同成分。


一、先运行v9
=============

1. 打开 v9_ABCD_all_methods_config.json。
2. 修改8组路径：A_TRUE、A_FALSE、B_TRUE、B_FALSE、C_TRUE、C_FALSE、D_TRUE、D_FALSE。
3. 每组：
   center_root_dir = 中心波束WAV根目录
   offset_root_dir = 周围偏移波束WAV根目录
   time_folders = [] 表示自动处理两个根目录共有的全部子文件夹。
4. 修改output_dir。
5. 双击 02_run_v9_ABCD.bat。

v9输出结构：

leak_v9_ABCD_all_methods_results
├─ factory_A
│  ├─ v9_all_features.csv
│  ├─ residual_npz                 合并NPZ，内含四种方法
│  └─ methods
│     ├─ raw\residual_npz
│     ├─ median\residual_npz
│     ├─ plane\residual_npz
│     └─ selected\residual_npz
├─ factory_B
├─ factory_C
├─ factory_D
├─ v9_ABCD_all_features.csv
└─ v9_ABCD_manifest.json

每个合并NPZ至少包含：
center_power_db / raw_power
excess_power_median
excess_power_plane
excess_power_selected
selected_method
plane_valid
plane_geometry_ok
fit_median_mae_db
fit_plane_mae_db

说明：
- plane会始终尝试计算，便于与median公平对照；
- selected只有在plane几何可靠且拟合误差至少改善5%时才选plane；
- 无后缀excess_power仍指向selected，以兼容旧程序。


二、再运行v14
==============

1. 确认v9已经完整运行结束。
2. 打开 v14_ABCD_lab_reference_config.json。
3. 修改：
   v9_abcd_root = 上一步v9输出根目录
   lab_wavs = 实验室纯泄漏WAV路径，可填写多条
   output_dir = v14结果目录
4. 场景名称必须和v9中的scene完全一致：factory_A/B/C/D。
5. 双击 03_run_v14_compare.bat。

新版v14默认require_all_methods=true：
如果median或plane缺失，程序会直接报错停止，不会再生成只有raw和selected的误导性排名表。


三、首先看哪些结果
==================

1. v14_preflight_method_coverage.csv
   每个场景raw/median/plane/selected的coverage都应接近1。

2. v14_method_ranking.csv
   主要看：
   - positive_lab_gap_scene_count：最好为4；
   - worst_scene_lab_auc：越大越好；
   - worst_pair_transfer_auc：越大越好；
   - coverage：越接近1越好；
   - eligible_as_primary：1表示具备主方法资格。

3. v14_method_scene_summary.csv
   分场景查看TRUE和FALSE与实验室纯泄漏的相似度：
   lab_similarity_gap = TRUE中位相似度 - FALSE中位相似度，必须为正。

4. v14_pair_transfer_summary.csv
   检查：AB共同成分能否迁移到C/D，CD共同成分能否迁移到A/B。

5. v14_core_spectrum_<method>.csv
   保存AB_common、CD_common、field_ABCD_common、lab_anchored_core。


四、结果解释
============

- raw最好：当前中心减周围背景可能削弱了泄漏；后续优先用场景内TRUE-FALSE和跨场景共性去噪。
- median最好：统一使用median，关闭plane自动选择更稳妥。
- plane最好：空间渐变背景建模有效，但仍需看coverage和最差场景。
- selected最好：当前自动选择规则总体有效。

不要只看平均AUC，优先看worst_scene_lab_auc和worst_pair_transfer_auc。


五、第一次运行建议
==================

依次双击：
00_install_dependencies.bat
01_run_self_tests.bat
02_run_v9_ABCD.bat
03_run_v14_compare.bat

自检只使用合成数据，不会读取或修改你的正式数据。
