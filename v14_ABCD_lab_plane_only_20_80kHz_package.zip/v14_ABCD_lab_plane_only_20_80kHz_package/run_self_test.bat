@echo off
chcp 65001 >nul
python v14_ABCD_lab_plane_only_20_80kHz.py --self-test
pause
