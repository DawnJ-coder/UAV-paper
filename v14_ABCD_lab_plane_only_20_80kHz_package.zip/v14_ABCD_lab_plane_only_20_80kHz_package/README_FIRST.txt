v14：20–80 kHz、仅Plane方法
========================================

用途
----
读取A/B/C/D的v9 Plane残差，直接计算：
1. A_vs_B_similarity
2. C_vs_D_similarity
3. AB_vs_lab_similarity
4. CD_vs_lab_similarity

输入要求
--------
每个场景目录必须包含：
  v9_all_features.csv
  residual_npz/*.npz

每个NPZ必须包含：
  freq_hz
  excess_power_plane
  plane_valid=1

频率范围必须来自20–80 kHz的v9结果。
实验室WAV采样率必须满足Nyquist高于80 kHz，建议192 kHz或更高。

配置
----
修改 v14_ABCD_lab_plane_only_20_80kHz_config.json：
  v9_abcd_root：包含factory_A/B/C/D四个目录的根目录
  lab_wavs：可填写.wav文件，也可填写包含.wav的文件夹
  output_dir：输出目录

运行
----
1. 安装：python -m pip install -r requirements.txt
2. 自检：双击 run_self_test.bat
3. 正式：双击 run_v14_plane_20_80kHz.bat

最先看
------
  00_四个相似度先看这里.txt
  00_AB_CD_LAB_similarity_summary.csv

结果只有一行：plane。
