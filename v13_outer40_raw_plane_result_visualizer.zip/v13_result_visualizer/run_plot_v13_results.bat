@echo off
chcp 65001 >nul
setlocal

REM 修改成你的V13结果根目录：该目录下面必须同时有 raw 和 plane
set "RESULT_ROOT=D:\wurenji\v13_AB_train_CD_test_outer40_results"

python "%~dp0plot_v13_outer40_raw_plane_results.py" --result-root "%RESULT_ROOT%"

if errorlevel 1 (
    echo.
    echo 运行失败，请查看上方错误信息。
    pause
    exit /b 1
)

echo.
echo 绘图完成，结果位于：
echo %RESULT_ROOT%\visual_report
pause
