# -*- coding: utf-8 -*-
"""
plot_v13_outer40_raw_plane_results.py

用途
----
读取 v13_1_AB_train_CD_test_outer40_raw_plane.py 的 raw / plane 运行结果，
自动生成：
1. C、D外部测试的AUC和平衡准确率对比；
2. 每个场景的混淆矩阵；
3. 每个样本的泄漏分数、TRUE/FALSE阈值和SUSPECT区；
4. 频谱、时间、空间三类证据的AUC；
5. A/B训练阶段OOF分数分布；
6. raw与plane公共泄漏频谱对比；
7. raw与plane对同一样本预测变化；
8. 外圈40点平均影响程度；
9. 中文结果总览CSV、文本报告和HTML图文报告。

运行示例
--------
python plot_v13_outer40_raw_plane_results.py ^
  --result-root "D:\\wurenji\\v13_AB_train_CD_test_outer40_results"

可选：
python plot_v13_outer40_raw_plane_results.py ^
  --result-root "D:\\wurenji\\v13_AB_train_CD_test_outer40_results" ^
  --output-dir "D:\\wurenji\\v13_AB_train_CD_test_outer40_results\\visual_report"
"""

from __future__ import annotations

import argparse
import html
import json
import math
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

try:
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
except Exception as exc:
    raise RuntimeError("缺少 matplotlib，请运行: pip install matplotlib") from exc


EPS = 1.0e-12
METHOD_ORDER = ("raw", "plane")
SCENE_ORDER = ("factory_C", "factory_D")


@dataclass
class MethodData:
    method: str
    root: Path
    train_dir: Path
    test_dir: Path
    train_summary: pd.DataFrame
    oof: pd.DataFrame
    model_dimensions: pd.DataFrame
    spectrum: pd.DataFrame
    train_weights: pd.DataFrame
    test_summary: pd.DataFrame
    predictions: pd.DataFrame
    test_weights: pd.DataFrame


def setup_chinese_font() -> str:
    """优先使用Windows常见中文字体，找不到时退回DejaVu Sans。"""
    preferred = [
        "Microsoft YaHei",
        "Microsoft YaHei UI",
        "SimHei",
        "SimSun",
        "Noto Sans CJK SC",
        "Source Han Sans SC",
        "Arial Unicode MS",
        "DejaVu Sans",
    ]
    available = {f.name for f in font_manager.fontManager.ttflist}
    chosen = next((name for name in preferred if name in available), "DejaVu Sans")
    plt.rcParams["font.sans-serif"] = [chosen, "DejaVu Sans"]
    plt.rcParams["axes.unicode_minus"] = False
    return chosen


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def read_csv_optional(path: Path) -> pd.DataFrame:
    if not path.exists():
        return pd.DataFrame()
    try:
        return pd.read_csv(path)
    except UnicodeDecodeError:
        return pd.read_csv(path, encoding="utf-8-sig")


def require_columns(df: pd.DataFrame, required: Sequence[str], source: Path) -> None:
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"{source} 缺少列: {missing}")


def numeric(series: pd.Series) -> np.ndarray:
    return pd.to_numeric(series, errors="coerce").to_numpy(dtype=float)


def finite(values: Iterable[float]) -> np.ndarray:
    arr = np.asarray(list(values), dtype=float)
    return arr[np.isfinite(arr)]


def safe_float(value: object, default: float = float("nan")) -> float:
    try:
        out = float(value)
        return out if np.isfinite(out) else default
    except Exception:
        return default


def safe_rate(numerator: float, denominator: float) -> float:
    if not np.isfinite(denominator) or denominator <= 0:
        return float("nan")
    return float(numerator / denominator)


def method_label(method: str) -> str:
    return {"raw": "raw（中心原始信号）", "plane": "plane（外圈40点背景扣除）"}.get(method, method)


def scene_label(scene: str) -> str:
    return str(scene).replace("factory_", "场景")


def load_method_data(result_root: Path, method: str) -> Optional[MethodData]:
    root = result_root / method
    train_dir = root / "train_AB"
    test_dir = root / "test_CD"
    if not root.exists():
        return None

    train_summary_path = train_dir / "v13_loso_calibrated_scene_summary.csv"
    oof_path = train_dir / "v13_loso_oof_scores.csv"
    model_dimensions_path = train_dir / "v13_model_dimensions.csv"
    spectrum_path = train_dir / "v13_shared_positive_leak_spectrum.csv"
    train_weights_path = train_dir / "v13_train_all_point_weights.csv"
    test_summary_path = test_dir / "v13_external_test_summary.csv"
    predictions_path = test_dir / "v13_external_test_predictions.csv"
    test_weights_path = test_dir / "v13_external_test_all_point_weights.csv"

    if not test_summary_path.exists() or not predictions_path.exists():
        raise FileNotFoundError(
            f"{method}结果不完整。至少需要:\n"
            f"  {test_summary_path}\n"
            f"  {predictions_path}"
        )

    data = MethodData(
        method=method,
        root=root,
        train_dir=train_dir,
        test_dir=test_dir,
        train_summary=read_csv_optional(train_summary_path),
        oof=read_csv_optional(oof_path),
        model_dimensions=read_csv_optional(model_dimensions_path),
        spectrum=read_csv_optional(spectrum_path),
        train_weights=read_csv_optional(train_weights_path),
        test_summary=read_csv_optional(test_summary_path),
        predictions=read_csv_optional(predictions_path),
        test_weights=read_csv_optional(test_weights_path),
    )
    require_columns(
        data.test_summary,
        ["test_scene", "score_auc", "balanced_accuracy", "tp", "tn", "fp", "fn"],
        test_summary_path,
    )
    require_columns(
        data.predictions,
        [
            "sample_id",
            "scene",
            "true_label",
            "shared_leak_score",
            "prediction",
            "binary_prediction",
        ],
        predictions_path,
    )
    return data


def save_figure(fig: plt.Figure, path: Path) -> Path:
    ensure_dir(path.parent)
    fig.tight_layout()
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return path


def add_reference_line(ax: plt.Axes, value: float, label: str, linestyle: str = "--") -> None:
    if np.isfinite(value):
        ax.axhline(value, linewidth=1.2, linestyle=linestyle, label=label)


def plot_metric_comparison(
    methods: Dict[str, MethodData],
    metric: str,
    ylabel: str,
    title: str,
    output_path: Path,
    reference: Optional[float] = None,
) -> Optional[Path]:
    records: List[Dict[str, object]] = []
    for method, data in methods.items():
        for _, row in data.test_summary.iterrows():
            records.append(
                {
                    "method": method,
                    "scene": str(row["test_scene"]),
                    "value": safe_float(row.get(metric)),
                }
            )
    df = pd.DataFrame(records)
    if df.empty or not np.any(np.isfinite(pd.to_numeric(df["value"], errors="coerce"))):
        return None

    scenes = [s for s in SCENE_ORDER if s in set(df["scene"])]
    scenes += [s for s in df["scene"].astype(str).unique() if s not in scenes]
    present_methods = [m for m in METHOD_ORDER if m in methods]
    x = np.arange(len(scenes), dtype=float)
    width = 0.34 if len(present_methods) > 1 else 0.55

    fig, ax = plt.subplots(figsize=(9.5, 5.8))
    for idx, method in enumerate(present_methods):
        values = []
        for scene in scenes:
            match = df[(df["method"] == method) & (df["scene"] == scene)]["value"]
            values.append(safe_float(match.iloc[0]) if len(match) else np.nan)
        offset = (idx - (len(present_methods) - 1) / 2.0) * width
        bars = ax.bar(x + offset, values, width=width, label=method_label(method))
        for bar, value in zip(bars, values):
            if np.isfinite(value):
                ax.text(
                    bar.get_x() + bar.get_width() / 2,
                    value + 0.02,
                    f"{value:.3f}",
                    ha="center",
                    va="bottom",
                    fontsize=9,
                )
    if reference is not None:
        add_reference_line(ax, reference, f"参考线 {reference:.2f}")
    ax.set_xticks(x)
    ax.set_xticklabels([scene_label(s) for s in scenes])
    ax.set_ylim(0.0, 1.08)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.grid(True, axis="y", alpha=0.25)
    ax.legend()
    return save_figure(fig, output_path)


def plot_block_auc(methods: Dict[str, MethodData], output_path: Path) -> Optional[Path]:
    rows: List[Dict[str, object]] = []
    for method, data in methods.items():
        for _, row in data.test_summary.iterrows():
            scene = str(row["test_scene"])
            for block, col in [
                ("频谱", "spectral_auc"),
                ("时间", "temporal_auc"),
                ("空间", "spatial_auc"),
            ]:
                if col in data.test_summary.columns:
                    rows.append(
                        {
                            "method": method,
                            "scene": scene,
                            "block": block,
                            "value": safe_float(row.get(col)),
                        }
                    )
    df = pd.DataFrame(rows)
    if df.empty:
        return None

    groups = []
    for scene in SCENE_ORDER:
        for method in METHOD_ORDER:
            if method in methods and scene in set(df["scene"]):
                groups.append((method, scene))
    for pair in df[["method", "scene"]].drop_duplicates().itertuples(index=False, name=None):
        if pair not in groups:
            groups.append(pair)

    blocks = ["频谱", "时间", "空间"]
    x = np.arange(len(groups), dtype=float)
    width = 0.24
    fig, ax = plt.subplots(figsize=(11.5, 6.2))
    for b_idx, block in enumerate(blocks):
        vals = []
        for method, scene in groups:
            match = df[
                (df["method"] == method)
                & (df["scene"] == scene)
                & (df["block"] == block)
            ]["value"]
            vals.append(safe_float(match.iloc[0]) if len(match) else np.nan)
        bars = ax.bar(x + (b_idx - 1) * width, vals, width=width, label=block)
        for bar, value in zip(bars, vals):
            if np.isfinite(value):
                ax.text(
                    bar.get_x() + bar.get_width() / 2,
                    value + 0.015,
                    f"{value:.2f}",
                    ha="center",
                    va="bottom",
                    fontsize=8,
                )
    ax.axhline(0.5, linewidth=1.1, linestyle="--", label="随机水平0.5")
    ax.set_xticks(x)
    ax.set_xticklabels(
        [f"{m}\n{scene_label(s)}" for m, s in groups], rotation=0
    )
    ax.set_ylim(0.0, 1.08)
    ax.set_ylabel("AUC")
    ax.set_title("频谱、时间、空间三类证据的区分能力")
    ax.grid(True, axis="y", alpha=0.25)
    ax.legend(ncol=4)
    return save_figure(fig, output_path)


def plot_confusion_matrix(
    method: str, scene: str, row: pd.Series, output_path: Path
) -> Path:
    matrix = np.array(
        [
            [safe_float(row.get("tn"), 0.0), safe_float(row.get("fp"), 0.0)],
            [safe_float(row.get("fn"), 0.0), safe_float(row.get("tp"), 0.0)],
        ],
        dtype=float,
    )
    fig, ax = plt.subplots(figsize=(6.3, 5.4))
    image = ax.imshow(matrix)
    fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04, label="样本数")
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["预测FALSE", "预测TRUE"])
    ax.set_yticks([0, 1])
    ax.set_yticklabels(["真实FALSE", "真实TRUE"])
    max_value = max(float(np.nanmax(matrix)), 1.0)
    for i in range(2):
        for j in range(2):
            value = int(round(matrix[i, j]))
            ax.text(j, i, str(value), ha="center", va="center", fontsize=16)
    ax.set_title(f"{method_label(method)}｜{scene_label(scene)}混淆矩阵")
    ax.set_xlabel("模型预测")
    ax.set_ylabel("真实标签")
    return save_figure(fig, output_path)


def deterministic_jitter(n: int, width: float = 0.12) -> np.ndarray:
    if n <= 1:
        return np.zeros(n, dtype=float)
    return np.linspace(-width, width, n)


def plot_score_distribution(
    method: str,
    scene: str,
    predictions: pd.DataFrame,
    output_path: Path,
) -> Optional[Path]:
    group = predictions[predictions["scene"].astype(str) == scene].copy()
    if group.empty:
        return None
    score = pd.to_numeric(group["shared_leak_score"], errors="coerce")
    group = group[np.isfinite(score)].copy()
    if group.empty:
        return None

    fig, ax = plt.subplots(figsize=(9.5, 6.2))
    label_x = {"FALSE_LEAK": 0.0, "TRUE_LEAK": 1.0}
    for true_label in ["FALSE_LEAK", "TRUE_LEAK"]:
        sub = group[group["true_label"].astype(str) == true_label].sort_values(
            "shared_leak_score"
        )
        x0 = label_x[true_label]
        xs = x0 + deterministic_jitter(len(sub))
        ys = pd.to_numeric(sub["shared_leak_score"], errors="coerce").to_numpy(float)
        ax.scatter(xs, ys, alpha=0.8, label=f"真实{true_label.replace('_LEAK', '')}")

        if len(ys):
            median = float(np.median(ys))
            ax.plot([x0 - 0.20, x0 + 0.20], [median, median], linewidth=3)
            ax.text(x0 + 0.23, median, f"中位数={median:.3g}", va="center", fontsize=9)

    first = group.iloc[0]
    false_thr = safe_float(first.get("score_false_threshold"))
    binary_thr = safe_float(first.get("score_binary_threshold"))
    true_thr = safe_float(first.get("score_true_threshold"))
    add_reference_line(ax, false_thr, "FALSE阈值", "--")
    add_reference_line(ax, binary_thr, "二分类阈值", "-")
    add_reference_line(ax, true_thr, "TRUE阈值", "--")

    if np.isfinite(false_thr) and np.isfinite(true_thr) and true_thr > false_thr:
        ax.axhspan(false_thr, true_thr, alpha=0.08, label="SUSPECT区")

    ax.set_xticks([0, 1])
    ax.set_xticklabels(["真实FALSE", "真实TRUE"])
    ax.set_ylabel("shared_leak_score（越高越接近泄漏）")
    ax.set_title(f"{method_label(method)}｜{scene_label(scene)}分数分布与训练阈值")
    ax.grid(True, axis="y", alpha=0.25)
    ax.legend(loc="best")
    return save_figure(fig, output_path)


def plot_sorted_sample_scores(
    method: str,
    scene: str,
    predictions: pd.DataFrame,
    output_path: Path,
) -> Optional[Path]:
    group = predictions[predictions["scene"].astype(str) == scene].copy()
    group["shared_leak_score"] = pd.to_numeric(
        group["shared_leak_score"], errors="coerce"
    )
    group = group[np.isfinite(group["shared_leak_score"])].sort_values(
        "shared_leak_score"
    )
    if group.empty:
        return None

    x = np.arange(len(group))
    fig, ax = plt.subplots(figsize=(12.0, 6.0))
    for label in ["FALSE_LEAK", "TRUE_LEAK"]:
        mask = group["true_label"].astype(str) == label
        ax.scatter(
            x[mask.to_numpy()],
            group.loc[mask, "shared_leak_score"],
            label=f"真实{label.replace('_LEAK', '')}",
            alpha=0.8,
        )
    first = group.iloc[0]
    add_reference_line(ax, safe_float(first.get("score_false_threshold")), "FALSE阈值", "--")
    add_reference_line(ax, safe_float(first.get("score_binary_threshold")), "二分类阈值", "-")
    add_reference_line(ax, safe_float(first.get("score_true_threshold")), "TRUE阈值", "--")
    ax.set_xlabel("样本（按泄漏分数从低到高排列）")
    ax.set_ylabel("shared_leak_score")
    ax.set_title(f"{method_label(method)}｜{scene_label(scene)}逐样本得分排序")
    ax.grid(True, axis="y", alpha=0.25)
    ax.legend()
    return save_figure(fig, output_path)


def plot_probability_distribution(
    method: str,
    scene: str,
    predictions: pd.DataFrame,
    output_path: Path,
) -> Optional[Path]:
    if "probability_TRUE" not in predictions.columns:
        return None
    group = predictions[predictions["scene"].astype(str) == scene].copy()
    group["probability_TRUE"] = pd.to_numeric(group["probability_TRUE"], errors="coerce")
    group = group[np.isfinite(group["probability_TRUE"])]
    if group.empty:
        return None

    fig, ax = plt.subplots(figsize=(9.5, 5.8))
    bins = np.linspace(0.0, 1.0, 16)
    for label in ["FALSE_LEAK", "TRUE_LEAK"]:
        values = group.loc[
            group["true_label"].astype(str) == label, "probability_TRUE"
        ].to_numpy(float)
        if len(values):
            ax.hist(values, bins=bins, alpha=0.55, label=f"真实{label.replace('_LEAK', '')}")
    ax.axvline(0.35, linewidth=1.1, linestyle="--", label="概率参考0.35")
    ax.axvline(0.65, linewidth=1.1, linestyle="--", label="概率参考0.65")
    ax.set_xlim(0.0, 1.0)
    ax.set_xlabel("probability_TRUE（仅供参考，不是正式三档判定来源）")
    ax.set_ylabel("样本数")
    ax.set_title(f"{method_label(method)}｜{scene_label(scene)}概率参考分布")
    ax.grid(True, axis="y", alpha=0.25)
    ax.legend()
    return save_figure(fig, output_path)


def plot_oof_scores(method: str, oof: pd.DataFrame, output_path: Path) -> Optional[Path]:
    required = {"test_scene", "true_label", "shared_leak_score_oof"}
    if oof.empty or not required.issubset(oof.columns):
        return None
    work = oof.copy()
    work["shared_leak_score_oof"] = pd.to_numeric(
        work["shared_leak_score_oof"], errors="coerce"
    )
    work = work[np.isfinite(work["shared_leak_score_oof"])]
    if work.empty:
        return None

    scenes = list(dict.fromkeys(work["test_scene"].astype(str).tolist()))
    positions: List[float] = []
    labels: List[str] = []
    fig, ax = plt.subplots(figsize=(10.5, 6.2))
    pos = 0.0
    for scene in scenes:
        for label in ["FALSE_LEAK", "TRUE_LEAK"]:
            values = work.loc[
                (work["test_scene"].astype(str) == scene)
                & (work["true_label"].astype(str) == label),
                "shared_leak_score_oof",
            ].to_numpy(float)
            xs = pos + deterministic_jitter(len(values))
            ax.scatter(xs, values, alpha=0.8)
            if len(values):
                med = float(np.median(values))
                ax.plot([pos - 0.18, pos + 0.18], [med, med], linewidth=3)
            positions.append(pos)
            labels.append(f"{scene_label(scene)}\n{label.replace('_LEAK', '')}")
            pos += 1.0
        pos += 0.45

    for col, label, linestyle in [
        ("score_false_threshold", "FALSE阈值", "--"),
        ("score_binary_threshold", "二分类阈值", "-"),
        ("score_true_threshold", "TRUE阈值", "--"),
    ]:
        if col in work.columns:
            vals = finite(pd.to_numeric(work[col], errors="coerce").dropna())
            if len(vals):
                add_reference_line(ax, float(np.median(vals)), label, linestyle)
    ax.set_xticks(positions)
    ax.set_xticklabels(labels, rotation=25, ha="right")
    ax.set_ylabel("A/B双向留一场景OOF泄漏分数")
    ax.set_title(f"{method_label(method)}｜A/B训练阶段跨场景验证")
    ax.grid(True, axis="y", alpha=0.25)
    ax.legend()
    return save_figure(fig, output_path)


def plot_shared_spectrum(methods: Dict[str, MethodData], output_path: Path) -> Optional[Path]:
    fig, ax = plt.subplots(figsize=(11.5, 5.8))
    plotted = False
    for method in METHOD_ORDER:
        data = methods.get(method)
        if data is None or data.spectrum.empty:
            continue
        freq_col = "frequency_khz" if "frequency_khz" in data.spectrum.columns else None
        value_col = (
            "shared_positive_leak_spectrum"
            if "shared_positive_leak_spectrum" in data.spectrum.columns
            else None
        )
        if not freq_col or not value_col:
            continue
        x = pd.to_numeric(data.spectrum[freq_col], errors="coerce").to_numpy(float)
        y = pd.to_numeric(data.spectrum[value_col], errors="coerce").to_numpy(float)
        valid = np.isfinite(x) & np.isfinite(y)
        if np.any(valid):
            ax.plot(x[valid], y[valid], linewidth=1.6, label=method_label(method))
            plotted = True
    if not plotted:
        plt.close(fig)
        return None
    ax.set_xlabel("频率（kHz）")
    ax.set_ylabel("公共泄漏富集强度（归一化）")
    ax.set_title("A+B训练得到的公共正向泄漏频谱：raw与plane对比")
    ax.grid(True, alpha=0.25)
    ax.legend()
    return save_figure(fig, output_path)


def plot_selected_spectral_weights(
    methods: Dict[str, MethodData], output_path: Path
) -> Optional[Path]:
    fig, ax = plt.subplots(figsize=(11.5, 5.8))
    plotted = False
    for method in METHOD_ORDER:
        data = methods.get(method)
        dims = data.model_dimensions if data is not None else pd.DataFrame()
        if dims.empty or not {"block", "selected", "weight", "frequency_hz"}.issubset(dims.columns):
            continue
        sub = dims[
            (dims["block"].astype(str) == "spectral")
            & (pd.to_numeric(dims["selected"], errors="coerce") == 1)
        ].copy()
        if sub.empty:
            continue
        x = pd.to_numeric(sub["frequency_hz"], errors="coerce").to_numpy(float) / 1000.0
        y = pd.to_numeric(sub["weight"], errors="coerce").to_numpy(float)
        valid = np.isfinite(x) & np.isfinite(y)
        if np.any(valid):
            order = np.argsort(x[valid])
            ax.plot(x[valid][order], y[valid][order], linewidth=1.4, label=method_label(method))
            plotted = True
    if not plotted:
        plt.close(fig)
        return None
    ax.axhline(0.0, linewidth=1.0)
    ax.set_xlabel("频率（kHz）")
    ax.set_ylabel("模型频谱维度权重")
    ax.set_title("被A、B共同支持的频谱维度及其模型权重")
    ax.grid(True, alpha=0.25)
    ax.legend()
    return save_figure(fig, output_path)


def plot_point_influence(
    method: str,
    scene: str,
    weights: pd.DataFrame,
    output_path: Path,
    top_n: int,
) -> Optional[Path]:
    required = {"scene", "role", "point_id", "plane_absolute_influence_percent"}
    if weights.empty or not required.issubset(weights.columns):
        return None
    sub = weights[
        (weights["scene"].astype(str) == scene)
        & (weights["role"].astype(str) == "USED_OUTER_40")
    ].copy()
    if sub.empty:
        return None
    sub["plane_absolute_influence_percent"] = pd.to_numeric(
        sub["plane_absolute_influence_percent"], errors="coerce"
    )
    summary = (
        sub.groupby("point_id", as_index=False)["plane_absolute_influence_percent"]
        .median()
        .sort_values("plane_absolute_influence_percent", ascending=False)
        .head(top_n)
        .sort_values("plane_absolute_influence_percent", ascending=True)
    )
    if summary.empty:
        return None

    fig, ax = plt.subplots(figsize=(9.5, max(5.6, 0.34 * len(summary) + 2.2)))
    bars = ax.barh(
        summary["point_id"].astype(str),
        summary["plane_absolute_influence_percent"].to_numpy(float),
    )
    for bar, value in zip(bars, summary["plane_absolute_influence_percent"]):
        ax.text(value, bar.get_y() + bar.get_height() / 2, f" {value:.2f}%", va="center")
    ax.set_xlabel("对中心背景平面估计的影响中位数（%）")
    ax.set_ylabel("外圈点")
    note = "（raw结果不使用这些权重，仅用于检查）" if method == "raw" else "（真实参与plane背景拟合）"
    ax.set_title(f"{method_label(method)}｜{scene_label(scene)}外圈40点影响最大的{len(summary)}个点\n{note}")
    ax.grid(True, axis="x", alpha=0.25)
    return save_figure(fig, output_path)


def summarize_point_weights(methods: Dict[str, MethodData]) -> pd.DataFrame:
    rows: List[pd.DataFrame] = []
    for method, data in methods.items():
        weights = data.test_weights
        required = {
            "scene",
            "role",
            "point_id",
            "robust_fit_weight_percent",
            "plane_absolute_influence_percent",
        }
        if weights.empty or not required.issubset(weights.columns):
            continue
        sub = weights[weights["role"].astype(str) == "USED_OUTER_40"].copy()
        if sub.empty:
            continue
        for col in ["robust_fit_weight_percent", "plane_absolute_influence_percent"]:
            sub[col] = pd.to_numeric(sub[col], errors="coerce")
        grouped = (
            sub.groupby(["scene", "point_id"], as_index=False)
            .agg(
                n_samples=("sample_id", "nunique") if "sample_id" in sub.columns else ("point_id", "size"),
                robust_weight_percent_median=("robust_fit_weight_percent", "median"),
                robust_weight_percent_mean=("robust_fit_weight_percent", "mean"),
                influence_percent_median=("plane_absolute_influence_percent", "median"),
                influence_percent_mean=("plane_absolute_influence_percent", "mean"),
                influence_percent_max=("plane_absolute_influence_percent", "max"),
            )
        )
        grouped.insert(0, "method", method)
        rows.append(grouped)
    return pd.concat(rows, ignore_index=True) if rows else pd.DataFrame()


def build_raw_plane_sample_comparison(methods: Dict[str, MethodData]) -> pd.DataFrame:
    if "raw" not in methods or "plane" not in methods:
        return pd.DataFrame()
    raw = methods["raw"].predictions.copy()
    plane = methods["plane"].predictions.copy()
    keys = ["scene", "sample_id"]
    keep = [
        "scene",
        "sample_id",
        "true_label",
        "shared_leak_score",
        "prediction",
        "binary_prediction",
        "correct_binary",
        "correct_3way",
        "probability_TRUE",
        "quality_warning",
    ]
    raw = raw[[c for c in keep if c in raw.columns]].copy()
    plane = plane[[c for c in keep if c in plane.columns]].copy()
    merged = raw.merge(plane, on=keys, how="inner", suffixes=("_raw", "_plane"))
    if merged.empty:
        return merged

    label_col = "true_label_raw" if "true_label_raw" in merged.columns else "true_label"
    merged["true_label"] = merged[label_col].astype(str)
    for method in ["raw", "plane"]:
        correct_col = f"correct_binary_{method}"
        if correct_col not in merged.columns:
            pred_col = f"binary_prediction_{method}"
            merged[correct_col] = (
                merged[pred_col].astype(str) == merged["true_label"].astype(str)
            ).astype(int)

    raw_ok = pd.to_numeric(merged["correct_binary_raw"], errors="coerce").fillna(0).astype(int)
    plane_ok = pd.to_numeric(merged["correct_binary_plane"], errors="coerce").fillna(0).astype(int)
    merged["change_category"] = np.select(
        [
            (raw_ok == 0) & (plane_ok == 1),
            (raw_ok == 1) & (plane_ok == 0),
            (raw_ok == 1) & (plane_ok == 1),
        ],
        ["plane改对", "plane改错", "两者都对"],
        default="两者都错",
    )
    if {"shared_leak_score_raw", "shared_leak_score_plane"}.issubset(merged.columns):
        merged["score_plane_minus_raw"] = (
            pd.to_numeric(merged["shared_leak_score_plane"], errors="coerce")
            - pd.to_numeric(merged["shared_leak_score_raw"], errors="coerce")
        )
    return merged


def plot_prediction_change(comparison: pd.DataFrame, output_path: Path) -> Optional[Path]:
    if comparison.empty or "change_category" not in comparison.columns:
        return None
    order = ["plane改对", "plane改错", "两者都对", "两者都错"]
    scenes = [s for s in SCENE_ORDER if s in set(comparison["scene"].astype(str))]
    if not scenes:
        scenes = list(comparison["scene"].astype(str).unique())
    x = np.arange(len(scenes), dtype=float)
    width = 0.18
    fig, ax = plt.subplots(figsize=(10.5, 6.0))
    for idx, category in enumerate(order):
        values = [
            int(
                np.sum(
                    (comparison["scene"].astype(str) == scene)
                    & (comparison["change_category"].astype(str) == category)
                )
            )
            for scene in scenes
        ]
        bars = ax.bar(x + (idx - 1.5) * width, values, width=width, label=category)
        for bar, value in zip(bars, values):
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                value + 0.15,
                str(value),
                ha="center",
                va="bottom",
                fontsize=9,
            )
    ax.set_xticks(x)
    ax.set_xticklabels([scene_label(s) for s in scenes])
    ax.set_ylabel("样本数")
    ax.set_title("同一样本从raw改为plane后，二分类结果如何变化")
    ax.grid(True, axis="y", alpha=0.25)
    ax.legend(ncol=2)
    return save_figure(fig, output_path)


def plot_ood_warning_rate(methods: Dict[str, MethodData], output_path: Path) -> Optional[Path]:
    rows = []
    for method, data in methods.items():
        if "quality_warning" not in data.predictions.columns:
            continue
        for scene, group in data.predictions.groupby(data.predictions["scene"].astype(str)):
            warning = group["quality_warning"].fillna("").astype(str).str.strip().ne("")
            rows.append({"method": method, "scene": scene, "rate": float(warning.mean())})
    df = pd.DataFrame(rows)
    if df.empty:
        return None
    scenes = [s for s in SCENE_ORDER if s in set(df["scene"])]
    methods_order = [m for m in METHOD_ORDER if m in set(df["method"])]
    x = np.arange(len(scenes), dtype=float)
    width = 0.34 if len(methods_order) > 1 else 0.55
    fig, ax = plt.subplots(figsize=(9.5, 5.8))
    for idx, method in enumerate(methods_order):
        vals = []
        for scene in scenes:
            match = df[(df["method"] == method) & (df["scene"] == scene)]["rate"]
            vals.append(safe_float(match.iloc[0]) if len(match) else np.nan)
        offset = (idx - (len(methods_order) - 1) / 2.0) * width
        bars = ax.bar(x + offset, vals, width=width, label=method_label(method))
        for bar, value in zip(bars, vals):
            if np.isfinite(value):
                ax.text(
                    bar.get_x() + bar.get_width() / 2,
                    value + 0.015,
                    f"{100*value:.1f}%",
                    ha="center",
                    fontsize=9,
                )
    ax.set_xticks(x)
    ax.set_xticklabels([scene_label(s) for s in scenes])
    ax.set_ylim(0.0, 1.05)
    ax.set_ylabel("出现质量警告的样本比例")
    ax.set_title("测试数据偏离A/B训练分布的比例")
    ax.grid(True, axis="y", alpha=0.25)
    ax.legend()
    return save_figure(fig, output_path)


def auc_text(value: float) -> str:
    if not np.isfinite(value):
        return "无法计算"
    if value >= 0.90:
        return "排序能力很强"
    if value >= 0.80:
        return "排序能力较好"
    if value >= 0.70:
        return "有一定排序能力"
    if value >= 0.60:
        return "排序能力偏弱"
    if value >= 0.50:
        return "接近随机"
    return "方向可能相反或失效"


def bal_text(value: float) -> str:
    if not np.isfinite(value):
        return "无法计算"
    if value >= 0.90:
        return "当前阈值分类很好"
    if value >= 0.80:
        return "当前阈值分类较好"
    if value >= 0.70:
        return "当前阈值分类一般"
    if value >= 0.60:
        return "当前阈值分类偏弱"
    return "当前阈值基本不可用"


def scene_judgement(row: pd.Series) -> Tuple[str, str]:
    auc = safe_float(row.get("score_auc"))
    bal = safe_float(row.get("balanced_accuracy"))
    suspect_rate = safe_float(row.get("suspect_rate"), 0.0)
    true_med = safe_float(row.get("true_score_median"))
    false_med = safe_float(row.get("false_score_median"))

    findings = [auc_text(auc), bal_text(bal)]
    issue = ""
    if np.isfinite(auc) and auc >= 0.80 and np.isfinite(bal) and bal < 0.70:
        issue = "TRUE/FALSE排序不错，但A+B学到的阈值在该场景发生偏移"
    elif np.isfinite(auc) and auc < 0.70:
        issue = "A+B学到的公共方向在该场景泛化不足"
    elif np.isfinite(true_med) and np.isfinite(false_med) and true_med <= false_med:
        issue = "TRUE分数中位数没有高于FALSE，分数方向异常"
    elif np.isfinite(suspect_rate) and suspect_rate > 0.25:
        issue = "SUSPECT比例较高，很多样本离训练阈值边界较近"
    else:
        issue = "未发现明显的阈值或方向异常"
    return "；".join(findings), issue


def build_overview(methods: Dict[str, MethodData]) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []
    for method in METHOD_ORDER:
        data = methods.get(method)
        if data is None:
            continue
        for _, source in data.test_summary.iterrows():
            n_samples = safe_float(source.get("n_samples"), 0.0)
            n_suspect = safe_float(source.get("n_pred_SUSPECT"), 0.0)
            suspect_rate = safe_rate(n_suspect, n_samples)
            row: Dict[str, object] = {
                "method": method,
                "method_meaning": method_label(method),
                "test_scene": str(source.get("test_scene", "")),
                "n_samples": int(round(n_samples)),
                "n_true": int(round(safe_float(source.get("n_true"), 0.0))),
                "n_false": int(round(safe_float(source.get("n_false"), 0.0))),
                "score_auc": safe_float(source.get("score_auc")),
                "balanced_accuracy": safe_float(source.get("balanced_accuracy")),
                "accuracy": safe_float(source.get("accuracy")),
                "spectral_auc": safe_float(source.get("spectral_auc")),
                "temporal_auc": safe_float(source.get("temporal_auc")),
                "spatial_auc": safe_float(source.get("spatial_auc")),
                "tp": int(round(safe_float(source.get("tp"), 0.0))),
                "tn": int(round(safe_float(source.get("tn"), 0.0))),
                "fp": int(round(safe_float(source.get("fp"), 0.0))),
                "fn": int(round(safe_float(source.get("fn"), 0.0))),
                "n_pred_TRUE_LEAK": int(round(safe_float(source.get("n_pred_TRUE_LEAK"), 0.0))),
                "n_pred_FALSE_LEAK": int(round(safe_float(source.get("n_pred_FALSE_LEAK"), 0.0))),
                "n_pred_SUSPECT": int(round(n_suspect)),
                "suspect_rate": suspect_rate,
                "decisive_rate": safe_float(source.get("decisive_rate")),
                "decisive_accuracy": safe_float(source.get("decisive_accuracy")),
                "true_score_median": safe_float(source.get("true_score_median")),
                "false_score_median": safe_float(source.get("false_score_median")),
                "score_median_gap_TRUE_minus_FALSE": (
                    safe_float(source.get("true_score_median"))
                    - safe_float(source.get("false_score_median"))
                ),
            }
            summary, issue = scene_judgement(pd.Series(row))
            row["plain_language_summary"] = summary
            row["main_issue"] = issue
            rows.append(row)
    return pd.DataFrame(rows)


def choose_better_method(overview: pd.DataFrame, scene: str) -> str:
    sub = overview[overview["test_scene"].astype(str) == scene].copy()
    if len(sub) < 2:
        return "只有一种方法，无法比较"
    sub["score_auc"] = pd.to_numeric(sub["score_auc"], errors="coerce")
    sub["balanced_accuracy"] = pd.to_numeric(sub["balanced_accuracy"], errors="coerce")
    sub["suspect_rate"] = pd.to_numeric(sub["suspect_rate"], errors="coerce").fillna(0.0)
    sub["comparison_index"] = (
        0.45 * sub["score_auc"].fillna(0.5)
        + 0.45 * sub["balanced_accuracy"].fillna(0.5)
        + 0.10 * (1.0 - sub["suspect_rate"])
    )
    best = sub.sort_values("comparison_index", ascending=False).iloc[0]
    other = sub.sort_values("comparison_index", ascending=False).iloc[-1]
    if abs(float(best["comparison_index"]) - float(other["comparison_index"])) < 0.03:
        return "raw与plane整体接近，不能仅凭单次结果断定优劣"
    return f"{best['method']}整体更好（综合考虑AUC、平衡准确率和SUSPECT比例）"


def write_text_report(
    methods: Dict[str, MethodData],
    overview: pd.DataFrame,
    comparison: pd.DataFrame,
    output_path: Path,
    figure_paths: Sequence[Path],
) -> Path:
    lines: List[str] = [
        "V13 outer40 raw/plane 结果解读",
        "=" * 88,
        "",
        "先看什么",
        "--------",
        "1. score_auc：只看TRUE是否整体排在FALSE前面，不依赖当前阈值。",
        "2. balanced_accuracy：看A+B训练阈值直接用于C/D后，分类是否仍然正确。",
        "3. AUC高但balanced_accuracy低：常见原因是场景阈值偏移，不是完全没有信息。",
        "4. spectral/temporal/spatial_auc：判断是哪类证据真正起作用。",
        "5. SUSPECT：分数落在FALSE阈值与TRUE阈值之间，模型主动不强行二选一。",
        "",
        "逐场景结论",
        "----------",
    ]
    for _, row in overview.iterrows():
        lines.extend(
            [
                f"[{row['method']} | {row['test_scene']}]",
                f"  AUC={row['score_auc']:.4f}：{auc_text(safe_float(row['score_auc']))}",
                f"  平衡准确率={row['balanced_accuracy']:.4f}：{bal_text(safe_float(row['balanced_accuracy']))}",
                f"  TP/TN/FP/FN={row['tp']}/{row['tn']}/{row['fp']}/{row['fn']}",
                f"  SUSPECT={row['n_pred_SUSPECT']}/{row['n_samples']} ({100*safe_float(row['suspect_rate'], 0.0):.1f}%)",
                f"  TRUE/FALSE分数中位数={row['true_score_median']:.5g}/{row['false_score_median']:.5g}",
                f"  判断：{row['main_issue']}",
                "",
            ]
        )

    lines.extend(["raw与plane比较", "------------"])
    for scene in SCENE_ORDER:
        if scene in set(overview["test_scene"].astype(str)):
            lines.append(f"{scene}: {choose_better_method(overview, scene)}")
    if not comparison.empty:
        counts = comparison.groupby(["scene", "change_category"]).size().unstack(fill_value=0)
        lines.append("")
        lines.append("同一样本由raw改为plane后的变化：")
        for scene, row in counts.iterrows():
            parts = [f"{col}={int(row[col])}" for col in row.index]
            lines.append(f"  {scene}: " + "，".join(parts))

    lines.extend(
        [
            "",
            "图表目录",
            "--------",
        ]
    )
    for path in figure_paths:
        lines.append(f"- {path.name}")
    lines.extend(
        [
            "",
            "注意",
            "----",
            "- probability_TRUE只是参考显示；正式三档prediction来自A/B训练OOF分数阈值。",
            "- raw不使用外圈40点做背景扣除；raw目录中的点权重仅供空间质量检查。",
            "- plane中的外圈40点权重真实参与中心背景平面的估计。",
            "- 若AUC高但阈值分类差，应优先考虑跨场景阈值校准，而不是直接否定频谱排序信息。",
        ]
    )
    output_path.write_text("\n".join(lines), encoding="utf-8")
    return output_path


def dataframe_html(df: pd.DataFrame, digits: int = 4) -> str:
    if df.empty:
        return "<p>没有可显示的数据。</p>"
    show = df.copy()
    for col in show.columns:
        if pd.api.types.is_float_dtype(show[col]):
            show[col] = show[col].map(
                lambda x: "" if not np.isfinite(x) else f"{x:.{digits}f}"
            )
    return show.to_html(index=False, border=0, classes="dataframe", escape=True)


def write_html_report(
    overview: pd.DataFrame,
    comparison: pd.DataFrame,
    figure_paths: Sequence[Path],
    output_dir: Path,
    output_path: Path,
) -> Path:
    cards = []
    for _, row in overview.iterrows():
        cards.append(
            f"""
            <div class="card">
              <h3>{html.escape(str(row['method']))}｜{html.escape(scene_label(str(row['test_scene'])))}</h3>
              <p><b>AUC：</b>{safe_float(row['score_auc']):.4f}（{html.escape(auc_text(safe_float(row['score_auc']))) }）</p>
              <p><b>平衡准确率：</b>{safe_float(row['balanced_accuracy']):.4f}（{html.escape(bal_text(safe_float(row['balanced_accuracy']))) }）</p>
              <p><b>TP/TN/FP/FN：</b>{int(row['tp'])}/{int(row['tn'])}/{int(row['fp'])}/{int(row['fn'])}</p>
              <p><b>SUSPECT：</b>{int(row['n_pred_SUSPECT'])}/{int(row['n_samples'])}</p>
              <p><b>主要判断：</b>{html.escape(str(row['main_issue']))}</p>
            </div>
            """
        )

    image_sections = []
    for path in figure_paths:
        rel = path.relative_to(output_dir).as_posix()
        image_sections.append(
            f'<section><h3>{html.escape(path.stem)}</h3><img src="{html.escape(rel)}" alt="{html.escape(path.stem)}"></section>'
        )

    document = f"""<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<title>V13 raw/plane结果图文报告</title>
<style>
body {{ font-family: "Microsoft YaHei", "Noto Sans CJK SC", sans-serif; margin: 28px; line-height: 1.65; color: #222; }}
h1, h2, h3 {{ line-height: 1.3; }}
.cards {{ display: flex; flex-wrap: wrap; gap: 14px; }}
.card {{ border: 1px solid #ddd; border-radius: 10px; padding: 14px 18px; min-width: 280px; flex: 1; background: #fafafa; }}
section {{ margin: 30px 0; page-break-inside: avoid; }}
img {{ max-width: 100%; border: 1px solid #ddd; border-radius: 8px; }}
table.dataframe {{ border-collapse: collapse; width: 100%; font-size: 14px; }}
table.dataframe th, table.dataframe td {{ border: 1px solid #ddd; padding: 6px 8px; text-align: center; }}
table.dataframe th {{ background: #f2f2f2; }}
.note {{ background: #fff8df; border-left: 4px solid #d6aa00; padding: 12px 16px; }}
</style>
</head>
<body>
<h1>V13 outer40 raw/plane结果图文报告</h1>
<div class="note">
<b>阅读顺序：</b>先看AUC和平衡准确率；若AUC高、平衡准确率低，说明排序信息存在，但A+B阈值迁移到C/D后发生偏移。
probability_TRUE仅供参考，正式三档判定来自A/B的OOF分数阈值。
</div>
<h2>逐场景结论</h2>
<div class="cards">{''.join(cards)}</div>
<h2>结果总览</h2>
{dataframe_html(overview)}
<h2>raw与plane同一样本比较</h2>
{dataframe_html(comparison.head(200)) if not comparison.empty else '<p>没有同时匹配到raw和plane样本。</p>'}
<h2>图表</h2>
{''.join(image_sections)}
</body>
</html>"""
    output_path.write_text(document, encoding="utf-8")
    return output_path


def run(result_root: Path, output_dir: Path, top_points: int) -> Dict[str, Path]:
    setup_chinese_font()
    ensure_dir(output_dir)
    figures_dir = output_dir / "figures"
    tables_dir = output_dir / "tables"
    ensure_dir(figures_dir)
    ensure_dir(tables_dir)

    methods: Dict[str, MethodData] = {}
    for method in METHOD_ORDER:
        data = load_method_data(result_root, method)
        if data is not None:
            methods[method] = data
    if not methods:
        raise FileNotFoundError(
            f"在 {result_root} 下没有找到 raw 或 plane 结果目录。\n"
            "期望结构：result_root/raw/train_AB、result_root/raw/test_CD、"
            "result_root/plane/train_AB、result_root/plane/test_CD"
        )

    overview = build_overview(methods)
    overview_path = tables_dir / "01_结果总览与中文判断.csv"
    overview.to_csv(overview_path, index=False, encoding="utf-8-sig")

    comparison = build_raw_plane_sample_comparison(methods)
    comparison_path = tables_dir / "02_raw_plane逐样本对比.csv"
    comparison.to_csv(comparison_path, index=False, encoding="utf-8-sig")

    point_summary = summarize_point_weights(methods)
    point_summary_path = tables_dir / "03_外圈40点平均权重与影响汇总.csv"
    point_summary.to_csv(point_summary_path, index=False, encoding="utf-8-sig")

    figure_paths: List[Path] = []
    candidates = [
        plot_metric_comparison(
            methods,
            "score_auc",
            "score AUC",
            "raw与plane在C、D上的排序能力（越接近1越好）",
            figures_dir / "01_raw_plane_score_AUC对比.png",
            reference=0.5,
        ),
        plot_metric_comparison(
            methods,
            "balanced_accuracy",
            "平衡准确率",
            "A+B训练阈值直接用于C、D后的分类效果",
            figures_dir / "02_raw_plane平衡准确率对比.png",
            reference=0.5,
        ),
        plot_metric_comparison(
            methods,
            "decisive_rate",
            "明确判定比例",
            "非SUSPECT样本比例（越高表示模型越敢于明确判断）",
            figures_dir / "03_raw_plane明确判定比例.png",
            reference=None,
        ),
        plot_block_auc(methods, figures_dir / "04_频谱时间空间AUC对比.png"),
        plot_shared_spectrum(methods, figures_dir / "05_AB公共泄漏频谱_raw_plane对比.png"),
        plot_selected_spectral_weights(
            methods, figures_dir / "06_被选择频谱维度的模型权重.png"
        ),
        plot_prediction_change(comparison, figures_dir / "07_raw改为plane后的预测变化.png"),
        plot_ood_warning_rate(methods, figures_dir / "08_质量警告比例.png"),
    ]
    figure_paths.extend([p for p in candidates if p is not None])

    for method, data in methods.items():
        oof_path = plot_oof_scores(
            method,
            data.oof,
            figures_dir / f"09_{method}_AB训练OOF分数分布.png",
        )
        if oof_path is not None:
            figure_paths.append(oof_path)

        scenes = list(dict.fromkeys(data.test_summary["test_scene"].astype(str).tolist()))
        for scene in scenes:
            row_df = data.test_summary[data.test_summary["test_scene"].astype(str) == scene]
            if not row_df.empty:
                figure_paths.append(
                    plot_confusion_matrix(
                        method,
                        scene,
                        row_df.iloc[0],
                        figures_dir / f"10_{method}_{scene}_混淆矩阵.png",
                    )
                )
            for path in [
                plot_score_distribution(
                    method,
                    scene,
                    data.predictions,
                    figures_dir / f"11_{method}_{scene}_TRUE_FALSE分数与阈值.png",
                ),
                plot_sorted_sample_scores(
                    method,
                    scene,
                    data.predictions,
                    figures_dir / f"12_{method}_{scene}_逐样本分数排序.png",
                ),
                plot_probability_distribution(
                    method,
                    scene,
                    data.predictions,
                    figures_dir / f"13_{method}_{scene}_概率参考分布.png",
                ),
                plot_point_influence(
                    method,
                    scene,
                    data.test_weights,
                    figures_dir / f"14_{method}_{scene}_外圈点影响Top{top_points}.png",
                    top_points,
                ),
            ]:
                if path is not None:
                    figure_paths.append(path)

    report_path = write_text_report(
        methods,
        overview,
        comparison,
        output_dir / "V13结果中文解读.txt",
        figure_paths,
    )
    html_path = write_html_report(
        overview,
        comparison,
        figure_paths,
        output_dir,
        output_dir / "V13结果图文报告.html",
    )

    manifest = {
        "result_root": str(result_root),
        "output_dir": str(output_dir),
        "methods_found": list(methods),
        "overview_csv": str(overview_path),
        "sample_comparison_csv": str(comparison_path),
        "point_summary_csv": str(point_summary_path),
        "text_report": str(report_path),
        "html_report": str(html_path),
        "figures": [str(p) for p in figure_paths],
    }
    manifest_path = output_dir / "visualization_manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

    print("=" * 90)
    print("V13结果可视化完成")
    print("结果总览:", overview_path)
    print("中文解读:", report_path)
    print("HTML图文报告:", html_path)
    print("图表目录:", figures_dir)
    print("=" * 90)
    return {
        "overview": overview_path,
        "comparison": comparison_path,
        "point_summary": point_summary_path,
        "report": report_path,
        "html": html_path,
        "manifest": manifest_path,
    }


def self_test() -> None:
    import tempfile

    with tempfile.TemporaryDirectory(prefix="v13_visualizer_test_") as tmp:
        root = Path(tmp) / "results"
        rng = np.random.default_rng(42)
        for method_idx, method in enumerate(METHOD_ORDER):
            train = root / method / "train_AB"
            test = root / method / "test_CD"
            ensure_dir(train)
            ensure_dir(test)

            oof_rows = []
            for scene in ["factory_A", "factory_B"]:
                for label, loc in [("FALSE_LEAK", -1.0), ("TRUE_LEAK", 1.0)]:
                    for i in range(8):
                        score = loc + 0.35 * rng.normal() + 0.05 * method_idx
                        oof_rows.append(
                            {
                                "sample_id": f"{method}_{scene}_{label}_{i}",
                                "test_scene": scene,
                                "true_label": label,
                                "shared_leak_score_oof": score,
                                "score_false_threshold": -0.35,
                                "score_binary_threshold": 0.0,
                                "score_true_threshold": 0.35,
                            }
                        )
            pd.DataFrame(oof_rows).to_csv(train / "v13_loso_oof_scores.csv", index=False)
            pd.DataFrame(
                [
                    {"test_scene": "factory_A", "score_auc": 0.92, "balanced_accuracy": 0.85},
                    {"test_scene": "factory_B", "score_auc": 0.90, "balanced_accuracy": 0.82},
                ]
            ).to_csv(train / "v13_loso_calibrated_scene_summary.csv", index=False)

            freq = np.linspace(20_000, 80_000, 61)
            spectrum = np.exp(-0.5 * ((freq - (58_000 + 1000 * method_idx)) / 5000) ** 2)
            pd.DataFrame(
                {
                    "frequency_hz": freq,
                    "frequency_khz": freq / 1000,
                    "shared_positive_leak_spectrum": spectrum / spectrum.sum(),
                    "selected_for_model": (spectrum > 0.25).astype(int),
                    "model_weight": spectrum,
                }
            ).to_csv(train / "v13_shared_positive_leak_spectrum.csv", index=False)
            pd.DataFrame(
                {
                    "block": ["spectral"] * len(freq),
                    "selected": (spectrum > 0.25).astype(int),
                    "weight": spectrum,
                    "frequency_hz": freq,
                }
            ).to_csv(train / "v13_model_dimensions.csv", index=False)

            summary_rows = []
            pred_rows = []
            weight_rows = []
            for scene_idx, scene in enumerate(SCENE_ORDER):
                y = np.array([0] * 10 + [1] * 10)
                signal = (2 * y - 1) + rng.normal(0, 0.55 + 0.1 * scene_idx, len(y))
                if method == "plane":
                    signal += 0.15 * (2 * y - 1)
                binary = (signal >= 0).astype(int)
                prediction = np.where(
                    signal >= 0.35,
                    "TRUE_LEAK",
                    np.where(signal <= -0.35, "FALSE_LEAK", "SUSPECT"),
                )
                tn = int(np.sum((y == 0) & (binary == 0)))
                fp = int(np.sum((y == 0) & (binary == 1)))
                fn = int(np.sum((y == 1) & (binary == 0)))
                tp = int(np.sum((y == 1) & (binary == 1)))
                tpr = tp / 10
                tnr = tn / 10
                bal = 0.5 * (tpr + tnr)
                # 用秩近似自检AUC，不依赖sklearn。
                pos = signal[y == 1]
                neg = signal[y == 0]
                auc = float(np.mean(pos[:, None] > neg[None, :]) + 0.5 * np.mean(pos[:, None] == neg[None, :]))
                summary_rows.append(
                    {
                        "test_scene": scene,
                        "n_samples": 20,
                        "n_true": 10,
                        "n_false": 10,
                        "score_auc": auc,
                        "probability_auc": auc,
                        "spectral_auc": min(1.0, auc + 0.02),
                        "temporal_auc": max(0.5, auc - 0.05),
                        "spatial_auc": max(0.5, auc - 0.10),
                        "accuracy": (tp + tn) / 20,
                        "balanced_accuracy": bal,
                        "tn": tn,
                        "fp": fp,
                        "fn": fn,
                        "tp": tp,
                        "decisive_rate": float(np.mean(prediction != "SUSPECT")),
                        "decisive_accuracy": 0.9,
                        "n_pred_TRUE_LEAK": int(np.sum(prediction == "TRUE_LEAK")),
                        "n_pred_FALSE_LEAK": int(np.sum(prediction == "FALSE_LEAK")),
                        "n_pred_SUSPECT": int(np.sum(prediction == "SUSPECT")),
                        "true_score_median": float(np.median(signal[y == 1])),
                        "false_score_median": float(np.median(signal[y == 0])),
                    }
                )
                for i, (yy, score, pred, bpred) in enumerate(
                    zip(y, signal, prediction, binary)
                ):
                    pred_rows.append(
                        {
                            "sample_id": f"{scene}_{i:02d}",
                            "scene": scene,
                            "true_label": "TRUE_LEAK" if yy else "FALSE_LEAK",
                            "shared_leak_score": score,
                            "probability_TRUE": 1.0 / (1.0 + np.exp(-score)),
                            "prediction": pred,
                            "binary_prediction": "TRUE_LEAK" if bpred else "FALSE_LEAK",
                            "correct_binary": int(yy == bpred),
                            "correct_3way": int(pred == ("TRUE_LEAK" if yy else "FALSE_LEAK")),
                            "score_spectral_raw": score + rng.normal(0, 0.1),
                            "score_temporal_raw": score + rng.normal(0, 0.2),
                            "score_spatial_raw": score + rng.normal(0, 0.3),
                            "score_false_threshold": -0.35,
                            "score_binary_threshold": 0.0,
                            "score_true_threshold": 0.35,
                            "quality_warning": "" if i % 7 else "SPECTRAL_OUT_RANGE",
                        }
                    )
                    for p in range(40):
                        weight_rows.append(
                            {
                                "sample_id": f"{scene}_{i:02d}",
                                "scene": scene,
                                "role": "USED_OUTER_40",
                                "point_id": f"outer_{p+1:02d}",
                                "robust_fit_weight_percent": 2.5,
                                "plane_absolute_influence_percent": float(
                                    100 * (p + 1) / sum(range(1, 41))
                                ),
                            }
                        )
            pd.DataFrame(summary_rows).to_csv(test / "v13_external_test_summary.csv", index=False)
            pd.DataFrame(pred_rows).to_csv(test / "v13_external_test_predictions.csv", index=False)
            pd.DataFrame(weight_rows).to_csv(test / "v13_external_test_all_point_weights.csv", index=False)

        out = Path(tmp) / "visual_report"
        paths = run(root, out, top_points=10)
        for name, path in paths.items():
            if not path.exists():
                raise AssertionError(f"自检输出不存在: {name}={path}")
        figures = list((out / "figures").glob("*.png"))
        if len(figures) < 10:
            raise AssertionError(f"自检图表数量过少: {len(figures)}")
        overview = pd.read_csv(paths["overview"])
        if len(overview) != 4:
            raise AssertionError(f"结果总览应有4行，当前={len(overview)}")
    print("SELF-TEST PASSED")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="绘制V13 outer40 raw/plane结果图")
    parser.add_argument(
        "--result-root",
        help="v13一键运行结果根目录，下面应有raw和plane文件夹",
    )
    parser.add_argument(
        "--output-dir",
        default="",
        help="图表输出目录；默认=result-root/visual_report",
    )
    parser.add_argument(
        "--top-points",
        type=int,
        default=15,
        help="每个场景绘制影响最大的外圈点数量，默认15",
    )
    parser.add_argument("--self-test", action="store_true", help="运行内置自检")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.self_test:
        self_test()
        return
    if not args.result_root:
        raise ValueError("正式运行必须提供 --result-root")
    result_root = Path(args.result_root).expanduser().resolve()
    output_dir = (
        Path(args.output_dir).expanduser().resolve()
        if str(args.output_dir).strip()
        else result_root / "visual_report"
    )
    run(result_root, output_dir, max(1, int(args.top_points)))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("\n[运行失败]", f"{type(exc).__name__}: {exc}", file=sys.stderr)
        traceback.print_exc()
        sys.exit(1)
