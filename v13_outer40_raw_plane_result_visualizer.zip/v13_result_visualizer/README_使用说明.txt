V13 outer40 raw/plane 结果可视化程序
====================================

一、程序读取什么目录
--------------------
本程序读取 v13 一键运行后的“结果根目录”，目录应类似：

v13_AB_train_CD_test_outer40_results
├─ raw
│  ├─ train_AB
│  └─ test_CD
└─ plane
   ├─ train_AB
   └─ test_CD

不要把 --result-root 指向 raw、plane、train_AB 或 test_CD，
应当指向同时包含 raw 和 plane 的上一层目录。

二、安装依赖
------------
pip install numpy pandas matplotlib

三、运行方法
------------
1. 先测试程序本身：

python plot_v13_outer40_raw_plane_results.py --self-test

看到：
SELF-TEST PASSED
说明程序可以运行。

2. 正式绘图：

python plot_v13_outer40_raw_plane_results.py --result-root "D:\wurenji\v13_AB_train_CD_test_outer40_results"

默认输出到：
D:\wurenji\v13_AB_train_CD_test_outer40_results\visual_report

3. 自定义输出目录：

python plot_v13_outer40_raw_plane_results.py ^
  --result-root "D:\wurenji\v13_AB_train_CD_test_outer40_results" ^
  --output-dir "D:\wurenji\v13_visual_report"

四、最先看哪些文件
------------------
1. visual_report\V13结果图文报告.html
   双击即可打开，是最容易理解的图文总报告。

2. visual_report\tables\01_结果总览与中文判断.csv
   每行对应 raw/plane × C/D，程序已经自动给出中文判断。

3. visual_report\figures\01_raw_plane_score_AUC对比.png
   看TRUE是否整体排在FALSE前面。越接近1越好，0.5接近随机。

4. visual_report\figures\02_raw_plane平衡准确率对比.png
   看A+B训练阈值直接用于C、D后，分类是否正确。

5. visual_report\figures\11_方法_场景_TRUE_FALSE分数与阈值.png
   判断问题到底是“没有区分能力”，还是“有排序但阈值偏移”。

五、结果怎么理解
----------------
AUC高、平衡准确率也高：
  A+B学到的规律和阈值都能迁移到该测试场景，结果最好。

AUC高、平衡准确率低：
  TRUE通常仍高于FALSE，但整个场景分数发生平移，A+B阈值不适合该场景。
  这是“阈值偏移”，不能简单说模型完全没学到泄漏规律。

AUC接近0.5：
  TRUE和FALSE排序接近随机，说明A+B公共方向在该场景泛化不足。

AUC小于0.5：
  分数方向可能发生反转，应重点检查场景差异、残差方法或标签对应关系。

SUSPECT很多：
  很多样本落在FALSE阈值与TRUE阈值之间，模型证据不够明确。

频谱AUC高、空间AUC低：
  泄漏频谱较稳定，但空间传播结构容易受场景影响。

plane优于raw：
  外圈40点背景扣除对跨场景识别有帮助。

raw优于plane：
  当前空间背景扣除可能减掉部分泄漏成分，或外圈背景估计不够稳定。

六、外圈40点图怎么理解
----------------------
plane目录中的外圈点影响图：
  表示各点真实参与背景平面估计的影响程度。

raw目录中的外圈点影响图：
  仅用于空间质量检查，因为raw本身不减背景，外圈点权重不参与raw信号。

七、输出内容
------------
visual_report
├─ V13结果中文解读.txt
├─ V13结果图文报告.html
├─ visualization_manifest.json
├─ tables
│  ├─ 01_结果总览与中文判断.csv
│  ├─ 02_raw_plane逐样本对比.csv
│  └─ 03_外圈40点平均权重与影响汇总.csv
└─ figures
   ├─ AUC、平衡准确率、明确判定比例
   ├─ 频谱/时间/空间AUC
   ├─ A+B训练OOF分数
   ├─ C、D混淆矩阵
   ├─ TRUE/FALSE分数与阈值
   ├─ 逐样本分数排序
   ├─ 概率参考分布
   ├─ 公共泄漏频谱
   ├─ raw改为plane后的预测变化
   └─ 外圈40点影响Top图
