@echo off
chcp 65001 >nul
echo [1/3] 空间拟合与RAW/PLANE输出自检...
python v22_EFG_raw_plane_outer40.py --self-test
if errorlevel 1 goto fail
echo [2/3] E/F/G跨场景分类自检...
python v22_EFG_raw_vs_plane_evaluate.py --self-test
if errorlevel 1 goto fail
echo [3/3] 消声室距离和相似度自检...
python v22_EFG_vs_anechoic_similarity.py --self-test
if errorlevel 1 goto fail
echo.
echo 全部自检通过。
pause
exit /b 0
:fail
echo.
echo 自检失败。
pause
exit /b 1
