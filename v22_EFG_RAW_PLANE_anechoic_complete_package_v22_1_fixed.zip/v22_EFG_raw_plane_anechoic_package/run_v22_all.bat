@echo off
chcp 65001 >nul
echo [1/3] 提取E/F/G的RAW和PLANE...
python v22_EFG_raw_plane_outer40.py --config v22_EFG_raw_plane_anechoic_config.json
if errorlevel 1 goto fail
echo [2/3] 做EF-G、EG-F、FG-E公平分类比较...
python v22_EFG_raw_vs_plane_evaluate.py --config v22_EFG_raw_plane_anechoic_config.json
if errorlevel 1 goto fail
echo [3/3] 与消声室0.1mm、0.5mm、ALL_LEAKS比较距离和相似度...
python v22_EFG_vs_anechoic_similarity.py --config v22_EFG_raw_plane_anechoic_config.json
if errorlevel 1 goto fail
echo.
echo 全部完成。
pause
exit /b 0
:fail
echo.
echo 运行失败，请查看屏幕报错和输出目录中的99_errors.csv。
pause
exit /b 1
