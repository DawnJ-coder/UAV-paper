@echo off
chcp 65001 >nul
python v22_EFG_raw_vs_plane_evaluate.py --config v22_EFG_raw_plane_anechoic_config.json
pause
