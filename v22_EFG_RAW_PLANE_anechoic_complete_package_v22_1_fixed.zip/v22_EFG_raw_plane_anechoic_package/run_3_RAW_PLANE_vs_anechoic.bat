@echo off
chcp 65001 >nul
python v22_EFG_vs_anechoic_similarity.py --config v22_EFG_raw_plane_anechoic_config.json
pause
