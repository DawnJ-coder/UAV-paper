空间局部超额泄漏分离 v3.1：消声室跨孔径划分
=================================================

默认实验：
- 0.5 mm全部WAV：训练泄漏NMF字典
- 0.1 mm全部WAV：独立验证与工厂结果相似度评价
- 不再进行每组70%/30%划分

配置关键项：
"lab_split_mode": "cross_group",
"lab_train_groups": ["0.5mm"],
"lab_validation_groups": ["0.1mm"]

正向运行：
python spatial_local_excess_leak_separation_v3_1.py --config spatial_local_excess_config_v3_1.json

反向验证：
python spatial_local_excess_leak_separation_v3_1.py --config spatial_local_excess_config_v3_1_reverse.json

检查输出：
01_lab_train_validation_split.csv
- 0.5mm应全部为train
- 0.1mm应全部为validation

04_lab_split_summary.json
- split_mode应为cross_group
- train_groups应为["0.5mm"]
- validation_groups应为["0.1mm"]

注意：
0.1 mm验证数据不参与泄漏字典训练，但会作为工厂提取结果的外部泄漏参考。
正向和反向实验都有效，才更能说明泄漏特征具有跨孔径稳定性。
