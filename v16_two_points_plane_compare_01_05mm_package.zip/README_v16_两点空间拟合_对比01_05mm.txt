v16：每个文件夹两个点，空间拟合滤出泄漏，并与0.1 mm、0.5 mm比较
==========================================================================

一、这版程序解决什么问题
------------------------

对每个样本文件夹中的两个中心点分别处理。每个中心点必须有64个周围偏移点。
程序会：

1. 对中心点和64个周围点做完全相同的STFT；
2. 排除距离中心最近的24个点；
3. 使用最外圈40个点拟合二维空间背景平面；
4. 用中心功率减去拟合背景，保留正残差作为泄漏候选分量；
5. 分别与0.1 mm和0.5 mm目录中的全部真实泄漏WAV比较；
6. 输出组参考相似度、逐WAV相似度、两点判断结果；
7. 输出严格共同频带和候选共同频带；
8. 保存空间残差NPZ和近似泄漏WAV。


二、核心原理
------------

1. 时频功率

对每个空间点的WAV做STFT：

\(P_i(f,t)=|X_i(f,t)|^2\)

中心点和周围点使用相同的采样时间、窗长、步长和频率范围。

2. 空间背景平面

在每个时频单元上，用外圈40个点拟合：

\(B_i(f,t)=a(f,t)+b(f,t)x_i+c(f,t)y_i\)

中心坐标为\((0,0)\)，所以中心处的背景估计为：

\(\widehat B_c(f,t)=a(f,t)\)

程序使用鲁棒权重，降低异常周围点对拟合的影响。

3. 泄漏正残差

\(L(f,t)=\max[P_c(f,t)-\widehat B_c(f,t),0]\)

这里的\(L(f,t)\)就是后续用于泄漏特征和相似度计算的空间残差。

4. 频谱相似度

程序把20–80 kHz划分为默认500 Hz频带，对每个频带求残差功率，形成固定长度频谱。
综合相似度由三部分平均得到：

- 余弦相似度：比较整体频谱方向；
- 频谱重叠度：比较能量分布的重合程度；
- Pearson形状相似度：比较频谱起伏形状。

综合相似度范围为0到1，越接近1表示频谱形状越相似。
它不是“泄漏概率”，不能直接理解成百分之多少一定是泄漏。

5. 严格共同频带

某个频带被判为STRICT_COMMON，需要同时满足：

- 工厂空间残差在该频带是明显正特征；
- 实验室参考在该频带也是明显正特征；
- 实验室组中至少一定比例的WAV支持该频带；
- 各来源的归一化重合强度达到阈值；
- 连续频带宽度达到最小要求。

TOP_CANDIDATE只是共同程度最高的候选频带，不等于严格共同特征。


三、当前输入目录
----------------

配置示例已经写入：

中心点根目录：
D:\gas\beamform_results_gc_cs

周围点根目录：
D:\gas\beamform_results_offset_multiple_gc_cs_0001

两根目录下面的同名子文件夹会自动配对。

例如：

center_root_dir/
    0.2mm铜管泄漏_100kPa_690sccm_2.0m_null/
        xxx_00_00_beamform_result.wav
        xxx_00_01_beamform_result.wav

offset_root_dir/
    0.2mm铜管泄漏_100kPa_690sccm_2.0m_null/
        xxx_00_00d5_up.wav
        xxx_00_00d5_down.wav
        ...
        xxx_00_01d40_up_right.wav
        ...

每个center_id至少要匹配64个方向/距离组合。

配置中的time_folders为空列表时，程序自动处理两根目录共有的全部子文件夹。
也可以只填需要处理的文件夹名称。


四、必须修改的路径
------------------

打开：

v16_two_points_config_example.json

只需要先确认三处：

1. center_root_dir；
2. offset_root_dir；
3. lab_groups中的0.1mm和0.5mm实际目录。

0.1mm和0.5mm目录会递归读取所有子目录中的全部.wav文件。

当前配置中实验室路径是占位符：

D:\请修改为实际路径\0.1mm
D:\请修改为实际路径\0.5mm

必须改成真实路径后再正式运行。


五、时间片设置
--------------

当前配置：

"segment_mode": "first"

含义是：两个空间点都读取各自WAV的第一段1秒数据。
这适合“00_00和00_01表示两个空间点，而不是连续秒编号”的当前结构。

可选值：

- first：每个点都读取第一段；
- center_id：00_00读取第0秒，00_01读取第1秒；
- auto：文件足够长时按center_id秒编号，否则读取第一段。

如果00_00和00_01实际表示连续时间，而不是两个空间位置，需要改成auto或center_id。


六、运行方法
------------

安装依赖：

pip install numpy pandas scipy matplotlib

先运行自检：

python v16_two_points_plane_compare_01_05mm.py --self-test

正式运行：

python v16_two_points_plane_compare_01_05mm.py --config v16_two_points_config_example.json

也可以双击：

run_v16_two_points.bat


七、主要输出文件
----------------

00_run_info.json
    本次参数、实验室WAV数量、成功点数和错误数。

00_lab_reference_manifest.csv
    0.1mm和0.5mm各自读取了多少个WAV。

00_lab_01mm_reference.csv
00_lab_05mm_reference.csv
    两类实验室泄漏的稳健参考频谱。

01_point_similarity_by_lab_group.csv
    一行=一个工厂点×一个实验室组。
    直接查看每个点分别与0.1mm、0.5mm的综合相似度。

02_all_points_summary.csv
    每个工厂点一行，包含：
    - 空间拟合质量；
    - 残差强度；
    - 与0.1mm相似度；
    - 与0.5mm相似度；
    - 两类参考的平均相似度；
    - 残差NPZ、近似泄漏WAV和对比图路径。

03_folder_two_point_decision.csv
    每个文件夹两点比较结果。
    decision为center_id时，表示该点更接近两类实验室泄漏的整体频谱。
    decision为UNCERTAIN时，表示相似度过低、差距过小，或只有一个点成功。

04_lab_wav_similarity_each_file.csv
    一行=一个工厂点×一个实验室WAV。
    可查看到底与哪个具体0.1mm或0.5mm文件最相似。

05_common_frequency_bands.csv
    最重要的共同频带明细。
    scope含义：

    LAB_GROUPS_ONLY
        0.1mm与0.5mm实验室数据自身的共同频带。

    POINT_VS_LAB_GROUP
        单个工厂点与某一个实验室组的共同频带。

    POINT_VS_ALL_LAB_GROUPS
        单个工厂点与0.1mm、0.5mm三方共同频带。

    FOLDER_TWO_POINTS_VS_LAB_GROUP
        同一文件夹两个点与某一个实验室组共同支持的频带。

    FOLDER_TWO_POINTS_VS_ALL_LAB_GROUPS
        同一文件夹两个点、0.1mm、0.5mm四方共同支持的频带。
        这是最严格的“全部共同特征”。

    feature_type：
    - STRICT_COMMON：满足全部严格条件；
    - TOP_CANDIDATE：共同程度最高的候选，不代表严格成立。

06_common_frequency_bin_details.csv
    每个500Hz频带的原始形状值、支持率、共同强度和严格标记。

07_common_feature_summary.csv
    每个比较范围有多少个严格共同频带、总宽度，以及最强候选频带。
    建议先看这个文件，再去05_common_frequency_bands.csv看详细频段。

99_errors.csv
    处理失败的文件夹、中心点和具体原因。


八、每个点的子目录
------------------

每个成功中心点会保存：

*_plane_leak_residual.npz
    包含中心功率、plane背景、正残差、频谱指纹、空间坐标和点权重。

*_filtered_leak.wav
    根据中心相位和空间残差掩膜重建的近似泄漏波形。
    该WAV用于试听或辅助检查，不是数学意义上的完全纯净泄漏声。

*_vs_01_05mm.png
    工厂空间残差与0.1mm、0.5mm参考频谱对比图。


九、怎样判断结果
----------------

建议按以下顺序查看：

1. 先看99_errors.csv，确认没有路径、采样率、周围点数量错误；
2. 看02_all_points_summary.csv中的plane_geometry_ok是否为1；
3. 看01_point_similarity_by_lab_group.csv，分别检查0.1mm和0.5mm相似度；
4. 看03_folder_two_point_decision.csv，比较同一文件夹两个点；
5. 看07_common_feature_summary.csv中的严格共同频带数量；
6. 最后查看05_common_frequency_bands.csv中的具体频率范围。

不能只看AUC或单个最大相似度。相似度、空间拟合质量、两点差值和严格共同频带需要一起判断。
