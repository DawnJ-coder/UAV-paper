@echo off
chcp 65001 >nul
python v16_two_points_plane_compare_01_05mm.py --config v16_two_points_config_example.json
pause
