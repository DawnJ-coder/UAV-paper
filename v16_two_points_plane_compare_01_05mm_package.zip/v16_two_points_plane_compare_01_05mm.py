# -*- coding: utf-8 -*-
"""
v16_two_points_plane_compare_01_05mm.py

用途
----
每个样本文件夹中包含两个待判断的中心点，每个中心点对应64个周围偏移点。
程序执行：
1. 对两个中心点分别使用v9相同的outer40鲁棒空间平面拟合；
2. 排除最近24个点，只用最外圈40个点估计中心背景；
3. 计算中心功率减空间背景后的正残差，作为泄漏候选分量；
4. 分别读取0.1 mm与0.5 mm目录中的全部实验室真实泄漏WAV；
5. 输出每个点与两类实验室泄漏的组参考相似度和逐WAV相似度；
6. 输出点级、文件夹两点级，以及“两点+0.1 mm+0.5 mm”严格共同频带；
7. 保存空间残差NPZ、近似泄漏WAV和频谱对比图。

重要说明
--------
- 每个中心点至少需要64个周围点，才能执行“排除最近24点、使用外圈40点”。
- filtered_leak.wav是基于中心相位和空间残差掩膜重建的近似波形；
  真正用于相似度与共同特征判断的是plane空间残差频谱。
- 相似度只比较20-80 kHz内的频谱形状，不使用逐文件峰值归一化。

依赖
----
pip install numpy pandas scipy matplotlib

同目录依赖
----------
v9_ABCD_raw_plane_outer40.py

运行
----
python v16_two_points_plane_compare_01_05mm.py --self-test
python v16_two_points_plane_compare_01_05mm.py --config v16_two_points_config_example.json
"""

from __future__ import annotations

import argparse
import json
import math
import re
import sys
import traceback
import warnings
from dataclasses import asdict, dataclass, fields, replace
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd

try:
    import matplotlib.pyplot as plt
    from scipy import signal
    from scipy.io import wavfile
except Exception as exc:
    raise RuntimeError("缺少 scipy 或 matplotlib，请先运行: pip install scipy matplotlib") from exc

try:
    import v9_ABCD_raw_plane_outer40 as v9
except Exception as exc:
    raise RuntimeError(
        "无法导入 v9_ABCD_raw_plane_outer40.py；请把两个程序放在同一文件夹。"
    ) from exc


EPS = 1.0e-20


@dataclass(frozen=True)
class AppConfig:
    # 每个样本文件夹正常应有两个中心点。
    expected_points_per_folder: int = 2

    # 频谱指纹采用固定宽度频带，默认每500 Hz一个维度。
    fingerprint_bin_hz: float = 500.0

    # 两点综合相似度差低于该值时，不强行选择，输出UNCERTAIN。
    minimum_similarity_gap: float = 0.03

    # 最高综合相似度低于该值时，不强行选择。
    minimum_winner_similarity: float = 0.45

    # 实验室每个WAV最多分析多少秒；None表示全部。
    max_lab_seconds_per_file: Optional[float] = 30.0

    # 是否保存利用中心相位重建的近似泄漏WAV。
    save_filtered_wav: bool = True

    # 是否绘制每个点与0.1/0.5 mm参考的频谱对比图。
    save_plots: bool = True

    # first：每个点都读取第一段，适合“一个文件夹两个空间点”的当前结构。
    # auto：长WAV按center_id秒序号切片；单秒WAV读取第一段。
    # center_id：始终按center_id最后数字切片。
    segment_mode: str = "first"

    strict_two_points: bool = True

    # 共同频带判定：稳健频谱形状z值至少达到该阈值。
    common_shape_threshold: float = 0.50

    # 实验室组中至少多少比例的WAV在该频带达到阈值。
    minimum_lab_support_fraction: float = 0.50

    # 严格共同频带还要求各来源归一化正特征的最小重合强度。
    minimum_shared_strength_for_strict: float = 0.20

    # 严格共同频带的最小连续宽度。
    minimum_common_band_width_hz: float = 1000.0

    # 无严格公共频带或用于辅助排序时，额外输出多少个候选频带。
    top_candidate_band_count: int = 5

    # 候选窗口宽度；None时使用minimum_common_band_width_hz。
    candidate_band_width_hz: Optional[float] = None

@dataclass(frozen=True)
class LabFingerprint:
    group_name: str
    files: Tuple[str, ...]
    failed_files: Tuple[str, ...]
    bin_centers_hz: np.ndarray
    probability_reference: np.ndarray
    shape_reference: np.ndarray
    individual_probabilities: np.ndarray
    individual_shapes: np.ndarray

def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def safe_slug(value: Any, max_len: int = 160) -> str:
    text = str(value).strip() or "sample"
    text = re.sub(r"[^0-9A-Za-z_\-.]+", "_", text)
    return text.strip("._")[:max_len] or "sample"


def group_column_tag(value: Any) -> str:
    text = str(value).strip().lower()
    text = text.replace("0.1", "01").replace("0.5", "05")
    text = re.sub(r"[^0-9a-z]+", "_", text)
    return text.strip("_") or "lab"


def dataclass_from_dict(cls: Any, values: Dict[str, Any]) -> Any:
    valid = {item.name for item in fields(cls)}
    unknown = sorted(set(values) - valid)
    if unknown:
        raise ValueError(f"{cls.__name__} 中存在未知配置项: {unknown}")
    return cls(**values)


def read_wav_float(path: Path) -> Tuple[int, np.ndarray]:
    fs, raw = wavfile.read(str(path))
    original_dtype = raw.dtype
    if raw.ndim > 1:
        x = np.mean(raw.astype(np.float64), axis=1)
    else:
        x = raw.astype(np.float64, copy=False)
    if np.issubdtype(original_dtype, np.integer):
        info = np.iinfo(original_dtype)
        scale = float(max(abs(info.min), abs(info.max)))
        x = x / max(scale, 1.0)
    finite = np.isfinite(x)
    if not np.any(finite):
        raise ValueError(f"WAV全部无效: {path}")
    fill = float(np.median(x[finite]))
    x = np.where(finite, x, fill)
    x = x - float(np.mean(x))
    return int(fs), x.astype(np.float64, copy=False)


def wav_duration(path: Path) -> Tuple[int, float]:
    fs, raw = wavfile.read(str(path), mmap=True)
    n = int(raw.shape[0]) if raw.ndim >= 1 else 0
    return int(fs), n / float(fs)


def center_id_second_index(center_id: str) -> int:
    token = str(center_id).split("_")[-1]
    if token.isdigit():
        return int(token)
    return 0


def resolve_segment(
    center_path: Path,
    center_id: str,
    app: AppConfig,
    v9_config: v9.V9Config,
) -> Tuple[int, float, float, str]:
    second_index = center_id_second_index(center_id)
    duration_fs, duration = wav_duration(center_path)
    del duration_fs
    length = float(v9_config.time_slice_seconds)
    requested_start = second_index * length
    requested_end = requested_start + length

    mode = app.segment_mode.lower().strip()
    if mode not in {"auto", "center_id", "first"}:
        raise ValueError(f"segment_mode必须是auto/center_id/first，当前={app.segment_mode}")

    if mode == "first":
        start, end, used_mode = 0.0, length, "FIRST_SECOND"
    elif mode == "center_id":
        start, end, used_mode = requested_start, requested_end, "CENTER_ID_SECOND"
    else:
        if duration + 1e-9 >= requested_end:
            start, end, used_mode = requested_start, requested_end, "AUTO_CENTER_ID_SECOND"
        elif duration + 1e-9 >= length:
            start, end, used_mode = 0.0, length, "AUTO_FIRST_SECOND"
        else:
            raise ValueError(
                f"{center_path.name}时长仅{duration:.6f}秒，不足一个{length:g}秒片段"
            )

    if duration + 1e-9 < end:
        raise ValueError(
            f"{center_path.name}时长{duration:.6f}秒，无法读取[{start:.3f},{end:.3f})秒"
        )
    return second_index, float(start), float(end), used_mode


def load_one_center_cube_explicit_segment(
    center_paths: Sequence[Path],
    offset_mapping: Dict[Tuple[str, str, float], List[Path]],
    center_id: str,
    config: v9.V9Config,
    segment_start_second: float,
    segment_end_second: float,
    second_index: int,
) -> Dict[str, Any]:
    if not center_paths:
        raise ValueError(f"center={center_id}没有中心WAV")

    center_result = v9.average_duplicate_wavs(
        center_paths,
        config,
        segment_start_second,
        segment_end_second,
    )

    offset_items: List[Tuple[str, float, List[Path]]] = []
    for (cid, direction, distance), paths in offset_mapping.items():
        if cid == center_id and direction in v9.DIRECTION_ANGLES:
            offset_items.append((direction, float(distance), paths))
    offset_items.sort(key=lambda item: (item[1], item[0]))

    required = int(config.inner_excluded_points + config.outer_background_points)
    if len(offset_items) < required:
        raise ValueError(
            f"center={center_id}只发现{len(offset_items)}个周围点；"
            f"当前outer40规则要求至少{required}个"
        )

    point_results: List[Dict[str, Any]] = [center_result]
    xy: List[Tuple[float, float]] = [(0.0, 0.0)]
    point_ids: List[str] = [f"center_{center_id}"]
    failed_offsets: List[Dict[str, str]] = []

    for direction, distance, paths in offset_items:
        try:
            result = v9.average_duplicate_wavs(
                paths,
                config,
                segment_start_second,
                segment_end_second,
            )
            if int(result["fs"]) != int(center_result["fs"]):
                raise ValueError("采样率与中心点不一致")
            if result["freq_hz"].shape != center_result["freq_hz"].shape:
                raise ValueError("频率轴长度与中心点不一致")
            if not np.allclose(result["freq_hz"], center_result["freq_hz"]):
                raise ValueError("频率轴与中心点不一致")
            point_results.append(result)
            xy.append(v9.coordinate_from_direction(direction, distance))
            point_ids.append(f"{distance:g}cm_{direction}")
        except Exception as exc:
            failed_offsets.append({
                "point": f"{distance:g}cm_{direction}",
                "error": f"{type(exc).__name__}: {exc}",
            })

    if len(point_results) - 1 < required:
        raise ValueError(
            f"center={center_id}成功读取的周围点只有{len(point_results)-1}个；"
            f"outer40规则要求至少{required}个"
        )

    n_frames = min(item["power"].shape[1] for item in point_results)
    power_cube = np.stack(
        [item["power"][:, :n_frames] for item in point_results], axis=0
    )
    peaks = np.asarray([item["quality"]["peak_abs"] for item in point_results], dtype=float)
    rms_values = np.asarray([item["quality"]["rms"] for item in point_results], dtype=float)

    return {
        "power": power_cube,
        "freq_hz": center_result["freq_hz"],
        "time_s": center_result["time_s"][:n_frames],
        "xy": np.asarray(xy, dtype=float),
        "point_ids": np.asarray(point_ids, dtype=str),
        "center_index": 0,
        "fs": int(center_result["fs"]),
        "peak_abs": peaks,
        "rms": rms_values,
        "failed_offsets": failed_offsets,
        "n_offset_discovered": int(len(offset_items)),
        "second_index": int(second_index),
        "segment_start_second": float(segment_start_second),
        "segment_end_second": float(segment_end_second),
    }


def make_bin_edges(config: v9.V9Config, app: AppConfig) -> np.ndarray:
    width = float(app.fingerprint_bin_hz)
    if width <= 0:
        raise ValueError("fingerprint_bin_hz必须大于0")
    low = float(config.freq_low_hz)
    high = float(config.freq_high_hz)
    edges = np.arange(low, high + width, width, dtype=float)
    if edges[-1] < high:
        edges = np.append(edges, high)
    else:
        edges[-1] = high
    if len(edges) < 3:
        raise ValueError("频谱指纹频带数量太少")
    return edges


def spectrum_to_bins(
    freq_hz: np.ndarray,
    power_spectrum: np.ndarray,
    edges_hz: np.ndarray,
) -> np.ndarray:
    freq = np.asarray(freq_hz, dtype=float).ravel()
    power = np.maximum(np.asarray(power_spectrum, dtype=float).ravel(), 0.0)
    if len(freq) != len(power):
        raise ValueError("频率轴与功率谱长度不一致")
    result = np.zeros(len(edges_hz) - 1, dtype=float)
    for index in range(len(result)):
        left, right = edges_hz[index], edges_hz[index + 1]
        if index == len(result) - 1:
            mask = (freq >= left) & (freq <= right)
        else:
            mask = (freq >= left) & (freq < right)
        if np.any(mask):
            result[index] = float(np.mean(power[mask]))
    return np.maximum(result, 0.0)


def robust_shape(vector: np.ndarray) -> np.ndarray:
    value = np.log10(np.maximum(np.asarray(vector, dtype=float), EPS))
    median = float(np.median(value))
    mad = float(np.median(np.abs(value - median)))
    scale = max(1.4826 * mad, 1.0e-6)
    return np.clip((value - median) / scale, -8.0, 8.0)


def probability_vector(vector: np.ndarray) -> np.ndarray:
    value = np.maximum(np.asarray(vector, dtype=float), 0.0)
    total = float(np.sum(value))
    if not np.isfinite(total) or total <= EPS:
        return np.full(len(value), 1.0 / max(len(value), 1), dtype=float)
    return value / total


def calculate_similarity(
    probability: np.ndarray,
    shape: np.ndarray,
    reference_probability: np.ndarray,
    reference_shape: np.ndarray,
) -> Dict[str, float]:
    p = np.asarray(probability, dtype=float)
    q = np.asarray(reference_probability, dtype=float)
    s = np.asarray(shape, dtype=float)
    r = np.asarray(reference_shape, dtype=float)

    denom = float(np.linalg.norm(p) * np.linalg.norm(q))
    cosine = float(np.dot(p, q) / denom) if denom > EPS else 0.0
    overlap = float(np.sum(np.minimum(p, q)))

    if np.std(s) <= 1.0e-12 or np.std(r) <= 1.0e-12:
        pearson = 0.0
    else:
        pearson = float(np.corrcoef(s, r)[0, 1])
        if not np.isfinite(pearson):
            pearson = 0.0

    pearson_01 = 0.5 * (pearson + 1.0)
    combined = float(np.mean([
        np.clip(cosine, 0.0, 1.0),
        np.clip(overlap, 0.0, 1.0),
        np.clip(pearson_01, 0.0, 1.0),
    ]))
    return {
        "cosine_similarity": float(np.clip(cosine, -1.0, 1.0)),
        "spectral_overlap": float(np.clip(overlap, 0.0, 1.0)),
        "pearson_similarity": float(np.clip(pearson, -1.0, 1.0)),
        "combined_similarity": float(np.clip(combined, 0.0, 1.0)),
    }


def wav_power_spectrum(
    path: Path,
    config: v9.V9Config,
    max_seconds: Optional[float],
) -> Tuple[np.ndarray, np.ndarray]:
    fs, x = read_wav_float(path)
    if max_seconds is not None:
        max_samples = int(round(float(max_seconds) * fs))
        if max_samples > 0:
            x = x[:max_samples]
    if len(x) < 256:
        raise ValueError(f"WAV太短: {path}")

    nperseg = min(int(config.nperseg), len(x))
    hop = min(int(config.hop_length), nperseg)
    noverlap = max(0, nperseg - hop)
    nfft = max(int(config.nfft), nperseg)
    freq_hz, _, z = signal.stft(
        x,
        fs=fs,
        window="hann",
        nperseg=nperseg,
        noverlap=noverlap,
        nfft=nfft,
        detrend=False,
        return_onesided=True,
        boundary=None,
        padded=False,
    )
    mask = (freq_hz >= config.freq_low_hz) & (freq_hz <= config.freq_high_hz)
    if int(np.sum(mask)) < config.min_frequency_bins:
        raise ValueError(
            f"{path.name}在{config.freq_low_hz:g}-{config.freq_high_hz:g}Hz频点不足"
        )
    power = np.mean(np.abs(z[mask]) ** 2, axis=1)
    return freq_hz[mask].astype(float), np.maximum(power, EPS)


def build_lab_fingerprint(
    group_name: str,
    roots: Sequence[Path],
    config: v9.V9Config,
    app: AppConfig,
) -> LabFingerprint:
    files: List[Path] = []
    for root in roots:
        root = Path(root)
        if root.is_file() and root.suffix.lower() == ".wav":
            files.append(root)
        elif root.exists():
            files.extend(path for path in root.rglob("*.wav") if path.is_file())
    files = sorted({path.resolve() for path in files}, key=lambda p: str(p).lower())
    if not files:
        raise FileNotFoundError(
            f"实验室组{group_name}没有找到WAV，检查路径: {[str(p) for p in roots]}"
        )

    edges = make_bin_edges(config, app)
    probabilities: List[np.ndarray] = []
    shapes: List[np.ndarray] = []
    used_files: List[str] = []
    errors: List[str] = []

    for wav_path in files:
        try:
            freq, spectrum = wav_power_spectrum(
                wav_path,
                config,
                app.max_lab_seconds_per_file,
            )
            bands = spectrum_to_bins(freq, spectrum, edges)
            probabilities.append(probability_vector(bands))
            shapes.append(robust_shape(bands))
            used_files.append(str(wav_path))
        except Exception as exc:
            errors.append(f"{wav_path}: {type(exc).__name__}: {exc}")

    if not probabilities:
        raise RuntimeError(
            f"实验室组{group_name}中的WAV全部处理失败。\n" + "\n".join(errors[:20])
        )

    probability_matrix = np.stack(probabilities, axis=0)
    shape_matrix = np.stack(shapes, axis=0)
    probability_reference = probability_vector(np.median(probability_matrix, axis=0))
    shape_reference = np.median(shape_matrix, axis=0)
    centers = 0.5 * (edges[:-1] + edges[1:])

    return LabFingerprint(
        group_name=str(group_name),
        files=tuple(used_files),
        failed_files=tuple(errors),
        bin_centers_hz=centers,
        probability_reference=probability_reference,
        shape_reference=shape_reference,
        individual_probabilities=probability_matrix,
        individual_shapes=shape_matrix,
    )

def compare_to_lab(
    factory_bands: np.ndarray,
    lab: LabFingerprint,
) -> Tuple[Dict[str, float], List[Dict[str, Any]]]:
    probability = probability_vector(factory_bands)
    shape = robust_shape(factory_bands)
    main = calculate_similarity(
        probability,
        shape,
        lab.probability_reference,
        lab.shape_reference,
    )

    individual_rows: List[Dict[str, Any]] = []
    individual_scores: List[float] = []
    for index, (file_name, probability_ref, shape_ref) in enumerate(zip(
        lab.files,
        lab.individual_probabilities,
        lab.individual_shapes,
    ), start=1):
        score = calculate_similarity(probability, shape, probability_ref, shape_ref)
        individual_scores.append(score["combined_similarity"])
        individual_rows.append({
            "lab_group": lab.group_name,
            "lab_wav_index": int(index),
            "lab_wav_name": Path(file_name).name,
            "lab_wav_file": file_name,
            **score,
        })

    main.update({
        "lab_wav_count": int(len(individual_scores)),
        "lab_individual_similarity_median": float(np.median(individual_scores)),
        "lab_individual_similarity_max": float(np.max(individual_scores)),
        "lab_individual_similarity_min": float(np.min(individual_scores)),
    })
    return main, individual_rows

def save_lab_reference_csv(lab: LabFingerprint, output_dir: Path) -> Path:
    tag = group_column_tag(lab.group_name)
    path = output_dir / f"00_lab_{tag}_reference.csv"
    support = np.mean(
        lab.individual_shapes >= 0.0,
        axis=0,
    )
    pd.DataFrame({
        "lab_group": lab.group_name,
        "frequency_hz": lab.bin_centers_hz,
        "frequency_khz": lab.bin_centers_hz / 1000.0,
        "reference_probability": lab.probability_reference,
        "reference_robust_shape": lab.shape_reference,
        "positive_shape_support_fraction": support,
    }).to_csv(path, index=False, encoding="utf-8-sig")
    return path

def save_filtered_waveform(
    center_path: Path,
    component_power: np.ndarray,
    config: v9.V9Config,
    segment_start_second: float,
    segment_end_second: float,
    output_path: Path,
) -> None:
    fs, x = read_wav_float(center_path)
    start = int(round(segment_start_second * fs))
    end = int(round(segment_end_second * fs))
    if start < 0 or end > len(x) or end <= start:
        raise ValueError("中心WAV重建时间片越界")
    x_segment = x[start:end]

    nperseg = min(int(config.nperseg), len(x_segment))
    hop = min(int(config.hop_length), nperseg)
    noverlap = max(0, nperseg - hop)
    nfft = max(int(config.nfft), nperseg)
    freq_hz, _, z = signal.stft(
        x_segment,
        fs=fs,
        window="hann",
        nperseg=nperseg,
        noverlap=noverlap,
        nfft=nfft,
        detrend=False,
        return_onesided=True,
        boundary=None,
        padded=False,
    )
    band_mask = (freq_hz >= config.freq_low_hz) & (freq_hz <= config.freq_high_hz)
    band_indices = np.flatnonzero(band_mask)
    n_frames = min(z.shape[1], component_power.shape[1])
    n_freq = min(len(band_indices), component_power.shape[0])
    if n_frames <= 0 or n_freq <= 0:
        raise ValueError("无法构造泄漏重建掩膜")

    z_output = np.zeros_like(z)
    selected_indices = band_indices[:n_freq]
    center_power = np.abs(z[selected_indices, :n_frames]) ** 2
    component = np.maximum(component_power[:n_freq, :n_frames], 0.0)
    amplitude_mask = np.sqrt(
        np.clip(component / np.maximum(center_power, EPS), 0.0, 1.0)
    )
    z_output[selected_indices, :n_frames] = z[selected_indices, :n_frames] * amplitude_mask

    _, reconstructed = signal.istft(
        z_output,
        fs=fs,
        window="hann",
        nperseg=nperseg,
        noverlap=noverlap,
        nfft=nfft,
        input_onesided=True,
        boundary=False,
    )
    target_length = len(x_segment)
    if len(reconstructed) < target_length:
        reconstructed = np.pad(reconstructed, (0, target_length - len(reconstructed)))
    else:
        reconstructed = reconstructed[:target_length]
    reconstructed = np.nan_to_num(reconstructed, nan=0.0, posinf=0.0, neginf=0.0)
    ensure_dir(output_path.parent)
    wavfile.write(str(output_path), fs, reconstructed.astype(np.float32))


def save_comparison_plot(
    bin_centers_hz: np.ndarray,
    point_probability: np.ndarray,
    labs: Dict[str, LabFingerprint],
    title: str,
    output_path: Path,
) -> None:
    ensure_dir(output_path.parent)
    plt.figure(figsize=(12, 5.8))
    plt.plot(
        bin_centers_hz / 1000.0,
        point_probability,
        linewidth=2.0,
        label="空间拟合后泄漏残差",
    )
    for group_name, lab in labs.items():
        plt.plot(
            bin_centers_hz / 1000.0,
            lab.probability_reference,
            label=f"{group_name}实验室参考",
        )
    plt.xlabel("频率 (kHz)")
    plt.ylabel("归一化频谱权重")
    plt.title(title)
    plt.grid(alpha=0.25)
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_path, dpi=160)
    plt.close()

def unit_positive_shape(shape: np.ndarray) -> np.ndarray:
    value = np.maximum(np.asarray(shape, dtype=float), 0.0)
    maximum = float(np.max(value)) if value.size else 0.0
    if maximum <= 1.0e-12:
        return np.zeros_like(value)
    return value / maximum


def merge_boolean_bands(
    mask: np.ndarray,
    centers_hz: np.ndarray,
    strength: np.ndarray,
    minimum_width_hz: float,
) -> List[Dict[str, float]]:
    mask = np.asarray(mask, dtype=bool).ravel()
    centers = np.asarray(centers_hz, dtype=float).ravel()
    strength = np.asarray(strength, dtype=float).ravel()
    if not (len(mask) == len(centers) == len(strength)):
        raise ValueError("共同频带数组长度不一致")
    if len(centers) < 2:
        return []
    bin_width = float(np.median(np.diff(centers)))
    minimum_bins = max(1, int(math.ceil(float(minimum_width_hz) / bin_width)))
    padded = np.concatenate([[False], mask, [False]]).astype(np.int8)
    changes = np.diff(padded)
    starts = np.flatnonzero(changes == 1)
    ends = np.flatnonzero(changes == -1)
    rows: List[Dict[str, float]] = []
    for start, end in zip(starts, ends):
        if end - start < minimum_bins:
            continue
        local = strength[start:end]
        weights = np.maximum(local, 0.0)
        if float(np.sum(weights)) > 0:
            center = float(np.average(centers[start:end], weights=weights))
        else:
            center = float(np.mean(centers[start:end]))
        rows.append({
            "start_hz": float(centers[start] - 0.5 * bin_width),
            "end_hz": float(centers[end - 1] + 0.5 * bin_width),
            "center_hz": center,
            "width_hz": float((end - start) * bin_width),
            "mean_shared_strength": float(np.mean(local)),
            "max_shared_strength": float(np.max(local)),
            "start_bin": int(start),
            "end_bin_exclusive": int(end),
        })
    rows.sort(key=lambda row: row["mean_shared_strength"], reverse=True)
    return rows


def top_candidate_windows(
    strength: np.ndarray,
    centers_hz: np.ndarray,
    width_hz: float,
    count: int,
) -> List[Dict[str, float]]:
    strength = np.maximum(np.asarray(strength, dtype=float).ravel(), 0.0)
    centers = np.asarray(centers_hz, dtype=float).ravel()
    if len(centers) < 2 or len(strength) != len(centers) or count <= 0:
        return []
    bin_width = float(np.median(np.diff(centers)))
    window_bins = max(1, int(math.ceil(float(width_hz) / bin_width)))
    window_bins = min(window_bins, len(strength))
    scores = np.convolve(strength, np.ones(window_bins) / window_bins, mode="valid")
    order = np.argsort(scores)[::-1]
    selected: List[Tuple[int, int]] = []
    rows: List[Dict[str, float]] = []
    for start in order:
        start = int(start)
        end = start + window_bins
        if any(not (end <= old_start or start >= old_end) for old_start, old_end in selected):
            continue
        local = strength[start:end]
        weights = np.maximum(local, 0.0)
        center = (
            float(np.average(centers[start:end], weights=weights))
            if float(np.sum(weights)) > 0
            else float(np.mean(centers[start:end]))
        )
        rows.append({
            "start_hz": float(centers[start] - 0.5 * bin_width),
            "end_hz": float(centers[end - 1] + 0.5 * bin_width),
            "center_hz": center,
            "width_hz": float(window_bins * bin_width),
            "mean_shared_strength": float(np.mean(local)),
            "max_shared_strength": float(np.max(local)),
            "start_bin": int(start),
            "end_bin_exclusive": int(end),
        })
        selected.append((start, end))
        if len(rows) >= int(count):
            break
    return rows


def common_feature_profile(
    source_shapes: Dict[str, np.ndarray],
    lab_supports: Dict[str, np.ndarray],
    app: AppConfig,
) -> Tuple[np.ndarray, np.ndarray, Dict[str, np.ndarray]]:
    if not source_shapes:
        raise ValueError("共同特征至少需要一个来源")
    normalized: Dict[str, np.ndarray] = {
        name: unit_positive_shape(shape) for name, shape in source_shapes.items()
    }
    lengths = {len(value) for value in normalized.values()}
    if len(lengths) != 1:
        raise ValueError("共同特征各来源频谱长度不一致")
    shared_strength = np.minimum.reduce(list(normalized.values()))
    strict_mask = np.ones(next(iter(lengths)), dtype=bool)
    for name, shape in source_shapes.items():
        strict_mask &= np.asarray(shape, dtype=float) >= float(app.common_shape_threshold)
    for name, support in lab_supports.items():
        strict_mask &= np.asarray(support, dtype=float) >= float(app.minimum_lab_support_fraction)
    strict_mask &= shared_strength >= float(app.minimum_shared_strength_for_strict)
    return strict_mask, shared_strength, normalized


def make_common_feature_outputs(
    metadata: Dict[str, Any],
    centers_hz: np.ndarray,
    source_shapes: Dict[str, np.ndarray],
    lab_supports: Dict[str, np.ndarray],
    app: AppConfig,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    strict_mask, strength, normalized = common_feature_profile(
        source_shapes, lab_supports, app
    )
    strict_bands = merge_boolean_bands(
        strict_mask,
        centers_hz,
        strength,
        app.minimum_common_band_width_hz,
    )
    candidate_width = (
        app.candidate_band_width_hz
        if app.candidate_band_width_hz is not None
        else app.minimum_common_band_width_hz
    )
    candidates = top_candidate_windows(
        strength,
        centers_hz,
        candidate_width,
        app.top_candidate_band_count,
    )

    band_rows: List[Dict[str, Any]] = []
    for feature_type, rows in (("STRICT_COMMON", strict_bands), ("TOP_CANDIDATE", candidates)):
        for rank, row in enumerate(rows, start=1):
            start = int(row["start_bin"])
            end = int(row["end_bin_exclusive"])
            output = {
                **metadata,
                "feature_type": feature_type,
                "band_rank": int(rank),
                "start_hz": row["start_hz"],
                "end_hz": row["end_hz"],
                "start_khz": row["start_hz"] / 1000.0,
                "end_khz": row["end_hz"] / 1000.0,
                "center_hz": row["center_hz"],
                "center_khz": row["center_hz"] / 1000.0,
                "width_hz": row["width_hz"],
                "mean_shared_strength": row["mean_shared_strength"],
                "max_shared_strength": row["max_shared_strength"],
                "strict_bin_fraction_in_band": float(np.mean(strict_mask[start:end])),
                "source_names": "|".join(source_shapes),
                "shape_threshold": float(app.common_shape_threshold),
                "minimum_lab_support_fraction": float(app.minimum_lab_support_fraction),
                "minimum_shared_strength_for_strict": float(app.minimum_shared_strength_for_strict),
            }
            for name, shape in source_shapes.items():
                output[f"mean_shape__{group_column_tag(name)}"] = float(
                    np.mean(np.asarray(shape)[start:end])
                )
            for name, support in lab_supports.items():
                output[f"mean_support__{group_column_tag(name)}"] = float(
                    np.mean(np.asarray(support)[start:end])
                )
            band_rows.append(output)

    bin_rows: List[Dict[str, Any]] = []
    for index, frequency in enumerate(np.asarray(centers_hz, dtype=float)):
        row: Dict[str, Any] = {
            **metadata,
            "frequency_hz": float(frequency),
            "frequency_khz": float(frequency / 1000.0),
            "strict_common": int(strict_mask[index]),
            "shared_strength": float(strength[index]),
        }
        for name, shape in source_shapes.items():
            tag = group_column_tag(name)
            row[f"shape__{tag}"] = float(np.asarray(shape)[index])
            row[f"positive_normalized__{tag}"] = float(normalized[name][index])
        for name, support in lab_supports.items():
            row[f"support__{group_column_tag(name)}"] = float(np.asarray(support)[index])
        bin_rows.append(row)
    return band_rows, bin_rows


def dataset_folders(dataset: Dict[str, Any]) -> List[Tuple[str, Path, Path]]:
    name = str(dataset.get("name", "dataset"))

    if dataset.get("center_root_dir") and dataset.get("offset_root_dir"):
        center_root = Path(str(dataset["center_root_dir"]))
        offset_root = Path(str(dataset["offset_root_dir"]))
        configured = [str(item) for item in dataset.get("time_folders", [])]
        folder_names = configured or v9.common_time_folders(center_root, offset_root)
        return [
            (folder, center_root / folder, offset_root / folder)
            for folder in folder_names
        ]

    if dataset.get("folder_root_dir"):
        root = Path(str(dataset["folder_root_dir"]))
        center_subdir = str(dataset.get("center_subdir_name", "beamform_results"))
        offset_subdir = str(
            dataset.get("offset_subdir_name", "beamform_results_offset_multiple")
        )
        configured = [str(item) for item in dataset.get("folders", [])]
        folder_paths = [root / item for item in configured] if configured else [
            path for path in sorted(root.iterdir()) if path.is_dir()
        ]
        result: List[Tuple[str, Path, Path]] = []
        for folder in folder_paths:
            center_dir = folder / center_subdir
            offset_dir = folder / offset_subdir
            if not center_dir.exists():
                center_dir = folder
            if not offset_dir.exists():
                offset_dir = folder
            result.append((folder.name, center_dir, offset_dir))
        return result

    raise ValueError(
        f"数据集{name}缺少路径。请配置center_root_dir+offset_root_dir，"
        "或配置folder_root_dir。"
    )


def process_one_point(
    dataset_name: str,
    folder_name: str,
    center_id: str,
    center_paths: Sequence[Path],
    offset_mapping: Dict[Tuple[str, str, float], List[Path]],
    output_dir: Path,
    v9_config: v9.V9Config,
    app: AppConfig,
    labs: Dict[str, LabFingerprint],
) -> Dict[str, Any]:
    second_index, start, end, segment_used = resolve_segment(
        center_paths[0], center_id, app, v9_config
    )
    sample = load_one_center_cube_explicit_segment(
        center_paths,
        offset_mapping,
        center_id,
        v9_config,
        start,
        end,
        second_index,
    )
    extracted = v9.extract_features_from_cube(sample, v9_config)
    features = dict(extracted["features"])
    diagnostics = extracted["diagnostics"]

    component_power = np.asarray(
        diagnostics["products"]["plane"]["component_power"], dtype=float
    )
    component_spectrum = np.mean(component_power, axis=1)
    edges = make_bin_edges(v9_config, app)
    bands = spectrum_to_bins(
        np.asarray(diagnostics["freq_hz"], dtype=float),
        component_spectrum,
        edges,
    )
    probability = probability_vector(bands)
    shape = robust_shape(bands)

    sample_id = safe_slug(f"{dataset_name}__{folder_name}__point_{center_id}")
    point_dir = output_dir / safe_slug(dataset_name) / safe_slug(folder_name) / safe_slug(center_id)
    ensure_dir(point_dir)

    group_summary_rows: List[Dict[str, Any]] = []
    individual_wav_rows: List[Dict[str, Any]] = []
    group_similarity_values: List[float] = []
    dynamic_similarity_fields: Dict[str, Any] = {}

    for group_name, lab in labs.items():
        summary, wav_rows = compare_to_lab(bands, lab)
        tag = group_column_tag(group_name)
        group_similarity_values.append(float(summary["combined_similarity"]))
        for metric_name, metric_value in summary.items():
            dynamic_similarity_fields[f"{metric_name}__{tag}"] = metric_value
        group_summary_rows.append({
            "sample_id": sample_id,
            "dataset": dataset_name,
            "folder": folder_name,
            "center_id": center_id,
            "lab_group": group_name,
            **summary,
        })
        for wav_row in wav_rows:
            individual_wav_rows.append({
                "sample_id": sample_id,
                "dataset": dataset_name,
                "folder": folder_name,
                "center_id": center_id,
                **wav_row,
            })

    mean_similarity = float(np.mean(group_similarity_values)) if group_similarity_values else np.nan
    min_similarity = float(np.min(group_similarity_values)) if group_similarity_values else np.nan
    max_similarity = float(np.max(group_similarity_values)) if group_similarity_values else np.nan
    best_group = ""
    if group_summary_rows:
        best_row = max(group_summary_rows, key=lambda row: float(row["combined_similarity"]))
        best_group = str(best_row["lab_group"])

    npz_payload: Dict[str, Any] = {
        "sample_id": np.asarray(sample_id),
        "dataset": np.asarray(dataset_name),
        "folder": np.asarray(folder_name),
        "center_id": np.asarray(center_id),
        "freq_hz": np.asarray(diagnostics["freq_hz"], dtype=float),
        "time_s": np.asarray(diagnostics["time_s"], dtype=float),
        "center_power": np.asarray(diagnostics["center_power"], dtype=float),
        "background_power": np.asarray(
            diagnostics["products"]["plane"]["background_power"], dtype=float
        ),
        "plane_component_power": component_power,
        "residual_db": np.asarray(
            diagnostics["products"]["plane"]["residual_db"], dtype=float
        ),
        "fingerprint_frequency_hz": next(iter(labs.values())).bin_centers_hz,
        "fingerprint_bands_power": bands,
        "fingerprint_probability": probability,
        "fingerprint_robust_shape": shape,
        "xy": np.asarray(diagnostics["xy"], dtype=float),
        "point_ids": np.asarray(diagnostics["point_ids"], dtype="U"),
        "point_roles": np.asarray(diagnostics["point_roles"], dtype="U"),
        "point_weights": np.asarray(
            diagnostics["all_point_weights_normalized"], dtype=float
        ),
    }
    for group_name, lab in labs.items():
        tag = group_column_tag(group_name)
        npz_payload[f"lab_reference_probability__{tag}"] = lab.probability_reference
        npz_payload[f"lab_reference_shape__{tag}"] = lab.shape_reference
    npz_path = point_dir / f"{sample_id}_plane_leak_residual.npz"
    np.savez_compressed(npz_path, **npz_payload)

    filtered_wav_path = ""
    filtered_wav_error = ""
    if app.save_filtered_wav:
        try:
            wav_path = point_dir / f"{sample_id}_filtered_leak.wav"
            save_filtered_waveform(
                center_paths[0],
                component_power,
                v9_config,
                start,
                end,
                wav_path,
            )
            filtered_wav_path = str(wav_path)
        except Exception as exc:
            filtered_wav_error = f"{type(exc).__name__}: {exc}"

    plot_path = ""
    if app.save_plots:
        plot_file = point_dir / f"{sample_id}_vs_01_05mm.png"
        save_comparison_plot(
            next(iter(labs.values())).bin_centers_hz,
            probability,
            labs,
            f"{dataset_name} / {folder_name} / 点 {center_id}",
            plot_file,
        )
        plot_path = str(plot_file)

    result: Dict[str, Any] = {
        "sample_id": sample_id,
        "dataset": dataset_name,
        "folder": folder_name,
        "center_id": center_id,
        "n_center_files": int(len(center_paths)),
        "n_offset_discovered": int(sample["n_offset_discovered"]),
        "n_offset_success": int(len(sample["xy"]) - 1),
        "segment_mode_used": segment_used,
        "segment_start_second": start,
        "segment_end_second": end,
        "plane_valid": int(features.get("plane_valid", 0)),
        "plane_geometry_ok": int(features.get("plane_geometry_ok", 0)),
        "plane_reject_reason": str(features.get("plane_reject_reason", "")),
        "plane_component_total_power": float(
            features.get("plane_component_total_power", np.sum(component_power))
        ),
        "plane_component_fraction_of_center": float(
            features.get("plane_component_fraction_of_center", np.nan)
        ),
        "plane_integrated_snr_db": float(
            features.get("plane_integrated_snr_db", np.nan)
        ),
        "plane_excess_to_background_ratio": float(
            features.get("plane_excess_to_background_ratio", np.nan)
        ),
        "mean_combined_similarity": mean_similarity,
        "minimum_combined_similarity": min_similarity,
        "maximum_combined_similarity": max_similarity,
        "best_matching_lab_group": best_group,
        **dynamic_similarity_fields,
        "residual_npz": str(npz_path),
        "filtered_leak_wav": filtered_wav_path,
        "filtered_leak_wav_error": filtered_wav_error,
        "comparison_plot": plot_path,
        "center_file": str(center_paths[0]),
        # 以下字段只在程序内部使用，写CSV前会移除。
        "_bands": bands,
        "_probability": probability,
        "_shape": shape,
        "_group_summary_rows": group_summary_rows,
        "_individual_wav_rows": individual_wav_rows,
    }
    return result

def summarize_two_points(
    point_rows: pd.DataFrame,
    app: AppConfig,
) -> pd.DataFrame:
    summaries: List[Dict[str, Any]] = []
    score_column = "mean_combined_similarity"
    for (dataset, folder), group in point_rows.groupby(["dataset", "folder"], sort=False):
        valid = group[np.isfinite(group[score_column])].copy()
        valid = valid.sort_values(score_column, ascending=False)
        row: Dict[str, Any] = {
            "dataset": dataset,
            "folder": folder,
            "n_points_success": int(len(valid)),
            "expected_points": int(app.expected_points_per_folder),
        }
        if len(valid) == 0:
            row.update({
                "decision": "NO_VALID_POINT",
                "winner_center_id": "",
                "winner_similarity": np.nan,
                "runner_up_center_id": "",
                "runner_up_similarity": np.nan,
                "similarity_gap": np.nan,
                "decision_reason": "两个点均处理失败或没有有效相似度",
            })
        elif len(valid) == 1:
            winner = valid.iloc[0]
            row.update({
                "decision": "UNCERTAIN",
                "winner_center_id": str(winner["center_id"]),
                "winner_similarity": float(winner[score_column]),
                "runner_up_center_id": "",
                "runner_up_similarity": np.nan,
                "similarity_gap": np.nan,
                "decision_reason": "只有一个点处理成功，无法完成两点比较",
            })
        else:
            winner = valid.iloc[0]
            runner = valid.iloc[1]
            gap = float(winner[score_column] - runner[score_column])
            winner_similarity = float(winner[score_column])
            if winner_similarity < app.minimum_winner_similarity:
                decision = "UNCERTAIN"
                reason = "两个点与0.1 mm、0.5 mm整体参考的相似度都偏低"
            elif gap < app.minimum_similarity_gap:
                decision = "UNCERTAIN"
                reason = "两个点的整体相似度过于接近"
            else:
                decision = str(winner["center_id"])
                reason = "该点的空间残差与0.1 mm、0.5 mm整体泄漏参考更相似"
            row.update({
                "decision": decision,
                "winner_center_id": str(winner["center_id"]),
                "winner_similarity": winner_similarity,
                "runner_up_center_id": str(runner["center_id"]),
                "runner_up_similarity": float(runner[score_column]),
                "similarity_gap": gap,
                "decision_reason": reason,
            })
        summaries.append(row)
    return pd.DataFrame(summaries)

def process_all(
    datasets: Sequence[Dict[str, Any]],
    lab_group_paths: Dict[str, Sequence[Path]],
    output_dir: Path,
    v9_config: v9.V9Config,
    app: AppConfig,
) -> None:
    ensure_dir(output_dir)

    labs: Dict[str, LabFingerprint] = {}
    lab_manifest_rows: List[Dict[str, Any]] = []
    for group_name, roots in lab_group_paths.items():
        lab = build_lab_fingerprint(group_name, roots, v9_config, app)
        labs[group_name] = lab
        reference_path = save_lab_reference_csv(lab, output_dir)
        lab_manifest_rows.append({
            "lab_group": group_name,
            "configured_roots": "|".join(str(path) for path in roots),
            "n_wav_used": int(len(lab.files)),
            "n_wav_failed": int(len(lab.failed_files)),
            "reference_csv": str(reference_path),
        })
    pd.DataFrame(lab_manifest_rows).to_csv(
        output_dir / "00_lab_reference_manifest.csv",
        index=False,
        encoding="utf-8-sig",
    )

    centers_hz = next(iter(labs.values())).bin_centers_hz
    for lab in labs.values():
        if not np.allclose(lab.bin_centers_hz, centers_hz):
            raise ValueError("不同实验室组的频谱指纹网格不一致")

    point_records: List[Dict[str, Any]] = []
    group_similarity_rows: List[Dict[str, Any]] = []
    individual_wav_rows: List[Dict[str, Any]] = []
    common_band_rows: List[Dict[str, Any]] = []
    common_bin_rows: List[Dict[str, Any]] = []
    errors: List[Dict[str, Any]] = []

    # 先输出0.1 mm与0.5 mm实验室数据自身的共同频带。
    lab_shapes = {f"lab_{name}": lab.shape_reference for name, lab in labs.items()}
    lab_supports = {
        f"lab_{name}": np.mean(
            lab.individual_shapes >= float(app.common_shape_threshold), axis=0
        )
        for name, lab in labs.items()
    }
    bands, bins = make_common_feature_outputs(
        {
            "scope": "LAB_GROUPS_ONLY",
            "dataset": "",
            "folder": "",
            "center_id": "",
            "reference_group": "|".join(labs),
        },
        centers_hz,
        lab_shapes,
        lab_supports,
        app,
    )
    common_band_rows.extend(bands)
    common_bin_rows.extend(bins)

    for dataset in datasets:
        dataset_name = str(dataset.get("name", "dataset"))
        try:
            folders = dataset_folders(dataset)
        except Exception as exc:
            errors.append({
                "dataset": dataset_name,
                "folder": "",
                "center_id": "",
                "error": f"{type(exc).__name__}: {exc}",
                "traceback": traceback.format_exc(),
            })
            continue

        for folder_name, center_dir, offset_dir in folders:
            folder_success: List[Dict[str, Any]] = []
            try:
                if not center_dir.exists():
                    raise FileNotFoundError(f"中心目录不存在: {center_dir}")
                if not offset_dir.exists():
                    raise FileNotFoundError(f"偏移点目录不存在: {offset_dir}")
                center_map = v9.detect_center_files(center_dir)
                offset_mapping = v9.parse_offset_files(offset_dir)
                center_ids = sorted(center_map, key=v9.center_id_sort_key)
                if not center_ids:
                    raise FileNotFoundError(f"没有识别到中心WAV: {center_dir}")
                if app.strict_two_points and len(center_ids) != app.expected_points_per_folder:
                    raise ValueError(
                        f"该文件夹识别到{len(center_ids)}个中心点，"
                        f"期望{app.expected_points_per_folder}个；center_ids={center_ids}"
                    )

                for center_id in center_ids:
                    try:
                        record = process_one_point(
                            dataset_name,
                            folder_name,
                            center_id,
                            center_map[center_id],
                            offset_mapping,
                            output_dir,
                            v9_config,
                            app,
                            labs,
                        )
                        point_records.append(record)
                        folder_success.append(record)
                        group_similarity_rows.extend(record["_group_summary_rows"])
                        individual_wav_rows.extend(record["_individual_wav_rows"])

                        # 每个点分别与0.1 mm、0.5 mm输出共同频带。
                        for group_name, lab in labs.items():
                            lab_key = f"lab_{group_name}"
                            band_part, bin_part = make_common_feature_outputs(
                                {
                                    "scope": "POINT_VS_LAB_GROUP",
                                    "dataset": dataset_name,
                                    "folder": folder_name,
                                    "center_id": center_id,
                                    "reference_group": group_name,
                                },
                                centers_hz,
                                {
                                    f"point_{center_id}": record["_shape"],
                                    lab_key: lab.shape_reference,
                                },
                                {
                                    lab_key: np.mean(
                                        lab.individual_shapes >= float(app.common_shape_threshold),
                                        axis=0,
                                    )
                                },
                                app,
                            )
                            common_band_rows.extend(band_part)
                            common_bin_rows.extend(bin_part)

                        # 单点与全部实验室组的严格共同频带。
                        source_shapes = {f"point_{center_id}": record["_shape"]}
                        source_shapes.update(lab_shapes)
                        band_part, bin_part = make_common_feature_outputs(
                            {
                                "scope": "POINT_VS_ALL_LAB_GROUPS",
                                "dataset": dataset_name,
                                "folder": folder_name,
                                "center_id": center_id,
                                "reference_group": "|".join(labs),
                            },
                            centers_hz,
                            source_shapes,
                            lab_supports,
                            app,
                        )
                        common_band_rows.extend(band_part)
                        common_bin_rows.extend(bin_part)

                        print(
                            f"[完成] {dataset_name}/{folder_name}/点{center_id}: "
                            f"mean_similarity={record['mean_combined_similarity']:.4f}, "
                            f"plane_valid={record['plane_valid']}"
                        )
                    except Exception as exc:
                        errors.append({
                            "dataset": dataset_name,
                            "folder": folder_name,
                            "center_id": center_id,
                            "error": f"{type(exc).__name__}: {exc}",
                            "traceback": traceback.format_exc(),
                        })
                        print(f"[失败] {dataset_name}/{folder_name}/点{center_id}: {exc}")

                # 文件夹两点共同特征：分别对每个实验室组，以及与全部实验室组。
                if len(folder_success) >= 2:
                    point_shapes = {
                        f"point_{record['center_id']}": record["_shape"]
                        for record in folder_success[: app.expected_points_per_folder]
                    }
                    for group_name, lab in labs.items():
                        lab_key = f"lab_{group_name}"
                        source_shapes = dict(point_shapes)
                        source_shapes[lab_key] = lab.shape_reference
                        band_part, bin_part = make_common_feature_outputs(
                            {
                                "scope": "FOLDER_TWO_POINTS_VS_LAB_GROUP",
                                "dataset": dataset_name,
                                "folder": folder_name,
                                "center_id": "|".join(
                                    str(record["center_id"])
                                    for record in folder_success[: app.expected_points_per_folder]
                                ),
                                "reference_group": group_name,
                            },
                            centers_hz,
                            source_shapes,
                            {
                                lab_key: np.mean(
                                    lab.individual_shapes >= float(app.common_shape_threshold),
                                    axis=0,
                                )
                            },
                            app,
                        )
                        common_band_rows.extend(band_part)
                        common_bin_rows.extend(bin_part)

                    all_sources = dict(point_shapes)
                    all_sources.update(lab_shapes)
                    band_part, bin_part = make_common_feature_outputs(
                        {
                            "scope": "FOLDER_TWO_POINTS_VS_ALL_LAB_GROUPS",
                            "dataset": dataset_name,
                            "folder": folder_name,
                            "center_id": "|".join(
                                str(record["center_id"])
                                for record in folder_success[: app.expected_points_per_folder]
                            ),
                            "reference_group": "|".join(labs),
                        },
                        centers_hz,
                        all_sources,
                        lab_supports,
                        app,
                    )
                    common_band_rows.extend(band_part)
                    common_bin_rows.extend(bin_part)

            except Exception as exc:
                errors.append({
                    "dataset": dataset_name,
                    "folder": folder_name,
                    "center_id": "",
                    "error": f"{type(exc).__name__}: {exc}",
                    "traceback": traceback.format_exc(),
                })
                print(f"[失败] {dataset_name}/{folder_name}: {exc}")

    # 点级总表：移除内部数组字段。
    public_point_rows = [
        {key: value for key, value in record.items() if not key.startswith("_")}
        for record in point_records
    ]
    points_df = pd.DataFrame(public_point_rows)
    points_path = output_dir / "02_all_points_summary.csv"
    points_df.to_csv(points_path, index=False, encoding="utf-8-sig")

    group_similarity_df = pd.DataFrame(group_similarity_rows)
    group_similarity_path = output_dir / "01_point_similarity_by_lab_group.csv"
    group_similarity_df.to_csv(group_similarity_path, index=False, encoding="utf-8-sig")

    individual_wav_df = pd.DataFrame(individual_wav_rows)
    individual_wav_path = output_dir / "04_lab_wav_similarity_each_file.csv"
    individual_wav_df.to_csv(individual_wav_path, index=False, encoding="utf-8-sig")

    summary_columns = [
        "dataset", "folder", "n_points_success", "expected_points",
        "decision", "winner_center_id", "winner_similarity",
        "runner_up_center_id", "runner_up_similarity", "similarity_gap",
        "decision_reason",
    ]
    if len(points_df):
        summary_df = summarize_two_points(points_df, app).reindex(columns=summary_columns)
    else:
        summary_df = pd.DataFrame(columns=summary_columns)
    summary_path = output_dir / "03_folder_two_point_decision.csv"
    summary_df.to_csv(summary_path, index=False, encoding="utf-8-sig")

    common_band_df = pd.DataFrame(common_band_rows)
    common_band_path = output_dir / "05_common_frequency_bands.csv"
    common_band_df.to_csv(common_band_path, index=False, encoding="utf-8-sig")

    common_bin_df = pd.DataFrame(common_bin_rows)
    common_bin_path = output_dir / "06_common_frequency_bin_details.csv"
    common_bin_df.to_csv(common_bin_path, index=False, encoding="utf-8-sig")

    # 共同特征摘要，方便直接查看严格频带数量和最强候选频带。
    summary_rows: List[Dict[str, Any]] = []
    if len(common_band_df):
        group_cols = ["scope", "dataset", "folder", "center_id", "reference_group"]
        for keys, group in common_band_df.groupby(group_cols, dropna=False, sort=False):
            strict = group[group["feature_type"] == "STRICT_COMMON"]
            candidate = group[group["feature_type"] == "TOP_CANDIDATE"].sort_values(
                "mean_shared_strength", ascending=False
            )
            best = candidate.iloc[0] if len(candidate) else None
            summary_rows.append({
                **dict(zip(group_cols, keys)),
                "n_strict_common_bands": int(len(strict)),
                "strict_common_total_width_hz": float(strict["width_hz"].sum()) if len(strict) else 0.0,
                "strongest_candidate_start_khz": float(best["start_khz"]) if best is not None else np.nan,
                "strongest_candidate_end_khz": float(best["end_khz"]) if best is not None else np.nan,
                "strongest_candidate_strength": float(best["mean_shared_strength"]) if best is not None else np.nan,
            })
    common_summary_path = output_dir / "07_common_feature_summary.csv"
    pd.DataFrame(summary_rows).to_csv(common_summary_path, index=False, encoding="utf-8-sig")

    error_columns = ["dataset", "folder", "center_id", "error", "traceback"]
    error_df = pd.DataFrame(errors)
    if error_df.empty:
        error_df = pd.DataFrame(columns=error_columns)
    else:
        error_df = error_df.reindex(columns=error_columns)
    error_path = output_dir / "99_errors.csv"
    error_df.to_csv(error_path, index=False, encoding="utf-8-sig")

    run_info = {
        "version": "v16_two_points_plane_compare_01_05mm",
        "app_config": asdict(app),
        "v9_config": asdict(v9_config),
        "lab_groups": {
            name: {
                "configured_roots": [str(path) for path in lab_group_paths[name]],
                "n_wav_used": len(lab.files),
                "n_wav_failed": len(lab.failed_files),
            }
            for name, lab in labs.items()
        },
        "output_dir": str(output_dir),
        "n_points_success": int(len(points_df)),
        "n_folders_summarized": int(len(summary_df)),
        "n_group_similarity_rows": int(len(group_similarity_df)),
        "n_individual_lab_wav_rows": int(len(individual_wav_df)),
        "n_common_band_rows": int(len(common_band_df)),
        "n_errors": int(len(errors)),
    }
    with open(output_dir / "00_run_info.json", "w", encoding="utf-8") as handle:
        json.dump(run_info, handle, ensure_ascii=False, indent=2)

    print("\n处理完成")
    print(f"分组相似度: {group_similarity_path}")
    print(f"点级总表: {points_path}")
    print(f"两点判断: {summary_path}")
    print(f"逐实验室WAV相似度: {individual_wav_path}")
    print(f"共同频带: {common_band_path}")
    print(f"共同特征摘要: {common_summary_path}")
    print(f"错误记录: {error_path}")

def load_config(
    path: Path,
) -> Tuple[
    List[Dict[str, Any]],
    Dict[str, List[Path]],
    Path,
    v9.V9Config,
    AppConfig,
]:
    with open(path, "r", encoding="utf-8-sig") as handle:
        raw = json.load(handle)

    datasets = raw.get("datasets")
    if not isinstance(datasets, list) or not datasets:
        raise ValueError("配置文件中的datasets必须是非空列表")

    raw_lab_groups = raw.get("lab_groups")
    if raw_lab_groups is None:
        # 兼容旧配置字段。
        raw_lab_groups = {}
        if raw.get("lab_01mm_root_dir"):
            raw_lab_groups["0.1mm"] = [raw["lab_01mm_root_dir"]]
        if raw.get("lab_05mm_root_dir"):
            raw_lab_groups["0.5mm"] = [raw["lab_05mm_root_dir"]]
    if not isinstance(raw_lab_groups, dict) or not raw_lab_groups:
        raise ValueError("缺少lab_groups，必须至少配置0.1mm和0.5mm")

    lab_group_paths: Dict[str, List[Path]] = {}
    for group_name, values in raw_lab_groups.items():
        if isinstance(values, (str, Path)):
            values = [values]
        if not isinstance(values, list) or not values:
            raise ValueError(f"lab_groups[{group_name!r}]必须是非空路径列表")
        lab_group_paths[str(group_name)] = [Path(str(value)) for value in values]

    required_tags = {"01mm", "05mm"}
    actual_tags = {group_column_tag(name) for name in lab_group_paths}
    missing = required_tags - actual_tags
    if missing:
        raise ValueError(
            "lab_groups必须同时包含0.1mm和0.5mm；"
            f"当前组={list(lab_group_paths)}"
        )

    output_value = raw.get("output_dir")
    if not output_value:
        raise ValueError("缺少output_dir")
    output_dir = Path(str(output_value))

    algorithm_values = dict(raw.get("algorithm", {}))
    v9_fields = {item.name for item in fields(v9.V9Config)}
    app_fields = {item.name for item in fields(AppConfig)}

    v9_values = {key: value for key, value in algorithm_values.items() if key in v9_fields}
    app_values = {key: value for key, value in algorithm_values.items() if key in app_fields}
    unknown = sorted(set(algorithm_values) - v9_fields - app_fields)
    if unknown:
        raise ValueError(f"algorithm中存在未知配置项: {unknown}")

    v9_config = dataclass_from_dict(v9.V9Config, v9_values)
    app = dataclass_from_dict(AppConfig, app_values)

    required = v9_config.inner_excluded_points + v9_config.outer_background_points
    if required < 3:
        raise ValueError("空间平面至少需要3个背景点")
    if v9_config.outer_background_points < 3:
        raise ValueError("outer_background_points至少为3")
    if app.expected_points_per_folder < 1:
        raise ValueError("expected_points_per_folder必须大于0")
    if app.fingerprint_bin_hz <= 0:
        raise ValueError("fingerprint_bin_hz必须大于0")
    if not 0 <= app.minimum_lab_support_fraction <= 1:
        raise ValueError("minimum_lab_support_fraction必须在0到1之间")
    if not 0 <= app.minimum_shared_strength_for_strict <= 1:
        raise ValueError("minimum_shared_strength_for_strict必须在0到1之间")
    if app.minimum_common_band_width_hz <= 0:
        raise ValueError("minimum_common_band_width_hz必须大于0")
    return datasets, lab_group_paths, output_dir, v9_config, app

def run_self_test() -> None:
    freq = np.arange(20_000.0, 80_000.0, 500.0) + 250.0
    common = (
        np.exp(-0.5 * ((freq - 57_000.0) / 3_000.0) ** 2)
        + 0.65 * np.exp(-0.5 * ((freq - 66_000.0) / 2_500.0) ** 2)
        + 0.08
    )
    similar = common * (1.0 + 0.03 * np.sin(freq / 3000.0))
    different = np.exp(-0.5 * ((freq - 30_000.0) / 2_000.0) ** 2) + 0.08

    lab_prob = probability_vector(common)
    lab_shape = robust_shape(common)
    score_common = calculate_similarity(
        probability_vector(similar),
        robust_shape(similar),
        lab_prob,
        lab_shape,
    )["combined_similarity"]
    score_different = calculate_similarity(
        probability_vector(different),
        robust_shape(different),
        lab_prob,
        lab_shape,
    )["combined_similarity"]
    if not score_common > score_different:
        raise AssertionError(
            f"相似度自检失败: common={score_common}, different={score_different}"
        )

    app = AppConfig(
        common_shape_threshold=0.35,
        minimum_lab_support_fraction=0.5,
        minimum_common_band_width_hz=1000.0,
    )
    source_shapes = {
        "point_1": robust_shape(similar),
        "lab_0.1mm": robust_shape(common),
        "lab_0.5mm": robust_shape(common * 0.95),
    }
    support = {
        "lab_0.1mm": np.ones_like(freq),
        "lab_0.5mm": np.ones_like(freq),
    }
    band_rows, _ = make_common_feature_outputs(
        {
            "scope": "SELF_TEST",
            "dataset": "",
            "folder": "",
            "center_id": "",
            "reference_group": "0.1mm|0.5mm",
        },
        freq,
        source_shapes,
        support,
        app,
    )
    strict = [row for row in band_rows if row["feature_type"] == "STRICT_COMMON"]
    if not strict:
        raise AssertionError("共同频带自检失败：没有发现严格共同频带")
    if not any(row["start_hz"] <= 57_000.0 <= row["end_hz"] for row in strict):
        raise AssertionError("共同频带自检失败：57 kHz未进入严格共同频带")

    print("自检通过")
    print(f"相似频谱综合相似度: {score_common:.6f}")
    print(f"不同频谱综合相似度: {score_different:.6f}")
    print(f"严格共同频带数量:   {len(strict)}")

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="每文件夹两点空间拟合，并与0.1mm、0.5mm实验室泄漏比较"
    )
    parser.add_argument("--config", type=str, help="JSON配置文件路径")
    parser.add_argument("--self-test", action="store_true", help="运行内置自检")
    return parser.parse_args()

def main() -> None:
    args = parse_args()
    if args.self_test:
        run_self_test()
        return
    if not args.config:
        raise SystemExit("请使用--config指定配置文件，或使用--self-test")
    datasets, lab_groups, output_dir, v9_config, app = load_config(Path(args.config))
    process_all(datasets, lab_groups, output_dir, v9_config, app)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n用户中止。")
        sys.exit(130)
    except Exception as exc:
        print("\n程序失败:", f"{type(exc).__name__}: {exc}")
        traceback.print_exc()
        sys.exit(1)
