@echo off
chcp 65001 >nul
python spatial_prior_fusion_v1.py --self-test
pause
