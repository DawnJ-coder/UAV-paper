消声室引导半监督泄漏/噪声分离 v2：修改说明
============================================================

为什么修改
------------------------------------------------------------
v1中噪声字典使用全部128个周围点原始时频帧持续更新。
周围点含有泄漏传播，因此泄漏可能被噪声字典吸收。
同时v1对泄漏激活的惩罚高于噪声激活，中心分解天然偏向噪声。

v2核心变化
------------------------------------------------------------
1. 只使用60~80 cm外圈点建立噪声字典；不足时自动选择最远35%的点。
2. 129点严格同步，因此对外圈同一时频单元取15%、25%、35%空间低分位。
   泄漏功率属于正污染，低分位优先保留泄漏较弱点的现场背景形状。
3. 先用冻结消声室泄漏字典解释低分位数据中的泄漏样成分，再用剩余功率训练噪声字典。
4. 禁止噪声字典再次用全部周围原始帧更新，避免重新吸收泄漏。
5. 噪声字典与泄漏字典均为8个成分，降低噪声模型容量优势。
6. 泄漏激活惩罚由0.015降为0.002；噪声激活惩罚由0.002升为0.010。
7. 噪声字典与泄漏字典的最大余弦相似度受到限制。
8. gain不再作为必须大于0的条件。
   原始中心本来很像泄漏时，分离泄漏相似度不一定继续升高。
   v2重点要求：
       leak_vs_noise_similarity_gap > 0.03
       noise_similarity_drop_from_raw > 0

运行
------------------------------------------------------------
自检：
    python anechoic_semisupervised_leak_separation_v2.py --self-test

正式运行：
    python anechoic_semisupervised_leak_separation_v2.py --config anechoic_semisupervised_config_v2.json

不要覆盖v1结果目录。v2配置已经使用新的输出目录。

重点查看
------------------------------------------------------------
10_factory_sample_summary.csv：
- leak_lab_similarity_combined_median
- noise_lab_similarity_combined_median
- leak_vs_noise_similarity_gap
- noise_similarity_drop_from_raw
- leak_similarity_gain_over_raw（仅参考）
- noise_model_outer_reference_points
- noise_model_floor_leak_power_fraction
- noise_model_max_leak_noise_atom_cosine
- separation_quality_flag

解释
------------------------------------------------------------
若gap仍小于0，说明即使采用外圈空间低分位，现场噪声与消声室泄漏仍不可分，
或者消声室泄漏字典不能覆盖工厂传播后的泄漏形态。此时不能继续只调NMF参数，
需要引入同工况无泄漏录音或泄漏关闭前后的数据。
