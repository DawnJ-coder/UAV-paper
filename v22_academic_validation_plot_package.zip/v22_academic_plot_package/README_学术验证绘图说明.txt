v22 学术验证绘图程序（重做版）
================================

一、这版与上一版的根本区别
--------------------------
上一版图太多、信息太散，而且把不同消声室参考模型的绝对马氏距离放在一起比较，容易误导。
本版只围绕“PLANE是否优于RAW”组织证据：

1. TRUE的相对马氏距离是否下降；
2. FALSE的相对马氏距离是否上升；
3. TRUE/FALSE距离分离是否扩大；
4. TRUE综合频谱相似度是否上升；
5. FALSE综合频谱相似度是否下降；
6. TRUE/FALSE相似度分离是否扩大；
7. 同一样本的距离与相似度变化是否方向一致；
8. 改善来自五维特征中的哪几个特征。

所有核心结果均使用：
- 同一样本RAW→PLANE配对；
- Bootstrap 95%置信区间；
- 配对Wilcoxon检验；
- 每个场景单独展示；
- 600 dpi PNG和PDF/SVG矢量图。

二、为什么主图使用“相对马氏距离”
--------------------------------
不同消声室参考模型的协方差和参考距离阈值不同，0.1mm、0.5mm、ALL_LEAKS的绝对马氏距离不能直接共用同一纵轴比较。

本版定义：

    相对马氏距离 = D_M / τ

D_M为马氏距离，τ为该消声室模型的窗口参考阈值。

- D_M/τ = 1：位于消声室参考边界；
- D_M/τ < 1：位于参考范围内；
- 越小：越接近消声室特征分布。

绝对D_M仍会按0.1mm、0.5mm、ALL_LEAKS分别生成补充图，但不会再跨参考组硬比较。

三、运行方法
------------
最简单：双击 run_v22_academic_plots.bat，然后粘贴v22总输出目录。

命令行：

python v22_academic_validation_plots.py --root "D:\\你的v22结果目录"

也可以直接指定第三步目录：

python v22_academic_validation_plots.py --anechoic-dir "D:\\结果\\RAW_PLANE_vs_anechoic"

指定主参考模型：

python v22_academic_validation_plots.py --root "D:\\结果" --reference ALL_LEAKS

四、输入文件
------------
至少需要：

RAW_PLANE_vs_anechoic\01_每个样本_距离与相似度_long.csv

建议同时存在：

04_同一样本_RAW变PLANE后的变化.csv
05_每个特征与消声室差异.csv
08_窗口距离明细.csv

如果04缺失，程序会由01自动重建RAW/PLANE配对表。

五、最先看哪几张图
------------------
1. Fig03_相对马氏距离_TRUE_FALSE分离度
   最关键。分离度 = median(FALSE)-median(TRUE)，越大越好。
   PLANE应位于RAW右侧。

2. Fig04_空间拟合方向性象限
   只有左上象限明确支持PLANE有效：TRUE更近、FALSE更远。

3. Fig06_综合频谱相似度_TRUE_FALSE分离度
   分离度 = median(TRUE)-median(FALSE)，越大越好。

4. Fig07_马氏距离与相似度联合变化
   TRUE理想在左上，FALSE理想在右下。

5. Fig09_五维特征到消声室差异变化
   解释PLANE到底改变了哪些物理/统计特征。

六、输出结构
------------
v22_学术验证图
├─ 00_运行摘要.txt
├─ 00_逐图说明.md
├─ 00_图表索引.csv
├─ 01_报告主图
├─ 02_补充图
└─ 03_统计表

七、依赖
--------
Python 3.10及以上：

pip install numpy pandas matplotlib scipy
