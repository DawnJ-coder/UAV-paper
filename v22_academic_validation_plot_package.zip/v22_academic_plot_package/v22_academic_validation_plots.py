#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
v22 RAW/PLANE × 消声室结果：学术化验证绘图程序

核心目的
--------
不是“把所有CSV都画一遍”，而是回答一个明确问题：
    PLANE空间拟合是否比RAW更有利于区分TRUE与FALSE？

程序围绕以下证据组织：
1. 相对马氏距离 D_M / tau：TRUE理想下降、FALSE理想上升；
2. 马氏距离分离度：median(FALSE) - median(TRUE)，越大越好；
3. 综合频谱相似度：TRUE理想上升、FALSE理想下降；
4. 相似度分离度：median(TRUE) - median(FALSE)，越大越好；
5. 同一样本RAW→PLANE配对变化，避免只比较不配对的总体均值；
6. 五维特征到消声室的绝对z差异，解释改变来自哪些特征；
7. Bootstrap 95%置信区间和配对Wilcoxon检验。

输入
----
v22第三步输出目录，通常名为：RAW_PLANE_vs_anechoic
至少需要：
- 01_每个样本_距离与相似度_long.csv
- 04_同一样本_RAW变PLANE后的变化.csv（若缺失可由01自动重建）
- 05_每个特征与消声室差异.csv
可选：
- 08_窗口距离明细.csv

输出
----
默认生成到：v22_学术验证图
- PNG：600 dpi
- PDF/SVG：矢量图
- 统计汇总CSV
- 逐图解释Markdown/TXT

运行示例
--------
python v22_academic_validation_plots.py --root "D:\\result\\v22_output"
python v22_academic_validation_plots.py --anechoic-dir "D:\\result\\RAW_PLANE_vs_anechoic"
"""

from __future__ import annotations

import argparse
import math
import sys
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle

try:
    from scipy.stats import wilcoxon
except Exception:  # pragma: no cover
    wilcoxon = None

EPS = 1.0e-12
RNG_SEED = 20260730

# 克制、色盲友好的学术配色。
COLOR_RAW = "#6B7280"       # 中性灰
COLOR_PLANE = "#B2182B"     # 深红
COLOR_TRUE = "#2166AC"      # 蓝
COLOR_FALSE = "#B2182B"     # 红
COLOR_POS = "#2166AC"
COLOR_NEG = "#B2182B"
COLOR_NEUTRAL = "#4B5563"
COLOR_GRID = "#D1D5DB"
COLOR_TEXT = "#111827"
COLOR_REF = "#7C3AED"

LABEL_DISPLAY = {
    "TRUE_LEAK": "TRUE（真实泄漏中心）",
    "FALSE_LEAK": "FALSE（非中心点）",
}
METHOD_DISPLAY = {"raw": "RAW", "plane": "PLANE"}
FEATURE_DISPLAY = {
    "spectral_flatness": "频谱平坦度",
    "spectral_spread_hz": "频谱展宽",
    "adaptive_snr_db": "自适应SNR",
    "flatness_local_std": "平坦度时间波动",
    "spread_local_std_hz": "展宽时间波动",
}
SIMILARITY_DISPLAY = {
    "combined_similarity": "综合频谱相似度",
    "cosine_similarity": "余弦相似度",
    "spectral_overlap": "频谱重合度",
    "pearson_similarity": "Pearson相似度",
}


@dataclass
class PlotRecord:
    number: str
    filename: str
    question: str
    metric: str
    ideal: str
    interpretation: str
    source: str


# ---------------------------------------------------------------------------
# 基础工具
# ---------------------------------------------------------------------------

def read_csv_safe(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"缺少文件：{path}")
    for enc in ("utf-8-sig", "utf-8", "gb18030"):
        try:
            return pd.read_csv(path, encoding=enc)
        except UnicodeDecodeError:
            continue
        except pd.errors.EmptyDataError:
            return pd.DataFrame()
    raise UnicodeError(f"无法识别CSV编码：{path}")


def find_anechoic_dir(root: Path) -> Path:
    root = root.expanduser().resolve()
    required = "01_每个样本_距离与相似度_long.csv"
    if (root / required).exists():
        return root
    direct = root / "RAW_PLANE_vs_anechoic"
    if (direct / required).exists():
        return direct
    candidates = list(root.rglob(required))
    if len(candidates) == 1:
        return candidates[0].parent
    if not candidates:
        raise FileNotFoundError(
            f"在 {root} 中找不到 {required}。\n"
            "请把--root指向v22总输出目录，或用--anechoic-dir直接指定RAW_PLANE_vs_anechoic目录。"
        )
    raise RuntimeError(
        "发现多个消声室比较结果目录，请用--anechoic-dir明确指定：\n"
        + "\n".join(str(p.parent) for p in candidates)
    )


def choose_chinese_font() -> str:
    # Matplotlib在部分Linux环境不会自动扫描TTC中文字体，因此先显式注册系统字体。
    known_paths = [
        Path("/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc"),
        Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
        Path(r"C:\\Windows\\Fonts\\simsun.ttc"),
        Path(r"C:\\Windows\\Fonts\\msyh.ttc"),
    ]
    for font_path in known_paths:
        if font_path.exists():
            try:
                mpl.font_manager.fontManager.addfont(str(font_path))
            except Exception:
                pass
    candidates = [
        "Noto Serif CJK SC", "Noto Serif CJK JP", "Source Han Serif SC",
        "SimSun", "宋体", "Noto Sans CJK SC", "Noto Sans CJK JP",
        "Microsoft YaHei", "微软雅黑", "DejaVu Sans",
    ]
    available = {f.name for f in mpl.font_manager.fontManager.ttflist}
    for name in candidates:
        if name in available:
            return name
    return "DejaVu Sans"


def configure_style() -> str:
    font_name = choose_chinese_font()
    mpl.rcParams.update({
        "font.family": [font_name],
        "font.serif": [font_name, "Times New Roman", "DejaVu Serif"],
        "font.sans-serif": [font_name, "Arial", "DejaVu Sans"],
        "mathtext.fontset": "stix",
        "axes.unicode_minus": False,
        "font.size": 10.5,
        "axes.titlesize": 12.5,
        "axes.labelsize": 11,
        "xtick.labelsize": 9.5,
        "ytick.labelsize": 9.5,
        "legend.fontsize": 9.2,
        "figure.titlesize": 13,
        "axes.linewidth": 0.8,
        "xtick.major.width": 0.8,
        "ytick.major.width": 0.8,
        "xtick.major.size": 4,
        "ytick.major.size": 4,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.08,
    })
    return font_name


def clean_axis(ax: plt.Axes, grid_axis: str = "y") -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#374151")
    ax.spines["bottom"].set_color("#374151")
    ax.tick_params(colors=COLOR_TEXT)
    ax.yaxis.label.set_color(COLOR_TEXT)
    ax.xaxis.label.set_color(COLOR_TEXT)
    ax.title.set_color(COLOR_TEXT)
    if grid_axis:
        ax.grid(axis=grid_axis, color=COLOR_GRID, linewidth=0.65, alpha=0.55, zorder=0)
    ax.set_axisbelow(True)


def save_figure(fig: plt.Figure, output_base: Path, formats: Sequence[str]) -> List[Path]:
    paths: List[Path] = []
    for fmt in formats:
        fmt = fmt.lower().strip().lstrip(".")
        path = output_base.with_suffix(f".{fmt}")
        kwargs = {"dpi": 600} if fmt == "png" else {}
        fig.savefig(path, **kwargs)
        paths.append(path)
    plt.close(fig)
    return paths


def scene_short(value: object) -> str:
    text = str(value)
    for prefix in ("factory_", "scene_", "Factory_"):
        if text.startswith(prefix):
            text = text[len(prefix):]
    return text


def as_numeric(df: pd.DataFrame, columns: Iterable[str]) -> pd.DataFrame:
    out = df.copy()
    for col in columns:
        if col in out.columns:
            out[col] = pd.to_numeric(out[col], errors="coerce")
    return out


def require_columns(df: pd.DataFrame, columns: Sequence[str], file_name: str) -> None:
    missing = [c for c in columns if c not in df.columns]
    if missing:
        raise ValueError(f"{file_name}缺少列：{missing}")


def bootstrap_ci(
    values: Sequence[float],
    statistic=np.median,
    n_boot: int = 5000,
    seed: int = RNG_SEED,
    confidence: float = 0.95,
) -> Tuple[float, float, float]:
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return np.nan, np.nan, np.nan
    estimate = float(statistic(x))
    if x.size == 1:
        return estimate, estimate, estimate
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, x.size, size=(n_boot, x.size))
    boot = np.asarray([statistic(x[row]) for row in idx], dtype=float)
    alpha = (1.0 - confidence) / 2.0
    low, high = np.quantile(boot[np.isfinite(boot)], [alpha, 1.0 - alpha])
    return estimate, float(low), float(high)


def bootstrap_separation_ci(
    positive_values: Sequence[float],
    negative_values: Sequence[float],
    orientation: str,
    n_boot: int = 5000,
    seed: int = RNG_SEED,
) -> Tuple[float, float, float]:
    """
    orientation='distance': median(FALSE)-median(TRUE)
    orientation='similarity': median(TRUE)-median(FALSE)
    这里positive_values传TRUE，negative_values传FALSE。
    """
    t = np.asarray(positive_values, dtype=float)
    f = np.asarray(negative_values, dtype=float)
    t = t[np.isfinite(t)]
    f = f[np.isfinite(f)]
    if t.size == 0 or f.size == 0:
        return np.nan, np.nan, np.nan
    if orientation == "distance":
        estimate = float(np.median(f) - np.median(t))
    else:
        estimate = float(np.median(t) - np.median(f))
    rng = np.random.default_rng(seed)
    vals = np.empty(n_boot, dtype=float)
    for i in range(n_boot):
        tb = t[rng.integers(0, t.size, t.size)]
        fb = f[rng.integers(0, f.size, f.size)]
        vals[i] = np.median(fb) - np.median(tb) if orientation == "distance" else np.median(tb) - np.median(fb)
    low, high = np.quantile(vals, [0.025, 0.975])
    return estimate, float(low), float(high)


def paired_wilcoxon_p(raw: Sequence[float], plane: Sequence[float]) -> float:
    if wilcoxon is None:
        return np.nan
    x = np.asarray(raw, dtype=float)
    y = np.asarray(plane, dtype=float)
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask]
    y = y[mask]
    if x.size < 3 or np.allclose(x, y):
        return np.nan
    try:
        return float(wilcoxon(y, x, alternative="two-sided", zero_method="wilcox").pvalue)
    except Exception:
        return np.nan


def p_text(p: float) -> str:
    if not np.isfinite(p):
        return "p=NA"
    if p < 0.001:
        return "p<0.001"
    return f"p={p:.3f}"


def stable_jitter(n: int, width: float, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    return rng.uniform(-width, width, size=n)


def make_paired_df(long_df: pd.DataFrame) -> pd.DataFrame:
    keys = ["sample_id", "scene", "label", "reference_group"]
    metrics = [
        "median_distance", "p90_distance", "median_distance_ratio", "p90_distance_ratio",
        "balanced_similarity", "combined_similarity", "cosine_similarity",
        "spectral_overlap", "pearson_similarity", "window_inside_fraction",
    ]
    available = [m for m in metrics if m in long_df.columns]
    raw = long_df[long_df["method"].str.lower() == "raw"][keys + available].copy()
    plane = long_df[long_df["method"].str.lower() == "plane"][keys + available].copy()
    paired = raw.merge(plane, on=keys, suffixes=("_raw", "_plane"), how="inner")
    for metric in available:
        paired[f"{metric}_change_plane_minus_raw"] = paired[f"{metric}_plane"] - paired[f"{metric}_raw"]
    return paired


def validate_and_prepare(long_df: pd.DataFrame, paired_df: pd.DataFrame, feature_df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    require_columns(
        long_df,
        ["sample_id", "scene", "label", "method", "reference_group", "median_distance", "window_distance_threshold", "combined_similarity"],
        "01_每个样本_距离与相似度_long.csv",
    )
    long_df = long_df.copy()
    long_df["method"] = long_df["method"].astype(str).str.lower().str.strip()
    long_df["label"] = long_df["label"].astype(str).str.upper().str.strip()
    long_df["reference_group"] = long_df["reference_group"].astype(str).str.strip()
    long_df["scene"] = long_df["scene"].astype(str)
    long_df = as_numeric(long_df, [
        "median_distance", "p90_distance", "window_distance_threshold", "median_distance_ratio",
        "p90_distance_ratio", "combined_similarity", "cosine_similarity", "spectral_overlap",
        "pearson_similarity", "balanced_similarity", "window_inside_fraction",
    ])
    if "median_distance_ratio" not in long_df.columns or long_df["median_distance_ratio"].isna().all():
        long_df["median_distance_ratio"] = long_df["median_distance"] / long_df["window_distance_threshold"].clip(lower=EPS)
    if "p90_distance_ratio" not in long_df.columns and "p90_distance" in long_df.columns:
        long_df["p90_distance_ratio"] = long_df["p90_distance"] / long_df["window_distance_threshold"].clip(lower=EPS)
    long_df = long_df[
        long_df["method"].isin(["raw", "plane"])
        & long_df["label"].isin(["TRUE_LEAK", "FALSE_LEAK"])
    ].copy()

    if paired_df.empty:
        paired_df = make_paired_df(long_df)
    else:
        paired_df = paired_df.copy()
        paired_df["label"] = paired_df["label"].astype(str).str.upper().str.strip()
        paired_df["reference_group"] = paired_df["reference_group"].astype(str).str.strip()
        paired_df["scene"] = paired_df["scene"].astype(str)
        # 老版04没有距离比变化列时，补齐。
        for side in ("raw", "plane"):
            ratio_col = f"median_distance_ratio_{side}"
            if ratio_col not in paired_df.columns:
                d = f"median_distance_{side}"
                th = f"window_distance_threshold_{side}"
                if d in paired_df.columns and th in paired_df.columns:
                    paired_df[ratio_col] = pd.to_numeric(paired_df[d], errors="coerce") / pd.to_numeric(paired_df[th], errors="coerce").clip(lower=EPS)
        for metric in ["median_distance_ratio", "combined_similarity", "cosine_similarity", "spectral_overlap", "pearson_similarity", "balanced_similarity"]:
            raw_col, plane_col = f"{metric}_raw", f"{metric}_plane"
            change_col = f"{metric}_change_plane_minus_raw"
            if change_col not in paired_df.columns and raw_col in paired_df.columns and plane_col in paired_df.columns:
                paired_df[change_col] = pd.to_numeric(paired_df[plane_col], errors="coerce") - pd.to_numeric(paired_df[raw_col], errors="coerce")
        paired_df = as_numeric(paired_df, [c for c in paired_df.columns if any(k in c for k in ("distance", "similarity", "overlap"))])

    if not feature_df.empty:
        require_columns(feature_df, ["sample_id", "scene", "label", "method", "reference_group", "feature", "absolute_z_difference"], "05_每个特征与消声室差异.csv")
        feature_df = feature_df.copy()
        feature_df["method"] = feature_df["method"].astype(str).str.lower().str.strip()
        feature_df["label"] = feature_df["label"].astype(str).str.upper().str.strip()
        feature_df["reference_group"] = feature_df["reference_group"].astype(str).str.strip()
        feature_df["scene"] = feature_df["scene"].astype(str)
        feature_df["absolute_z_difference"] = pd.to_numeric(feature_df["absolute_z_difference"], errors="coerce")
    return long_df, paired_df, feature_df


# ---------------------------------------------------------------------------
# 绘图函数
# ---------------------------------------------------------------------------

def plot_metric_distribution(
    df: pd.DataFrame,
    metric: str,
    ylabel: str,
    title: str,
    output_base: Path,
    formats: Sequence[str],
    reference: str,
    favorable_note: str,
    reference_line: Optional[float] = None,
) -> List[Path]:
    """每个场景绘制TRUE/FALSE × RAW/PLANE分布（箱线+原始点+中位数）。"""
    sub = df[df["reference_group"] == reference].dropna(subset=[metric]).copy()
    scenes = sorted(sub["scene"].unique(), key=scene_short)
    if not scenes:
        return []
    fig, axes = plt.subplots(1, len(scenes), figsize=(4.35 * len(scenes), 4.7), sharey=False)
    if len(scenes) == 1:
        axes = [axes]
    positions = {
        ("TRUE_LEAK", "raw"): 0.78,
        ("TRUE_LEAK", "plane"): 1.22,
        ("FALSE_LEAK", "raw"): 2.78,
        ("FALSE_LEAK", "plane"): 3.22,
    }
    for si, (ax, scene) in enumerate(zip(axes, scenes)):
        g = sub[sub["scene"] == scene]
        for li, label in enumerate(("TRUE_LEAK", "FALSE_LEAK")):
            for mi, method in enumerate(("raw", "plane")):
                vals = g[(g["label"] == label) & (g["method"] == method)][metric].dropna().to_numpy(float)
                if vals.size == 0:
                    continue
                pos = positions[(label, method)]
                color = COLOR_RAW if method == "raw" else COLOR_PLANE
                bp = ax.boxplot(
                    [vals], positions=[pos], widths=0.30, patch_artist=True,
                    showfliers=False, whis=(5, 95), zorder=2,
                    medianprops={"color": "white", "linewidth": 1.6},
                    boxprops={"facecolor": color, "edgecolor": color, "alpha": 0.80, "linewidth": 1.0},
                    whiskerprops={"color": color, "linewidth": 1.0},
                    capprops={"color": color, "linewidth": 1.0},
                )
                jitter = stable_jitter(len(vals), 0.095, seed=RNG_SEED + si * 100 + li * 10 + mi)
                marker = "o" if label == "TRUE_LEAK" else "s"
                ax.scatter(np.full(len(vals), pos) + jitter, vals, s=16, marker=marker,
                           facecolors="white", edgecolors=color, linewidths=0.65, alpha=0.68, zorder=3)
                med = float(np.median(vals))
                ax.scatter([pos], [med], s=30, marker="D", color=COLOR_TEXT, zorder=4)
        if reference_line is not None:
            ax.axhline(reference_line, color=COLOR_REF, linestyle=(0, (4, 3)), linewidth=1.0, zorder=1)
        ax.set_xticks([1.0, 3.0], ["TRUE", "FALSE"])
        ax.set_title(f"场景 {scene_short(scene)}", pad=9, fontweight="semibold")
        ax.set_xlabel("样本标签")
        if si == 0:
            ax.set_ylabel(ylabel)
        clean_axis(ax)
    legend_handles = [
        Patch(facecolor=COLOR_RAW, edgecolor=COLOR_RAW, label="RAW"),
        Patch(facecolor=COLOR_PLANE, edgecolor=COLOR_PLANE, label="PLANE"),
        Line2D([0], [0], marker="o", linestyle="none", markerfacecolor="white", markeredgecolor=COLOR_TEXT, label="单个样本"),
        Line2D([0], [0], marker="D", linestyle="none", color=COLOR_TEXT, label="中位数"),
    ]
    if reference_line is not None:
        legend_handles.append(Line2D([0], [0], color=COLOR_REF, linestyle=(0, (4, 3)), label="消声室参考边界"))
    fig.legend(handles=legend_handles, loc="upper center", bbox_to_anchor=(0.5, 1.015), ncol=len(legend_handles), frameon=False)
    fig.suptitle(title, y=1.075, fontweight="semibold")
    fig.text(0.5, -0.015, favorable_note, ha="center", va="top", fontsize=9.3, color=COLOR_NEUTRAL)
    fig.tight_layout(rect=(0, 0.03, 1, 0.96))
    return save_figure(fig, output_base, formats)


def plot_paired_change(
    paired: pd.DataFrame,
    metric: str,
    ylabel: str,
    title: str,
    output_base: Path,
    formats: Sequence[str],
    reference: str,
    label: str,
    ideal_text: str,
) -> List[Path]:
    sub = paired[(paired["reference_group"] == reference) & (paired["label"] == label)].copy()
    raw_col, plane_col = f"{metric}_raw", f"{metric}_plane"
    if raw_col not in sub or plane_col not in sub:
        return []
    sub = sub.dropna(subset=[raw_col, plane_col])
    scenes = sorted(sub["scene"].unique(), key=scene_short)
    if not scenes:
        return []
    fig, ax = plt.subplots(figsize=(max(7.2, 2.35 * len(scenes)), 5.1))
    x_centers = np.arange(len(scenes), dtype=float) * 1.8
    for si, (scene, xc) in enumerate(zip(scenes, x_centers)):
        g = sub[sub["scene"] == scene]
        x0, x1 = xc - 0.27, xc + 0.27
        raw = g[raw_col].to_numpy(float)
        plane = g[plane_col].to_numpy(float)
        # 样本配对线：低透明度，显示方向但不抢主信息。
        for j, (r, p) in enumerate(zip(raw, plane)):
            ax.plot([x0, x1], [r, p], color="#9CA3AF", linewidth=0.65, alpha=0.42, zorder=1)
        ax.scatter(np.full(len(raw), x0), raw, s=18, facecolors="white", edgecolors=COLOR_RAW, linewidths=0.75, alpha=0.75, zorder=2)
        ax.scatter(np.full(len(plane), x1), plane, s=18, facecolors="white", edgecolors=COLOR_PLANE, linewidths=0.75, alpha=0.75, zorder=2)
        # 中位数和Bootstrap CI。
        med_r, lo_r, hi_r = bootstrap_ci(raw, seed=RNG_SEED + si)
        med_p, lo_p, hi_p = bootstrap_ci(plane, seed=RNG_SEED + 100 + si)
        ax.errorbar([x0], [med_r], yerr=[[med_r - lo_r], [hi_r - med_r]], fmt="D", color=COLOR_RAW,
                    markersize=5.5, capsize=3.5, linewidth=1.35, zorder=4)
        ax.errorbar([x1], [med_p], yerr=[[med_p - lo_p], [hi_p - med_p]], fmt="D", color=COLOR_PLANE,
                    markersize=5.5, capsize=3.5, linewidth=1.35, zorder=4)
        pval = paired_wilcoxon_p(raw, plane)
        y_top = np.nanmax(np.r_[raw, plane])
        y_bottom = np.nanmin(np.r_[raw, plane])
        offset = max((y_top - y_bottom) * 0.08, abs(y_top) * 0.02, 0.02)
        ax.text(xc, y_top + offset, p_text(pval), ha="center", va="bottom", fontsize=8.6, color=COLOR_NEUTRAL)
        ax.text(x0, y_bottom - offset * 0.75, "RAW", ha="center", va="top", fontsize=8.7, color=COLOR_RAW)
        ax.text(x1, y_bottom - offset * 0.75, "PLANE", ha="center", va="top", fontsize=8.7, color=COLOR_PLANE)
    ax.set_xticks(x_centers, [f"场景 {scene_short(s)}" for s in scenes])
    ax.set_ylabel(ylabel)
    ax.set_title(title, pad=12, fontweight="semibold")
    clean_axis(ax)
    ax.text(0.99, 0.02, ideal_text, transform=ax.transAxes, ha="right", va="bottom", fontsize=9.2,
            color=COLOR_NEUTRAL, bbox={"boxstyle": "round,pad=0.28", "fc": "white", "ec": "#D1D5DB", "alpha": 0.92})
    ax.legend(handles=[
        Line2D([0], [0], marker="D", color=COLOR_RAW, linestyle="none", label="RAW中位数及95% CI"),
        Line2D([0], [0], marker="D", color=COLOR_PLANE, linestyle="none", label="PLANE中位数及95% CI"),
        Line2D([0], [0], color="#9CA3AF", linewidth=0.8, label="同一样本配对变化"),
    ], loc="best", frameon=False)
    fig.tight_layout()
    return save_figure(fig, output_base, formats)


def separation_table(
    long_df: pd.DataFrame,
    reference: str,
    metric: str,
    orientation: str,
    n_boot: int,
) -> pd.DataFrame:
    sub = long_df[long_df["reference_group"] == reference].dropna(subset=[metric]).copy()
    scenes = sorted(sub["scene"].unique(), key=scene_short)
    rows: List[Dict[str, object]] = []
    groups: List[Tuple[str, pd.DataFrame]] = [(s, sub[sub["scene"] == s]) for s in scenes]
    groups.append(("总体", sub))
    for scene, g in groups:
        for method in ("raw", "plane"):
            m = g[g["method"] == method]
            true = m[m["label"] == "TRUE_LEAK"][metric].dropna().to_numpy(float)
            false = m[m["label"] == "FALSE_LEAK"][metric].dropna().to_numpy(float)
            est, low, high = bootstrap_separation_ci(true, false, orientation, n_boot=n_boot,
                                                      seed=RNG_SEED + len(rows) * 17)
            rows.append({
                "scene": scene,
                "method": method,
                "estimate": est,
                "ci_low": low,
                "ci_high": high,
                "n_true": len(true),
                "n_false": len(false),
            })
    return pd.DataFrame(rows)


def plot_separation_forest(
    table: pd.DataFrame,
    xlabel: str,
    title: str,
    output_base: Path,
    formats: Sequence[str],
    note: str,
) -> List[Path]:
    scenes = list(dict.fromkeys(table["scene"].tolist()))
    fig, ax = plt.subplots(figsize=(8.3, max(4.4, 0.72 * len(scenes) + 1.8)))
    y = np.arange(len(scenes))[::-1]
    offsets = {"raw": 0.13, "plane": -0.13}
    for method in ("raw", "plane"):
        color = COLOR_RAW if method == "raw" else COLOR_PLANE
        g = table[table["method"] == method].set_index("scene").reindex(scenes)
        yy = y + offsets[method]
        est = g["estimate"].to_numpy(float)
        lo = g["ci_low"].to_numpy(float)
        hi = g["ci_high"].to_numpy(float)
        ax.errorbar(est, yy, xerr=[est - lo, hi - est], fmt="o", color=color, ecolor=color,
                    markersize=5.8, capsize=3.2, elinewidth=1.45, label=METHOD_DISPLAY[method], zorder=3)
    ax.axvline(0.0, color="#111827", linewidth=0.9, linestyle=(0, (3, 3)), zorder=1)
    ax.set_yticks(y, [f"场景 {scene_short(s)}" if s != "总体" else "总体" for s in scenes])
    ax.set_xlabel(xlabel)
    ax.set_title(title, pad=12, fontweight="semibold")
    clean_axis(ax, grid_axis="x")
    ax.legend(frameon=False, loc="best")
    ax.text(0.99, 0.02, note, transform=ax.transAxes, ha="right", va="bottom", fontsize=9.1,
            color=COLOR_NEUTRAL, bbox={"boxstyle": "round,pad=0.28", "fc": "white", "ec": "#D1D5DB", "alpha": 0.92})
    fig.tight_layout()
    return save_figure(fig, output_base, formats)


def plot_change_quadrant(
    paired: pd.DataFrame,
    reference: str,
    output_base: Path,
    formats: Sequence[str],
) -> List[Path]:
    metric_change = "median_distance_ratio_change_plane_minus_raw"
    if metric_change not in paired.columns:
        return []
    sub = paired[paired["reference_group"] == reference].dropna(subset=[metric_change]).copy()
    rows = []
    for scene in sorted(sub["scene"].unique(), key=scene_short):
        g = sub[sub["scene"] == scene]
        true = g[g["label"] == "TRUE_LEAK"][metric_change].dropna().to_numpy(float)
        false = g[g["label"] == "FALSE_LEAK"][metric_change].dropna().to_numpy(float)
        if true.size and false.size:
            x, xlo, xhi = bootstrap_ci(true, seed=RNG_SEED + len(rows) * 2)
            y, ylo, yhi = bootstrap_ci(false, seed=RNG_SEED + len(rows) * 2 + 1)
            rows.append((scene, x, xlo, xhi, y, ylo, yhi))
    if not rows:
        return []
    fig, ax = plt.subplots(figsize=(6.6, 5.7))
    xall = np.asarray([r[1] for r in rows])
    yall = np.asarray([r[4] for r in rows])
    # 理想象限：TRUE距离下降(x<0)，FALSE距离上升(y>0)。
    xmin = min(0.0, np.nanmin([r[2] for r in rows]))
    xmax = max(0.0, np.nanmax([r[3] for r in rows]))
    ymin = min(0.0, np.nanmin([r[5] for r in rows]))
    ymax = max(0.0, np.nanmax([r[6] for r in rows]))
    padx = max((xmax - xmin) * 0.16, 0.03)
    pady = max((ymax - ymin) * 0.16, 0.03)
    ax.set_xlim(xmin - padx, xmax + padx)
    ax.set_ylim(ymin - pady, ymax + pady)
    # 只标出真正的左上象限：x<0且y>0。不能用固定ymin=0.5，
    # 因为不同数据下y=0不一定位于坐标轴正中。
    x_left, x_right = ax.get_xlim()
    _, y_top = ax.get_ylim()
    if x_left < 0 < y_top:
        ax.add_patch(Rectangle((x_left, 0.0), 0.0 - x_left, y_top,
                               facecolor="#DCFCE7", edgecolor="none", alpha=0.65, zorder=0))
    ax.axhline(0, color="#111827", linewidth=0.85, linestyle=(0, (3, 3)))
    ax.axvline(0, color="#111827", linewidth=0.85, linestyle=(0, (3, 3)))
    for i, row in enumerate(rows):
        scene, x, xlo, xhi, y, ylo, yhi = row
        color = ["#2166AC", "#7B3294", "#008837", "#E08214", "#4D4D4D"][i % 5]
        ax.errorbar(x, y, xerr=[[x - xlo], [xhi - x]], yerr=[[y - ylo], [yhi - y]],
                    fmt="o", color=color, capsize=3.2, markersize=7, linewidth=1.25, zorder=3)
        ax.annotate(f"场景 {scene_short(scene)}", (x, y), xytext=(5, 5), textcoords="offset points", fontsize=9, color=color)
    ax.set_xlabel("TRUE：PLANE − RAW 相对马氏距离（越负越好）")
    ax.set_ylabel("FALSE：PLANE − RAW 相对马氏距离（越正越好）")
    ax.set_title(f"空间拟合的方向性验证（{reference}）", pad=12, fontweight="semibold")
    clean_axis(ax)
    ax.text(0.03, 0.97, "理想区域\nTRUE更近、FALSE更远", transform=ax.transAxes, ha="left", va="top",
            fontsize=9.4, color="#166534", fontweight="semibold")
    fig.tight_layout()
    return save_figure(fig, output_base, formats)


def plot_joint_change(
    paired: pd.DataFrame,
    reference: str,
    output_base: Path,
    formats: Sequence[str],
) -> List[Path]:
    xcol = "median_distance_ratio_change_plane_minus_raw"
    ycol = "combined_similarity_change_plane_minus_raw"
    if xcol not in paired.columns or ycol not in paired.columns:
        return []
    sub = paired[paired["reference_group"] == reference].dropna(subset=[xcol, ycol]).copy()
    if sub.empty:
        return []
    fig, ax = plt.subplots(figsize=(7.2, 5.8))
    ax.axhline(0, color="#111827", linewidth=0.85, linestyle=(0, (3, 3)), zorder=1)
    ax.axvline(0, color="#111827", linewidth=0.85, linestyle=(0, (3, 3)), zorder=1)
    for label, color, marker in (("TRUE_LEAK", COLOR_TRUE, "o"), ("FALSE_LEAK", COLOR_FALSE, "s")):
        g = sub[sub["label"] == label]
        ax.scatter(g[xcol], g[ycol], s=28, marker=marker, facecolors="white", edgecolors=color,
                   linewidths=0.9, alpha=0.72, label=LABEL_DISPLAY[label], zorder=2)
        # 各场景中位数。
        for scene in sorted(g["scene"].unique(), key=scene_short):
            h = g[g["scene"] == scene]
            xm, ym = float(h[xcol].median()), float(h[ycol].median())
            ax.scatter([xm], [ym], marker=marker, s=76, color=color, edgecolor="white", linewidth=0.8, zorder=4)
            ax.annotate(scene_short(scene), (xm, ym), xytext=(4, 4), textcoords="offset points", fontsize=8.3, color=color)
    ax.set_xlabel("相对马氏距离变化：PLANE − RAW（左侧更接近消声室）")
    ax.set_ylabel("综合频谱相似度变化：PLANE − RAW（上方更相似）")
    ax.set_title(f"马氏距离与频谱相似度的交叉验证（{reference}）", pad=12, fontweight="semibold")
    clean_axis(ax)
    ax.legend(frameon=False, loc="best")
    ax.text(0.02, 0.98, "TRUE理想：左上", transform=ax.transAxes, ha="left", va="top", color=COLOR_TRUE, fontsize=9.2)
    ax.text(0.98, 0.02, "FALSE理想：右下", transform=ax.transAxes, ha="right", va="bottom", color=COLOR_FALSE, fontsize=9.2)
    fig.tight_layout()
    return save_figure(fig, output_base, formats)


def build_similarity_component_stats(
    paired: pd.DataFrame,
    reference: str,
    n_boot: int,
) -> pd.DataFrame:
    rows: List[Dict[str, object]] = []
    for metric in ("cosine_similarity", "spectral_overlap", "pearson_similarity", "combined_similarity"):
        change = f"{metric}_change_plane_minus_raw"
        if change not in paired.columns:
            continue
        for label in ("TRUE_LEAK", "FALSE_LEAK"):
            vals = paired[(paired["reference_group"] == reference) & (paired["label"] == label)][change].dropna().to_numpy(float)
            est, low, high = bootstrap_ci(vals, n_boot=n_boot, seed=RNG_SEED + len(rows) * 13)
            rows.append({"metric": metric, "label": label, "estimate": est, "ci_low": low, "ci_high": high, "n": len(vals)})
    return pd.DataFrame(rows)


def plot_similarity_components(
    stats: pd.DataFrame,
    reference: str,
    output_base: Path,
    formats: Sequence[str],
) -> List[Path]:
    if stats.empty:
        return []
    metrics = [m for m in ("cosine_similarity", "spectral_overlap", "pearson_similarity", "combined_similarity") if m in stats["metric"].unique()]
    y = np.arange(len(metrics))[::-1]
    fig, ax = plt.subplots(figsize=(8.0, 4.9))
    for label, offset, color, marker in (("TRUE_LEAK", 0.12, COLOR_TRUE, "o"), ("FALSE_LEAK", -0.12, COLOR_FALSE, "s")):
        g = stats[stats["label"] == label].set_index("metric").reindex(metrics)
        est = g["estimate"].to_numpy(float)
        lo = g["ci_low"].to_numpy(float)
        hi = g["ci_high"].to_numpy(float)
        ax.errorbar(est, y + offset, xerr=[est - lo, hi - est], fmt=marker, color=color, ecolor=color,
                    capsize=3.2, markersize=6, linewidth=1.35, label=LABEL_DISPLAY[label])
    ax.axvline(0, color="#111827", linewidth=0.85, linestyle=(0, (3, 3)))
    ax.set_yticks(y, [SIMILARITY_DISPLAY[m] for m in metrics])
    ax.set_xlabel("相似度变化：PLANE − RAW（95% Bootstrap CI）")
    ax.set_title(f"空间拟合对各类频谱相似度的影响（{reference}）", pad=12, fontweight="semibold")
    clean_axis(ax, grid_axis="x")
    ax.legend(frameon=False, loc="best")
    ax.text(0.01, 0.02, "TRUE理想为正；FALSE理想为负", transform=ax.transAxes, ha="left", va="bottom",
            fontsize=9.2, color=COLOR_NEUTRAL)
    fig.tight_layout()
    return save_figure(fig, output_base, formats)


def build_feature_change_stats(feature_df: pd.DataFrame, reference: str, n_boot: int) -> pd.DataFrame:
    if feature_df.empty:
        return pd.DataFrame()
    keys = ["sample_id", "scene", "label", "reference_group", "feature"]
    raw = feature_df[feature_df["method"] == "raw"][keys + ["absolute_z_difference"]].rename(columns={"absolute_z_difference": "raw"})
    plane = feature_df[feature_df["method"] == "plane"][keys + ["absolute_z_difference"]].rename(columns={"absolute_z_difference": "plane"})
    paired = raw.merge(plane, on=keys, how="inner")
    paired["change"] = paired["plane"] - paired["raw"]
    paired = paired[paired["reference_group"] == reference]
    rows = []
    for feature in FEATURE_DISPLAY:
        for label in ("TRUE_LEAK", "FALSE_LEAK"):
            vals = paired[(paired["feature"] == feature) & (paired["label"] == label)]["change"].dropna().to_numpy(float)
            est, low, high = bootstrap_ci(vals, n_boot=n_boot, seed=RNG_SEED + len(rows) * 19)
            rows.append({"feature": feature, "label": label, "estimate": est, "ci_low": low, "ci_high": high, "n": len(vals)})
    return pd.DataFrame(rows)


def plot_feature_changes(stats: pd.DataFrame, reference: str, output_base: Path, formats: Sequence[str]) -> List[Path]:
    if stats.empty:
        return []
    features = [f for f in FEATURE_DISPLAY if f in stats["feature"].unique()]
    y = np.arange(len(features))[::-1]
    fig, ax = plt.subplots(figsize=(8.7, 5.3))
    for label, offset, color, marker in (("TRUE_LEAK", 0.13, COLOR_TRUE, "o"), ("FALSE_LEAK", -0.13, COLOR_FALSE, "s")):
        g = stats[stats["label"] == label].set_index("feature").reindex(features)
        est = g["estimate"].to_numpy(float)
        lo = g["ci_low"].to_numpy(float)
        hi = g["ci_high"].to_numpy(float)
        ax.errorbar(est, y + offset, xerr=[est - lo, hi - est], fmt=marker, color=color, ecolor=color,
                    capsize=3.0, markersize=6, linewidth=1.3, label=LABEL_DISPLAY[label])
    ax.axvline(0, color="#111827", linewidth=0.85, linestyle=(0, (3, 3)))
    ax.set_yticks(y, [FEATURE_DISPLAY[f] for f in features])
    ax.set_xlabel("到消声室的绝对z差异变化：PLANE − RAW")
    ax.set_title(f"五维特征层面的空间拟合效应（{reference}）", pad=12, fontweight="semibold")
    clean_axis(ax, grid_axis="x")
    ax.legend(frameon=False, loc="best")
    ax.text(0.01, 0.02, "TRUE理想为负（更接近消声室）；FALSE理想为正（更远离消声室）",
            transform=ax.transAxes, ha="left", va="bottom", fontsize=9.1, color=COLOR_NEUTRAL)
    fig.tight_layout()
    return save_figure(fig, output_base, formats)


def plot_window_ecdf(window_df: pd.DataFrame, reference: str, output_base: Path, formats: Sequence[str]) -> List[Path]:
    if window_df.empty:
        return []
    require_columns(window_df, ["scene", "label", "method", "reference_group", "mahalanobis_distance", "window_distance_threshold"], "08_窗口距离明细.csv")
    w = window_df.copy()
    w["reference_group"] = w["reference_group"].astype(str)
    w["method"] = w["method"].astype(str).str.lower()
    w["label"] = w["label"].astype(str).str.upper()
    w["distance_ratio"] = pd.to_numeric(w["mahalanobis_distance"], errors="coerce") / pd.to_numeric(w["window_distance_threshold"], errors="coerce").clip(lower=EPS)
    sub = w[w["reference_group"] == reference].dropna(subset=["distance_ratio"])
    if sub.empty:
        return []
    # 为避免长录音压倒短录音，每个sample等量抽取最多200个窗。
    if "sample_id" in sub.columns:
        sampled = []
        for _, g in sub.groupby(["sample_id", "method", "reference_group"], dropna=False):
            if len(g) > 200:
                sampled.append(g.sample(200, random_state=RNG_SEED))
            else:
                sampled.append(g)
        sub = pd.concat(sampled, ignore_index=True)
    fig, ax = plt.subplots(figsize=(7.4, 5.4))
    for label, method, color, linestyle in [
        ("TRUE_LEAK", "raw", COLOR_TRUE, (0, (4, 2))),
        ("TRUE_LEAK", "plane", COLOR_TRUE, "solid"),
        ("FALSE_LEAK", "raw", COLOR_FALSE, (0, (4, 2))),
        ("FALSE_LEAK", "plane", COLOR_FALSE, "solid"),
    ]:
        vals = sub[(sub["label"] == label) & (sub["method"] == method)]["distance_ratio"].dropna().to_numpy(float)
        if vals.size == 0:
            continue
        vals = np.sort(vals)
        y = np.arange(1, len(vals) + 1) / len(vals)
        ax.plot(vals, y, color=color, linestyle=linestyle, linewidth=1.55,
                label=f"{'TRUE' if label == 'TRUE_LEAK' else 'FALSE'}–{METHOD_DISPLAY[method]}")
    ax.axvline(1.0, color=COLOR_REF, linestyle=(0, (3, 3)), linewidth=1.0, label="消声室参考边界")
    ax.set_xscale("log")
    ax.set_xlabel("窗口相对马氏距离 $D_M/\\tau$（对数坐标）")
    ax.set_ylabel("经验累积分布 ECDF")
    ax.set_title(f"所有100 ms窗口的马氏距离分布（{reference}）", pad=12, fontweight="semibold")
    clean_axis(ax)
    ax.legend(frameon=False, ncol=2, loc="lower right")
    fig.tight_layout()
    return save_figure(fig, output_base, formats)


# ---------------------------------------------------------------------------
# 统计表和说明
# ---------------------------------------------------------------------------

def build_paired_test_table(paired: pd.DataFrame, reference: str, n_boot: int) -> pd.DataFrame:
    rows = []
    metrics = [
        ("median_distance_ratio", "相对马氏距离", "TRUE下降、FALSE上升"),
        ("combined_similarity", "综合频谱相似度", "TRUE上升、FALSE下降"),
        ("cosine_similarity", "余弦相似度", "TRUE上升、FALSE下降"),
        ("spectral_overlap", "频谱重合度", "TRUE上升、FALSE下降"),
        ("pearson_similarity", "Pearson相似度", "TRUE上升、FALSE下降"),
    ]
    scenes = sorted(paired[paired["reference_group"] == reference]["scene"].unique(), key=scene_short)
    for metric, display, ideal in metrics:
        rcol, pcol = f"{metric}_raw", f"{metric}_plane"
        if rcol not in paired.columns or pcol not in paired.columns:
            continue
        for scene_name in scenes + ["总体"]:
            base = paired[paired["reference_group"] == reference]
            if scene_name != "总体":
                base = base[base["scene"] == scene_name]
            for label in ("TRUE_LEAK", "FALSE_LEAK"):
                g = base[base["label"] == label].dropna(subset=[rcol, pcol])
                raw = g[rcol].to_numpy(float)
                plane = g[pcol].to_numpy(float)
                delta = plane - raw
                est, low, high = bootstrap_ci(delta, n_boot=n_boot, seed=RNG_SEED + len(rows) * 23)
                rows.append({
                    "reference_group": reference,
                    "scene": scene_name,
                    "label": label,
                    "metric": metric,
                    "metric_name": display,
                    "n_pairs": len(g),
                    "raw_median": float(np.median(raw)) if len(raw) else np.nan,
                    "plane_median": float(np.median(plane)) if len(plane) else np.nan,
                    "plane_minus_raw_median": est,
                    "ci95_low": low,
                    "ci95_high": high,
                    "wilcoxon_p": paired_wilcoxon_p(raw, plane),
                    "ideal_direction": ideal,
                })
    return pd.DataFrame(rows)


def build_separation_gain_table(long_df: pd.DataFrame, reference: str, n_boot: int) -> pd.DataFrame:
    rows = []
    for metric, orient, display in [
        ("median_distance_ratio", "distance", "相对马氏距离分离"),
        ("combined_similarity", "similarity", "综合频谱相似度分离"),
    ]:
        table = separation_table(long_df, reference, metric, orient, n_boot)
        scenes = list(dict.fromkeys(table["scene"].tolist()))
        for scene in scenes:
            g = table[table["scene"] == scene].set_index("method")
            if not {"raw", "plane"}.issubset(g.index):
                continue
            rows.append({
                "reference_group": reference,
                "scene": scene,
                "metric": metric,
                "metric_name": display,
                "raw_separation": g.loc["raw", "estimate"],
                "raw_ci_low": g.loc["raw", "ci_low"],
                "raw_ci_high": g.loc["raw", "ci_high"],
                "plane_separation": g.loc["plane", "estimate"],
                "plane_ci_low": g.loc["plane", "ci_low"],
                "plane_ci_high": g.loc["plane", "ci_high"],
                "plane_minus_raw_separation": g.loc["plane", "estimate"] - g.loc["raw", "estimate"],
                "interpretation": "分离度越大越好；PLANE-RAW>0表示空间拟合扩大TRUE/FALSE差异",
            })
    return pd.DataFrame(rows)


def write_explanation(output_dir: Path, records: List[PlotRecord], font_name: str, reference: str) -> None:
    lines = [
        "# v22 空间拟合学术验证图：逐图说明",
        "",
        f"默认主参考模型：**{reference}**。绘图字体：{font_name}。",
        "",
        "## 为什么新版优先使用相对马氏距离",
        "",
        "绝对马氏距离 $D_M$ 只能在同一个消声室参考模型内比较。0.1 mm、0.5 mm、ALL_LEAKS 的协方差和距离阈值不同，因此不应把三者的绝对距离直接放在同一纵轴上。新版主图使用：",
        "",
        "$$D_{rel}=D_M/\\tau$$",
        "",
        "其中 $\\tau$ 是对应消声室模型的窗口参考距离阈值。$D_{rel}=1$ 表示处于参考边界，越小表示越接近该消声室模型。绝对 $D_M$ 仍在补充图中按参考模型单独绘制。",
        "",
        "## 判断PLANE是否有效的核心逻辑",
        "",
        "- TRUE：PLANE后马氏距离应下降、频谱相似度应上升。",
        "- FALSE：PLANE后马氏距离应上升、频谱相似度应下降。",
        "- 只看到TRUE和FALSE一起靠近消声室，不能证明PLANE有效。",
        "- 最核心的统计量不是单组均值，而是TRUE/FALSE分离度是否扩大。",
        "",
    ]
    for r in records:
        lines.extend([
            f"## {r.number}　{r.filename}",
            "",
            f"**回答的问题：** {r.question}",
            "",
            f"**指标：** {r.metric}",
            "",
            f"**理想结果：** {r.ideal}",
            "",
            f"**如何解释：** {r.interpretation}",
            "",
            f"**数据来源：** `{r.source}`",
            "",
        ])
    text = "\n".join(lines)
    (output_dir / "00_逐图说明.md").write_text(text, encoding="utf-8")
    (output_dir / "00_逐图说明.txt").write_text(text.replace("**", "").replace("# ", "").replace("## ", ""), encoding="utf-8")


def write_run_summary(
    output_dir: Path,
    long_df: pd.DataFrame,
    paired_df: pd.DataFrame,
    reference: str,
    paired_tests: pd.DataFrame,
    separation_gains: pd.DataFrame,
) -> None:
    lines = [
        "v22 学术验证绘图运行摘要",
        "=" * 72,
        f"主参考模型：{reference}",
        f"场景：{', '.join(scene_short(x) for x in sorted(long_df.scene.unique(), key=scene_short))}",
        f"样本-方法-参考组记录数：{len(long_df)}",
        f"RAW/PLANE成功配对记录数：{len(paired_df)}",
        "",
        "最重要的两类分离结果：",
    ]
    if not separation_gains.empty:
        overall = separation_gains[separation_gains["scene"] == "总体"]
        for _, row in overall.iterrows():
            lines.append(
                f"- {row['metric_name']}：RAW={row['raw_separation']:.6g}，"
                f"PLANE={row['plane_separation']:.6g}，增益={row['plane_minus_raw_separation']:.6g}。"
            )
    lines.extend([
        "",
        "解释规则：",
        "1. 相对马氏距离分离 = median(FALSE) - median(TRUE)，越大越好。",
        "2. 综合相似度分离 = median(TRUE) - median(FALSE)，越大越好。",
        "3. PLANE分离 - RAW分离 > 0，才说明空间拟合扩大了真假差异。",
        "4. 还要看各场景是否方向一致，不能只看总体平均。",
        "5. 置信区间跨0时，改善证据仍不稳定。",
    ])
    (output_dir / "00_运行摘要.txt").write_text("\n".join(lines), encoding="utf-8")


# ---------------------------------------------------------------------------
# 主流程
# ---------------------------------------------------------------------------

def run(args: argparse.Namespace) -> Path:
    font_name = configure_style()
    formats = tuple(x.strip().lower() for x in args.formats.split(",") if x.strip())
    allowed_formats = {"png", "pdf", "svg"}
    if not formats or not set(formats).issubset(allowed_formats):
        raise ValueError("--formats仅支持png,pdf,svg，例如 --formats png,pdf,svg")

    if args.anechoic_dir:
        anechoic_dir = find_anechoic_dir(Path(args.anechoic_dir))
    elif args.root:
        anechoic_dir = find_anechoic_dir(Path(args.root))
    else:
        raise ValueError("必须提供--root或--anechoic-dir")

    output_dir = Path(args.output).expanduser().resolve() if args.output else anechoic_dir.parent / "v22_学术验证图"
    output_dir.mkdir(parents=True, exist_ok=True)
    main_dir = output_dir / "01_报告主图"
    supp_dir = output_dir / "02_补充图"
    stat_dir = output_dir / "03_统计表"
    for p in (main_dir, supp_dir, stat_dir):
        p.mkdir(parents=True, exist_ok=True)

    long_df = read_csv_safe(anechoic_dir / "01_每个样本_距离与相似度_long.csv")
    paired_path = anechoic_dir / "04_同一样本_RAW变PLANE后的变化.csv"
    paired_df = read_csv_safe(paired_path) if paired_path.exists() else pd.DataFrame()
    feature_path = anechoic_dir / "05_每个特征与消声室差异.csv"
    feature_df = read_csv_safe(feature_path) if feature_path.exists() else pd.DataFrame()
    window_path = anechoic_dir / "08_窗口距离明细.csv"
    window_df = read_csv_safe(window_path) if window_path.exists() else pd.DataFrame()

    long_df, paired_df, feature_df = validate_and_prepare(long_df, paired_df, feature_df)
    references = list(dict.fromkeys(long_df["reference_group"].astype(str).tolist()))
    reference = args.reference
    if reference not in references:
        if "ALL_LEAKS" in references:
            warnings.warn(f"指定参考组{reference}不存在，自动使用ALL_LEAKS")
            reference = "ALL_LEAKS"
        else:
            reference = references[0]
            warnings.warn(f"指定参考组不存在，自动使用{reference}")

    records: List[PlotRecord] = []

    # Fig. 1：最直观的样本分布。
    base = main_dir / "Fig01_相对马氏距离分布_TRUE_FALSE_RAW_PLANE"
    paths = plot_metric_distribution(
        long_df, "median_distance_ratio", "相对马氏距离 $D_M/\\tau$",
        f"RAW与PLANE的相对马氏距离分布（{reference}）", base, formats, reference,
        "理想方向：TRUE的PLANE低于RAW；FALSE的PLANE高于RAW；紫色虚线为消声室参考边界。", 1.0,
    )
    if paths:
        records.append(PlotRecord("Fig. 1", paths[0].stem, "PLANE后TRUE是否更接近消声室、FALSE是否更远离消声室？", "每个样本的中位相对马氏距离 $D_M/\\tau$", "TRUE下降，FALSE上升。", "箱体表示四分位区间，白色点为单样本，黑色菱形为中位数。三场景应分别检查，不能只看总体。", "01_每个样本_距离与相似度_long.csv"))

    # Fig. 2a/2b：配对变化，TRUE/FALSE分开以减少认知负担。
    for label, suffix, ideal in [
        ("TRUE_LEAK", "TRUE", "理想：配对线总体向下（PLANE距离更小）"),
        ("FALSE_LEAK", "FALSE", "理想：配对线总体向上（PLANE距离更大）"),
    ]:
        base = main_dir / f"Fig02_{suffix}_相对马氏距离配对变化"
        paths = plot_paired_change(
            paired_df, "median_distance_ratio", "相对马氏距离 $D_M/\\tau$",
            f"{suffix}样本：RAW到PLANE的相对马氏距离配对变化（{reference}）",
            base, formats, reference, label, ideal,
        )
        if paths:
            records.append(PlotRecord(f"Fig. 2{'a' if label=='TRUE_LEAK' else 'b'}", paths[0].stem, f"同一个{suffix}样本经过PLANE后马氏距离怎样变化？", "同一样本RAW→PLANE配对变化，中位数及Bootstrap 95% CI", ideal, "灰线连接同一样本；若只是个别样本改善而总体不变，会在这张图中直接暴露。p值来自配对Wilcoxon检验。", "04_同一样本_RAW变PLANE后的变化.csv"))

    # Fig. 3：最关键的距离分离森林图。
    distance_sep = separation_table(long_df, reference, "median_distance_ratio", "distance", args.bootstrap)
    distance_sep.to_csv(stat_dir / "01_相对马氏距离分离_Bootstrap.csv", index=False, encoding="utf-8-sig")
    base = main_dir / "Fig03_相对马氏距离_TRUE_FALSE分离度"
    paths = plot_separation_forest(
        distance_sep,
        "距离分离度：median(FALSE) − median(TRUE)",
        f"TRUE/FALSE相对马氏距离分离度（{reference}）",
        base, formats,
        "越大越好；95% CI完全高于0表示TRUE比FALSE稳定地更接近消声室。",
    )
    if paths:
        records.append(PlotRecord("Fig. 3", paths[0].stem, "PLANE是否真正扩大了TRUE与FALSE的马氏距离差异？", "$S_D=median(D_{FALSE})-median(D_{TRUE})$，带Bootstrap 95% CI", "PLANE点位于RAW右侧，并且各场景分离度大于0。", "这是验证空间拟合优劣的主图。TRUE自己变近并不够，必须同时让TRUE/FALSE分离度扩大。", "01_每个样本_距离与相似度_long.csv"))

    # Fig. 4：方向性象限。
    base = main_dir / "Fig04_空间拟合方向性象限"
    paths = plot_change_quadrant(paired_df, reference, base, formats)
    if paths:
        records.append(PlotRecord("Fig. 4", paths[0].stem, "每个场景中，PLANE是否同时做到TRUE更近、FALSE更远？", "横轴TRUE的距离变化；纵轴FALSE的距离变化", "点落在左上象限。", "左上是唯一明确支持PLANE有效的象限；若落在左下，说明TRUE和FALSE都被拉近，不能证明有效。", "04_同一样本_RAW变PLANE后的变化.csv"))

    # Fig. 5：综合频谱相似度分布。
    base = main_dir / "Fig05_综合频谱相似度分布_TRUE_FALSE_RAW_PLANE"
    paths = plot_metric_distribution(
        long_df, "combined_similarity", "综合频谱相似度（0–1）",
        f"RAW与PLANE的综合频谱相似度分布（{reference}）", base, formats, reference,
        "理想方向：TRUE的PLANE高于RAW；FALSE的PLANE低于RAW。", None,
    )
    if paths:
        records.append(PlotRecord("Fig. 5", paths[0].stem, "PLANE是否让TRUE频谱更像消声室，同时让FALSE更不像？", "余弦相似度、频谱重合度与Pearson相似度的综合值", "TRUE上升，FALSE下降。", "相似度只是频谱形状证据，必须与马氏距离图共同解释。", "01_每个样本_距离与相似度_long.csv"))

    # Fig. 6：相似度分离森林图。
    sim_sep = separation_table(long_df, reference, "combined_similarity", "similarity", args.bootstrap)
    sim_sep.to_csv(stat_dir / "02_综合频谱相似度分离_Bootstrap.csv", index=False, encoding="utf-8-sig")
    base = main_dir / "Fig06_综合频谱相似度_TRUE_FALSE分离度"
    paths = plot_separation_forest(
        sim_sep,
        "相似度分离度：median(TRUE) − median(FALSE)",
        f"TRUE/FALSE综合频谱相似度分离度（{reference}）",
        base, formats,
        "越大越好；PLANE位于RAW右侧表示空间拟合扩大相似度差异。",
    )
    if paths:
        records.append(PlotRecord("Fig. 6", paths[0].stem, "PLANE是否扩大了TRUE与FALSE的频谱相似度差异？", "$S_S=median(S_{TRUE})-median(S_{FALSE})$，带Bootstrap 95% CI", "PLANE大于RAW，且尽量在0右侧。", "这张图与Fig. 3形成双重验证：一个基于五维马氏距离，一个基于频谱形状相似度。", "01_每个样本_距离与相似度_long.csv"))

    # Fig. 7：距离与相似度交叉验证。
    base = main_dir / "Fig07_马氏距离与相似度联合变化"
    paths = plot_joint_change(paired_df, reference, base, formats)
    if paths:
        records.append(PlotRecord("Fig. 7", paths[0].stem, "同一样本的马氏距离变化和频谱相似度变化是否互相支持？", "横轴为相对马氏距离变化，纵轴为综合频谱相似度变化", "TRUE位于左上；FALSE位于右下。", "如果两个指标方向冲突，点会落入其他象限，说明不能简单宣称该样本得到改善。大点及字母为场景中位数。", "04_同一样本_RAW变PLANE后的变化.csv"))

    # Fig. 8：相似度组成。
    sim_component_stats = build_similarity_component_stats(paired_df, reference, args.bootstrap)
    sim_component_stats.to_csv(stat_dir / "03_各类相似度变化_Bootstrap.csv", index=False, encoding="utf-8-sig")
    base = main_dir / "Fig08_各类频谱相似度变化"
    paths = plot_similarity_components(sim_component_stats, reference, base, formats)
    if paths:
        records.append(PlotRecord("Fig. 8", paths[0].stem, "综合相似度的改变由余弦、重合度还是Pearson哪一部分贡献？", "各相似度的PLANE−RAW中位变化及95% CI", "TRUE为正；FALSE为负。", "若只有某一个相似度改善、其他指标不支持，应降低结论强度。", "04_同一样本_RAW变PLANE后的变化.csv"))

    # Fig. 9：五维特征解释。
    feature_stats = build_feature_change_stats(feature_df, reference, args.bootstrap)
    if not feature_stats.empty:
        feature_stats.to_csv(stat_dir / "04_五维特征绝对z差异变化_Bootstrap.csv", index=False, encoding="utf-8-sig")
        base = main_dir / "Fig09_五维特征到消声室差异变化"
        paths = plot_feature_changes(feature_stats, reference, base, formats)
        if paths:
            records.append(PlotRecord("Fig. 9", paths[0].stem, "PLANE究竟改变了哪些泄漏特征？", "到消声室参考均值的绝对z差异：PLANE−RAW", "TRUE为负，FALSE为正。", "这张图解释马氏距离变化的来源，可判断PLANE是改善频谱形态、时间稳定性，还是只改变SNR。", "05_每个特征与消声室差异.csv"))

    # Fig. 10：窗口级ECDF（可选）。
    if not window_df.empty:
        base = supp_dir / "Fig10_窗口级相对马氏距离_ECDF"
        paths = plot_window_ecdf(window_df, reference, base, formats)
        if paths:
            records.append(PlotRecord("Fig. 10", paths[0].stem, "文件级中位数是否掩盖了100 ms窗口内的不稳定？", "所有窗口的相对马氏距离ECDF", "TRUE–PLANE曲线应更靠左；FALSE–PLANE曲线应更靠右。", "该图展示完整时间窗分布，适合放在附录。曲线在x=1左侧的高度等于进入消声室参考范围的窗口比例。", "08_窗口距离明细.csv"))

    # 补充：每个参考组单独画绝对马氏距离，明确不跨组共轴。
    for ref in references:
        ref_dir = supp_dir / f"参考组_{ref}"
        ref_dir.mkdir(parents=True, exist_ok=True)
        plot_metric_distribution(
            long_df, "median_distance", "绝对马氏距离 $D_M$",
            f"绝对马氏距离分布（参考组：{ref}）",
            ref_dir / f"S01_{ref}_绝对马氏距离分布", formats, ref,
            "绝对距离只在当前参考模型内部解释，不能与其他参考组直接比较。", None,
        )
        if ref != reference:
            plot_metric_distribution(
                long_df, "median_distance_ratio", "相对马氏距离 $D_M/\\tau$",
                f"相对马氏距离分布（参考组：{ref}）",
                ref_dir / f"S02_{ref}_相对马氏距离分布", formats, ref,
                "TRUE理想下降，FALSE理想上升；虚线为消声室参考边界。", 1.0,
            )

    paired_tests = build_paired_test_table(paired_df, reference, args.bootstrap)
    paired_tests.to_csv(stat_dir / "05_RAW_PLANE配对统计检验.csv", index=False, encoding="utf-8-sig")
    separation_gains = build_separation_gain_table(long_df, reference, args.bootstrap)
    separation_gains.to_csv(stat_dir / "06_TRUE_FALSE分离度汇总.csv", index=False, encoding="utf-8-sig")

    # 索引。
    pd.DataFrame([r.__dict__ for r in records]).to_csv(output_dir / "00_图表索引.csv", index=False, encoding="utf-8-sig")
    write_explanation(output_dir, records, font_name, reference)
    write_run_summary(output_dir, long_df, paired_df, reference, paired_tests, separation_gains)

    print("\n绘图完成")
    print("消声室结果目录:", anechoic_dir)
    print("输出目录:", output_dir)
    print("主参考模型:", reference)
    print("主图数量:", len([r for r in records if r.number != "Fig. 10"]))
    print("请先看:", output_dir / "00_运行摘要.txt")
    print("逐图说明:", output_dir / "00_逐图说明.md")
    return output_dir


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="v22 RAW/PLANE与消声室结果的学术化验证绘图")
    parser.add_argument("--root", type=str, default=None, help="v22总输出目录；程序会自动寻找RAW_PLANE_vs_anechoic")
    parser.add_argument("--anechoic-dir", type=str, default=None, help="直接指定RAW_PLANE_vs_anechoic目录")
    parser.add_argument("--output", type=str, default=None, help="输出目录；默认在v22总输出目录下生成v22_学术验证图")
    parser.add_argument("--reference", type=str, default="ALL_LEAKS", help="报告主参考模型，默认ALL_LEAKS")
    parser.add_argument("--formats", type=str, default="png,pdf,svg", help="输出格式，默认png,pdf,svg")
    parser.add_argument("--bootstrap", type=int, default=5000, help="Bootstrap重复次数，默认5000")
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        run(args)
        return 0
    except Exception as exc:
        print(f"\n运行失败：{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
