@echo off
chcp 65001 >nul
set /p ROOT=请粘贴v22总输出目录（里面应有RAW_PLANE_vs_anechoic）：
python v22_academic_validation_plots.py --root "%ROOT%" --reference ALL_LEAKS --formats png,pdf,svg
if errorlevel 1 (
  echo.
  echo 运行失败，请查看上方报错。
  pause
  exit /b 1
)
echo.
echo 绘图完成。请查看v22总输出目录下的“v22_学术验证图”。
pause
